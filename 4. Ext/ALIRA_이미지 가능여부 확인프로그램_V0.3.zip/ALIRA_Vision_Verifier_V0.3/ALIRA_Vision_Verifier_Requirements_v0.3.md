# ALIRA Vision Verifier v0.1 — Requirements

- VVF-001: Requirement Studio와 독립 실행되어야 한다.
- VVF-002: 매 Run마다 이미지 안에만 존재하는 랜덤 Secret Code를 생성해야 한다.
- VVF-003: 정답 파일은 모든 ALIRA 호출이 끝난 후 생성해야 한다.
- VVF-004: 이미지 없는 Control과 이미지 포함 ALIRA CLI Test를 분리 실행해야 한다.
- VVF-005: 주 판정은 ALIRA CLI/EncodeImage 경로 결과를 기준으로 해야 한다.
- VVF-006: Direct API image_url Test는 보조 원인진단으로 제공해야 한다.
- VVF-007: Fixture/Prompt/Raw stdout·stderr/Response/Verdict/Report를 한 Run 폴더에 보존해야 한다.
- VVF-008: 실제 License/API Key를 배포물에 포함하거나 평문 Config에 저장하지 않아야 한다.
- VVF-009: PASS는 랜덤 Secret Code 일치와 최소 5/6 Field 일치를 모두 요구해야 한다.
- VVF-010: 실행 환경에서 실제 ALIRA/Qwen 연결 검증 전에는 Runtime PASS를 문서에서 주장하지 않아야 한다.


## V0.2 Runtime bootstrap
- RUN_VISION_VERIFIER.bat shall create/use a local `.venv` and install required GUI dependencies when missing.
- Direct IDLE F5 execution is not the supported primary launch path.


## V0.3 Headless Vision permission requirements
- Vision CLI test shall add `--no-permission-enabled` only for the isolated randomized fixture run.
- Control/no-image test shall not enable tool permission bypass.
- Direct API diagnostic shall be disabled by default and shall not affect the primary CLI verdict.
- Tool permission refusal shall be reported as `BLOCKED_PERMISSION`, not as a Vision capability FAIL.
- Requirement Studio production code shall not inherit the verifier-only `--no-permission-enabled` behavior.
