﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "VENV_DIR=%~dp0.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "VENV_PYW=%VENV_DIR%\Scripts\pythonw.exe"
set "BASE_PY="

echo ============================================================
echo  ALIRA Vision Verifier v0.3
echo  Local Python environment bootstrap
echo ============================================================
echo.

if exist "%VENV_PY%" goto CHECK_DEPS

rem Prefer the Windows Python launcher if available.
where py >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%I in ('py -3.14 -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%I"
    if not defined BASE_PY (
        for /f "delims=" %%I in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%I"
    )
)

if not defined BASE_PY (
    where python >nul 2>nul
    if not errorlevel 1 (
        for /f "delims=" %%I in ('python -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%I"
    )
)

if not defined BASE_PY (
    echo [ERROR] Python 3 was not found.
    echo Install Python 3.10-3.14 and run this file again.
    pause
    exit /b 1
)

echo [1/3] Creating isolated environment:
echo       %VENV_DIR%
"%BASE_PY%" -m venv "%VENV_DIR%"
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to create .venv.
    echo Base Python: %BASE_PY%
    pause
    exit /b 1
)

:CHECK_DEPS
echo [2/3] Checking GUI dependencies...
"%VENV_PY%" -c "import PySide6, requests" >nul 2>nul
if errorlevel 1 (
    echo       PySide6 / requests not found. Installing into local .venv...
    "%VENV_PY%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
    if errorlevel 1 (
        echo.
        echo [ERROR] Dependency installation failed.
        echo.
        echo If your company network blocks PyPI, install these packages using
        echo your internal Python package mirror and run this launcher again:
        echo   PySide6^>=6.10.2
        echo   requests^>=2.31
        echo.
        echo Debug command:
        echo   "%VENV_PY%" -m pip install -r "%~dp0requirements.txt"
        pause
        exit /b 1
    )
)

echo [3/3] Starting ALIRA Vision Verifier...
if not exist "%VENV_PYW%" (
    echo [ERROR] pythonw.exe was not found inside .venv.
    pause
    exit /b 1
)

start "" "%VENV_PYW%" "%~dp0ALIRA_Vision_Verifier_V0.3.pyw"
exit /b 0
