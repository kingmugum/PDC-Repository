발급받은 ALIRA 라이선스 (*.lic)를 이 폴더에 넣을 수 있습니다.
실제 라이선스 파일은 배포 ZIP에 포함하지 않습니다.
Verifier는 이 폴더의 최신 *.lic를 우선 사용하고, 없으면 ALIRA 기본 설치 위치의 license.lic를 확인합니다.
