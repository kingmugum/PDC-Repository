# ALIRA Vision Verifier v0.3

## 목적
Requirement Studio와 독립적으로 **ALIRA가 실제 그림 내용을 읽는지 증거를 남기는 전용 검증 도구**입니다.
Requirement Studio V0.39 패키지에는 포함되지 않으며, 이 폴더를 삭제해도 Requirement Studio에는 영향이 없습니다.

## 무엇을 검증하나
1. **Control (이미지 없음)**: 랜덤 Fixture를 주지 않은 상태에서 같은 필드를 물어봅니다.
2. **ALIRA CLI Vision (주 판정)**: ALIRA `general_agent` headless 실행에 Fixture의 절대경로를 전달하고 `EncodeImage` 또는 동등 이미지 도구로 읽도록 요청합니다.
3. **Direct API Vision (보조 진단)**: 동일 그림을 OpenAI-compatible `image_url` 형식으로 현재 Qwen API에 직접 전달합니다.

**최종 주 판정은 ALIRA CLI Vision**입니다. Direct API는 Model/Gateway가 멀티모달 Payload를 받는지 원인 분리에 쓰는 보조 증거입니다.

## 강한 증거가 되는 이유
매 실행마다 그림 안에만 존재하는 랜덤 코드 `VSN-xxxxxx`를 새로 생성합니다. Prompt에는 정답이 포함되지 않습니다. 따라서 ALIRA가 랜덤 코드를 정확히 답하고 색상/방향/시간/별 위치까지 맞히면 실제 이미지 내용에 접근했다는 강한 근거가 됩니다.

## 실행
- **권장:** `RUN_VISION_VERIFIER.bat` 더블클릭
- V0.2 Launcher는 프로그램 폴더 안에 `.venv`를 만들고 `PySide6`, `requests`가 없으면 자동 설치한 뒤 실행합니다.
- 전역 Python/IDLE 환경을 변경하지 않고 Verifier 전용 환경을 사용합니다.
- 오류를 콘솔에서 보고 싶으면 `RUN_VISION_VERIFIER_DEBUG.bat`를 사용합니다.
- `.pyw`를 IDLE에서 직접 F5 실행하면 IDLE이 사용하는 Python에 PySide6가 없을 경우 `ModuleNotFoundError: No module named 'PySide6'`가 발생할 수 있습니다.
- 필요하면 `alira_license` 폴더에 `*.lic` 배치
- Model/API Base 확인 후 **증빙 테스트 실행** 클릭

## 증빙 산출물
`output/run_YYYYMMDD_HHMMSS/`
- `fixture.png` — 실제 입력 그림
- `prompt.txt` — 정답이 없는 실제 Prompt
- `control_stdout.txt`, `control_stderr.txt`
- `cli_command.json`, `cli_stdout.txt`, `cli_stderr.txt`, `cli_response.txt`
- `direct_api_response.txt`, `direct_api_raw_body.txt` (Direct API 실행 가능 시)
- `expected_after_test.json` — **모든 ALIRA 호출이 끝난 뒤에만 생성**되는 정답
- `verdict.json` — 필드별 일치 판정
- `verdict_summary.md`
- `report.html` — 사람이 보기 쉬운 증빙 보고서

## 판정
- `PASS`: 랜덤 code가 일치하고 총 6개 중 5개 이상 일치
- `PARTIAL`: 랜덤 code가 일치하고 3개 이상 일치
- `FAIL`: 랜덤 code 불일치 또는 이미지 정보 회수가 충분하지 않음

`expected_after_test.json`은 ALIRA 실행 후 생성되므로 ALIRA Agent가 정답 파일을 미리 읽어 통과할 수 없습니다.

## 결과 해석
- **CLI PASS / Direct API PASS**: ALIRA Agent 경로와 Qwen/Gateway 모두 이미지 처리 성공
- **CLI FAIL / Direct API PASS**: Model/Gateway는 Vision 가능하지만 ALIRA Agent/EncodeImage 경로 문제 가능성
- **CLI FAIL / Direct API FAIL**: 현재 Model/API가 Vision Payload를 처리하지 못하거나 연결/모델이 Text-only일 가능성
- **Control에서 랜덤 code까지 맞음**: 테스트 격리 문제가 있으므로 해당 Run은 증거로 사용하지 말고 재실행

## 안전/분리 원칙
- Requirement Studio 코드를 import하지 않습니다.
- 실제 라이선스를 패키지에 포함하지 않습니다.
- API Key는 config.json에 저장하지 않습니다. Direct API 인증이 필요한 경우 환경변수 `ALIRA_API_KEY`만 사용합니다.


## V0.2 변경
- Python 3.14 환경에서 `PySide6` 미설치로 `.pyw` 직접 실행이 실패하던 사용성 문제를 보완했습니다.
- `RUN_VISION_VERIFIER.bat`가 로컬 `.venv`를 자동 생성하고 `requirements.txt`를 설치합니다.
- `requirements.txt`의 PySide6 최소 버전을 Python 3.14 지원 범위인 `6.10.2` 이상으로 올렸습니다.
- `RUN_VISION_VERIFIER_DEBUG.bat`를 추가했습니다.


## V0.3 변경 — Headless Vision Tool 권한 보완

V0.2 실제 사용자 테스트에서 ALIRA CLI가 다음 취지의 응답을 반환했습니다.

- `The image cannot be inspected due to a permission error.`

이 결과는 Vision 능력 자체의 FAIL이 아니라, `-p` Headless 실행에서 `EncodeImage`/동등 이미지 도구의 권한 승인을 할 수 없어 테스트가 막힌 상태입니다.

V0.3은 Vision Test에만 다음 원칙을 적용합니다.

1. Control Test
   - 이미지 없음
   - Tool 권한 해제 옵션을 사용하지 않음
   - UNKNOWN 응답이 정상

2. ALIRA CLI Vision Test — **주 판정**
   - Run별 격리 작업 폴더를 `--cwd`로 사용
   - `--no-permission-enabled`를 추가하여 Headless에서 Image Tool이 interactive permission prompt 없이 실행될 수 있게 함
   - Fixture의 랜덤 6개 항목을 비교
   - PASS/PARTIAL/FAIL을 ALIRA Vision의 최종 판정으로 사용

3. Direct API — **참고 진단 / 기본 Off**
   - GUI의 `Direct API도 추가 확인`을 체크한 경우에만 실행
   - 404 등 Direct API Route 문제는 ALIRA CLI Vision 결과를 FAIL로 만들지 않음
   - Qwen Gateway/Model 경로를 별도로 볼 때만 사용

4. Permission 오류 분리
   - 응답에 permission error/denied 계열 문구가 남으면 단순 FAIL이 아닌 `BLOCKED_PERMISSION`으로 표시
   - 즉, Vision 성능 실패와 Test 실행 자체가 막힌 경우를 구분

### 보안 경계

`--no-permission-enabled`는 **ALIRA Vision Verifier의 랜덤 Fixture 시험에만** 사용합니다.
Requirement Studio 본체에는 이 옵션을 추가하지 않습니다.
Verifier는 Run별 작업 폴더를 `--cwd`로 넘기고, 예상 정답 파일은 ALIRA 호출이 끝난 뒤에 생성합니다.
