﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Local .venv has not been prepared yet.
    echo Run RUN_VISION_VERIFIER.bat once first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" "ALIRA_Vision_Verifier_V0.3.pyw"
echo.
echo Process exit code: %errorlevel%
pause
