from __future__ import annotations

import base64
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QRectF, QPointF
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QImage, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QVBoxLayout, QWidget, QCheckBox
)
from PySide6.QtCore import QUrl

try:
    import requests
except Exception:
    requests = None

APP_TITLE = "ALIRA Vision Verifier"
APP_VERSION = "v0.3"
DEFAULT_MODEL = "hosted_vllm/Qwen/Qwen3.6-27B"
DEFAULT_API_BASE = "http://10.10.10.200:19640/v1"
FIELDS = [
    "code", "arrow_color", "arrow_direction", "timeout_seconds",
    "star_position_relative_to_state_b", "mode",
]


@dataclass
class FixtureFacts:
    code: str
    arrow_color: str
    arrow_direction: str
    timeout_seconds: str
    star_position_relative_to_state_b: str
    mode: str = "VISION_ONLY"


def app_root() -> Path:
    return Path(__file__).resolve().parent


def default_cli_path() -> Path:
    local = os.environ.get("LOCALAPPDATA", "")
    p = Path(local) / "Programs" / "alira" / "alira.exe"
    if p.is_file():
        return p
    found = shutil.which("alira")
    return Path(found) if found else p


def license_dir() -> Path:
    p = app_root() / "alira_license"
    p.mkdir(parents=True, exist_ok=True)
    return p


def find_license() -> Path | None:
    candidates = sorted(license_dir().glob("*.lic"), key=lambda x: x.stat().st_mtime, reverse=True)
    if candidates:
        return candidates[0]
    installed = default_cli_path().with_name("license.lic")
    return installed if installed.is_file() else None


def load_config() -> dict:
    p = app_root() / "config.json"
    default = {"model": DEFAULT_MODEL, "api_base": DEFAULT_API_BASE, "timeout_seconds": 180, "direct_api_enabled": False}
    if not p.is_file():
        return default
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            default.update({k: v for k, v in data.items() if k in default})
    except Exception:
        pass
    return default


def save_config(model: str, api_base: str, timeout_seconds: int, direct_api_enabled: bool = False) -> None:
    data = {"model": model.strip(), "api_base": api_base.strip(), "timeout_seconds": int(timeout_seconds), "direct_api_enabled": bool(direct_api_enabled)}
    (app_root() / "config.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def new_facts() -> FixtureFacts:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    code = "VSN-" + "".join(random.choice(alphabet) for _ in range(6))
    color = random.choice(["GREEN", "MAGENTA", "ORANGE", "BLUE"])
    direction = random.choice(["STATE_A_TO_STATE_B", "STATE_B_TO_STATE_A"])
    timeout = random.choice(["1.7", "2.9", "3.7", "4.3", "6.1"])
    star = random.choice(["LEFT", "RIGHT", "ABOVE", "BELOW"])
    return FixtureFacts(code, color, direction, timeout, star)


def draw_star(painter: QPainter, center: QPointF, radius: float = 18.0) -> None:
    import math
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        r = radius if i % 2 == 0 else radius * 0.42
        pts.append(QPointF(center.x() + r * math.cos(a), center.y() + r * math.sin(a)))
    painter.setBrush(QColor("#F6C344"))
    painter.setPen(QPen(QColor("#D49A00"), 2))
    painter.drawPolygon(QPolygonF(pts))


def generate_fixture(path: Path, facts: FixtureFacts) -> None:
    img = QImage(1000, 620, QImage.Format.Format_ARGB32)
    img.fill(QColor("#F7FAFC"))
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    p.setPen(QColor("#0F172A"))
    p.setFont(QFont("Arial", 28, QFont.Weight.Bold))
    p.drawText(QRectF(0, 30, 1000, 50), Qt.AlignmentFlag.AlignCenter, "ALIRA VISION EVIDENCE FIXTURE")
    p.setFont(QFont("Consolas", 26, QFont.Weight.Bold))
    p.drawText(QRectF(0, 88, 1000, 45), Qt.AlignmentFlag.AlignCenter, facts.code)

    a = QRectF(160, 235, 230, 120)
    b = QRectF(610, 235, 230, 120)
    for rect, label in [(a, "STATE_A"), (b, "STATE_B")]:
        p.setBrush(QColor("#FFFFFF"))
        p.setPen(QPen(QColor("#2B6CB0"), 4))
        p.drawRoundedRect(rect, 18, 18)
        p.setPen(QColor("#102A43"))
        p.setFont(QFont("Arial", 28, QFont.Weight.Bold))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, label)

    palette = {
        "GREEN": QColor("#16A34A"), "MAGENTA": QColor("#D946EF"),
        "ORANGE": QColor("#F97316"), "BLUE": QColor("#2563EB"),
    }
    arrow_color = palette[facts.arrow_color]
    if facts.arrow_direction == "STATE_A_TO_STATE_B":
        start, end = QPointF(a.right() + 25, a.center().y()), QPointF(b.left() - 25, b.center().y())
    else:
        start, end = QPointF(b.left() - 25, b.center().y()), QPointF(a.right() + 25, a.center().y())
    p.setPen(QPen(arrow_color, 12, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawLine(start, end)
    import math
    angle = math.atan2(end.y() - start.y(), end.x() - start.x())
    head_len = 30
    pts = [end,
           QPointF(end.x() - head_len * math.cos(angle - 0.55), end.y() - head_len * math.sin(angle - 0.55)),
           QPointF(end.x() - head_len * math.cos(angle + 0.55), end.y() - head_len * math.sin(angle + 0.55))]
    p.setBrush(arrow_color)
    p.setPen(QPen(arrow_color, 2))
    p.drawPolygon(QPolygonF(pts))

    offset = {"LEFT": (-70, 0), "RIGHT": (70, 0), "ABOVE": (0, -85), "BELOW": (0, 85)}[facts.star_position_relative_to_state_b]
    draw_star(p, QPointF(b.center().x() + offset[0], b.center().y() + offset[1]), 21)

    p.setPen(QColor("#334155"))
    p.setFont(QFont("Consolas", 24, QFont.Weight.Bold))
    p.drawText(QRectF(80, 450, 840, 40), Qt.AlignmentFlag.AlignCenter, f"TIMEOUT = {facts.timeout_seconds} s")
    p.setFont(QFont("Consolas", 23, QFont.Weight.Bold))
    p.drawText(QRectF(80, 505, 840, 40), Qt.AlignmentFlag.AlignCenter, f"MODE = {facts.mode}")
    p.setFont(QFont("Arial", 13))
    p.setPen(QColor("#64748B"))
    p.drawText(QRectF(0, 565, 1000, 30), Qt.AlignmentFlag.AlignCenter, "The answers are intentionally present only inside this image.")
    p.end()
    if not img.save(str(path), "PNG"):
        raise RuntimeError("Fixture PNG 저장에 실패했습니다.")


def prompt_for_image(path: Path) -> str:
    return f"""This is a controlled vision verification test.\nUse ALIRA's image-reading capability (EncodeImage or equivalent) to inspect ONLY this image file:\n{path}\n\nDo not infer from filenames, prior knowledge, or other files. Return ONLY one JSON object, no Markdown, with exactly these keys:\ncode\narrow_color\narrow_direction\ntimeout_seconds\nstar_position_relative_to_state_b\nmode\n\nAllowed arrow_direction values: STATE_A_TO_STATE_B or STATE_B_TO_STATE_A.\nAllowed star position values: LEFT, RIGHT, ABOVE, BELOW.\nUse uppercase English for color, direction, star position, and mode. timeout_seconds must contain only the numeric value as a string.\nIf the image cannot be inspected, set every value to UNKNOWN."""


def control_prompt() -> str:
    return """CONTROL TEST: You are NOT given an image and must NOT use files or tools. Return ONLY a JSON object with exactly these keys: code, arrow_color, arrow_direction, timeout_seconds, star_position_relative_to_state_b, mode. Set values to UNKNOWN if unavailable."""


def parse_json_object(text: str) -> dict:
    raw = str(text or "").strip()
    if not raw:
        return {}
    candidates = [raw]
    m = re.search(r"\{.*\}", raw, flags=re.S)
    if m:
        candidates.append(m.group(0))
    for c in candidates:
        try:
            obj = json.loads(c)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
    return {}


def extract_cli_result(stdout: str) -> str:
    raw = stdout.strip()
    if not raw:
        return ""
    lines = [x.strip() for x in raw.splitlines() if x.strip()]
    for candidate in reversed(lines + [raw]):
        try:
            obj = json.loads(candidate)
        except Exception:
            continue
        if isinstance(obj, dict):
            for key in ("result", "response", "text", "content", "message"):
                val = obj.get(key)
                if isinstance(val, str) and val.strip():
                    return val.strip()
                if isinstance(val, dict):
                    for kk in ("content", "text"):
                        vv = val.get(kk)
                        if isinstance(vv, str) and vv.strip():
                            return vv.strip()
    return raw


def normalize_value(key: str, value) -> str:
    s = str(value if value is not None else "").strip()
    if key == "timeout_seconds":
        m = re.search(r"\d+(?:\.\d+)?", s)
        return m.group(0) if m else s.upper()
    return s.upper().replace(" ", "_")


def score_response(response_text: str, facts: FixtureFacts) -> dict:
    lowered = str(response_text or "").lower()
    permission_blocked = any(token in lowered for token in (
        "permission error",
        "permission denied",
        "permission was denied",
        "cannot be inspected due to a permission",
        "tool permission",
    ))
    parsed = parse_json_object(response_text)
    expected = asdict(facts)
    matches = {}
    count = 0
    for key in FIELDS:
        exp = normalize_value(key, expected.get(key))
        got = normalize_value(key, parsed.get(key))
        ok = bool(got) and got == exp
        matches[key] = {"expected": exp, "actual": got or "<MISSING>", "match": ok}
        count += int(ok)
    code_ok = matches["code"]["match"]
    if code_ok and count >= 5:
        verdict = "PASS"
    elif code_ok and count >= 3:
        verdict = "PARTIAL"
    else:
        verdict = "FAIL"
    if permission_blocked:
        verdict = "BLOCKED_PERMISSION"
    return {"verdict": verdict, "matched": count, "total": len(FIELDS), "parsed": parsed, "fields": matches}


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def run_alira_cli(
    prompt: str,
    cwd: Path,
    model: str,
    api_base: str,
    timeout_s: int,
    license_path: Path | None,
    *,
    allow_tools_without_prompt: bool = False,
) -> dict:
    """Run ALIRA headlessly.

    Vision verification uses a randomized fixture whose expected values remain
    only in Python memory until ALIRA finishes.  When allow_tools_without_prompt
    is True, ALIRA receives --no-permission-enabled so EncodeImage/equivalent
    tools can execute in headless mode without an interactive permission prompt.
    """
    exe = default_cli_path()
    if not exe.is_file():
        raise RuntimeError(f"ALIRA CLI를 찾지 못했습니다: {exe}")
    env = os.environ.copy()
    if license_path:
        env["ALIRA_LICENSE_PATH"] = str(license_path)

    cmd = [
        str(exe),
        "--model", model,
        "--api-base", api_base,
        "--agent-type", "general_agent",
        "--cwd", str(cwd),
    ]
    if allow_tools_without_prompt:
        cmd.append("--no-permission-enabled")
    cmd += ["-p", prompt, "--output-format", "json"]

    proc = subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_s,
        check=False,
    )
    stdout = proc.stdout.decode("utf-8", errors="replace")
    stderr = proc.stderr.decode("utf-8", errors="replace")
    return {
        "command": cmd,
        "returncode": proc.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "response": extract_cli_result(stdout),
        "tools_permission_bypass": bool(allow_tools_without_prompt),
    }


def run_direct_api(image_path: Path, prompt: str, model: str, api_base: str, timeout_s: int) -> dict:
    if requests is None:
        raise RuntimeError("requests 패키지가 설치되어 있지 않습니다.")
    base = api_base.rstrip("/")
    url = base if base.endswith("/chat/completions") else base + "/chat/completions"
    data_url = "data:image/png;base64," + base64.b64encode(image_path.read_bytes()).decode("ascii")
    content = [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": data_url}}]
    payload = {"model": model, "messages": [{"role": "user", "content": content}]}
    headers = {"Content-Type": "application/json"}
    key = os.environ.get("ALIRA_API_KEY", "").strip()
    if key:
        headers["Authorization"] = f"Bearer {key}"
    r = requests.post(url, headers=headers, json=payload, timeout=timeout_s)
    body_text = r.text
    r.raise_for_status()
    body = r.json()
    msg = body.get("choices", [{}])[0].get("message", {}).get("content", "")
    if isinstance(msg, list):
        msg = "\n".join(str(x.get("text", "")) for x in msg if isinstance(x, dict))
    return {"url": url, "status_code": r.status_code, "response": str(msg).strip(), "raw_body": body_text}


def write_report(run_dir: Path, facts: FixtureFacts, fixture: Path, control: dict, cli: dict, api: dict | None, errors: list[str]) -> dict:
    cli_score = score_response(cli.get("response", ""), facts) if cli else {"verdict": "FAIL", "matched": 0, "total": 6, "fields": {}}
    api_score = score_response(api.get("response", ""), facts) if api else None
    control_score = score_response(control.get("response", ""), facts) if control else None
    overall = cli_score["verdict"]
    evidence = {
        "tool": f"{APP_TITLE} {APP_VERSION}",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "fixture_sha256": file_sha256(fixture),
        "expected": asdict(facts),
        "cli_vision": cli_score,
        "direct_api_vision": api_score,
        "control_without_image": control_score,
        "overall_cli_verdict": overall,
        "errors": errors,
    }
    (run_dir / "expected_after_test.json").write_text(json.dumps(asdict(facts), ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "verdict.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")

    def table_rows(score):
        if not score:
            return "<tr><td colspan='4'>Not executed</td></tr>"
        out=[]
        for key in FIELDS:
            d=score.get("fields",{}).get(key,{})
            out.append(f"<tr><td>{key}</td><td>{d.get('expected','')}</td><td>{d.get('actual','')}</td><td>{'PASS' if d.get('match') else 'FAIL'}</td></tr>")
        return "\n".join(out)
    html=f"""<!doctype html><meta charset='utf-8'><title>ALIRA Vision Evidence</title>
<style>body{{font-family:Arial,sans-serif;max-width:1000px;margin:32px auto;color:#132238}}h1{{color:#174EA6}}.badge{{display:inline-block;padding:8px 16px;border-radius:20px;background:{'#DCFCE7' if overall=='PASS' else ('#FEF3C7' if overall=='BLOCKED_PERMISSION' else '#FEE2E2')};font-weight:700}}table{{border-collapse:collapse;width:100%;margin:16px 0}}th,td{{border:1px solid #CBD5E1;padding:8px;text-align:left}}th{{background:#EFF6FF}}img{{max-width:100%;border:1px solid #CBD5E1;border-radius:12px}}pre{{white-space:pre-wrap;background:#F8FAFC;padding:12px;border-radius:8px}}</style>
<h1>ALIRA Vision Verifier Evidence Report</h1><p class='badge'>CLI Vision: {overall} ({cli_score['matched']}/{cli_score['total']})</p>
<p>Generated: {evidence['generated_at']}<br>Fixture SHA-256: {evidence['fixture_sha256']}</p>
<h2>Fixture</h2><img src='fixture.png'>
<h2>ALIRA CLI Vision</h2><table><tr><th>Field</th><th>Expected</th><th>Actual</th><th>Match</th></tr>{table_rows(cli_score)}</table><pre>{cli.get('response','')}</pre>
<h2>Control without image</h2><pre>{control.get('response','') if control else ''}</pre>
<h2>Direct API (diagnostic)</h2><table><tr><th>Field</th><th>Expected</th><th>Actual</th><th>Match</th></tr>{table_rows(api_score)}</table><pre>{api.get('response','') if api else 'Not executed'}</pre>
<h2>Errors</h2><pre>{chr(10).join(errors) if errors else 'None'}</pre>
<p><b>Interpretation:</b> CLI PASS means the actual ALIRA agent/headless path successfully recovered the randomized information from the image. Direct API is optional secondary diagnostic evidence for the model/gateway path and never changes the CLI verdict. BLOCKED_PERMISSION means the image test did not execute because a tool permission gate prevented image inspection.</p>"""
    (run_dir / "report.html").write_text(html, encoding="utf-8")
    md=[f"# ALIRA Vision Verification\n", f"- CLI Vision verdict: **{overall}** ({cli_score['matched']}/{cli_score['total']})", f"- Fixture SHA-256: `{evidence['fixture_sha256']}`", "", "## Expected", "```json", json.dumps(asdict(facts), ensure_ascii=False, indent=2), "```", "", "## CLI response", "```", cli.get("response", ""), "```"]
    if api:
        md += ["", "## Direct API response", "```", api.get("response", ""), "```"]
    (run_dir / "verdict_summary.md").write_text("\n".join(md), encoding="utf-8")
    return evidence


class TestWorker(QThread):
    log = Signal(str)
    done = Signal(object)

    def __init__(self, model: str, api_base: str, timeout_s: int, direct_api_enabled: bool = False):
        super().__init__()
        self.model, self.api_base, self.timeout_s = model, api_base, timeout_s
        self.direct_api_enabled = bool(direct_api_enabled)

    def run(self):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = app_root() / "output" / f"run_{stamp}"
        run_dir.mkdir(parents=True, exist_ok=True)
        control_dir = run_dir / "control_no_image"
        control_dir.mkdir(parents=True, exist_ok=True)
        fixture = run_dir / "fixture.png"
        facts = new_facts()
        generate_fixture(fixture, facts)
        prompt = prompt_for_image(fixture)
        (run_dir / "prompt.txt").write_text(prompt, encoding="utf-8")
        errors=[]
        lic=find_license()
        try:
            self.log.emit("CONTROL · 이미지 없이 ALIRA CLI 실행")
            control = run_alira_cli(control_prompt(), control_dir, self.model, self.api_base, self.timeout_s, lic, allow_tools_without_prompt=False)
            (run_dir / "control_stdout.txt").write_text(control["stdout"], encoding="utf-8")
            (run_dir / "control_stderr.txt").write_text(control["stderr"], encoding="utf-8")
        except Exception as exc:
            control={"response":""}; errors.append(f"CONTROL: {exc}"); self.log.emit(f"CONTROL 실패 · {exc}")
        try:
            self.log.emit("CLI VISION · 격리된 Run 폴더에서 Headless Tool 권한 활성화 (--no-permission-enabled)")
            self.log.emit("CLI VISION · ALIRA에 fixture 경로 전달 / EncodeImage 또는 동등 Image Tool 사용 요청")
            cli = run_alira_cli(prompt, run_dir, self.model, self.api_base, self.timeout_s, lic, allow_tools_without_prompt=True)
            (run_dir / "cli_command.json").write_text(json.dumps(cli["command"], ensure_ascii=False, indent=2), encoding="utf-8")
            (run_dir / "cli_stdout.txt").write_text(cli["stdout"], encoding="utf-8")
            (run_dir / "cli_stderr.txt").write_text(cli["stderr"], encoding="utf-8")
            (run_dir / "cli_response.txt").write_text(cli["response"], encoding="utf-8")
        except Exception as exc:
            cli={"response":""}; errors.append(f"CLI VISION: {exc}"); self.log.emit(f"CLI Vision 실패 · {exc}")
        api=None
        if self.direct_api_enabled:
            try:
                self.log.emit("DIRECT API · 참고 진단 실행 (주 판정에는 영향 없음)")
                api=run_direct_api(fixture, prompt, self.model, self.api_base, self.timeout_s)
                (run_dir / "direct_api_response.txt").write_text(api["response"], encoding="utf-8")
                (run_dir / "direct_api_raw_body.txt").write_text(api["raw_body"], encoding="utf-8")
            except Exception as exc:
                errors.append(f"DIRECT API (diagnostic only): {exc}")
                self.log.emit(f"Direct API 참고 진단 실패 · {exc} · ALIRA CLI Vision 판정은 계속")
        else:
            self.log.emit("DIRECT API · 참고 진단 비활성 · ALIRA CLI Vision만 주 판정")
        evidence=write_report(run_dir, facts, fixture, control, cli, api, errors)
        self.done.emit({"run_dir":str(run_dir), "fixture":str(fixture), "evidence":evidence, "cli_response":cli.get("response", ""), "api_response":api.get("response", "") if api else ""})


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_TITLE} {APP_VERSION}")
        self.resize(1180, 800)
        self.last_run_dir: Path | None = None
        self.worker: TestWorker | None = None
        cfg=load_config()
        root=QWidget(); self.setCentralWidget(root)
        layout=QVBoxLayout(root); layout.setContentsMargins(20,18,20,18); layout.setSpacing(14)

        title=QLabel("ALIRA Vision Verifier"); title.setObjectName("title")
        sub=QLabel("ALIRA가 실제 이미지 내용을 읽는지 랜덤 Fixture와 증빙 파일로 확인합니다."); sub.setObjectName("sub")
        layout.addWidget(title); layout.addWidget(sub)

        settings=QFrame(); settings.setObjectName("card")
        grid=QGridLayout(settings); grid.setContentsMargins(18,16,18,16); grid.setHorizontalSpacing(10); grid.setVerticalSpacing(10)
        grid.addWidget(QLabel("ALIRA CLI"),0,0); self.cli_label=QLabel(); grid.addWidget(self.cli_label,0,1)
        grid.addWidget(QLabel("License"),1,0); self.license_label=QLabel(); grid.addWidget(self.license_label,1,1)
        self.license_btn=QPushButton("라이선스 폴더 열기"); self.license_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(license_dir())))); grid.addWidget(self.license_btn,1,2)
        grid.addWidget(QLabel("Model"),2,0); self.model=QLineEdit(str(cfg.get("model") or DEFAULT_MODEL)); grid.addWidget(self.model,2,1,1,2)
        grid.addWidget(QLabel("API Base"),3,0); self.api=QLineEdit(str(cfg.get("api_base") or DEFAULT_API_BASE)); grid.addWidget(self.api,3,1,1,2)
        grid.addWidget(QLabel("Timeout"),4,0); self.timeout=QSpinBox(); self.timeout.setRange(30,900); self.timeout.setValue(int(cfg.get("timeout_seconds") or 180)); self.timeout.setSuffix(" s"); grid.addWidget(self.timeout,4,1)
        self.refresh_btn=QPushButton("환경 새로고침"); self.refresh_btn.clicked.connect(self.refresh_env); grid.addWidget(self.refresh_btn,4,2)
        grid.addWidget(QLabel("참고 진단"),5,0)
        self.direct_api_check=QCheckBox("Direct API도 추가 확인 (기본 Off · CLI 판정과 무관)")
        self.direct_api_check.setChecked(bool(cfg.get("direct_api_enabled", False)))
        grid.addWidget(self.direct_api_check,5,1,1,2)
        layout.addWidget(settings)

        body=QHBoxLayout(); body.setSpacing(14)
        left=QFrame(); left.setObjectName("card"); ll=QVBoxLayout(left); ll.setContentsMargins(14,14,14,14)
        ll.addWidget(QLabel("테스트 이미지")); self.preview=QLabel("증빙 테스트를 실행하면 랜덤 Fixture가 생성됩니다."); self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter); self.preview.setMinimumSize(520,330); self.preview.setObjectName("preview"); ll.addWidget(self.preview,1)
        body.addWidget(left,5)
        right=QFrame(); right.setObjectName("card"); rl=QVBoxLayout(right); rl.setContentsMargins(14,14,14,14); rl.addWidget(QLabel("실행 로그 / 판정")); self.log=QPlainTextEdit(); self.log.setReadOnly(True); rl.addWidget(self.log,1)
        self.result=QLabel("대기"); self.result.setObjectName("verdict"); rl.addWidget(self.result)
        btnrow=QHBoxLayout(); self.run_btn=QPushButton("증빙 테스트 실행"); self.run_btn.setObjectName("primary"); self.run_btn.clicked.connect(self.start_test); self.open_btn=QPushButton("결과 폴더 열기"); self.open_btn.clicked.connect(self.open_result); btnrow.addWidget(self.run_btn); btnrow.addWidget(self.open_btn); rl.addLayout(btnrow)
        body.addWidget(right,4); layout.addLayout(body,1)

        self.setStyleSheet("""
            QWidget { font-family:'Malgun Gothic','Segoe UI'; font-size:13px; color:#14213D; background:#F4F7FB; }
            QLabel#title { font-size:25px; font-weight:800; color:#102A43; }
            QLabel#sub { color:#64748B; margin-bottom:5px; }
            QFrame#card { background:white; border:1px solid #DCE5F0; border-radius:14px; }
            QLineEdit,QSpinBox,QPlainTextEdit { background:white; border:1px solid #CBD5E1; border-radius:8px; padding:7px; }
            QPushButton { background:white; border:1px solid #B8C6D9; border-radius:9px; padding:9px 15px; font-weight:700; }
            QPushButton:hover { border-color:#3B82F6; }
            QPushButton#primary { background:#2563EB; color:white; border-color:#2563EB; }
            QLabel#preview { background:#F8FAFC; border:1px dashed #B8C6D9; border-radius:10px; color:#64748B; }
            QLabel#verdict { font-size:18px; font-weight:800; padding:10px; background:#EFF6FF; border-radius:9px; }
        """)
        self.refresh_env()

    def append(self, text):
        self.log.appendPlainText(f"[{datetime.now().strftime('%H:%M:%S')}] {text}")

    def refresh_env(self):
        cli=default_cli_path(); lic=find_license()
        self.cli_label.setText(f"{'✓' if cli.is_file() else '○'} {cli}")
        self.license_label.setText(f"{'✓ ' + str(lic) if lic else '○ 라이선스 미감지'}")

    def start_test(self):
        if self.worker and self.worker.isRunning(): return
        save_config(self.model.text(), self.api.text(), self.timeout.value(), self.direct_api_check.isChecked())
        self.log.clear(); self.result.setText("실행 중 ..."); self.run_btn.setEnabled(False)
        self.worker=TestWorker(self.model.text().strip(), self.api.text().strip(), self.timeout.value(), self.direct_api_check.isChecked())
        self.worker.log.connect(self.append); self.worker.done.connect(self.finish_test); self.worker.start()

    def finish_test(self, data):
        self.run_btn.setEnabled(True)
        self.last_run_dir=Path(data["run_dir"])
        pm=QPixmap(data["fixture"]).scaled(self.preview.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.preview.setPixmap(pm)
        ev=data["evidence"]; verdict=ev.get("overall_cli_verdict","FAIL"); sc=ev.get("cli_vision",{})
        if verdict == "BLOCKED_PERMISSION":
            self.result.setText("ALIRA CLI Vision: TEST BLOCKED · Image Tool 권한 거부")
        else:
            self.result.setText(f"ALIRA CLI Vision: {verdict} · {sc.get('matched',0)}/{sc.get('total',6)} 일치")
        self.append(f"증빙 저장 완료 · {self.last_run_dir}")
        self.append("report.html / verdict.json / raw stdout·stderr를 확인하세요.")

    def open_result(self):
        target=self.last_run_dir or (app_root()/"output")
        target.mkdir(parents=True,exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))


if __name__ == "__main__":
    app=QApplication(sys.argv)
    w=MainWindow(); w.show()
    sys.exit(app.exec())
