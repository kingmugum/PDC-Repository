# -*- coding: utf-8 -*-
import subprocess,sys,tkinter as tk
from tkinter import messagebox
r=tk.Tk(); r.withdraw()
p=subprocess.run([sys.executable,"-m","pip","install","--upgrade","pywinauto==0.6.9","pywin32>=306"],capture_output=True,text=True)
if p.returncode==0:messagebox.showinfo("완료","설치 완료. 이제 SuresoftMessengerManager_v0.4.1.pyw를 실행하세요.")
else:messagebox.showerror("실패",(p.stderr or p.stdout)[-4000:])
