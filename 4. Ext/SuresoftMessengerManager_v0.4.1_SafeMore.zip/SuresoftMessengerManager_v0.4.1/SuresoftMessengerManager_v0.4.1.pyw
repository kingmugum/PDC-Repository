# -*- coding: utf-8 -*-
"""
Suresoft Messenger Manager v0.4.1
- v0.4 통합 구조 유지
- "더보기" 안전 필터 강화
  1) exact text match only: 정확히 '더보기'인 UIA 요소만
  2) 상단 툴바 영역 제외: 창 상단 N px 이내 요소는 절대 클릭하지 않음
  3) 자동 펼치기 전 현재 화면에서 안전 후보 개수 확인 가능
"""

from __future__ import annotations
import ctypes, hashlib, json, os, queue, sys, threading, time, tkinter as tk
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from tkinter import ttk, messagebox

APP_NAME="Suresoft Messenger Manager"
APP_VERSION="v0.4.1"
IS_WINDOWS=sys.platform.startswith("win")

BASE_DIR=Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent
INPUT_DIR=BASE_DIR/"input"; OUTPUT_DIR=BASE_DIR/"output"; LOG_DIR=BASE_DIR/"logs"
CONFIG_FILE=BASE_DIR/"config.json"; UPLOAD_STATE_FILE=BASE_DIR/".upload_state.json"
for d in (INPUT_DIR,OUTPUT_DIR,LOG_DIR): d.mkdir(exist_ok=True)

VK_CONTROL=0x11; VK_V=0x56; VK_RETURN=0x0D; VK_ESCAPE=0x1B; KEYEVENTF_KEYUP=0x0002

try:
    from pywinauto import Desktop, mouse
except Exception as e:
    r=tk.Tk(); r.withdraw()
    messagebox.showerror("필수 패키지 설치 필요",
        "pywinauto가 필요합니다.\n같은 폴더의 install_dependencies.py를 먼저 실행하세요.\n\n"+str(e))
    raise

def safe_text(v):
    try: return str(v or "").strip()
    except: return ""

def rect_tuple(r):
    try: return (r.left,r.top,r.right,r.bottom)
    except: return (0,0,0,0)

def rect_intersects(a,b):
    try:
        return not (a.right<=b.left or a.left>=b.right or a.bottom<=b.top or a.top>=b.bottom)
    except: return True

def load_json(p,default):
    try: return json.loads(p.read_text(encoding="utf-8"))
    except: return default

def save_json(p,data):
    try: p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    except: pass

def win_key(vk,up=False):
    if IS_WINDOWS: ctypes.windll.user32.keybd_event(vk,0,KEYEVENTF_KEYUP if up else 0,0)

def send_ctrl_v():
    win_key(VK_CONTROL); win_key(VK_V); win_key(VK_V,True); win_key(VK_CONTROL,True)

def send_enter(ctrl=False):
    if ctrl: win_key(VK_CONTROL)
    win_key(VK_RETURN); win_key(VK_RETURN,True)
    if ctrl: win_key(VK_CONTROL,True)

def escape_pressed():
    return bool(IS_WINDOWS and ctypes.windll.user32.GetAsyncKeyState(VK_ESCAPE)&0x8000)

def smart_read_text(path):
    raw=path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"): return raw.decode("utf-8-sig"),"UTF-8 BOM"
    if raw.startswith(b"\xff\xfe"): return raw.decode("utf-16"),"UTF-16 LE"
    if raw.startswith(b"\xfe\xff"): return raw.decode("utf-16"),"UTF-16 BE"
    try: return raw.decode("utf-8"),"UTF-8"
    except UnicodeDecodeError:
        try: return raw.decode("cp949"),"CP949"
        except UnicodeDecodeError: return raw.decode("cp949",errors="replace"),"CP949(replace)"

def split_text(text,lines_per_chunk,max_chars=None):
    normalized=text.replace("\r\n","\n").replace("\r","\n")
    lines=normalized.split("\n")
    if lines and lines[-1]=="" and normalized.endswith("\n"): lines=lines[:-1]
    if not lines: return [],0
    chunks=[]; current=[]; current_chars=0
    def flush():
        nonlocal current,current_chars
        if current:
            chunks.append("\r\n".join(current)); current=[]; current_chars=0
    for line in lines:
        if max_chars and len(line)>max_chars:
            flush()
            for i in range(0,len(line),max_chars): chunks.append(line[i:i+max_chars])
            continue
        extra=len(line) if not current else len(line)+2
        if current and (len(current)>=lines_per_chunk or (max_chars and current_chars+extra>max_chars)):
            flush(); extra=len(line)
        current.append(line); current_chars+=extra
    flush()
    return chunks,len(lines)

def file_signature(paths):
    h=hashlib.sha256()
    for p in paths:
        s=p.stat()
        h.update(p.name.encode("utf-8",errors="replace")); h.update(str(s.st_size).encode()); h.update(str(s.st_mtime_ns).encode())
    return h.hexdigest()

@dataclass
class UploadFile:
    path:Path; encoding:str; line_count:int; chunks:list[str]

@dataclass
class UploadItem:
    file_name:str; file_index:int; file_total:int; chunk_index:int; chunk_total:int; text:str

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}"); self.geometry("1080x830"); self.minsize(980,740)
        self.cfg=load_json(CONFIG_FILE,{})
        self.window_map={}; self.selected_window=tk.StringVar()

        # download settings
        self.more_text=tk.StringVar(value="더보기")
        self.top_exclude_px=tk.IntVar(value=int(self.cfg.get("top_exclude_px",100)))
        self.scroll_amount=tk.IntVar(value=int(self.cfg.get("scroll_amount",6)))
        self.max_scroll_cycles=tk.IntVar(value=int(self.cfg.get("max_scroll_cycles",120)))
        self.bottom_stable_count=tk.IntVar(value=int(self.cfg.get("bottom_stable_count",3)))
        self.collect_status=tk.StringVar(value="메신저 창을 선택해 주세요.")
        self.collect_progress=tk.StringVar(value="-")
        self.collect_stop=threading.Event(); self.collect_worker=None

        # upload settings
        self.lines_per_chunk=tk.IntVar(value=int(self.cfg.get("lines_per_chunk",90)))
        self.message_delay=tk.DoubleVar(value=float(self.cfg.get("message_delay",1.0)))
        self.file_delay=tk.DoubleVar(value=float(self.cfg.get("file_delay",1.5)))
        self.countdown=tk.IntVar(value=int(self.cfg.get("countdown",5)))
        self.send_key=tk.StringVar(value=self.cfg.get("send_key","Enter"))
        self.use_char_limit=tk.BooleanVar(value=bool(self.cfg.get("use_char_limit",False)))
        self.max_chars=tk.IntVar(value=int(self.cfg.get("max_chars",10000)))
        self.prefix_filename=tk.BooleanVar(value=bool(self.cfg.get("prefix_filename",False)))
        self.upload_status=tk.StringVar(value="input 폴더 확인 중...")
        self.upload_summary=tk.StringVar(value="-")
        self.upload_progress=tk.DoubleVar(value=0)
        self.upload_progress_text=tk.StringVar(value="0 / 0")
        self.upload_resume=tk.StringVar(value="처음부터")
        self.upload_stop=threading.Event(); self.upload_worker=None
        self.upload_files=[]; self.upload_queue=[]; self.upload_signature=""; self.upload_resume_index=0

        self.ui_queue=queue.Queue()
        self.build_ui()
        self.refresh_windows(); self.refresh_input()
        self.after(100,self.process_queue); self.after(80,self.poll_escape)

    def build_ui(self):
        outer=ttk.Frame(self,padding=12); outer.pack(fill="both",expand=True)
        ttk.Label(outer,text=f"{APP_NAME} {APP_VERSION}",font=("Malgun Gothic",17,"bold")).pack(anchor="w")
        ttk.Label(outer,text="다운로드(대화 수집) + 업로드(TXT 전송) 통합 도구 / v0.4.1: 상단 메뉴 '더보기' 안전 제외").pack(anchor="w",pady=(3,8))

        common=ttk.LabelFrame(outer,text="Suresoft Messenger 창"); common.pack(fill="x",pady=(0,8))
        r=ttk.Frame(common); r.pack(fill="x",padx=10,pady=8)
        self.window_combo=ttk.Combobox(r,textvariable=self.selected_window,state="readonly",width=82)
        self.window_combo.pack(side="left",fill="x",expand=True)
        ttk.Button(r,text="창 새로고침",command=self.refresh_windows,width=13).pack(side="left",padx=6)
        ttk.Button(r,text="선택 창 앞으로",command=self.focus_window,width=14).pack(side="left")

        tabs=ttk.Notebook(outer); tabs.pack(fill="both",expand=True)
        self.down=ttk.Frame(tabs,padding=10); self.up=ttk.Frame(tabs,padding=10)
        tabs.add(self.down,text="  다운로드 / 대화 수집  "); tabs.add(self.up,text="  업로드 / TXT 전송  ")
        self.build_download(); self.build_upload()
        ttk.Label(outer,text="긴급 중지: ESC. v0.5에서는 시작/종료 시간 자동 탐색을 추가 예정.",foreground="#555").pack(anchor="w",pady=(8,0))

    def build_download(self):
        t=self.down
        intro=ttk.LabelFrame(t,text="v0.4.1 안전 규칙"); intro.pack(fill="x",pady=(0,8))
        ttk.Label(intro,text="메시지 본문에 실제로 표시된 '더보기'만 대상으로 하며, 창 상단 툴바 영역은 무조건 제외합니다.",font=("Malgun Gothic",9,"bold")).pack(anchor="w",padx=10,pady=8)

        s=ttk.LabelFrame(t,text="1. 자동 펼치기 설정"); s.pack(fill="x",pady=(0,8))
        g=ttk.Frame(s); g.pack(fill="x",padx=10,pady=8)
        ttk.Label(g,text="정확히 일치할 텍스트").grid(row=0,column=0,sticky="w",padx=4,pady=4)
        e=ttk.Entry(g,textvariable=self.more_text,width=12,state="readonly"); e.grid(row=0,column=1,sticky="w")
        ttk.Label(g,text="상단 제외 영역(px)").grid(row=0,column=2,sticky="w",padx=(25,4))
        ttk.Spinbox(g,from_=60,to=300,textvariable=self.top_exclude_px,width=9).grid(row=0,column=3,sticky="w")
        ttk.Label(g,text="기본 100px — 오른쪽 위 메뉴 아이콘 보호").grid(row=0,column=4,columnspan=2,sticky="w",padx=(10,0))
        ttk.Label(g,text="스크롤 양").grid(row=1,column=0,sticky="w",padx=4,pady=4)
        ttk.Spinbox(g,from_=1,to=20,textvariable=self.scroll_amount,width=8).grid(row=1,column=1,sticky="w")
        ttk.Label(g,text="최대 반복").grid(row=1,column=2,sticky="w",padx=(25,4))
        ttk.Spinbox(g,from_=5,to=1000,textvariable=self.max_scroll_cycles,width=9).grid(row=1,column=3,sticky="w")
        ttk.Label(g,text="하단 판정 반복").grid(row=1,column=4,sticky="w",padx=(25,4))
        ttk.Spinbox(g,from_=1,to=10,textvariable=self.bottom_stable_count,width=8).grid(row=1,column=5,sticky="w")

        a=ttk.LabelFrame(t,text="2. 더보기 자동 펼치기"); a.pack(fill="x",pady=(0,8))
        r=ttk.Frame(a); r.pack(fill="x",padx=10,pady=9)
        ttk.Button(r,text="안전 후보 찾기",command=self.scan_more,width=18).pack(side="left",padx=(0,7))
        ttk.Button(r,text="현재 위치부터 자동 펼치기",command=self.start_expand,width=26).pack(side="left",padx=(0,7))
        ttk.Button(r,text="중지",command=lambda:self.collect_stop.set(),width=12).pack(side="left",padx=(0,7))
        ttk.Button(r,text="전체 UI 텍스트 진단",command=self.dump_ui,width=18).pack(side="left")

        st=ttk.LabelFrame(t,text="3. 상태"); st.pack(fill="x",pady=(0,8))
        ttk.Label(st,textvariable=self.collect_status,font=("Malgun Gothic",9,"bold")).pack(anchor="w",padx=10,pady=(8,3))
        ttk.Label(st,textvariable=self.collect_progress).pack(anchor="w",padx=10,pady=(0,8))

        sb=ttk.LabelFrame(t,text="4. 복사한 대화 저장"); sb.pack(fill="x")
        ttk.Label(sb,text="더보기가 모두 펼쳐진 뒤 메신저에서 원하는 구간을 드래그 → Ctrl+C → 아래 버튼으로 저장").pack(anchor="w",padx=10,pady=(8,5))
        r=ttk.Frame(sb); r.pack(fill="x",padx=10,pady=(0,9))
        ttk.Button(r,text="클립보드 → output TXT 저장",command=self.save_clipboard,width=28).pack(side="left",padx=(0,7))
        ttk.Button(r,text="output 폴더 열기",command=lambda:os.startfile(OUTPUT_DIR),width=16).pack(side="left",padx=(0,7))
        ttk.Button(r,text="logs 폴더 열기",command=lambda:os.startfile(LOG_DIR),width=16).pack(side="left")

    def build_upload(self):
        t=self.up
        b=ttk.LabelFrame(t,text="input 폴더"); b.pack(fill="x",pady=(0,8))
        r=ttk.Frame(b); r.pack(fill="x",padx=10,pady=8)
        e=ttk.Entry(r); e.insert(0,str(INPUT_DIR)); e.configure(state="readonly"); e.pack(side="left",fill="x",expand=True)
        ttk.Button(r,text="input 폴더 열기",command=lambda:os.startfile(INPUT_DIR),width=15).pack(side="left",padx=6)
        ttk.Button(r,text="새로고침",command=self.refresh_input,width=11).pack(side="left")

        f=ttk.LabelFrame(t,text="1. 전송 대상 TXT"); f.pack(fill="both",expand=True,pady=(0,8))
        cols=("order","name","encoding","lines","chunks")
        self.upload_tree=ttk.Treeview(f,columns=cols,show="headings",height=7)
        for c,tt,w in [("order","#",45),("name","파일명",480),("encoding","인코딩",110),("lines","줄 수",90),("chunks","메시지 수",90)]:
            self.upload_tree.heading(c,text=tt); self.upload_tree.column(c,width=w,anchor="w" if c=="name" else "center")
        self.upload_tree.pack(fill="both",expand=True,padx=8,pady=8)
        ttk.Label(f,textvariable=self.upload_summary).pack(anchor="w",padx=10,pady=(0,7))

        s=ttk.LabelFrame(t,text="2. 전송 설정"); s.pack(fill="x",pady=(0,8))
        g=ttk.Frame(s); g.pack(fill="x",padx=10,pady=8)
        ttk.Label(g,text="줄 수/메시지").grid(row=0,column=0,sticky="w",padx=4,pady=4)
        ttk.Spinbox(g,from_=1,to=1000,textvariable=self.lines_per_chunk,width=9).grid(row=0,column=1,sticky="w")
        ttk.Label(g,text="메시지 간격").grid(row=0,column=2,sticky="w",padx=(25,4))
        ttk.Spinbox(g,from_=0.2,to=30,increment=0.1,textvariable=self.message_delay,width=9).grid(row=0,column=3,sticky="w")
        ttk.Label(g,text="파일 간격").grid(row=0,column=4,sticky="w",padx=(25,4))
        ttk.Spinbox(g,from_=0.2,to=30,increment=0.1,textvariable=self.file_delay,width=9).grid(row=0,column=5,sticky="w")
        ttk.Label(g,text="카운트다운").grid(row=1,column=0,sticky="w",padx=4,pady=4)
        ttk.Spinbox(g,from_=1,to=30,textvariable=self.countdown,width=9).grid(row=1,column=1,sticky="w")
        ttk.Label(g,text="전송 키").grid(row=1,column=2,sticky="w",padx=(25,4))
        ttk.Combobox(g,textvariable=self.send_key,values=["Enter","Ctrl+Enter"],state="readonly",width=11).grid(row=1,column=3,sticky="w")
        ttk.Checkbutton(g,text="첫 청크 앞 파일명 표시",variable=self.prefix_filename).grid(row=1,column=4,columnspan=2,sticky="w",padx=(25,4))
        ttk.Checkbutton(g,text="최대 글자 수 제한",variable=self.use_char_limit).grid(row=2,column=0,sticky="w",padx=4,pady=4)
        ttk.Spinbox(g,from_=100,to=100000,increment=100,textvariable=self.max_chars,width=10).grid(row=2,column=1,sticky="w")
        ttk.Label(g,text="시작 위치").grid(row=2,column=4,sticky="e",padx=(25,4))
        self.resume_combo=ttk.Combobox(g,textvariable=self.upload_resume,values=["처음부터"],state="readonly",width=22)
        self.resume_combo.grid(row=2,column=5,sticky="w")

        a=ttk.LabelFrame(t,text="3. 실행"); a.pack(fill="x")
        r=ttk.Frame(a); r.pack(fill="x",padx=10,pady=9)
        ttk.Button(r,text="첫 메시지 붙여넣기 테스트",command=self.upload_test,width=24).pack(side="left",padx=(0,7))
        ttk.Button(r,text="전체 자동 전송 시작",command=self.upload_start,width=20).pack(side="left",padx=(0,7))
        ttk.Button(r,text="긴급 중지",command=lambda:self.upload_stop.set(),width=12).pack(side="left",padx=(0,7))
        ttk.Button(r,text="진행상태 초기화",command=self.reset_upload_state,width=15).pack(side="left")
        ttk.Label(a,textvariable=self.upload_status,font=("Malgun Gothic",9,"bold")).pack(anchor="w",padx=10,pady=(0,4))
        ttk.Progressbar(a,variable=self.upload_progress,maximum=100).pack(fill="x",padx=10,pady=3)
        ttk.Label(a,textvariable=self.upload_progress_text).pack(anchor="e",padx=10,pady=(0,8))
        self.lines_per_chunk.trace_add("write",lambda *_:self.after(250,self.refresh_input))
        self.use_char_limit.trace_add("write",lambda *_:self.after(250,self.refresh_input))
        self.max_chars.trace_add("write",lambda *_:self.after(250,self.refresh_input))

    # common windows
    def refresh_windows(self):
        try:
            vals=[]; self.window_map={}
            for w in Desktop(backend="uia").windows():
                try:
                    title=safe_text(w.window_text())
                    if not title: continue
                    try:
                        if not w.is_visible(): continue
                    except: pass
                    key=f"{title} [handle={getattr(w,'handle','?')}]"; self.window_map[key]=w; vals.append(key)
                except: pass
            vals.sort(key=str.lower); self.window_combo["values"]=vals
            pref=next((v for v in vals if any(k in v.lower() for k in ("suresoft","messenger","슈어","메신저"))),None)
            if pref:self.selected_window.set(pref)
            elif vals and not self.selected_window.get():self.selected_window.set(vals[0])
            self.collect_status.set(f"보이는 창 {len(vals)}개 확인.")
        except Exception as e: messagebox.showerror("창 목록 오류",str(e))

    def getwin(self):
        w=self.window_map.get(self.selected_window.get())
        if w is None: raise RuntimeError("Suresoft Messenger 창을 선택하세요.")
        return w

    def focus_window(self):
        try:
            w=self.getwin()
            try:w.restore()
            except:pass
            w.set_focus()
        except Exception as e:messagebox.showerror("오류",str(e))

    # SAFE more filtering
    def collect_safe_more(self,w):
        exact=self.more_text.get().strip() or "더보기"
        wr=w.rectangle()
        top_cut=wr.top + max(0,int(self.top_exclude_px.get()))
        out=[]
        for c in w.descendants():
            try:
                a=safe_text(c.window_text())
                b=safe_text(c.element_info.name)
                candidate=a or b

                # SAFETY 1: substring 금지, exact match only
                if candidate != exact:
                    continue

                rr=c.rectangle()
                if not rect_intersects(rr,wr): continue

                # SAFETY 2: 상단 툴바 영역 무조건 제외
                center_y=(rr.top+rr.bottom)/2
                if center_y < top_cut:
                    continue

                try:
                    if not c.is_visible(): continue
                except: pass

                out.append({
                    "wrapper":c,
                    "text":candidate,
                    "type":safe_text(c.element_info.control_type),
                    "autoid":safe_text(c.element_info.automation_id),
                    "rect":rr
                })
            except: pass

        uniq=[]; seen=set()
        for x in out:
            sig=(x["text"],x["type"],rect_tuple(x["rect"]))
            if sig in seen: continue
            seen.add(sig); uniq.append(x)
        return uniq

    def scan_more(self):
        try:
            w=self.getwin()
            m=self.collect_safe_more(w)
            self.collect_status.set(f"안전 후보 '{self.more_text.get()}': {len(m)}개 (상단 {self.top_exclude_px.get()}px 제외)")
            p=LOG_DIR/f"safe_more_scan_{datetime.now():%Y%m%d_%H%M%S}.txt"
            rows=[f"{APP_NAME} {APP_VERSION}",f"Window: {self.selected_window.get()}",f"Top excluded: {self.top_exclude_px.get()}px",f"Found: {len(m)}",""]
            for i,x in enumerate(m,1): rows.append(f"{i}\t{x['text']}\t{x['type']}\t{x['autoid']}\t{rect_tuple(x['rect'])}")
            p.write_text("\n".join(rows),encoding="utf-8")
        except Exception as e:messagebox.showerror("검색 오류",str(e))

    def click_ctrl(self,c):
        for meth in ("invoke","click","click_input"):
            try:getattr(c,meth)(); return meth
            except:pass
        raise RuntimeError("클릭 실패")

    def snapshot(self,w):
        rows=[]
        try:
            wr=w.rectangle()
            for c in w.descendants():
                try:
                    t=safe_text(c.window_text()) or safe_text(c.element_info.name)
                    if not t:continue
                    rr=c.rectangle()
                    if rect_intersects(rr,wr):rows.append((t[:100],rect_tuple(rr)))
                except:pass
        except:pass
        return hashlib.sha1(repr(rows[-80:]).encode("utf-8",errors="replace")).hexdigest()

    def start_expand(self):
        if self.collect_worker and self.collect_worker.is_alive():return
        if not messagebox.askyesno("안전 자동 펼치기",
            f"현재 화면부터 아래로 진행합니다.\n\n안전 조건:\n- 정확히 '더보기'만 클릭\n- 창 상단 {self.top_exclude_px.get()}px는 절대 클릭하지 않음\n\n계속할까요?"):
            return
        self.collect_stop.clear(); self.save_config()
        self.collect_worker=threading.Thread(target=self.expand_worker,daemon=True); self.collect_worker.start()

    def expand_worker(self):
        try:
            w=self.getwin()
            try:w.restore(); w.set_focus()
            except:pass
            wr=w.rectangle(); center=(int((wr.left+wr.right)/2),int((wr.top+wr.bottom)/2))
            total=0; stable=0; prev=None
            max_cycles=max(5,int(self.max_scroll_cycles.get())); need=max(1,int(self.bottom_stable_count.get())); wheel=max(1,int(self.scroll_amount.get()))
            logs=[f"{APP_NAME} {APP_VERSION}",f"Window: {self.selected_window.get()}",f"TopExcludePx: {self.top_exclude_px.get()}",""]
            for cyc in range(1,max_cycles+1):
                if self.collect_stop.is_set():break
                guard=0
                while not self.collect_stop.is_set():
                    m=self.collect_safe_more(w)
                    if not m:break
                    target=max(m,key=lambda x:rect_tuple(x["rect"])[1])
                    try:
                        method=self.click_ctrl(target["wrapper"]); total+=1; guard+=1
                        logs.append(f"{cyc}\tCLICK\t{method}\t{rect_tuple(target['rect'])}")
                    except Exception as e:
                        logs.append(f"{cyc}\tFAIL\t{e}\t{rect_tuple(target['rect'])}"); break
                    self.ui_queue.put(("collect_status",f"자동 펼치기 중: 반복 {cyc}/{max_cycles}, 안전 더보기 {total}개 클릭"))
                    time.sleep(.22)
                    if guard>=100:break

                before=self.snapshot(w)
                mouse.move(coords=center); mouse.scroll(coords=center,wheel_dist=-wheel)
                time.sleep(.45)
                after=self.snapshot(w)
                stable=stable+1 if (after==before or after==prev) else 0
                prev=after
                self.ui_queue.put(("collect_progress",f"스크롤 {cyc}/{max_cycles} | 클릭 {total}개 | 하단 판정 {stable}/{need}"))
                if stable>=need:break

            p=LOG_DIR/f"auto_expand_safe_{datetime.now():%Y%m%d_%H%M%S}.txt"
            p.write_text("\n".join(logs+[f"Total clicked: {total}"]),encoding="utf-8")
            self.ui_queue.put(("collect_status",f"완료: 안전한 '더보기' {total}개 처리. 상단 메뉴 아이콘은 제외됨."))
        except Exception as e:self.ui_queue.put(("collect_error",str(e)))

    def dump_ui(self):
        try:
            w=self.getwin(); rows=[]
            for i,c in enumerate(w.descendants(),1):
                try:
                    a=safe_text(c.window_text()); b=safe_text(c.element_info.name)
                    if not a and not b:continue
                    rows.append(f"{i}\tTYPE={safe_text(c.element_info.control_type)}\tAUTOID={safe_text(c.element_info.automation_id)}\tRECT={rect_tuple(c.rectangle())}\tTEXT={a!r}\tNAME={b!r}")
                except:pass
            p=LOG_DIR/f"uia_text_dump_{datetime.now():%Y%m%d_%H%M%S}.txt"
            p.write_text("\n".join(rows),encoding="utf-8"); messagebox.showinfo("저장",str(p))
        except Exception as e:messagebox.showerror("오류",str(e))

    def save_clipboard(self):
        try:text=self.clipboard_get()
        except:
            messagebox.showwarning("클립보드 없음","메신저에서 드래그 선택 → Ctrl+C 후 다시 눌러 주세요."); return
        if not str(text).strip():return
        p=OUTPUT_DIR/f"SuresoftMessenger_{datetime.now():%Y%m%d_%H%M%S}.txt"
        p.write_text(str(text),encoding="utf-8")
        self.collect_status.set(f"저장 완료: {p.name} ({len(str(text)):,}자)")
        messagebox.showinfo("저장 완료",str(p))

    # upload
    def refresh_input(self):
        if self.upload_worker and self.upload_worker.is_alive():return
        paths=sorted([p for p in INPUT_DIR.iterdir() if p.is_file() and p.suffix.lower()==".txt" and not p.name.startswith((".","~"))],key=lambda p:p.name.lower())
        try:lpc=max(1,int(self.lines_per_chunk.get()))
        except:lpc=90
        try:mc=max(100,int(self.max_chars.get())) if self.use_char_limit.get() else None
        except:mc=None
        files=[]
        for p in paths:
            try:
                text,enc=smart_read_text(p); chunks,n=split_text(text,lpc,mc)
                files.append(UploadFile(p,enc,n,chunks))
            except:pass
        q=[]; total=len(files)
        for fi,f in enumerate(files,1):
            for ci,ch in enumerate(f.chunks,1):
                content=(f"[{f.path.name}]\r\n"+ch) if self.prefix_filename.get() and ci==1 else ch
                q.append(UploadItem(f.path.name,fi,total,ci,len(f.chunks),content))
        self.upload_files=files; self.upload_queue=q; self.upload_signature=file_signature(paths) if paths else ""
        for x in self.upload_tree.get_children():self.upload_tree.delete(x)
        lines=0
        for i,f in enumerate(files,1):
            lines+=f.line_count
            self.upload_tree.insert("","end",values=(i,f.path.name,f.encoding,f"{f.line_count:,}",f"{len(f.chunks):,}"))
        self.upload_summary.set(f"TXT {len(files)}개 | 총 {lines:,}줄 | 메시지 {len(q):,}개")
        self.load_resume(); self.upload_status.set("input 폴더 분석 완료." if files else "input 폴더에 TXT 파일을 넣어 주세요.")
        self.upload_progress.set(0); self.upload_progress_text.set(f"0 / {len(q)}"); self.save_config()

    def load_resume(self):
        st=load_json(UPLOAD_STATE_FILE,{})
        self.upload_resume_index=0
        if self.upload_signature and st.get("signature")==self.upload_signature and 0<int(st.get("next_index",0))<len(self.upload_queue):
            self.upload_resume_index=int(st["next_index"]); label=f"이전 중단 지점부터 ({self.upload_resume_index+1}번째)"
            self.resume_combo["values"]=["처음부터",label]; self.upload_resume.set(label)
        else:
            self.resume_combo["values"]=["처음부터"]; self.upload_resume.set("처음부터")

    def reset_upload_state(self):
        try:UPLOAD_STATE_FILE.unlink(missing_ok=True)
        except:pass
        self.upload_resume.set("처음부터"); self.resume_combo["values"]=["처음부터"]

    def upload_start_index(self):
        return self.upload_resume_index if self.upload_resume.get().startswith("이전") else 0

    def upload_test(self):
        if self.upload_worker and self.upload_worker.is_alive():return
        self.refresh_input()
        if not self.upload_queue:return
        idx=self.upload_start_index(); self.upload_stop.clear()
        self.upload_worker=threading.Thread(target=self.upload_test_worker,args=(idx,),daemon=True); self.upload_worker.start()

    def upload_test_worker(self,idx):
        try:
            for sec in range(max(1,int(self.countdown.get())),0,-1):
                if self.upload_stop.is_set():return
                self.ui_queue.put(("upload_status",f"테스트 시작까지 {sec}초 — 메신저 입력창 클릭")); time.sleep(1)
            item=self.upload_queue[idx]; self.set_clip_thread(item.text); time.sleep(.12); send_ctrl_v()
            self.ui_queue.put(("upload_status",f"테스트 완료: {item.file_name} {item.chunk_index}/{item.chunk_total} 붙여넣음"))
        except Exception as e:self.ui_queue.put(("upload_error",str(e)))

    def upload_start(self):
        if self.upload_worker and self.upload_worker.is_alive():return
        self.refresh_input()
        if not self.upload_queue:return
        idx=self.upload_start_index()
        if not messagebox.askyesno("전체 자동 전송",f"남은 메시지 {len(self.upload_queue)-idx}개를 전송합니다. 계속할까요?"):return
        self.upload_stop.clear(); self.save_config()
        self.upload_worker=threading.Thread(target=self.upload_worker_func,args=(idx,),daemon=True); self.upload_worker.start()

    def set_clip_thread(self,text):
        done=threading.Event(); holder={"error":None}
        self.ui_queue.put(("clipboard_set",text,done,holder)); done.wait(5)
        if holder["error"]:raise holder["error"]

    def upload_worker_func(self,start):
        try:
            for sec in range(max(1,int(self.countdown.get())),0,-1):
                if self.upload_stop.is_set():return
                self.ui_queue.put(("upload_status",f"자동 전송 시작까지 {sec}초 — 입력창 클릭")); time.sleep(1)
            for idx in range(start,len(self.upload_queue)):
                if self.upload_stop.is_set():break
                it=self.upload_queue[idx]; self.set_clip_thread(it.text); time.sleep(.12); send_ctrl_v(); time.sleep(.12); send_enter(self.send_key.get()=="Ctrl+Enter")
                nxt=idx+1
                save_json(UPLOAD_STATE_FILE,{"signature":self.upload_signature,"next_index":nxt,"total":len(self.upload_queue),"updated_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
                pct=nxt/len(self.upload_queue)*100
                self.ui_queue.put(("upload_progress",nxt,len(self.upload_queue),pct))
                self.ui_queue.put(("upload_status",f"전송 중: {it.file_name} | {it.chunk_index}/{it.chunk_total}"))
                if nxt<len(self.upload_queue):
                    delay=float(self.file_delay.get()) if it.chunk_index==it.chunk_total else float(self.message_delay.get())
                    end=time.time()+max(.2,delay)
                    while time.time()<end:
                        if self.upload_stop.is_set():break
                        time.sleep(.05)
            if not self.upload_stop.is_set():self.ui_queue.put(("upload_status","업로드 완료."))
        except Exception as e:self.ui_queue.put(("upload_error",str(e)))

    def save_config(self):
        save_json(CONFIG_FILE,{
            "top_exclude_px":int(self.top_exclude_px.get() or 100),
            "scroll_amount":int(self.scroll_amount.get() or 6),
            "max_scroll_cycles":int(self.max_scroll_cycles.get() or 120),
            "bottom_stable_count":int(self.bottom_stable_count.get() or 3),
            "lines_per_chunk":int(self.lines_per_chunk.get() or 90),
            "message_delay":float(self.message_delay.get() or 1.0),
            "file_delay":float(self.file_delay.get() or 1.5),
            "countdown":int(self.countdown.get() or 5),
            "send_key":self.send_key.get(),
            "use_char_limit":bool(self.use_char_limit.get()),
            "max_chars":int(self.max_chars.get() or 10000),
            "prefix_filename":bool(self.prefix_filename.get())
        })

    def poll_escape(self):
        if escape_pressed():
            self.collect_stop.set(); self.upload_stop.set()
        self.after(80,self.poll_escape)

    def process_queue(self):
        try:
            while True:
                x=self.ui_queue.get_nowait(); k=x[0]
                if k=="collect_status":self.collect_status.set(x[1])
                elif k=="collect_progress":self.collect_progress.set(x[1])
                elif k=="collect_error":messagebox.showerror("자동 펼치기 오류",x[1])
                elif k=="upload_status":self.upload_status.set(x[1])
                elif k=="upload_progress":
                    self.upload_progress.set(x[3]); self.upload_progress_text.set(f"{x[1]} / {x[2]} ({x[3]:.1f}%)")
                elif k=="upload_error":messagebox.showerror("업로드 오류",x[1])
                elif k=="clipboard_set":
                    text,done,holder=x[1],x[2],x[3]
                    try:self.clipboard_clear(); self.clipboard_append(text); self.update()
                    except Exception as e:holder["error"]=e
                    finally:done.set()
        except queue.Empty:pass
        self.after(100,self.process_queue)

App().mainloop()
