# -*- coding: utf-8 -*-
"""
Windows 자동 타이핑 프로그램 (표준 라이브러리만 사용)

- '입력내용.txt'에 미리 저장된 텍스트를 키 입력으로 전송합니다.
- 시작 버튼 -> 3초 준비 -> 웹페이지의 입력란 클릭 -> 자동 타이핑
  * 준비 시간 동안 입력란을 클릭해도 3초가 지난 뒤 시작됩니다.
  * 3초 뒤에 클릭해도 해당 클릭 직후 시작됩니다.
- F9를 누르면 준비 중이든 입력 중이든 중단합니다.
- Ctrl+V를 사용하지 않습니다. 한글은 Windows SendInput(유니코드)으로 입력합니다.
"""

import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import queue
import struct
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk


if os.name != "nt":
    raise SystemExit("이 프로그램은 Windows에서만 실행할 수 있습니다.")

BASE_DIR = Path(__file__).resolve().parent
TEXT_PATH = BASE_DIR / "입력내용.txt"

# Windows 키보드 입력 API: x86/x64 구조체 크기에 모두 대응
ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("data", INPUT_UNION)]


user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT
user32.GetAsyncKeyState.argtypes = (ctypes.c_int,)
user32.GetAsyncKeyState.restype = wintypes.SHORT
user32.GetForegroundWindow.argtypes = ()
user32.GetForegroundWindow.restype = wintypes.HWND

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
VK_SHIFT = 0x10
VK_RETURN = 0x0D
VK_LBUTTON = 0x01
VK_F9 = 0x78


def key_event(vk=0, scan=0, flags=0):
    return INPUT(
        type=INPUT_KEYBOARD,
        data=INPUT_UNION(
            ki=KEYBDINPUT(wVk=vk, wScan=scan, dwFlags=flags, time=0, dwExtraInfo=0)
        ),
    )


def send_events(events):
    arr = (INPUT * len(events))(*events)
    sent = user32.SendInput(len(events), arr, ctypes.sizeof(INPUT))
    if sent != len(events):
        error = ctypes.get_last_error()
        raise OSError(error, "Windows가 키 입력을 허용하지 않았습니다. 관리자 권한/사이트 제한을 확인하세요.")


def send_unicode_character(ch):
    """클립보드 사용 없이 UTF-16 유니코드 키 입력을 발생시킵니다."""
    encoded = ch.encode("utf-16-le")
    words = struct.unpack("<" + "H" * (len(encoded) // 2), encoded)
    for code_unit in words:
        send_events([
            key_event(scan=code_unit, flags=KEYEVENTF_UNICODE),
            key_event(scan=code_unit, flags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP),
        ])


def send_newline(mode):
    # 채팅 웹사이트는 Enter만 누르면 글이 제출될 수 있어 Shift+Enter가 기본입니다.
    if mode == "Shift+Enter":
        send_events([
            key_event(vk=VK_SHIFT),
            key_event(vk=VK_RETURN),
            key_event(vk=VK_RETURN, flags=KEYEVENTF_KEYUP),
            key_event(vk=VK_SHIFT, flags=KEYEVENTF_KEYUP),
        ])
    else:
        send_events([
            key_event(vk=VK_RETURN),
            key_event(vk=VK_RETURN, flags=KEYEVENTF_KEYUP),
        ])


def key_held(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


class Aborted(Exception):
    pass


class AutoTypingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("한글 자동 타이핑 - Python")
        self.root.geometry("750x550")
        self.root.minsize(620, 440)
        self.running = False
        self.stop_event = threading.Event()
        self.messages = queue.Queue()
        self.delay_var = tk.StringVar(value="40")
        self.newline_var = tk.StringVar(value="Shift+Enter")
        self.status_var = tk.StringVar(value="준비 완료. 입력내용.txt를 확인한 뒤 시작하세요.")
        self.count_var = tk.StringVar(value="")

        frame = ttk.Frame(root, padding=18)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="자동 타이핑", font=("맑은 고딕", 17, "bold")).pack(anchor="w")
        ttk.Label(
            frame,
            text="시작 → 3초 준비 → 대상 웹페이지의 글 입력칸 클릭 → 한 글자씩 자동 입력",
            font=("맑은 고딕", 10),
        ).pack(anchor="w", pady=(5, 14))

        option = ttk.Frame(frame)
        option.pack(fill="x", pady=(0, 12))
        ttk.Label(option, text="글자 간격(ms)").pack(side="left")
        ttk.Entry(option, width=6, textvariable=self.delay_var).pack(side="left", padx=(6, 20))
        ttk.Label(option, text="줄바꿈").pack(side="left")
        ttk.Combobox(
            option, width=15, state="readonly", textvariable=self.newline_var,
            values=("Shift+Enter", "Enter"),
        ).pack(side="left", padx=(6, 20))
        ttk.Label(option, text="기본 40ms / 채팅창은 Shift+Enter 권장").pack(side="left")

        top = ttk.Frame(frame)
        top.pack(fill="x")
        ttk.Label(top, text="입력할 내용 (외부 TXT 파일)").pack(side="left")
        ttk.Button(top, text="메모장으로 수정", command=self.open_txt).pack(side="right")
        ttk.Button(top, text="새로고침", command=self.load_preview).pack(side="right", padx=(0, 6))

        preview_frame = ttk.Frame(frame)
        preview_frame.pack(fill="both", expand=True, pady=(7, 12))
        self.preview = tk.Text(
            preview_frame, wrap="word", font=("맑은 고딕", 10),
            state="disabled", relief="solid", borderwidth=1,
        )
        scrollbar = ttk.Scrollbar(preview_frame, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=scrollbar.set)
        self.preview.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        actions = ttk.Frame(frame)
        actions.pack(fill="x", pady=(0, 10))
        self.start_button = ttk.Button(actions, text="▶  시작 (3초 준비)", command=self.start)
        self.start_button.pack(side="left")
        ttk.Button(actions, text="중단 (F9)", command=self.stop).pack(side="left", padx=(8, 0))
        ttk.Label(actions, textvariable=self.count_var).pack(side="right")

        ttk.Label(frame, textvariable=self.status_var, foreground="#16477a").pack(anchor="w")
        ttk.Label(
            frame,
            text="중단: F9  |  입력되는 동안 마우스/키보드는 건드리지 마세요.  |  Ctrl+V 미사용",
            foreground="#555555",
        ).pack(anchor="w", pady=(5, 0))

        self.load_preview()
        self.root.after(100, self.poll_messages)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def read_text(self):
        if not TEXT_PATH.exists():
            TEXT_PATH.write_text("여기에 자동으로 입력할 문장을 작성하세요.\n", encoding="utf-8")
        return TEXT_PATH.read_text(encoding="utf-8-sig")

    def load_preview(self):
        try:
            content = self.read_text()
            self.preview.configure(state="normal")
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", content)
            self.preview.configure(state="disabled")
            self.count_var.set(f"총 {len(content):,}자")
            if not self.running:
                self.status_var.set(f"텍스트 파일: {TEXT_PATH.name} (저장 후 '시작'을 누르면 다시 읽습니다)")
        except Exception as exc:
            messagebox.showerror("파일 읽기 실패", str(exc))

    def open_txt(self):
        try:
            self.read_text()
            os.startfile(str(TEXT_PATH))
        except Exception as exc:
            messagebox.showerror("편집기 실행 실패", str(exc))

    def start(self):
        if self.running:
            return
        try:
            content = self.read_text().replace("\r\n", "\n").replace("\r", "\n")
            if not content.strip():
                messagebox.showwarning("입력 내용 없음", "입력내용.txt에 문장을 작성하고 저장하세요.")
                return
            delay_ms = int(self.delay_var.get())
            if not 5 <= delay_ms <= 1000:
                raise ValueError("글자 간격은 5~1000ms의 정수여야 합니다.")
        except (ValueError, OSError, UnicodeError) as exc:
            messagebox.showerror("설정 확인", str(exc))
            return

        self.load_preview()
        self.stop_event.clear()
        self.running = True
        self.start_button.configure(state="disabled")
        self.status_var.set("3초 준비 중. 웹사이트 입력칸을 클릭하세요.")
        self.root.withdraw()  # 웹사이트를 클릭할 수 있도록 프로그램 창 숨김
        worker = threading.Thread(
            target=self.worker, args=(content, delay_ms, self.newline_var.get()),
            daemon=True,
        )
        worker.start()

    def stop(self):
        if self.running:
            self.stop_event.set()
            self.status_var.set("중단 요청 중...")

    def check_abort(self):
        if self.stop_event.is_set() or key_held(VK_F9):
            raise Aborted()

    def worker(self, content, delay_ms, newline_mode):
        try:
            # 시작 버튼을 누른 마우스 클릭은 대상 웹페이지 클릭으로 취급하지 않습니다.
            while key_held(VK_LBUTTON):
                self.check_abort()
                time.sleep(0.01)

            begin = time.monotonic()
            clicked = False
            prev_down = False
            while time.monotonic() - begin < 3.0:
                self.check_abort()
                down = key_held(VK_LBUTTON)
                if down and not prev_down:
                    clicked = True
                prev_down = down
                time.sleep(0.01)

            if not clicked:
                self.messages.put(("status", "3초 경과. 대상 입력칸을 클릭하면 시작합니다."))
                # 3초 후에 클릭한 경우에도 동작하게 계속 기다립니다.
                prev_down = key_held(VK_LBUTTON)
                while not clicked:
                    self.check_abort()
                    down = key_held(VK_LBUTTON)
                    if down and not prev_down:
                        clicked = True
                    prev_down = down
                    time.sleep(0.01)

            # 클릭 해제 및 포커스 적용 대기
            while key_held(VK_LBUTTON):
                self.check_abort()
                time.sleep(0.01)
            time.sleep(0.18)
            self.check_abort()
            if not user32.GetForegroundWindow():
                raise RuntimeError("활성 창을 찾을 수 없습니다. 웹페이지를 먼저 열어 주세요.")

            self.messages.put(("status", "자동 타이핑 중... F9를 누르면 중단됩니다."))
            typed = 0
            for ch in content:
                self.check_abort()
                if ch == "\n":
                    send_newline(newline_mode)
                else:
                    send_unicode_character(ch)
                typed += 1
                if typed % 60 == 0:
                    self.messages.put(("count", f"입력 중 {typed:,}/{len(content):,}자"))
                time.sleep(delay_ms / 1000)
            self.messages.put(("done", f"완료: {typed:,}자를 입력했습니다."))
        except Aborted:
            self.messages.put(("done", "사용자가 F9로 자동 타이핑을 중단했습니다."))
        except Exception as exc:
            self.messages.put(("done", f"오류: {exc}"))

    def poll_messages(self):
        try:
            while True:
                kind, message = self.messages.get_nowait()
                if kind == "status":
                    self.status_var.set(message)
                elif kind == "count":
                    self.count_var.set(message)
                elif kind == "done":
                    self.running = False
                    self.start_button.configure(state="normal")
                    self.root.deiconify()
                    self.root.lift()
                    self.status_var.set(message)
                    self.count_var.set(f"총 {len(self.read_text()):,}자")
        except queue.Empty:
            pass
        self.root.after(100, self.poll_messages)

    def on_close(self):
        if self.running:
            self.stop_event.set()
            messagebox.showinfo("타이핑 중단", "입력 중단을 요청했습니다. F9로도 중단할 수 있습니다.")
        else:
            self.root.destroy()


def main():
    root = tk.Tk()
    try:
        ttk.Style(root).theme_use("clam")
    except tk.TclError:
        pass
    AutoTypingGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
