# -*- coding: utf-8 -*-
from __future__ import annotations
import ctypes, hashlib, json, os, sys, time, tkinter as tk
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

APP='Suresoft Messenger Sender'; VER='v0.2'
WIN=sys.platform.startswith('win')
VK_CTRL=0x11; VK_V=0x56; VK_ENTER=0x0D; VK_ESC=0x1B; KEYUP=0x0002
BASE=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
INPUT=BASE/'input'; LOGS=BASE/'logs'; STATE=BASE/'.sender_state.json'; CFG=BASE/'config.json'
INPUT.mkdir(exist_ok=True); LOGS.mkdir(exist_ok=True)

@dataclass
class FInfo:
    path: Path; encoding: str; lines: int; chunks: list[str]
@dataclass
class Item:
    file_name: str; file_no: int; file_total: int; chunk_no: int; chunk_total: int; text: str

def read_text(p:Path):
    b=p.read_bytes()
    if b.startswith(b'\xef\xbb\xbf'): return b.decode('utf-8-sig'),'UTF-8 BOM'
    if b.startswith(b'\xff\xfe'): return b.decode('utf-16'),'UTF-16 LE'
    if b.startswith(b'\xfe\xff'): return b.decode('utf-16'),'UTF-16 BE'
    try: return b.decode('utf-8'),'UTF-8'
    except UnicodeDecodeError: pass
    try: return b.decode('cp949'),'CP949'
    except UnicodeDecodeError: return b.decode('cp949',errors='replace'),'CP949(replace)'

def split_text(text, n=90, max_chars=None):
    t=text.replace('\r\n','\n').replace('\r','\n')
    lines=t.split('\n')
    if lines and lines[-1]=='' and t.endswith('\n'): lines=lines[:-1]
    if not lines: return [],0
    out=[]; cur=[]; chars=0
    for line in lines:
        if max_chars and len(line)>max_chars:
            if cur: out.append('\r\n'.join(cur)); cur=[]; chars=0
            for s in range(0,len(line),max_chars): out.append(line[s:s+max_chars])
            continue
        extra=len(line) if not cur else len(line)+2
        if cur and (len(cur)>=n or (max_chars and chars+extra>max_chars)):
            out.append('\r\n'.join(cur)); cur=[]; chars=0; extra=len(line)
        cur.append(line); chars+=extra
    if cur: out.append('\r\n'.join(cur))
    return out,len(lines)

def load_json(p, default):
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception: return default

def save_json(p, obj):
    try: p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception: pass

def sig(paths):
    h=hashlib.sha256()
    for p in paths:
        s=p.stat(); h.update(p.name.encode()); h.update(str(s.st_size).encode()); h.update(str(s.st_mtime_ns).encode())
    return h.hexdigest()

def key(vk, up=False):
    if WIN: ctypes.windll.user32.keybd_event(vk,0,KEYUP if up else 0,0)
def ctrl_v():
    key(VK_CTRL); key(VK_V); key(VK_V,True); key(VK_CTRL,True)
def enter(ctrl=False):
    if ctrl: key(VK_CTRL)
    key(VK_ENTER); key(VK_ENTER,True)
    if ctrl: key(VK_CTRL,True)
def esc_pressed():
    return WIN and bool(ctypes.windll.user32.GetAsyncKeyState(VK_ESC)&0x8000)

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title(f'{APP} {VER}'); self.geometry('900x735'); self.minsize(850,680)
        c=load_json(CFG,{})
        self.lines=tk.IntVar(value=c.get('lines_per_chunk',90)); self.delay=tk.DoubleVar(value=c.get('message_delay',1.0))
        self.file_delay=tk.DoubleVar(value=c.get('file_delay',1.5)); self.count=tk.IntVar(value=c.get('countdown',5))
        self.sendkey=tk.StringVar(value=c.get('send_key','Enter')); self.char_on=tk.BooleanVar(value=c.get('use_char_limit',False))
        self.maxchars=tk.IntVar(value=c.get('max_chars',10000)); self.prefix=tk.BooleanVar(value=c.get('prefix_filename',False))
        self.status=tk.StringVar(value='input 폴더 확인 중...'); self.summary=tk.StringVar(value='-'); self.prog=tk.DoubleVar(value=0); self.progtext=tk.StringVar(value='0 / 0')
        self.resume=tk.StringVar(value='처음부터'); self.files=[]; self.queue=[]; self.signature=''; self.resume_index=0
        self.running=False; self.stop=False; self.mode=''; self.idx=0; self.started=None; self.log=[]
        self.build(); self.refresh(); self.after(80,self.poll_esc)
        if not WIN: messagebox.showwarning('Windows 전용','자동 키 입력은 Windows에서만 동작합니다.')
    def build(self):
        o=ttk.Frame(self,padding=14); o.pack(fill='both',expand=True)
        ttk.Label(o,text=f'{APP} {VER}',font=('Malgun Gothic',17,'bold')).pack(anchor='w')
        ttk.Label(o,text='input 폴더의 모든 TXT → 파일명 순서 → 파일별 90줄 분할 → 메신저 연속 전송').pack(anchor='w',pady=(3,10))
        r=ttk.Frame(o); r.pack(fill='x',pady=(0,8)); ttk.Label(r,text='입력 폴더:').pack(side='left')
        e=ttk.Entry(r); e.pack(side='left',fill='x',expand=True,padx=7); e.insert(0,str(INPUT)); e.config(state='readonly')
        ttk.Button(r,text='폴더 열기',command=self.open_folder,width=10).pack(side='left',padx=(0,5)); ttk.Button(r,text='새로고침',command=self.refresh,width=10).pack(side='left')
        box=ttk.LabelFrame(o,text='1. input 폴더 TXT 목록'); box.pack(fill='both',expand=True,pady=(0,8))
        cols=('n','name','enc','lines','chunks'); self.tree=ttk.Treeview(box,columns=cols,show='headings',height=8)
        for c,t,w,a in [('n','#',45,'center'),('name','파일명',430,'w'),('enc','인코딩',110,'center'),('lines','줄 수',90,'e'),('chunks','메시지 수',90,'e')]:
            self.tree.heading(c,text=t); self.tree.column(c,width=w,anchor=a)
        self.tree.pack(fill='both',expand=True,padx=8,pady=8); ttk.Label(box,textvariable=self.summary).pack(anchor='w',padx=10,pady=(0,8))
        s=ttk.LabelFrame(o,text='2. 전송 설정'); s.pack(fill='x',pady=(0,8)); g=ttk.Frame(s); g.pack(fill='x',padx=10,pady=8)
        ttk.Label(g,text='줄 수/메시지').grid(row=0,column=0,sticky='w',padx=4,pady=4); ttk.Spinbox(g,from_=1,to=1000,textvariable=self.lines,width=9).grid(row=0,column=1,sticky='w')
        ttk.Label(g,text='메시지 간격(초)').grid(row=0,column=2,sticky='w',padx=(22,4)); ttk.Spinbox(g,from_=0.2,to=30,increment=0.1,textvariable=self.delay,width=9).grid(row=0,column=3,sticky='w')
        ttk.Label(g,text='파일 사이 대기(초)').grid(row=0,column=4,sticky='w',padx=(22,4)); ttk.Spinbox(g,from_=0.2,to=30,increment=0.1,textvariable=self.file_delay,width=9).grid(row=0,column=5,sticky='w')
        ttk.Label(g,text='카운트다운(초)').grid(row=1,column=0,sticky='w',padx=4,pady=4); ttk.Spinbox(g,from_=1,to=30,textvariable=self.count,width=9).grid(row=1,column=1,sticky='w')
        ttk.Label(g,text='전송 키').grid(row=1,column=2,sticky='w',padx=(22,4)); ttk.Combobox(g,textvariable=self.sendkey,values=['Enter','Ctrl+Enter'],state='readonly',width=11).grid(row=1,column=3,sticky='w')
        ttk.Checkbutton(g,text='첫 청크 앞 파일명 표시',variable=self.prefix).grid(row=1,column=4,columnspan=2,sticky='w',padx=(22,4))
        ttk.Checkbutton(g,text='최대 글자 수 제한',variable=self.char_on).grid(row=2,column=0,sticky='w',padx=4,pady=4); ttk.Spinbox(g,from_=100,to=100000,increment=100,textvariable=self.maxchars,width=10).grid(row=2,column=1,sticky='w')
        ttk.Label(g,text='시작 위치').grid(row=2,column=4,sticky='e',padx=(22,4)); self.resume_combo=ttk.Combobox(g,textvariable=self.resume,values=['처음부터'],state='readonly',width=22); self.resume_combo.grid(row=2,column=5,sticky='w')
        b=ttk.LabelFrame(o,text='3. 실행'); b.pack(fill='x',pady=(0,8)); ttk.Label(b,text='먼저 첫 메시지 붙여넣기 테스트 후 전체 자동 전송을 권장합니다.').pack(anchor='w',padx=10,pady=(8,5))
        rr=ttk.Frame(b); rr.pack(fill='x',padx=10,pady=(0,9)); ttk.Button(rr,text='첫 메시지 붙여넣기 테스트',command=self.test,width=24).pack(side='left',padx=(0,7)); ttk.Button(rr,text='전체 자동 전송 시작',command=self.start,width=20).pack(side='left',padx=(0,7)); ttk.Button(rr,text='긴급 중지',command=self.request_stop,width=13).pack(side='left',padx=(0,7)); ttk.Button(rr,text='진행상태 초기화',command=self.reset_state,width=15).pack(side='left')
        p=ttk.LabelFrame(o,text='4. 진행 상태'); p.pack(fill='x'); ttk.Label(p,textvariable=self.status,font=('Malgun Gothic',9,'bold')).pack(anchor='w',padx=10,pady=(8,4)); ttk.Progressbar(p,variable=self.prog,maximum=100).pack(fill='x',padx=10,pady=3); ttk.Label(p,textvariable=self.progtext).pack(anchor='e',padx=10,pady=(0,8))
        ttk.Label(o,text='긴급 중지: ESC 또는 긴급 중지 버튼. 전송 중에는 메신저 입력창 포커스를 유지하세요.',foreground='#555555').pack(anchor='w',pady=(8,0))
        self.lines.trace_add('write',lambda *_: self.after(250,self.refresh)); self.char_on.trace_add('write',lambda *_: self.after(250,self.refresh)); self.maxchars.trace_add('write',lambda *_: self.after(250,self.refresh))
    def open_folder(self):
        try: os.startfile(INPUT)
        except Exception as e: messagebox.showerror('오류',str(e))
    def refresh(self):
        if self.running: return
        paths=sorted([p for p in INPUT.iterdir() if p.is_file() and p.suffix.lower()=='.txt' and not p.name.startswith(('~','.'))],key=lambda p:p.name.lower())
        infos=[]; q=[]; errors=[]
        try: n=max(1,int(self.lines.get()))
        except: n=90
        try: mx=max(100,int(self.maxchars.get())) if self.char_on.get() else None
        except: mx=None
        for p in paths:
            try:
                t,e=read_text(p); ch,lc=split_text(t,n,mx); infos.append(FInfo(p,e,lc,ch))
            except Exception as ex: errors.append(f'{p.name}: {ex}')
        total=len(infos)
        for fi,f in enumerate(infos,1):
            for ci,ch in enumerate(f.chunks,1):
                text=(f'[{f.path.name}]\r\n'+ch) if self.prefix.get() and ci==1 else ch
                q.append(Item(f.path.name,fi,total,ci,len(f.chunks),text))
        self.files=infos; self.queue=q; self.signature=sig(paths) if paths else ''
        for x in self.tree.get_children(): self.tree.delete(x)
        tl=0
        for i,f in enumerate(infos,1): tl+=f.lines; self.tree.insert('', 'end', values=(i,f.path.name,f.encoding,f'{f.lines:,}',f'{len(f.chunks):,}'))
        self.summary.set(f'TXT {len(infos)}개 | 총 {tl:,}줄 | 전송 메시지 {len(q):,}개 | 파일명 오름차순')
        self.load_resume(); self.prog.set(0); self.progtext.set(f'0 / {len(q)}'); self.save_cfg()
        self.status.set('input 폴더 분석 완료. 테스트 후 전체 전송을 시작할 수 있습니다.' if infos else 'input 폴더에 .txt 파일을 넣고 새로고침하세요.')
        if errors: self.status.set(f'{len(infos)}개 로드 / {len(errors)}개 오류. 오류 파일은 제외됨.')
    def save_cfg(self):
        save_json(CFG,{'lines_per_chunk':int(self.lines.get() or 90),'message_delay':float(self.delay.get() or 1.0),'file_delay':float(self.file_delay.get() or 1.5),'countdown':int(self.count.get() or 5),'send_key':self.sendkey.get(),'use_char_limit':bool(self.char_on.get()),'max_chars':int(self.maxchars.get() or 10000),'prefix_filename':bool(self.prefix.get())})
    def load_resume(self):
        self.resume_index=0; st=load_json(STATE,{})
        if self.signature and st.get('signature')==self.signature and 0<int(st.get('next_index',0))<len(self.queue):
            self.resume_index=int(st['next_index']); label=f'이전 중단 지점부터 ({self.resume_index+1}번째 메시지)'; self.resume_combo.config(values=['처음부터',label]); self.resume.set(label)
        else: self.resume_combo.config(values=['처음부터']); self.resume.set('처음부터')
    def reset_state(self):
        if self.running: return
        try: STATE.unlink(missing_ok=True)
        except: pass
        self.resume_index=0; self.resume_combo.config(values=['처음부터']); self.resume.set('처음부터'); self.status.set('진행상태 초기화 완료.')
    def ready(self):
        if self.running: messagebox.showwarning('실행 중','이미 작업이 진행 중입니다.'); return False
        if not self.queue: messagebox.showwarning('내용 없음','input 폴더에 TXT 파일을 넣고 새로고침하세요.'); return False
        return True
    def start_index(self): return self.resume_index if self.resume.get().startswith('이전 중단') else 0
    def test(self):
        if not self.ready(): return
        self.refresh(); self.mode='test'; self.idx=self.start_index(); self.begin()
    def start(self):
        if not self.ready(): return
        self.refresh(); s=self.start_index(); rem=len(self.queue)-s
        if not messagebox.askyesno('전체 자동 전송 확인',f'TXT {len(self.files)}개 / 남은 메시지 {rem}개를 순차 전송합니다.\n\n카운트다운 동안 Suresoft Messenger의 본인 대화방 입력창을 클릭하세요.\n전송 중에는 다른 창을 클릭하지 않는 것이 안전합니다.\n\n계속하시겠습니까?'): return
        self.mode='send'; self.idx=s; self.begin()
    def begin(self): self.running=True; self.stop=False; self.left=max(1,int(self.count.get())); self.save_cfg(); self.tick()
    def tick(self):
        if self.stop: self.finish_stop('시작 전에 중지되었습니다.'); return
        if self.left>0:
            self.status.set(f"{'붙여넣기 테스트' if self.mode=='test' else '자동 전송'} 시작까지 {self.left}초 — 지금 메신저 입력창을 클릭하세요."); self.left-=1; self.after(1000,self.tick); return
        if self.mode=='test': self.do_test()
        else: self.started=datetime.now(); self.log=[]; self.send_current()
    def set_clip(self,text): self.clipboard_clear(); self.clipboard_append(text); self.update(); time.sleep(0.08)
    def do_test(self):
        try:
            it=self.queue[self.idx]; self.set_clip(it.text); ctrl_v(); self.status.set(f'테스트 완료: {it.file_name} / {it.chunk_no}/{it.chunk_total} 청크를 붙여넣었습니다. 전송키는 누르지 않았습니다.'); self.running=False
        except Exception as e: self.running=False; messagebox.showerror('테스트 오류',str(e))
    def send_current(self):
        if self.stop: self.finish_stop('사용자 요청으로 중지되었습니다.'); return
        if self.idx>=len(self.queue): self.finish_complete(); return
        it=self.queue[self.idx]
        try: self.set_clip(it.text); ctrl_v(); self.after(120,lambda:self.press_send(it))
        except Exception as e: self.stop=True; self.finish_stop(f'오류로 중지: {e}')
    def press_send(self,it):
        if self.stop: self.finish_stop('사용자 요청으로 중지되었습니다.'); return
        try:
            enter(self.sendkey.get()=='Ctrl+Enter'); now=datetime.now(); self.log.append(f'{now:%Y-%m-%d %H:%M:%S}\t{self.idx+1}/{len(self.queue)}\t{it.file_name}\tchunk {it.chunk_no}/{it.chunk_total}')
            nxt=self.idx+1; save_json(STATE,{'signature':self.signature,'next_index':nxt,'total':len(self.queue),'updated_at':now.strftime('%Y-%m-%d %H:%M:%S')}); pct=nxt/len(self.queue)*100; self.prog.set(pct); self.progtext.set(f'{nxt} / {len(self.queue)} ({pct:.1f}%)'); self.status.set(f'전송 중: 파일 {it.file_no}/{it.file_total} {it.file_name} | 청크 {it.chunk_no}/{it.chunk_total}')
            done_file=it.chunk_no==it.chunk_total; self.idx=nxt
            if self.idx>=len(self.queue): self.after(200,self.finish_complete); return
            d=float(self.file_delay.get()) if done_file else float(self.delay.get()); self.after(max(200,int(d*1000)),self.send_current)
        except Exception as e: self.stop=True; self.finish_stop(f'오류로 중지: {e}')
    def request_stop(self):
        if self.running: self.stop=True; self.status.set('중지 요청됨. 현재 동작 후 멈춥니다.')
    def finish_stop(self,reason):
        self.running=False; self.stop=True
        if self.mode=='send': self.write_log('STOPPED')
        self.status.set(f'{reason} 다음 시작 위치: {min(self.idx+1,len(self.queue)) if self.queue else 0}번째 메시지.'); self.load_resume()
    def finish_complete(self):
        self.running=False; self.stop=False; self.prog.set(100); self.progtext.set(f'{len(self.queue)} / {len(self.queue)} (100.0%)'); self.status.set(f'완료: TXT {len(self.files)}개 / 메시지 {len(self.queue)}개 전송 처리.'); self.write_log('COMPLETED')
        save_json(STATE,{'signature':self.signature,'next_index':len(self.queue),'total':len(self.queue),'updated_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S')}); self.resume_combo.config(values=['처음부터']); self.resume.set('처음부터')
    def write_log(self,status):
        if not self.started: return
        p=LOGS/f"send_log_{self.started:%Y%m%d_%H%M%S}.txt"; head=[f'{APP} {VER}',f'Status: {status}',f'Started: {self.started:%Y-%m-%d %H:%M:%S}',f'Finished: {datetime.now():%Y-%m-%d %H:%M:%S}',f'Input: {INPUT}',f'Files: {len(self.files)}',f'Messages: {len(self.queue)}','']
        try: p.write_text('\n'.join(head+self.log),encoding='utf-8')
        except: pass
    def poll_esc(self):
        if self.running and esc_pressed(): self.stop=True; self.status.set('ESC 감지 — 중지 요청됨.')
        self.after(80,self.poll_esc)

if __name__=='__main__': App().mainloop()
