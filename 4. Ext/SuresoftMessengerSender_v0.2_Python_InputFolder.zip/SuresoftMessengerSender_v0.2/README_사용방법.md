# Suresoft Messenger Sender v0.2

## 사용 방식
1. `input` 폴더에 전송할 TXT 파일들을 넣습니다.
2. `SuresoftMessengerSender_v0.2.pyw`를 실행합니다.
3. 프로그램은 `.txt` 파일을 **파일명 오름차순**으로 읽습니다.
4. 각 파일을 기본 **90줄씩** 분할합니다.
5. `첫 메시지 붙여넣기 테스트`로 확인합니다.
6. 정상이라면 `전체 자동 전송 시작`을 누릅니다.
7. 카운트다운 동안 Suresoft Messenger의 본인 대화방 입력창을 클릭합니다.
8. 이후 전체 TXT가 순서대로 `Ctrl+V → Enter` 방식으로 전송됩니다.

## 폴더 구조
```text
SuresoftMessengerSender_v0.2/
├─ SuresoftMessengerSender_v0.2.pyw
├─ config.json
├─ input/       ← 여기에 TXT 파일 넣기
├─ logs/        ← 전송 로그
├─ sample/      ← 샘플 TXT
└─ README_사용방법.md
```

## input 규칙
- `.txt`만 읽습니다.
- 파일명 앞이 `.` 또는 `~`인 파일은 제외합니다.
- 파일명 오름차순으로 처리합니다.

예: `001_first.txt` → `002_second.txt` → `003_third.txt`

각 파일은 개별적으로 90줄씩 분할됩니다.

## 주요 기능
- 여러 TXT 일괄 처리
- 파일별 90줄 분할
- 첫 메시지 붙여넣기 테스트
- 메시지 간격 / 파일 사이 대기 설정
- Enter / Ctrl+Enter 선택
- ESC 긴급중지
- 중단 지점 저장 및 재개
- `logs` 폴더에 전송 로그 저장
- UTF-8 / UTF-16 / CP949 대응
- 첫 청크 앞 파일명 표시 옵션(기본 OFF)

## 실행 조건
- Windows
- Python 3.11~3.13 권장
- 별도 pip 패키지 설치 필요 없음 (표준 라이브러리만 사용)

## 주의
v0.2는 아직 메신저 창이나 본인 대화방을 자동으로 찾지는 않습니다.
카운트다운 중 직접 해당 입력창을 한 번 클릭해야 합니다. 자동 전송 중 다른 창으로 포커스를 옮기지 않는 것을 권장합니다.
