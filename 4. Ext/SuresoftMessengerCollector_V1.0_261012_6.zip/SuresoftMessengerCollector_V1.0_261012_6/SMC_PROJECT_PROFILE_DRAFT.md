# SMC Project Profile (DRAFT)

- Project ID: `SMC`
- Project Name: `Suresoft Messenger Collector`
- Status: `DRAFT`
- Profile Version: `v0.7`
- Requirements Mode: `DUAL_LAYER_XLSX_V1`
- Requirements Pattern: `SuresoftMessengerCollector_Requirements_v*.xlsx`
- Package Pattern: `SuresoftMessengerCollector_V<major>.<minor>_YYMMDD_N.zip`
- Primary Environment: Android / Java 17 / AccessibilityService / Suresoft Messenger (`com.daou.go_mobile`)

## Version rule
`v0.4 -> ... -> v0.9 -> v1.0 -> ...`

Functional releases increment by `0.1`. Technical Version and ZIP Package Sequence are independent.

## Functional boundary
- Target chat: `박동천` (나와의 대화) only.
- Text messages only.
- Attachments/images/deleted attachment UI: always ignored.
- No automatic send action.
- No Internet permission.
- One user-selected collection date per session; default is device local date.
- Start/end time selectable within the selected date.

## v1.0 baseline policy
1. Date bounds are evaluated before time/message logic.
2. Before Active Time Group exists, unresolved messages remain Pending.
3. After Active Time Group exists, in-date text bubbles use Capture-First and do not wait for bubble tail visibility.
4. Long/truncated preview cannot prove duplicate identity before full text is read.
5. Full text + time is authoritative for final dedupe.
6. Screen Y/bounds are never persistent message identifiers.
7. Pending Queue remaining at scroll end is ERROR, not silent COMPLETE.
8. Diagnostic TXT must expose enough evidence to distinguish scan, time-group, preview-dedupe, full-text and pending failures.

9. v1.0 distinguishes terminal states as COMPLETE / STOPPED / ERROR and stores finish timestamp/reason.
10. v1.0 does not intentionally alter the validated v0.9 collection algorithm.

## DRAFT reason
The common Governance requires a newly introduced Project ID to remain `DRAFT` until the user explicitly approves the Project ID/profile.

## Open issue
The source currently carries a development signing keystore to preserve APK update compatibility between internal test versions. Before production/external distribution, secure signing should replace the embedded test key.
