# Suresoft Messenger Collector Architecture v0.7

- Technical App Version: v1.0
- Requirements: SuresoftMessengerCollector_Requirements_v0.7.xlsx
- Target package: `com.daou.go_mobile`
- Target room: `박동천` (나와의 대화)
- Internet permission: none
- Attachments/images/deleted attachments: always ignored

## 1. State Machine

Collection path:
`WAIT_ROOM -> ROOM_STABILIZING -> SEEK_DATE -> RUNNING -> WAIT_COPY_MENU -> WAIT_PASTE -> WAIT_PASTE_READ -> UI_RECOVERY -> RUNNING`

Terminal states:
- Normal automatic completion -> `COMPLETE`
- User presses collection stop -> `STOPPED`
- Non-recoverable automation failure -> `ERROR`

`STOPPED` is intentionally distinct from `COMPLETE` in v1.0.

## 2. v1.0 Baseline Decision

The v0.9 real-device result produced 9 timestamped message blocks for the target 9-message regression sequence. v1.0 therefore treats the v0.9 collection algorithm as the functional baseline and limits changes to terminal-state presentation and metadata.

No intentional change is made to:
- selected-date bounds
- explicit/inherited time-group logic
- capture-first long-message behavior
- overlap scroll
- long preview pre-dedupe bypass
- exact full-text repository dedupe
- pending queue completeness guard

## 3. Completion Semantics

`COMPLETE` is allowed only through existing normal completion gates:
1. explicit in-date created_at proves configured end time crossed;
2. next-date divider reached after target-date processing;
3. no newer scroll is possible and no unresolved Pending Queue remains.

A timer alone never means complete.

## 4. User-visible Completion

On normal completion:
- service stores `PHASE_COMPLETE`;
- service stores `finished_at` and `finish_reason`;
- service status becomes `✅ 완료됨 · 총 N건 · <reason>`;
- Messenger foreground receives a long Toast: `✅ 완료됨 · N건 수집...`;
- Collector status card remains green and shows `✅ 완료됨`, count, phase and finish time.

## 5. Stop Semantics

When the user presses `[수집 중지]`:
- active=false;
- phase=`STOPPED`;
- finished_at is stored;
- finish_reason=`사용자 중지`;
- Collector displays `⚠️ 중지됨` with yellow status card.

This prevents manual stop from being mistaken for verified automatic completion.

## 6. Error Semantics

On non-recoverable automation failure:
- active=false;
- phase=`ERROR`;
- finished_at and error reason are stored;
- status begins with `❌ 오류`;
- Messenger foreground receives an error Toast;
- Collector displays a red error card.

## 7. Diagnostics

Diagnostic TXT includes:
- Active / Phase / Status
- Finished at
- Finish reason
- collected count
- date bounds / end decision
- Active Time Group
- pending/retry state
- result snapshot
- trace log

## 8. Regression Protection

v1.0 PASS requires both:
- v0.9 9-message collection regression remains 9/9; and
- COMPLETE / STOPPED / ERROR are visually and logically distinguishable.
