# CHANGELOG

## v1.0 — 2026-10-12

### Added
- 정상 완료 시 Messenger에 `✅ 완료됨 · N건 수집` 안내.
- Collector 상태 영역에 지속적인 `✅ 완료됨` 표시.
- 별도 `STOPPED` phase와 `⚠️ 중지됨` 표시.
- 오류 상태 `❌ 오류` 명시.
- `finished_at`, `finish_reason` 종료 메타데이터 및 진단 로그 출력.

### Baseline
- v0.9 실기기 9-message 회귀 결과에서 9개 시간 블록 저장 확인.
- v1.0은 v0.9 수집 알고리즘을 기능 기준선으로 동결하고 종료상태 UX만 정리.

### Retained
- Date-Bounded Time Group
- Capture-First long message
- long-preview pre-dedupe bypass
- exact full-text dedupe
- Pending Queue guard
- overlap scroll / 첨부파일 제외 / 자동 전송 금지

## v0.9 — 2026-10-12

### Fixed
- v0.8에서 긴 `Part 2/2` 메시지가 말풍선 하단/`created_at`을 기다리다가 화면을 지나쳐 9개 중 7개만 수집되던 경로 수정.
- 서로 다른 긴 Part 메시지가 동일한 약 353자 preview prefix를 공유할 때 preview 기반 사전 중복판정으로 누락될 수 있는 위험 제거.

### Changed
- Active Time Group 확정 후 후속 텍스트는 tail-visible 조건 없이 Capture-First.
- 300자 이상 long preview는 pre-copy dedupe 우회.
- full text exact dedupe를 최종 권위로 유지.
- uniqueId 미지원 시 node hash + preview fingerprint를 best-effort identity로 사용.
- Pending Queue 세션 추적 추가.

### Diagnostics
- `PREVIEW_DEDUPE bypass` 로그 추가.
- `CAPTURE success`에 `fullHash` 추가.
- 오류 TXT에 `Pending queue size` 추가.

### Retained
- v0.8 date-bounded time group
- explicit in-bound end gate
- monotonic Active Time Group
- overlap scroll
- 첨부파일 제외
- 자동 전송 금지
- Long Press 최대 3회 재시도
