package com.example.suresoftmessengercollector;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SAVE = 3003;
    private static final int REQ_SAVE_LOG = 3004;
    private static final String TARGET_PACKAGE = "com.daou.go_mobile";

    private TextView statusView;
    private TextView resultView;
    private Button dateButton;
    private Button startTimeButton;
    private Button endTimeButton;

    private int startMinutes = 0;
    private int endMinutes;
    private String targetDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Date now = new Date();
        targetDate = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(now);
        java.util.Calendar c = java.util.Calendar.getInstance();
        endMinutes = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshResults();
    }

    private View buildUi() {
        int p = dp(18);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Suresoft Messenger Collector v1.0");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(0, 92, 108));
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("선택한 날짜의 '박동천(나와의 대화)'에서 지정한 시작~종료 시간 메시지만 연속 수집합니다.\n\n"
                + "v1.0은 v0.9의 9건 완전 수집 로직을 기준선으로 유지하면서, 정상 완료/사용자 중지/오류 상태를 명확하게 구분해 표시합니다. 정상 완료 시 Messenger 화면에는 '✅ 완료됨 · N건' 안내가 표시되고, Collector로 돌아오면 완료 상태와 종료 시각이 계속 남습니다.\n\n"
                + "텍스트 메시지만 Long Press → '텍스트 복사'를 사용하며, 첨부파일·사진·삭제된 첨부파일은 자동으로 무시합니다.\n\n"
                + "[수집 시작] 후 Messenger 실행/이동 시간은 3초 대기시간에 포함하지 않습니다. '박동천' 방이 실제로 감지된 순간부터 3초 안정화 후 날짜 탐색을 시작합니다.\n\n"
                + "복사 원문은 Suresoft Messenger 입력창에 임시 붙여넣어 읽은 뒤 즉시 원래 입력 상태로 복원합니다. Long Press 실패는 재시도하며, 화면 Y좌표는 메시지 ID로 사용하지 않습니다. 같은 메시지 재복사를 줄이고, 시간 그룹이 아직 확정되지 않은 첫 구간만 Pending으로 유지합니다. 전송 버튼은 누르지 않습니다.\n\n"
                + "인터넷 권한 없음 · 대상 대화방은 '박동천'으로 고정");
        desc.setTextSize(15);
        desc.setLineSpacing(0f, 1.2f);
        desc.setPadding(0, 0, 0, dp(14));
        root.addView(desc);

        dateButton = button("수집 날짜: " + targetDate + " (기본: 오늘)");
        dateButton.setOnClickListener(v -> pickDate());
        root.addView(dateButton);

        startTimeButton = button("시작 시간: " + CollectionRepository.formatMinutes(startMinutes));
        startTimeButton.setOnClickListener(v -> pickTime(true));
        root.addView(startTimeButton);

        endTimeButton = button("종료 시간: " + CollectionRepository.formatMinutes(endMinutes));
        endTimeButton.setOnClickListener(v -> pickTime(false));
        root.addView(endTimeButton);

        TextView fixedRules = new TextView(this);
        fixedRules.setText("고정 규칙: 첨부파일 무시 · 삭제 메시지 무시 · 중복 제거 · 결과는 오래된→최신 순서");
        fixedRules.setTextSize(14);
        fixedRules.setPadding(dp(8), dp(6), dp(8), dp(14));
        root.addView(fixedRules);

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(statusView);

        Button accessibility = button("1. 접근성 설정 열기");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button start = button("2. 지정 날짜/시간 범위 수집 시작");
        start.setOnClickListener(v -> startCollection());
        root.addView(start);

        Button stop = button("3. 수집 중지");
        stop.setOnClickListener(v -> stopCollection());
        root.addView(stop);

        Button refresh = button("상태 / 결과 새로고침");
        refresh.setOnClickListener(v -> {
            refreshStatus();
            refreshResults();
        });
        root.addView(refresh);

        Button save = button("수집 결과 TXT 저장");
        save.setOnClickListener(v -> saveResult());
        root.addView(save);

        Button saveLog = button("오류/진단 로그 TXT 생성");
        saveLog.setOnClickListener(v -> saveDiagnosticLog());
        root.addView(saveLog);

        Button clear = button("수집 결과 초기화");
        clear.setOnClickListener(v -> clearSession());
        root.addView(clear);

        TextView guide = new TextView(this);
        guide.setText("\n사용 순서\n"
                + "① 수집 날짜와 시작/종료 시간을 지정합니다. 날짜 기본값은 앱을 연 당일입니다.\n"
                + "② [지정 날짜/시간 범위 수집 시작]을 누릅니다. 이 시점에는 3초 타이머가 아직 시작되지 않습니다.\n"
                + "③ Suresoft Messenger가 열리면 사용자가 상단 고정 '박동천' 방으로 들어갑니다.\n"
                + "④ Collector가 '박동천' 방과 대화 UI를 확인한 순간부터 3초 안정화 대기를 시작합니다.\n"
                + "⑤ 이후 Collector가 선택 날짜 구분선을 찾습니다. 필요하면 과거 방향으로 이동하지만, 이 단계에서는 메시지를 복사하지 않습니다.\n"
                + "⑥ 선택 날짜 구분선이 확인되면 방향을 전환해 작은 겹침 스크롤로 오래된→최신 방향을 이동하면서 지정 시간 범위의 텍스트 메시지를 수집합니다.\n"
                + "⑦ 정상 종료 조건이 확인되면 Messenger 화면에 '✅ 완료됨 · N건'이 표시됩니다. Collector로 돌아오면 완료 상태/종료 시각이 계속 표시됩니다.\n⑧ 사용자가 직접 중지하면 '⚠️ 중지됨', 자동화 오류이면 '❌ 오류'로 구분합니다.\n⑨ 누락/정지/오류가 의심되면 [오류/진단 로그 TXT 생성]을 눌러 진단 로그를 저장해 공유할 수 있습니다.\n\n"
                + "※ 방 감지 전의 Messenger 실행/탭 이동 시간은 안정화 3초에 포함되지 않습니다. '3초 후 자동 수집' 안내가 뜬 뒤에는 완료될 때까지 화면을 조작하지 마세요.");
        guide.setTextSize(14);
        guide.setLineSpacing(0f, 1.2f);
        guide.setPadding(0, dp(8), 0, dp(16));
        root.addView(guide);

        resultView = new TextView(this);
        resultView.setTextSize(14);
        resultView.setTextIsSelectable(true);
        resultView.setPadding(dp(12), dp(12), dp(12), dp(28));
        root.addView(resultView);

        return scroll;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void pickDate() {
        Calendar cal = Calendar.getInstance();
        try {
            Date parsed = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).parse(targetDate);
            if (parsed != null) cal.setTime(parsed);
        } catch (Exception ignored) {
        }
        DatePickerDialog dlg = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            targetDate = String.format(Locale.KOREA, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            dateButton.setText("수집 날짜: " + targetDate + " (기본: 오늘)");
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        dlg.getDatePicker().setMaxDate(System.currentTimeMillis());
        dlg.show();
    }

    private void pickTime(boolean start) {
        int current = start ? startMinutes : endMinutes;
        int h = current / 60;
        int m = current % 60;
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            int value = hourOfDay * 60 + minute;
            if (start) {
                startMinutes = value;
                startTimeButton.setText("시작 시간: " + CollectionRepository.formatMinutes(value));
            } else {
                endMinutes = value;
                endTimeButton.setText("종료 시간: " + CollectionRepository.formatMinutes(value));
            }
        }, h, m, true).show();
    }

    private void startCollection() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "먼저 접근성 서비스를 켜주세요.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if (endMinutes < startMinutes) {
            Toast.makeText(this, "같은 날짜 안에서 시작 시간이 종료 시간보다 빨라야 합니다.", Toast.LENGTH_LONG).show();
            return;
        }

        CollectionRepository.clear(this);
        LogRepository.clear(this);
        prefs().edit()
                .putBoolean(CollectorAccessibilityService.KEY_ACTIVE, true)
                .putString(CollectorAccessibilityService.KEY_PHASE, CollectorAccessibilityService.PHASE_WAIT_ROOM)
                .putString(CollectorAccessibilityService.KEY_STATUS, "'박동천' 대화방을 기다리는 중...")
                .putString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate)
                .putInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes)
                .putInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes)
                .putInt(CollectorAccessibilityService.KEY_CAPTURE_ORDER, 0)
                .putInt(CollectorAccessibilityService.KEY_COLLECTED_COUNT, 0)
                .putStringSet(CollectorAccessibilityService.KEY_PROCESSED, new HashSet<>())
                .putStringSet(CollectorAccessibilityService.KEY_PENDING_QUEUE, new HashSet<>())
                .putString(CollectorAccessibilityService.KEY_LAST_SCREEN_SIGNATURE, "")
                .putInt(CollectorAccessibilityService.KEY_STALE_SCROLLS, 0)
                .putInt(CollectorAccessibilityService.KEY_PASTE_RETRY, 0)
                .putInt(CollectorAccessibilityService.KEY_ROOM_STABILIZE_RETRY, 0)
                .putBoolean(CollectorAccessibilityService.KEY_TARGET_DATE_FOUND, false)
                .putString(CollectorAccessibilityService.KEY_SEEK_DIRECTION, "OLDER")
                .putString(CollectorAccessibilityService.KEY_LONG_CLICK_RETRY_KEY, "")
                .putInt(CollectorAccessibilityService.KEY_LONG_CLICK_RETRY_COUNT, 0)
                .putString(CollectorAccessibilityService.KEY_PENDING_TIME_KEY, "")
                .putInt(CollectorAccessibilityService.KEY_PENDING_TIME_RETRY, 0)
                .putInt(CollectorAccessibilityService.KEY_ACTIVE_GROUP_MINUTES, -1)
                .putString(CollectorAccessibilityService.KEY_ACTIVE_GROUP_TEXT, "")
                .putString(CollectorAccessibilityService.KEY_LAST_DATE_BOUNDS, "UNSET")
                .putString(CollectorAccessibilityService.KEY_LAST_END_DECISION, "NONE")
                .putLong(CollectorAccessibilityService.KEY_FINISHED_AT, 0L)
                .putString(CollectorAccessibilityService.KEY_FINISH_REASON, "")
                .apply();
        LogRepository.append(this, timestamp() + " | BATCH START date=" + targetDate
                + " range=" + CollectionRepository.formatMinutes(startMinutes)
                + "~" + CollectionRepository.formatMinutes(endMinutes) + "\n");
        refreshStatus();
        refreshResults();

        Intent launch = getPackageManager().getLaunchIntentForPackage(TARGET_PACKAGE);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(launch);
            Toast.makeText(this, "Suresoft Messenger에서 '박동천' 방으로 들어가세요. 방 확인 후 3초 안정화 → 선택 날짜 탐색 순으로 진행됩니다.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Suresoft Messenger 실행 정보를 찾지 못했습니다. 직접 열어주세요.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopCollection() {
        int count = CollectionRepository.count(this);
        prefs().edit()
                .putBoolean(CollectorAccessibilityService.KEY_ACTIVE, false)
                .putString(CollectorAccessibilityService.KEY_PHASE, CollectorAccessibilityService.PHASE_STOPPED)
                .putString(CollectorAccessibilityService.KEY_STATUS, "⚠️ 중지됨 · 사용자가 수집 중지 · 현재 " + count + "건")
                .putInt(CollectorAccessibilityService.KEY_COLLECTED_COUNT, count)
                .putLong(CollectorAccessibilityService.KEY_FINISHED_AT, System.currentTimeMillis())
                .putString(CollectorAccessibilityService.KEY_FINISH_REASON, "사용자 중지")
                .apply();
        LogRepository.append(this, timestamp() + " | USER STOP count=" + count + "\n");
        Toast.makeText(this, "⚠️ 중지됨 · 현재 " + count + "건", Toast.LENGTH_LONG).show();
        refreshStatus();
        refreshResults();
    }

    private void clearSession() {
        prefs().edit().clear().apply();
        CollectionRepository.clear(this);
        LogRepository.clear(this);
        Toast.makeText(this, "수집 결과를 초기화했습니다.", Toast.LENGTH_SHORT).show();
        refreshStatus();
        refreshResults();
    }

    private void refreshStatus() {
        SharedPreferences p = prefs();
        boolean enabled = isAccessibilityEnabled();
        boolean active = p.getBoolean(CollectorAccessibilityService.KEY_ACTIVE, false);
        String phase = p.getString(CollectorAccessibilityService.KEY_PHASE, CollectorAccessibilityService.PHASE_IDLE);
        String status = p.getString(CollectorAccessibilityService.KEY_STATUS, "대기");
        int count = CollectionRepository.count(this);
        long finishedAt = p.getLong(CollectorAccessibilityService.KEY_FINISHED_AT, 0L);

        String headline;
        int background;
        if (CollectorAccessibilityService.PHASE_COMPLETE.equals(phase)) {
            headline = "✅ 완료됨";
            background = Color.rgb(218, 245, 226);
        } else if (CollectorAccessibilityService.PHASE_STOPPED.equals(phase)) {
            headline = "⚠️ 중지됨";
            background = Color.rgb(255, 244, 204);
        } else if (CollectorAccessibilityService.PHASE_ERROR.equals(phase)) {
            headline = "❌ 오류";
            background = Color.rgb(255, 224, 224);
        } else if (active) {
            headline = "⏳ 수집 중";
            background = Color.rgb(226, 240, 250);
        } else {
            headline = "대기";
            background = enabled ? Color.rgb(226, 245, 236) : Color.rgb(255, 238, 230);
        }

        String finishedText = finishedAt > 0L
                ? "\n종료 시각: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA).format(new Date(finishedAt))
                : "";

        statusView.setText(headline
                + "\n\n접근성 서비스: " + (enabled ? "ON" : "OFF")
                + "\n자동 수집: " + (active ? "진행 중" : "정지")
                + "\n단계: " + phase
                + "\n누적 수집: " + count + "건"
                + finishedText
                + "\n상태: " + status);
        statusView.setBackgroundColor(background);
    }

    private void refreshResults() {
        SharedPreferences p = prefs();
        int count = CollectionRepository.count(this);
        String log = LogRepository.read(this);
        String preview = CollectionRepository.exportText(
                this,
                p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate),
                p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes),
                p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes));
        if (preview.length() > 5000) preview = preview.substring(0, 5000) + "\n...(화면 미리보기 생략)...";

        resultView.setText("[요약]\n"
                + "대상: 박동천 (나와의 대화)\n"
                + "날짜: " + p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate) + "\n"
                + "시간: " + CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes))
                + " ~ " + CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes)) + "\n"
                + "수집 메시지: " + count + "건\n"
                + "첨부파일: 자동 제외\n"
                + "감지 Package: " + p.getString(CollectorAccessibilityService.KEY_LAST_PACKAGE, "아직 감지되지 않음") + "\n\n"
                + "[결과 미리보기]\n" + preview + "\n\n"
                + "[동작 로그]\n" + (log.isEmpty() ? "아직 로그 없음" : log));
    }

    private void saveResult() {
        if (CollectionRepository.count(this) == 0) {
            Toast.makeText(this, "저장할 수집 메시지가 없습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        SharedPreferences p = prefs();
        String date = p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate);
        String title = "SuresoftMessenger_박동천_" + date.replace("-", "")
                + "_" + CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes)).replace(":", "")
                + "-" + CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes)).replace(":", "")
                + ".txt";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, title);
        startActivityForResult(intent, REQ_SAVE);
    }

    private void saveDiagnosticLog() {
        String title = "SuresoftMessengerCollector_v1.0_DiagnosticLog_"
                + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date()) + ".txt";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, title);
        startActivityForResult(intent, REQ_SAVE_LOG);
    }

    private String buildDiagnosticReport() {
        SharedPreferences p = prefs();
        StringBuilder sb = new StringBuilder();
        sb.append("Suresoft Messenger Collector v1.0 Diagnostic Log\n");
        sb.append("Generated: ").append(timestamp()).append('\n');
        sb.append("Target package: ").append(TARGET_PACKAGE).append('\n');
        sb.append("Target chat: 박동천\n");
        sb.append("Target date: ").append(p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate)).append('\n');
        sb.append("Range: ")
                .append(CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes)))
                .append(" ~ ")
                .append(CollectionRepository.formatMinutes(p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes)))
                .append('\n');
        sb.append("Active: ").append(p.getBoolean(CollectorAccessibilityService.KEY_ACTIVE, false)).append('\n');
        sb.append("Phase: ").append(p.getString(CollectorAccessibilityService.KEY_PHASE, CollectorAccessibilityService.PHASE_IDLE)).append('\n');
        sb.append("Status: ").append(p.getString(CollectorAccessibilityService.KEY_STATUS, "")).append('\n');
        long finishedAt = p.getLong(CollectorAccessibilityService.KEY_FINISHED_AT, 0L);
        sb.append("Finished at: ")
                .append(finishedAt <= 0L ? "UNSET" : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA).format(new Date(finishedAt)))
                .append('\n');
        sb.append("Finish reason: ").append(p.getString(CollectorAccessibilityService.KEY_FINISH_REASON, "")).append('\n');
        sb.append("Collected count: ").append(CollectionRepository.count(this)).append('\n');
        sb.append("Last package: ").append(p.getString(CollectorAccessibilityService.KEY_LAST_PACKAGE, "")).append('\n');
        sb.append("Target date found: ").append(p.getBoolean(CollectorAccessibilityService.KEY_TARGET_DATE_FOUND, false)).append('\n');
        sb.append("Seek direction: ").append(p.getString(CollectorAccessibilityService.KEY_SEEK_DIRECTION, "")).append('\n');
        sb.append("Stale scrolls: ").append(p.getInt(CollectorAccessibilityService.KEY_STALE_SCROLLS, 0)).append('\n');
        sb.append("Long-click retry: ")
                .append(p.getInt(CollectorAccessibilityService.KEY_LONG_CLICK_RETRY_COUNT, 0))
                .append(" / key=").append(p.getString(CollectorAccessibilityService.KEY_LONG_CLICK_RETRY_KEY, "")).append('\n');
        sb.append("Pending-time retry: ")
                .append(p.getInt(CollectorAccessibilityService.KEY_PENDING_TIME_RETRY, 0))
                .append(" / key=").append(p.getString(CollectorAccessibilityService.KEY_PENDING_TIME_KEY, "")).append('\n');
        sb.append("Pending queue size: ")
                .append(p.getStringSet(CollectorAccessibilityService.KEY_PENDING_QUEUE, new HashSet<>()).size())
                .append('\n');
        int activeGroup = p.getInt(CollectorAccessibilityService.KEY_ACTIVE_GROUP_MINUTES, -1);
        sb.append("Active time group: ")
                .append(activeGroup < 0 ? "UNSET" : CollectionRepository.formatMinutes(activeGroup))
                .append(" / text=").append(p.getString(CollectorAccessibilityService.KEY_ACTIVE_GROUP_TEXT, "")).append('\n');
        sb.append("Last date bounds: ").append(p.getString(CollectorAccessibilityService.KEY_LAST_DATE_BOUNDS, "UNSET")).append('\n');
        sb.append("Last end decision: ").append(p.getString(CollectorAccessibilityService.KEY_LAST_END_DECISION, "NONE")).append('\n');
        sb.append("Last screen signature: ").append(p.getString(CollectorAccessibilityService.KEY_LAST_SCREEN_SIGNATURE, "")).append("\n\n");

        sb.append("==================== COLLECTED RESULT SNAPSHOT ====================\n");
        sb.append(CollectionRepository.exportText(
                this,
                p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate),
                p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes),
                p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes)));
        sb.append("\n\n==================== TRACE LOG ====================\n");
        String log = LogRepository.read(this);
        sb.append(log.isEmpty() ? "(no trace log)\n" : log);
        return sb.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;

        String export;
        String successMessage;
        if (requestCode == REQ_SAVE) {
            SharedPreferences p = prefs();
            export = CollectionRepository.exportText(
                    this,
                    p.getString(CollectorAccessibilityService.KEY_TARGET_DATE, targetDate),
                    p.getInt(CollectorAccessibilityService.KEY_START_MIN, startMinutes),
                    p.getInt(CollectorAccessibilityService.KEY_END_MIN, endMinutes));
            successMessage = "TXT 저장 완료";
        } else if (requestCode == REQ_SAVE_LOG) {
            export = buildDiagnosticReport();
            successMessage = "오류/진단 로그 TXT 저장 완료";
        } else {
            return;
        }

        try (OutputStream os = getContentResolver().openOutputStream(uri, "w")) {
            if (os == null) throw new IllegalStateException("출력 스트림 생성 실패");
            os.write(export.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "저장 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(CollectorAccessibilityService.PREFS, MODE_PRIVATE);
    }

    private boolean isAccessibilityEnabled() {
        String expected = new ComponentName(this, CollectorAccessibilityService.class).flattenToString();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            if (expected.equalsIgnoreCase(splitter.next())) return true;
        }
        return false;
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA).format(new Date());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
