package com.example.suresoftmessengercollector;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class LogRepository {
    private static final Object LOCK = new Object();
    private static final String FILE_NAME = "collector_trace.txt";

    private LogRepository() {}

    public static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    public static void clear(Context context) {
        synchronized (LOCK) {
            try (FileOutputStream fos = new FileOutputStream(file(context), false)) {
                fos.write("".getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
    }

    public static void append(Context context, String text) {
        synchronized (LOCK) {
            try (FileOutputStream fos = new FileOutputStream(file(context), true)) {
                fos.write(text.getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
    }

    public static String read(Context context) {
        synchronized (LOCK) {
            File f = file(context);
            if (!f.exists()) return "";
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
            } catch (Exception e) {
                return "로그 읽기 실패: " + e.getMessage();
            }
            return sb.toString();
        }
    }
}
