package com.example.suresoftmessengercollector;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class CollectorAccessibilityService extends AccessibilityService {
    public static final String PREFS = "collector_prefs";

    public static final String KEY_ACTIVE = "batch_active";
    public static final String KEY_PHASE = "phase";
    public static final String KEY_STATUS = "status";
    public static final String KEY_TARGET_DATE = "target_date";
    public static final String KEY_START_MIN = "start_min";
    public static final String KEY_END_MIN = "end_min";
    public static final String KEY_PENDING_PREVIEW = "pending_preview";
    public static final String KEY_PENDING_MINUTES = "pending_minutes";
    public static final String KEY_PENDING_DRAFT = "pending_draft";
    public static final String KEY_PENDING_CANDIDATE_KEY = "pending_candidate_key";
    public static final String KEY_CAPTURE_ORDER = "capture_order";
    public static final String KEY_COLLECTED_COUNT = "collected_count";
    public static final String KEY_LAST_PACKAGE = "last_package";
    public static final String KEY_PROCESSED = "processed_keys";
    public static final String KEY_LAST_SCREEN_SIGNATURE = "last_screen_signature";
    public static final String KEY_STALE_SCROLLS = "stale_scrolls";
    public static final String KEY_PASTE_RETRY = "paste_retry";
    public static final String KEY_ROOM_STABILIZE_RETRY = "room_stabilize_retry";
    public static final String KEY_TARGET_DATE_FOUND = "target_date_found";
    public static final String KEY_SEEK_DIRECTION = "seek_direction";
    public static final String KEY_LONG_CLICK_RETRY_KEY = "long_click_retry_key";
    public static final String KEY_LONG_CLICK_RETRY_COUNT = "long_click_retry_count";
    public static final String KEY_PENDING_TIME_KEY = "pending_time_key";
    public static final String KEY_PENDING_TIME_RETRY = "pending_time_retry";
    public static final String KEY_ACTIVE_GROUP_MINUTES = "active_group_minutes";
    public static final String KEY_ACTIVE_GROUP_TEXT = "active_group_text";
    public static final String KEY_LAST_DATE_BOUNDS = "last_date_bounds";
    public static final String KEY_LAST_END_DECISION = "last_end_decision";
    public static final String KEY_PENDING_QUEUE = "pending_queue";
    public static final String KEY_FINISHED_AT = "finished_at";
    public static final String KEY_FINISH_REASON = "finish_reason";

    public static final String PHASE_IDLE = "IDLE";
    public static final String PHASE_WAIT_ROOM = "WAIT_ROOM";
    public static final String PHASE_ROOM_STABILIZING = "ROOM_STABILIZING";
    public static final String PHASE_SEEK_DATE = "SEEK_DATE";
    public static final String PHASE_RUNNING = "RUNNING";
    public static final String PHASE_WAIT_COPY_MENU = "WAIT_COPY_MENU";
    public static final String PHASE_WAIT_PASTE = "WAIT_PASTE";
    public static final String PHASE_WAIT_PASTE_READ = "WAIT_PASTE_READ";
    public static final String PHASE_UI_RECOVERY = "UI_RECOVERY";
    public static final String PHASE_COMPLETE = "COMPLETE";
    public static final String PHASE_STOPPED = "STOPPED";
    public static final String PHASE_ERROR = "ERROR";

    private static final String TARGET_PACKAGE = "com.daou.go_mobile";
    private static final String ROOM_ID = TARGET_PACKAGE + ":id/room_name";
    private static final String MESSAGE_ID = TARGET_PACKAGE + ":id/text_message_view";
    private static final String TIME_ID = TARGET_PACKAGE + ":id/created_at";
    private static final String DATE_ID = TARGET_PACKAGE + ":id/time_tv";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastActionAt = 0L;

    // v1.0 baseline: v0.9 collection logic retained + explicit COMPLETE/STOPPED/ERROR user-visible status:
    // Collection behavior is intentionally frozen from v0.9; v1.0 adds completion-state UX.
    // v0.9 date-bound/capture-first/full-text-dedupe behavior remains unchanged.
    // The 3-second timer starts only AFTER the target room ("박동천") is confirmed.
    // Time spent launching Suresoft Messenger or manually navigating to the room is NOT included.
    private static final long ROOM_STABILIZE_MS = 3000L;
    private static final long ACTION_INTERVAL_MS = 900L;
    private static final long COPY_MENU_DEBOUNCE_MS = 350L;
    private static final long PASTE_DEBOUNCE_MS = 650L;
    private static final long PASTE_READ_DEBOUNCE_MS = 650L;
    private static final long UI_RECOVERY_MS = 1200L;
    private static final long SCROLL_SETTLE_MS = 1100L;
    private static final long OVERLAP_SCROLL_SETTLE_MS = 900L;
    private static final int LONG_CLICK_MAX_RETRY = 3;
    private static final int PENDING_TIME_MAX_SCROLLS = 30;

    private static final class DateNode {
        AccessibilityNodeInfo node;
        Rect rect;
        String date;
        String text;
    }

    private static final class DateBounds {
        int lowerY = Integer.MIN_VALUE;
        int upperY = Integer.MAX_VALUE;
        boolean targetDividerVisible = false;
        boolean nextDateVisible = false;

        boolean containsY(int y) {
            return y > lowerY && y < upperY;
        }

        String describe() {
            return "lowerY=" + lowerY + ", upperY=" + upperY
                    + ", targetDivider=" + targetDividerVisible
                    + ", nextDivider=" + nextDateVisible;
        }
    }

    private static final class TimeNode {
        AccessibilityNodeInfo node;
        Rect rect;
        int minutes;
        String text;
    }

    private static final class MessageCandidate {
        AccessibilityNodeInfo node;
        Rect rect;
        String preview;
        String stableId = "";
        int minutes = -1;
        String timeText = "";
        boolean explicitTime = false;
        boolean inheritedTime = false;

        boolean hasTime() {
            return minutes >= 0;
        }

        String key() {
            // v0.9: never use screen Y as identity. Prefer Android uniqueId; when unavailable
            // stableNodeId() includes AccessibilityNodeInfo.hashCode() plus preview fingerprint
            // so two distinct Part 1/2 vs Part 2/2 bubbles with the same 353-char prefix are not
            // automatically collapsed before their full text is copied.
            return minutes + "|" + stableId;
        }

        String pendingKey() {
            return previewFingerprint(preview);
        }

        boolean collisionPronePreview() {
            return preview != null && preview.length() >= 300;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        log("Accessibility service connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences prefs = prefs();
        if (!prefs.getBoolean(KEY_ACTIVE, false)) return;

        CharSequence pkgCs = event.getPackageName();
        String pkg = pkgCs == null ? "" : pkgCs.toString();
        prefs.edit().putString(KEY_LAST_PACKAGE, pkg).apply();

        String phase = prefs.getString(KEY_PHASE, PHASE_IDLE);
        if (PHASE_COMPLETE.equals(phase) || PHASE_STOPPED.equals(phase) || PHASE_ERROR.equals(phase)) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // Phase-specific UI transitions are debounced. Do not react immediately to every
        // accessibility event because Suresoft Messenger emits several events while dialogs,
        // the composer, and scrolling are still settling.
        if (PHASE_WAIT_COPY_MENU.equals(phase)) {
            scheduleCopyMenu(COPY_MENU_DEBOUNCE_MS);
            return;
        }
        if (PHASE_WAIT_PASTE.equals(phase)) {
            schedulePaste(PASTE_DEBOUNCE_MS);
            return;
        }
        if (PHASE_WAIT_PASTE_READ.equals(phase)) {
            schedulePasteRead(PASTE_READ_DEBOUNCE_MS);
            return;
        }
        if (PHASE_UI_RECOVERY.equals(phase)) {
            return;
        }

        boolean targetRoom = isTargetRoom(root);

        if (PHASE_WAIT_ROOM.equals(phase)) {
            if (!targetRoom) {
                setStatus("'박동천' 나와의 대화방을 기다리는 중... (아직 3초 타이머 시작 전)");
                return;
            }
            beginRoomStabilization();
            return;
        }

        if (PHASE_ROOM_STABILIZING.equals(phase)) {
            if (!targetRoom) {
                cancelRoomStabilization();
                prefs.edit()
                        .putString(KEY_PHASE, PHASE_WAIT_ROOM)
                        .putInt(KEY_ROOM_STABILIZE_RETRY, 0)
                        .putString(KEY_STATUS, "대화방 확인이 풀려 안정화 타이머를 취소했습니다. '박동천' 방을 다시 기다립니다.")
                        .apply();
                log("Target room lost during stabilization -> WAIT_ROOM");
            }
            return;
        }

        if (PHASE_SEEK_DATE.equals(phase) || PHASE_RUNNING.equals(phase)) {
            if (!targetRoom) {
                handler.removeCallbacks(processRunnable);
                prefs.edit()
                        .putString(KEY_PHASE, PHASE_WAIT_ROOM)
                        .putString(KEY_STATUS, "대상 대화방에서 벗어났습니다. 자동 동작을 일시중지하고 '박동천' 방 재진입을 기다립니다.")
                        .apply();
                log("Target room lost while " + phase + " -> paused WAIT_ROOM");
                return;
            }
            scheduleProcess(ACTION_INTERVAL_MS);
        }
    }

    private void beginRoomStabilization() {
        SharedPreferences p = prefs();
        p.edit()
                .putString(KEY_PHASE, PHASE_ROOM_STABILIZING)
                .putInt(KEY_ROOM_STABILIZE_RETRY, 0)
                .putString(KEY_STATUS, "'박동천' 방 확인 완료 → 3초 화면 안정화 대기 중. 이제 화면을 건드리지 마세요.")
                .apply();
        log("Target room confirmed: 박동천 -> stabilize 3000ms");
        Toast.makeText(this,
                "'박동천' 방 확인. 3초 후 자동 수집을 시작합니다. 이제 화면을 건드리지 마세요.",
                Toast.LENGTH_LONG).show();

        cancelRoomStabilization();
        handler.postDelayed(roomStabilizeRunnable, ROOM_STABILIZE_MS);
    }

    private void cancelRoomStabilization() {
        handler.removeCallbacks(roomStabilizeRunnable);
    }

    private final Runnable roomStabilizeRunnable = new Runnable() {
        @Override
        public void run() {
            SharedPreferences p = prefs();
            if (!p.getBoolean(KEY_ACTIVE, false)) return;
            if (!PHASE_ROOM_STABILIZING.equals(p.getString(KEY_PHASE, PHASE_IDLE))) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isTargetRoom(root)) {
                p.edit()
                        .putString(KEY_PHASE, PHASE_WAIT_ROOM)
                        .putInt(KEY_ROOM_STABILIZE_RETRY, 0)
                        .putString(KEY_STATUS, "3초 안정화 중 대상 방 확인이 풀렸습니다. 다시 '박동천' 방을 기다립니다.")
                        .apply();
                log("Room stabilization failed: target room missing -> WAIT_ROOM");
                return;
            }

            if (!isRoomLayoutReady(root)) {
                int retry = p.getInt(KEY_ROOM_STABILIZE_RETRY, 0) + 1;
                p.edit()
                        .putInt(KEY_ROOM_STABILIZE_RETRY, retry)
                        .putString(KEY_STATUS, "3초 경과했지만 대화 UI가 아직 전환 중입니다. 1초 더 안정화 확인 (" + retry + "/5)")
                        .apply();
                log("Room layout not ready after stabilization, retry=" + retry);
                if (retry <= 5) {
                    handler.postDelayed(this, 1000L);
                } else {
                    error("대상 방은 확인됐지만 대화 UI가 안정화되지 않았습니다. 다시 시도해주세요.");
                }
                return;
            }

            p.edit()
                    .putString(KEY_PHASE, PHASE_SEEK_DATE)
                    .putInt(KEY_ROOM_STABILIZE_RETRY, 0)
                    .putBoolean(KEY_TARGET_DATE_FOUND, false)
                    .putString(KEY_SEEK_DIRECTION, "OLDER")
                    .putString(KEY_LAST_SCREEN_SIGNATURE, "")
                    .putInt(KEY_STALE_SCROLLS, 0)
                    .putString(KEY_STATUS, "대화방 안정화 확인 완료 → 선택 날짜 구분선 탐색 시작")
                    .apply();
            lastActionAt = SystemClock.elapsedRealtime();
            log("Room stabilization PASS -> SEEK_DATE");
            Toast.makeText(CollectorAccessibilityService.this,
                    "선택 날짜를 찾은 뒤 오래된→최신 방향으로 수집합니다. 완료될 때까지 화면을 조작하지 마세요.",
                    Toast.LENGTH_LONG).show();
            scheduleProcess(ACTION_INTERVAL_MS);
        }
    };

    private boolean isRoomLayoutReady(AccessibilityNodeInfo root) {
        if (!isTargetRoom(root)) return false;
        if (findEditable(root) == null) return false;
        return !findById(root, MESSAGE_ID).isEmpty()
                || !findById(root, TIME_ID).isEmpty()
                || !findById(root, DATE_ID).isEmpty();
    }

    private void scheduleCopyMenu(long delayMs) {
        handler.removeCallbacks(copyMenuRunnable);
        handler.postDelayed(copyMenuRunnable, delayMs);
    }

    private final Runnable copyMenuRunnable = () -> {
        if (!prefs().getBoolean(KEY_ACTIVE, false)) return;
        if (!PHASE_WAIT_COPY_MENU.equals(prefs().getString(KEY_PHASE, PHASE_IDLE))) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) tryClickCopyMenu(root);
    };

    private void schedulePaste(long delayMs) {
        handler.removeCallbacks(pasteRunnable);
        handler.postDelayed(pasteRunnable, delayMs);
    }

    private final Runnable pasteRunnable = () -> {
        if (!prefs().getBoolean(KEY_ACTIVE, false)) return;
        if (!PHASE_WAIT_PASTE.equals(prefs().getString(KEY_PHASE, PHASE_IDLE))) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) tryPasteIntoComposer(root);
    };

    private void schedulePasteRead(long delayMs) {
        handler.removeCallbacks(pasteReadRunnable);
        handler.postDelayed(pasteReadRunnable, delayMs);
    }

    private final Runnable pasteReadRunnable = () -> {
        if (!prefs().getBoolean(KEY_ACTIVE, false)) return;
        if (!PHASE_WAIT_PASTE_READ.equals(prefs().getString(KEY_PHASE, PHASE_IDLE))) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) tryReadPastedText(root);
    };

    private void scheduleProcess(long delayMs) {
        handler.removeCallbacks(processRunnable);
        handler.postDelayed(processRunnable, delayMs);
    }

    private final Runnable processRunnable = new Runnable() {
        @Override
        public void run() {
            SharedPreferences p = prefs();
            if (!p.getBoolean(KEY_ACTIVE, false)) return;
            String phase = p.getString(KEY_PHASE, PHASE_IDLE);
            if (!PHASE_SEEK_DATE.equals(phase) && !PHASE_RUNNING.equals(phase)) return;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isTargetRoom(root)) return;
            if (PHASE_SEEK_DATE.equals(phase)) seekTargetDate(root);
            else processCurrentScreen(root);
        }
    };

    private void seekTargetDate(AccessibilityNodeInfo root) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastActionAt < ACTION_INTERVAL_MS) {
            scheduleProcess(ACTION_INTERVAL_MS);
            return;
        }

        SharedPreferences p = prefs();
        String targetDate = p.getString(KEY_TARGET_DATE, todayString());
        List<DateNode> dates = collectDateNodes(root);

        for (DateNode d : dates) {
            if (targetDate.equals(d.date)) {
                p.edit()
                        .putString(KEY_PHASE, PHASE_RUNNING)
                        .putBoolean(KEY_TARGET_DATE_FOUND, true)
                        .putString(KEY_LAST_SCREEN_SIGNATURE, "")
                        .putInt(KEY_STALE_SCROLLS, 0)
                        .putString(KEY_PENDING_TIME_KEY, "")
                        .putInt(KEY_PENDING_TIME_RETRY, 0)
                        .putStringSet(KEY_PENDING_QUEUE, new HashSet<>())
                        .putString(KEY_LONG_CLICK_RETRY_KEY, "")
                        .putInt(KEY_LONG_CLICK_RETRY_COUNT, 0)
                        .putInt(KEY_ACTIVE_GROUP_MINUTES, -1)
                        .putString(KEY_ACTIVE_GROUP_TEXT, "")
                        .putString(KEY_STATUS, "선택 날짜 " + targetDate + " 확인 → 오래된→최신 방향 수집 시작")
                        .apply();
                lastActionAt = SystemClock.elapsedRealtime();
                log("TARGET DATE FOUND " + targetDate + " -> RUNNING newer direction");
                Toast.makeText(this,
                        "선택 날짜 " + targetDate + " 확인. 이제 최신 방향으로 수집합니다.",
                        Toast.LENGTH_SHORT).show();
                scheduleProcess(SCROLL_SETTLE_MS);
                return;
            }
        }

        String direction = p.getString(KEY_SEEK_DIRECTION, "OLDER");
        if (!dates.isEmpty()) {
            String minDate = dates.get(0).date;
            String maxDate = dates.get(0).date;
            for (DateNode d : dates) {
                if (d.date.compareTo(minDate) < 0) minDate = d.date;
                if (d.date.compareTo(maxDate) > 0) maxDate = d.date;
            }

            if (minDate.compareTo(targetDate) > 0) {
                direction = "OLDER";
            } else if (maxDate.compareTo(targetDate) < 0) {
                // We moved past the requested date. Correct one or more pages toward newer messages.
                direction = "NEWER";
            }
            p.edit().putString(KEY_SEEK_DIRECTION, direction).apply();
        }

        String signature = "SEEK|" + direction + "|" + buildDateSignature(dates)
                + "|" + buildScreenSignature(collectCandidates(root, false));
        boolean ok;
        if ("NEWER".equals(direction)) {
            ok = scrollNewerInternal(root, signature, "선택 날짜를 지나쳐 최신 방향으로 날짜 위치 보정 중...");
            log("SEEK DATE newer target=" + targetDate);
        } else {
            ok = scrollOlderInternal(root, signature, "선택 날짜 " + targetDate + " 구분선을 찾는 중... (메시지는 아직 복사하지 않음)");
            log("SEEK DATE older target=" + targetDate);
        }
        if (!ok) {
            error("선택 날짜 " + targetDate + " 구분선을 찾지 못했습니다. 대화 이력에 해당 날짜가 있는지 확인해주세요.");
        }
    }

    private void processCurrentScreen(AccessibilityNodeInfo root) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastActionAt < ACTION_INTERVAL_MS) {
            scheduleProcess(ACTION_INTERVAL_MS);
            return;
        }

        SharedPreferences p = prefs();
        int startMin = p.getInt(KEY_START_MIN, 0);
        int endMin = p.getInt(KEY_END_MIN, 23 * 60 + 59);
        String targetDate = p.getString(KEY_TARGET_DATE, todayString());

        // v0.8: establish the selected-date visual region BEFORE collecting timestamps.
        // This prevents a timestamp from the previous/next date from entering the Active Time Group
        // or being attached to a selected-date bubble that happens to share the same viewport.
        List<DateNode> dateNodes = collectDateNodes(root);
        DateBounds dateBounds = computeTargetDateBounds(dateNodes, targetDate);
        p.edit().putString(KEY_LAST_DATE_BOUNDS, dateBounds.describe()).apply();

        List<MessageCandidate> candidates = collectCandidates(
                root, true, dateBounds.lowerY, dateBounds.upperY);
        int lowerY = dateBounds.lowerY;
        int upperY = dateBounds.upperY;
        boolean nextDateVisible = dateBounds.nextDateVisible;

        Set<String> processed = new HashSet<>(p.getStringSet(KEY_PROCESSED, new HashSet<>()));
        Set<String> pendingQueue = new HashSet<>(p.getStringSet(KEY_PENDING_QUEUE, new HashSet<>()));
        boolean sawExplicitAfterEnd = false;
        boolean sawAnyTargetDateCandidate = false;
        List<MessageCandidate> unresolved = new ArrayList<>();
        int inBounds = 0;
        int withTime = 0;

        for (MessageCandidate c : candidates) {
            int cy = c.rect.centerY();
            if (cy <= lowerY || cy >= upperY) continue;
            inBounds++;
            sawAnyTargetDateCandidate = true;
            if (!c.hasTime()) {
                unresolved.add(c);
                pendingQueue.add(c.pendingKey());
                p.edit().putStringSet(KEY_PENDING_QUEUE, pendingQueue).apply();
                continue;
            }
            pendingQueue.remove(c.pendingKey());
            p.edit().putStringSet(KEY_PENDING_QUEUE, pendingQueue).apply();
            if (c.explicitTime) adoptActiveTimeGroup(c);
            withTime++;
            if (c.minutes < startMin) continue;
            if (c.minutes > endMin) {
                // v0.8: an inherited/group time must never terminate the session by itself.
                // Only an explicit created_at that is already inside the selected-date bounds
                // is authoritative enough to prove that the configured end time was crossed.
                if (c.explicitTime) {
                    sawExplicitAfterEnd = true;
                    p.edit().putString(KEY_LAST_END_DECISION,
                            "explicit " + c.timeText + " > " + CollectionRepository.formatMinutes(endMin)
                                    + " | " + dateBounds.describe()).apply();
                    log("END_BOUND explicit after end, time=" + c.timeText
                            + ", end=" + CollectionRepository.formatMinutes(endMin)
                            + ", preview=" + compact(c.preview)
                            + ", " + dateBounds.describe());
                } else {
                    log("END_BOUND inherited time ignored for termination, time=" + c.timeText
                            + ", preview=" + compact(c.preview));
                }
                continue;
            }
            if (processed.contains(c.key())) continue;

            // v0.9: preview-only pre-dedupe is safe only for short messages whose full text is
            // completely visible in Accessibility. Long Suresoft bubbles are truncated to about
            // 353 chars and Part 1/2 vs Part 2/2 can share the exact same prefix. Therefore long
            // previews MUST be copied first and deduped only after the complete clipboard text is
            // obtained.
            long candidateEpoch = epochFor(targetDate, c.minutes);
            if (!c.collisionPronePreview()
                    && CollectionRepository.hasCapturedPreview(this, candidateEpoch, c.preview)) {
                processed.add(c.key());
                pendingQueue.remove(c.pendingKey());
                p.edit()
                        .putStringSet(KEY_PROCESSED, processed)
                        .putStringSet(KEY_PENDING_QUEUE, pendingQueue)
                        .apply();
                log("SKIP exact short message already captured, time=" + c.timeText
                        + ", source=" + (c.explicitTime ? "explicit" : "inherited")
                        + ", preview=" + compact(c.preview));
                continue;
            }
            if (c.collisionPronePreview()) {
                log("PREVIEW_DEDUPE bypass long/collision-prone preview len=" + c.preview.length()
                        + ", stableId=" + c.stableId);
            }

            boolean ok = longClickSelfOrParent(c.node);
            lastActionAt = now;
            if (!ok) {
                String retryKey = c.key();
                String lastRetryKey = p.getString(KEY_LONG_CLICK_RETRY_KEY, "");
                int retry = retryKey.equals(lastRetryKey) ? p.getInt(KEY_LONG_CLICK_RETRY_COUNT, 0) + 1 : 1;
                p.edit()
                        .putString(KEY_LONG_CLICK_RETRY_KEY, retryKey)
                        .putInt(KEY_LONG_CLICK_RETRY_COUNT, retry)
                        .putString(KEY_STATUS, "[" + c.timeText + "] Long Press 실패 → 같은 메시지 재시도 " + retry + "/" + LONG_CLICK_MAX_RETRY)
                        .apply();
                log("LONG_CLICK retry=" + retry + "/" + LONG_CLICK_MAX_RETRY
                        + ", time=" + c.timeText + ", key=" + compact(retryKey)
                        + ", preview=" + compact(c.preview));
                if (retry >= LONG_CLICK_MAX_RETRY) {
                    error("동일 메시지 Long Press가 " + LONG_CLICK_MAX_RETRY + "회 연속 실패했습니다. 누락 방지를 위해 수집을 중단했습니다. '오류 시 로그 TXT 생성'으로 로그를 저장해주세요.");
                } else {
                    scheduleProcess(700L);
                }
                return;
            }

            p.edit()
                    .putString(KEY_LONG_CLICK_RETRY_KEY, "")
                    .putInt(KEY_LONG_CLICK_RETRY_COUNT, 0)
                    .putString(KEY_PHASE, PHASE_WAIT_COPY_MENU)
                    .putString(KEY_STATUS, "[" + c.timeText + "] 메시지 Long Press 성공 → '텍스트 복사' 선택 중")
                    .putString(KEY_PENDING_PREVIEW, c.preview)
                    .putString(KEY_PENDING_CANDIDATE_KEY, c.key())
                    .putInt(KEY_PENDING_MINUTES, c.minutes)
                    .putInt(KEY_PASTE_RETRY, 0)
                    .apply();
            log("LONG_CLICK success, time=" + c.timeText
                    + ", source=" + (c.explicitTime ? "explicit" : (c.inheritedTime ? "inherited" : "unknown"))
                    + ", stableId=" + c.stableId
                    + ", previewLen=" + c.preview.length()
                    + ", preview=" + compact(c.preview));
            return;
        }

        p.edit().putStringSet(KEY_PENDING_QUEUE, pendingQueue).apply();

        log("SCAN phase=RUNNING candidates=" + candidates.size()
                + ", inDateBounds=" + inBounds + ", withTime=" + withTime
                + ", unresolvedTime=" + unresolved.size()
                + ", pendingQueue=" + pendingQueue.size()
                + ", processedKeys=" + processed.size()
                + ", dateNodes=" + dateNodes.size()
                + ", activeGroup=" + formatKoreanTime(p.getInt(KEY_ACTIVE_GROUP_MINUTES, -1))
                + ", " + dateBounds.describe());

        // A long bubble can be visible while its created_at node is still below the viewport.
        // Do not discard it. Move only a small amount toward newer content so the time node can
        // enter the tree while most of the previous screen remains overlapped.
        if (!unresolved.isEmpty()) {
            MessageCandidate pending = unresolved.get(0);
            String pendingKey = pending.pendingKey();
            String lastPending = p.getString(KEY_PENDING_TIME_KEY, "");
            int retry = pendingKey.equals(lastPending) ? p.getInt(KEY_PENDING_TIME_RETRY, 0) + 1 : 1;
            p.edit()
                    .putString(KEY_PENDING_TIME_KEY, pendingKey)
                    .putInt(KEY_PENDING_TIME_RETRY, retry)
                    .putString(KEY_STATUS, "시간표시가 아직 안 보이는 메시지 발견 → 겹침 스크롤로 시간 노드 탐색 " + retry + "/" + PENDING_TIME_MAX_SCROLLS)
                    .apply();
            log("PENDING_TIME retry=" + retry + "/" + PENDING_TIME_MAX_SCROLLS
                    + ", preview=" + compact(pending.preview));
            if (retry > PENDING_TIME_MAX_SCROLLS) {
                error("긴 메시지의 시간(created_at)을 " + PENDING_TIME_MAX_SCROLLS + "회 겹침 스크롤 후에도 연결하지 못했습니다. 누락 방지를 위해 중단했습니다.");
                return;
            }
            String pendingSig = "PENDING|" + pendingKey + "|" + buildScreenSignature(candidates) + "|" + buildDateSignature(dateNodes);
            boolean moved = scrollNewerOverlapInternal(root, pendingSig, "긴 메시지 시간 표시를 찾기 위해 조금만 아래/최신 방향으로 이동 중...");
            if (!moved) {
                error("시간 미확정 메시지가 남아 있는데 더 이상 최신 방향으로 이동할 수 없습니다. 오류 로그를 저장해 확인해주세요.");
            }
            return;
        } else {
            p.edit().putString(KEY_PENDING_TIME_KEY, "").putInt(KEY_PENDING_TIME_RETRY, 0).apply();
        }

        if (sawExplicitAfterEnd) {
            complete("선택 날짜 영역 안의 명시적 시간(created_at)이 종료 시간 "
                    + CollectionRepository.formatMinutes(endMin) + " 이후임을 확인했습니다.");
            return;
        }

        if (nextDateVisible) {
            complete("선택 날짜 다음 날짜 구분선에 도달했습니다.");
            return;
        }

        String signature = "RUN|" + buildScreenSignature(candidates) + "|" + buildDateSignature(dateNodes);
        boolean ok = scrollNewerOverlapInternal(root, signature,
                "선택 날짜 안에서 겹침 스크롤로 최신 메시지 방향 이동 중... (첨부파일은 자동 무시)");
        if (!ok) {
            Set<String> stillPending = new HashSet<>(p.getStringSet(KEY_PENDING_QUEUE, new HashSet<>()));
            if (!stillPending.isEmpty()) {
                error("시간 미확정 Pending 메시지가 " + stillPending.size()
                        + "건 남아 있는데 더 이상 최신 방향으로 이동할 수 없습니다. 오류 로그를 저장해 확인해주세요.");
                return;
            }
            complete(sawAnyTargetDateCandidate
                    ? "더 이상 최신 메시지로 이동하지 않아 현재까지의 결과로 종료했습니다."
                    : "선택 날짜에서 더 이상 수집할 텍스트 메시지가 없어 종료했습니다.");
        }
    }

    private List<MessageCandidate> collectCandidates(AccessibilityNodeInfo root, boolean allowGroupInheritance) {
        return collectCandidates(root, allowGroupInheritance, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private List<MessageCandidate> collectCandidates(AccessibilityNodeInfo root, boolean allowGroupInheritance,
                                                     int lowerY, int upperY) {
        List<AccessibilityNodeInfo> messageNodes = findById(root, MESSAGE_ID);
        List<AccessibilityNodeInfo> timeNodesRaw = findById(root, TIME_ID);
        List<TimeNode> times = new ArrayList<>();

        for (AccessibilityNodeInfo n : timeNodesRaw) {
            if (n == null) continue;
            CharSequence cs = n.getText();
            int minutes = parseKoreanTime(cs == null ? "" : cs.toString());
            if (minutes < 0) continue;
            TimeNode tn = new TimeNode();
            tn.node = n;
            tn.rect = bounds(n);
            if (tn.rect.centerY() <= lowerY || tn.rect.centerY() >= upperY) continue;
            tn.minutes = minutes;
            tn.text = cs.toString();
            times.add(tn);
        }
        Collections.sort(times, new Comparator<TimeNode>() {
            @Override
            public int compare(TimeNode a, TimeNode b) {
                return Integer.compare(a.rect.centerY(), b.rect.centerY());
            }
        });

        Collections.sort(messageNodes, new Comparator<AccessibilityNodeInfo>() {
            @Override
            public int compare(AccessibilityNodeInfo a, AccessibilityNodeInfo b) {
                return Integer.compare(bounds(a).bottom, bounds(b).bottom);
            }
        });

        SharedPreferences p = prefs();
        int activeGroup = allowGroupInheritance ? p.getInt(KEY_ACTIVE_GROUP_MINUTES, -1) : -1;
        String activeGroupText = allowGroupInheritance ? p.getString(KEY_ACTIVE_GROUP_TEXT, "") : "";

        List<MessageCandidate> out = new ArrayList<>();
        for (AccessibilityNodeInfo n : messageNodes) {
            if (n == null) continue;
            CharSequence cs = n.getText();
            String preview = cs == null ? "" : cs.toString();
            if (preview.trim().isEmpty()) continue;
            Rect r = bounds(n);
            if (r.centerY() <= lowerY || r.centerY() >= upperY) continue;
            TimeNode direct = nearestTime(r, times);

            MessageCandidate mc = new MessageCandidate();
            mc.node = n;
            mc.rect = r;
            mc.preview = preview;
            mc.stableId = stableNodeId(n, preview);

            if (direct != null) {
                mc.minutes = direct.minutes;
                mc.timeText = direct.text;
                mc.explicitTime = true;
                // Overlap scrolling can re-expose an older explicit time near the top. Keep the
                // inheritance cursor monotonic while still allowing this bubble to retain its own
                // explicit timestamp for dedupe/range checks.
                if (activeGroup < 0 || direct.minutes >= activeGroup) {
                    activeGroup = direct.minutes;
                    activeGroupText = direct.text;
                }
            } else if (allowGroupInheritance && activeGroup >= 0) {
                // v0.9 capture-first policy: once a minute is explicitly confirmed, every
                // subsequent text bubble in the selected-date region inherits that minute until a
                // later explicit created_at is observed. Do NOT wait for the bubble tail. A long
                // Part 2/2 bubble may otherwise leave the Accessibility tree before its tail/time
                // becomes visible, which was the v0.8 9 -> 7 field defect.
                mc.minutes = activeGroup;
                mc.timeText = activeGroupText.isEmpty() ? formatKoreanTime(activeGroup) : activeGroupText;
                mc.inheritedTime = true;
            }
            out.add(mc);
        }

        // Visible messages are processed top/older -> bottom/newer.
        Collections.sort(out, new Comparator<MessageCandidate>() {
            @Override
            public int compare(MessageCandidate a, MessageCandidate b) {
                return Integer.compare(a.rect.bottom, b.rect.bottom);
            }
        });
        return out;
    }

    private void adoptActiveTimeGroup(MessageCandidate c) {
        if (c == null || !c.explicitTime || c.minutes < 0) return;
        SharedPreferences p = prefs();
        int old = p.getInt(KEY_ACTIVE_GROUP_MINUTES, -1);
        String oldText = p.getString(KEY_ACTIVE_GROUP_TEXT, "");
        if (old == c.minutes && oldText.equals(c.timeText)) return;
        if (old >= 0 && c.minutes < old) {
            log("TIME_GROUP regression rejected old=" + formatKoreanTime(old)
                    + ", candidate=" + c.timeText + ", preview=" + compact(c.preview));
            return;
        }
        p.edit()
                .putInt(KEY_ACTIVE_GROUP_MINUTES, c.minutes)
                .putString(KEY_ACTIVE_GROUP_TEXT, c.timeText)
                .apply();
        log("TIME_GROUP explicit -> " + formatKoreanTime(c.minutes));
    }

    private TimeNode nearestTime(Rect messageRect, List<TimeNode> times) {
        TimeNode best = null;
        long bestScore = Long.MAX_VALUE;
        int tolerancePx = Math.round(28f * getResources().getDisplayMetrics().density);
        for (TimeNode t : times) {
            int cy = t.rect.centerY();

            // A bubble's own created_at is vertically aligned with that bubble. Do not attach a
            // timestamp that sits clearly above the bubble; that was the v0.6 cause of borrowing
            // the previous bubble's time merely because it was within a broad 180dp radius.
            if (cy < messageRect.top - tolerancePx || cy > messageRect.bottom + tolerancePx) continue;

            long score = Math.abs((long) cy - messageRect.bottom);
            if (score < bestScore) {
                best = t;
                bestScore = score;
            }
        }
        return best;
    }

    private boolean isMessageTailVisible(Rect r) {
        if (r == null) return false;
        int h = getResources().getDisplayMetrics().heightPixels;
        int topGuard = Math.round(90f * getResources().getDisplayMetrics().density);
        int bottomGuard = Math.round(150f * getResources().getDisplayMetrics().density);
        return r.bottom > topGuard && r.bottom <= (h - bottomGuard);
    }

    private String stableNodeId(AccessibilityNodeInfo node, String preview) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                String uniqueId = node.getUniqueId();
                if (uniqueId != null && !uniqueId.trim().isEmpty()) return "uid:" + uniqueId;
            }
        } catch (Throwable ignored) {}

        // Many Samsung/Daou accessibility trees do not expose getUniqueId(). AccessibilityNodeInfo
        // hashCode is a better best-effort discriminator than preview alone because distinct
        // bubbles with an identical truncated 353-char prefix normally remain different nodes.
        // If it changes after a scroll, full-text repository dedupe still prevents duplicate TXT
        // records; correctness is intentionally preferred over premature skipping.
        int nodeHash = 0;
        try { nodeHash = node == null ? 0 : node.hashCode(); } catch (Throwable ignored) {}
        String fp = previewFingerprint(preview);
        return nodeHash != 0 ? "node:" + Integer.toHexString(nodeHash) + ":" + fp : fp;
    }

    private static String previewFingerprint(String preview) {
        String normalized = preview == null ? "" : preview.replaceAll("\s+", " ").trim();
        return "preview:" + Integer.toHexString(normalized.hashCode()) + ":" + normalized.length();
    }

    private String formatKoreanTime(int minutes) {
        if (minutes < 0) return "";
        int h24 = minutes / 60;
        int m = minutes % 60;
        boolean pm = h24 >= 12;
        int h12 = h24 % 12;
        if (h12 == 0) h12 = 12;
        return String.format(Locale.KOREA, "%s %02d:%02d", pm ? "오후" : "오전", h12, m);
    }

    private void tryClickCopyMenu(AccessibilityNodeInfo root) {
        String[] labels = {"텍스트 복사", "복사하기", "복사"};
        for (String label : labels) {
            List<AccessibilityNodeInfo> matches;
            try {
                matches = root.findAccessibilityNodeInfosByText(label);
            } catch (Exception e) {
                continue;
            }
            if (matches == null) continue;
            for (AccessibilityNodeInfo node : matches) {
                if (node == null) continue;
                CharSequence t = node.getText();
                if (t == null || !label.contentEquals(t)) continue;
                if (clickSelfOrParent(node)) {
                    prefs().edit()
                            .putString(KEY_PHASE, PHASE_WAIT_PASTE)
                            .putString(KEY_STATUS, "'" + label + "' 클릭 성공 → 입력창을 이용해 전체 원문 확인 중")
                            .apply();
                    log("COPY_MENU click success: " + label);
                    schedulePaste(PASTE_DEBOUNCE_MS);
                    return;
                }
            }
        }
    }

    /**
     * Android 10+ blocks a background process from reading another foreground app's clipboard.
     * Instead, keep Suresoft Messenger in the foreground and paste the clipboard into its own
     * composer via Accessibility. Then read the EditText node, restore the original draft,
     * and continue. Nothing is sent.
     */
    private void tryPasteIntoComposer(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo edit = findEditable(root);
        if (edit == null) {
            retryOrError("메시지 입력창(EditText)을 찾지 못했습니다.", PHASE_WAIT_PASTE);
            return;
        }

        CharSequence oldCs = edit.getText();
        String draft = oldCs == null ? "" : oldCs.toString();
        prefs().edit().putString(KEY_PENDING_DRAFT, draft).apply();

        setNodeText(edit, "");
        edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        boolean pasted = edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        if (!pasted) {
            setNodeText(edit, draft);
            retryOrError("입력창 ACTION_PASTE 실행에 실패했습니다.", PHASE_WAIT_PASTE);
            return;
        }

        prefs().edit()
                .putString(KEY_PHASE, PHASE_WAIT_PASTE_READ)
                .putString(KEY_STATUS, "클립보드를 Suresoft Messenger 입력창에 임시 붙여넣음 → 원문 읽는 중")
                .putInt(KEY_PASTE_RETRY, 0)
                .apply();
        log("ACTION_PASTE success");
        schedulePasteRead(PASTE_READ_DEBOUNCE_MS);
    }

    private void tryReadPastedText(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo edit = findEditable(root);
        if (edit == null) {
            retryOrError("붙여넣기 후 입력창을 찾지 못했습니다.", PHASE_WAIT_PASTE_READ);
            return;
        }

        CharSequence cs = edit.getText();
        String fullText = cs == null ? "" : cs.toString();
        String draft = prefs().getString(KEY_PENDING_DRAFT, "");

        if (fullText.isEmpty() || fullText.equals(draft)) {
            int retry = prefs().getInt(KEY_PASTE_RETRY, 0) + 1;
            prefs().edit().putInt(KEY_PASTE_RETRY, retry).apply();
            if (retry <= 4) {
                schedulePasteRead(PASTE_READ_DEBOUNCE_MS);
            } else {
                setNodeText(edit, draft);
                error("클립보드 원문이 입력창에 나타나지 않았습니다.");
            }
            return;
        }

        // Restore any pre-existing user draft immediately. Never press Send.
        setNodeText(edit, draft);
        edit.performAction(AccessibilityNodeInfo.ACTION_CLEAR_FOCUS);

        SharedPreferences p = prefs();
        int minutes = p.getInt(KEY_PENDING_MINUTES, -1);
        String preview = p.getString(KEY_PENDING_PREVIEW, "");
        String candidateKey = p.getString(KEY_PENDING_CANDIDATE_KEY, minutes + "|" + preview + "|captured");
        String targetDate = p.getString(KEY_TARGET_DATE, todayString());
        long epoch = epochFor(targetDate, minutes);
        int order = p.getInt(KEY_CAPTURE_ORDER, 0) + 1;

        boolean added = CollectionRepository.add(this, order, epoch, fullText);
        Set<String> processed = new HashSet<>(p.getStringSet(KEY_PROCESSED, new HashSet<>()));
        processed.add(candidateKey);
        Set<String> pendingQueue = new HashSet<>(p.getStringSet(KEY_PENDING_QUEUE, new HashSet<>()));
        pendingQueue.remove(previewFingerprint(preview));

        int count = CollectionRepository.count(this);
        p.edit()
                .putStringSet(KEY_PROCESSED, processed)
                .putStringSet(KEY_PENDING_QUEUE, pendingQueue)
                .putInt(KEY_CAPTURE_ORDER, order)
                .putInt(KEY_COLLECTED_COUNT, count)
                .putString(KEY_PHASE, PHASE_RUNNING)
                .putString(KEY_STATUS, "원문 " + fullText.length() + "자 수집 " + (added ? "완료" : "(중복 제외)")
                        + " · 누적 " + count + "건")
                .putInt(KEY_PASTE_RETRY, 0)
                .apply();
        log("CAPTURE success, minutes=" + minutes + ", fullLen=" + fullText.length()
                + ", fullHash=" + CollectionRepository.shortTextHash(fullText)
                + ", added=" + added + ", count=" + count);
        lastActionAt = SystemClock.elapsedRealtime();

        p.edit()
                .putString(KEY_PHASE, PHASE_UI_RECOVERY)
                .putString(KEY_STATUS, "입력창 원상복구 후 화면 안정화 대기 중...")
                .apply();
        handler.removeCallbacks(uiRecoveryRunnable);
        handler.postDelayed(uiRecoveryRunnable, UI_RECOVERY_MS);
    }

    private final Runnable uiRecoveryRunnable = new Runnable() {
        @Override
        public void run() {
            SharedPreferences p = prefs();
            if (!p.getBoolean(KEY_ACTIVE, false)) return;
            if (!PHASE_UI_RECOVERY.equals(p.getString(KEY_PHASE, PHASE_IDLE))) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isTargetRoom(root)) {
                p.edit()
                        .putString(KEY_PHASE, PHASE_WAIT_ROOM)
                        .putString(KEY_STATUS, "입력창 복구 중 대상 방을 벗어나 자동 동작을 일시중지했습니다.")
                        .apply();
                log("UI recovery ended outside target room -> WAIT_ROOM");
                return;
            }

            p.edit()
                    .putString(KEY_PHASE, PHASE_RUNNING)
                    .putString(KEY_STATUS, "화면 복구 완료 → 다음 메시지 확인")
                    .apply();
            lastActionAt = SystemClock.elapsedRealtime();
            log("UI recovery PASS -> RUNNING");
            scheduleProcess(ACTION_INTERVAL_MS);
        }
    };

    private boolean scrollOlderInternal(AccessibilityNodeInfo root, String signature, String status) {
        if (isScrollStale(signature)) return false;

        AccessibilityNodeInfo scrollable = findChatScrollable(root);
        boolean ok = false;
        if (scrollable != null) {
            ok = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
        if (!ok) ok = dispatchSwipeDown();
        if (!ok) return false;

        lastActionAt = SystemClock.elapsedRealtime();
        setStatus(status);
        log("SCROLL older");
        scheduleProcess(SCROLL_SETTLE_MS);
        return true;
    }

    private boolean scrollNewerOverlapInternal(AccessibilityNodeInfo root, String signature, String status) {
        if (isScrollStale(signature)) return false;

        boolean ok = dispatchPartialSwipeUp();
        String mode = "gesture_overlap";
        if (!ok) {
            AccessibilityNodeInfo scrollable = findChatScrollable(root);
            if (scrollable != null) {
                ok = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
                mode = "ACTION_SCROLL_FORWARD_fallback";
            }
        }
        if (!ok) ok = dispatchSwipeUp();
        if (!ok) return false;

        lastActionAt = SystemClock.elapsedRealtime();
        setStatus(status);
        log("SCROLL newer overlap mode=" + mode);
        scheduleProcess(OVERLAP_SCROLL_SETTLE_MS);
        return true;
    }

    private boolean scrollNewerInternal(AccessibilityNodeInfo root, String signature, String status) {
        if (isScrollStale(signature)) return false;

        AccessibilityNodeInfo scrollable = findChatScrollable(root);
        boolean ok = false;
        if (scrollable != null) {
            ok = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        }
        if (!ok) ok = dispatchSwipeUp();
        if (!ok) return false;

        lastActionAt = SystemClock.elapsedRealtime();
        setStatus(status);
        log("SCROLL newer");
        scheduleProcess(SCROLL_SETTLE_MS);
        return true;
    }

    private boolean isScrollStale(String signature) {
        SharedPreferences p = prefs();
        String lastSig = p.getString(KEY_LAST_SCREEN_SIGNATURE, "");
        int stale = p.getInt(KEY_STALE_SCROLLS, 0);
        if (signature.equals(lastSig)) stale++; else stale = 0;
        p.edit().putString(KEY_LAST_SCREEN_SIGNATURE, signature).putInt(KEY_STALE_SCROLLS, stale).apply();
        return stale >= 4;
    }

    private AccessibilityNodeInfo findChatScrollable(AccessibilityNodeInfo root) {
        String[] anchorIds = {MESSAGE_ID, TIME_ID, DATE_ID};
        for (String id : anchorIds) {
            List<AccessibilityNodeInfo> anchors = findById(root, id);
            for (AccessibilityNodeInfo anchor : anchors) {
                AccessibilityNodeInfo current = anchor;
                for (int depth = 0; current != null && depth < 10; depth++) {
                    if (current.isScrollable()) return current;
                    current = current.getParent();
                }
            }
        }
        return findAnyScrollable(root);
    }

    private AccessibilityNodeInfo findAnyScrollable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isScrollable() && !node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findAnyScrollable(node.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean dispatchSwipeDown() {
        try {
            float w = getResources().getDisplayMetrics().widthPixels;
            float h = getResources().getDisplayMetrics().heightPixels;
            Path path = new Path();
            path.moveTo(w * 0.5f, h * 0.35f);
            path.lineTo(w * 0.5f, h * 0.78f);
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(path, 0, 420);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
            return dispatchGesture(gesture, null, null);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean dispatchPartialSwipeUp() {
        try {
            float w = getResources().getDisplayMetrics().widthPixels;
            float h = getResources().getDisplayMetrics().heightPixels;
            Path path = new Path();
            // About 20% of the screen height: keep large overlap between scans so long bubbles
            // and their created_at nodes cannot be jumped over by a page-size scroll.
            path.moveTo(w * 0.5f, h * 0.72f);
            path.lineTo(w * 0.5f, h * 0.52f);
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(path, 0, 320);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
            return dispatchGesture(gesture, null, null);
        } catch (Exception e) {
            log("PARTIAL_SWIPE exception=" + e.getClass().getSimpleName() + ":" + e.getMessage());
            return false;
        }
    }

    private boolean dispatchSwipeUp() {
        try {
            float w = getResources().getDisplayMetrics().widthPixels;
            float h = getResources().getDisplayMetrics().heightPixels;
            Path path = new Path();
            path.moveTo(w * 0.5f, h * 0.78f);
            path.lineTo(w * 0.5f, h * 0.35f);
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(path, 0, 420);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
            return dispatchGesture(gesture, null, null);
        } catch (Exception e) {
            return false;
        }
    }

    private DateBounds computeTargetDateBounds(List<DateNode> dates, String targetDate) {
        DateBounds bounds = new DateBounds();
        if (dates == null) return bounds;
        for (DateNode d : dates) {
            if (d == null || d.date == null || d.rect == null) continue;
            int y = d.rect.centerY();
            if (targetDate.equals(d.date)) {
                bounds.lowerY = Math.max(bounds.lowerY, y);
                bounds.targetDividerVisible = true;
            } else if (d.date.compareTo(targetDate) > 0) {
                bounds.upperY = Math.min(bounds.upperY, y);
                bounds.nextDateVisible = true;
            }
        }
        return bounds;
    }

    private List<DateNode> collectDateNodes(AccessibilityNodeInfo root) {
        List<DateNode> out = new ArrayList<>();
        for (AccessibilityNodeInfo n : findById(root, DATE_ID)) {
            if (n == null || n.getText() == null) continue;
            String parsed = parseKoreanDate(n.getText().toString());
            if (parsed == null) continue;
            DateNode d = new DateNode();
            d.node = n;
            d.rect = bounds(n);
            d.date = parsed;
            d.text = n.getText().toString();
            out.add(d);
        }
        Collections.sort(out, new Comparator<DateNode>() {
            @Override
            public int compare(DateNode a, DateNode b) {
                return Integer.compare(a.rect.centerY(), b.rect.centerY());
            }
        });
        return out;
    }

    private String buildDateSignature(List<DateNode> dates) {
        StringBuilder sb = new StringBuilder();
        for (DateNode d : dates) {
            sb.append(d.date).append('@').append(d.rect.centerY()).append(";;");
        }
        return sb.toString();
    }

    private boolean hasEarlierDateDivider(AccessibilityNodeInfo root, String targetDate) {
        List<AccessibilityNodeInfo> nodes = findById(root, DATE_ID);
        for (AccessibilityNodeInfo n : nodes) {
            if (n == null || n.getText() == null) continue;
            String parsed = parseKoreanDate(n.getText().toString());
            if (parsed != null && parsed.compareTo(targetDate) < 0) return true;
        }
        return false;
    }

    private boolean isTargetRoom(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> rooms = findById(root, ROOM_ID);
        for (AccessibilityNodeInfo n : rooms) {
            CharSequence t = n == null ? null : n.getText();
            if (t != null && "박동천".contentEquals(t)) return true;
        }
        return false;
    }

    private List<AccessibilityNodeInfo> findById(AccessibilityNodeInfo root, String id) {
        try {
            List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByViewId(id);
            return found == null ? new ArrayList<>() : found;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        CharSequence cls = node.getClassName();
        if (node.isEditable() || (cls != null && cls.toString().contains("EditText"))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findEditable(node.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean longClickSelfOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int depth = 0; current != null && depth < 5; depth++) {
            if (current.isLongClickable() && current.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true;
            current = current.getParent();
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK);
    }

    private boolean clickSelfOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int depth = 0; current != null && depth < 5; depth++) {
            if (current.isClickable() && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            current = current.getParent();
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private boolean setNodeText(AccessibilityNodeInfo node, String text) {
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private void retryOrError(String message, String phase) {
        SharedPreferences p = prefs();
        int retry = p.getInt(KEY_PASTE_RETRY, 0) + 1;
        p.edit().putInt(KEY_PASTE_RETRY, retry).apply();
        if (retry <= 3) {
            setStatus(message + " 재시도 " + retry + "/3");
            if (PHASE_WAIT_PASTE.equals(phase)) schedulePaste(PASTE_DEBOUNCE_MS);
            else schedulePasteRead(PASTE_READ_DEBOUNCE_MS);
        } else {
            error(message);
        }
    }

    private void complete(String reason) {
        SharedPreferences p = prefs();
        int count = CollectionRepository.count(this);
        long now = System.currentTimeMillis();
        p.edit()
                .putBoolean(KEY_ACTIVE, false)
                .putString(KEY_PHASE, PHASE_COMPLETE)
                .putInt(KEY_COLLECTED_COUNT, count)
                .putLong(KEY_FINISHED_AT, now)
                .putString(KEY_FINISH_REASON, reason)
                .putString(KEY_STATUS, "✅ 완료됨 · 총 " + count + "건 · " + reason)
                .apply();
        log("COMPLETE count=" + count + " reason=" + reason);
        Toast.makeText(this, "✅ 완료됨 · " + count + "건 수집. Collector로 돌아가 TXT를 저장하세요.", Toast.LENGTH_LONG).show();
    }

    private void error(String message) {
        long now = System.currentTimeMillis();
        prefs().edit()
                .putBoolean(KEY_ACTIVE, false)
                .putString(KEY_PHASE, PHASE_ERROR)
                .putLong(KEY_FINISHED_AT, now)
                .putString(KEY_FINISH_REASON, message)
                .putString(KEY_STATUS, "❌ 오류 · " + message)
                .apply();
        log("ERROR " + message);
        Toast.makeText(this, "❌ 수집 오류 · " + message, Toast.LENGTH_LONG).show();
    }

    private void setStatus(String status) {
        prefs().edit().putString(KEY_STATUS, status).apply();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private Rect bounds(AccessibilityNodeInfo node) {
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        return r;
    }

    private int parseKoreanTime(String s) {
        if (s == null) return -1;
        String v = s.trim();
        try {
            boolean pm = v.startsWith("오후");
            boolean am = v.startsWith("오전");
            if (!pm && !am) return -1;
            v = v.replace("오전", "").replace("오후", "").trim();
            String[] parts = v.split(":");
            if (parts.length != 2) return -1;
            int h = Integer.parseInt(parts[0].trim());
            int m = Integer.parseInt(parts[1].trim());
            if (h == 12) h = 0;
            if (pm) h += 12;
            return h * 60 + m;
        } catch (Exception e) {
            return -1;
        }
    }

    private String parseKoreanDate(String s) {
        if (s == null) return null;
        try {
            // Weekday suffix is ignored by extracting only Y/M/D numbers.
            String digits = s.replaceAll("[^0-9]+", " ").trim();
            String[] p = digits.split("\\s+");
            if (p.length < 3) return null;
            return String.format(Locale.KOREA, "%04d-%02d-%02d",
                    Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
        } catch (Exception e) {
            return null;
        }
    }

    private long epochFor(String yyyyMmDd, int minutes) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA);
            fmt.setLenient(false);
            Date d = fmt.parse(yyyyMmDd + " " + CollectionRepository.formatMinutes(minutes));
            return d == null ? System.currentTimeMillis() : d.getTime();
        } catch (ParseException e) {
            return System.currentTimeMillis();
        }
    }

    private String buildScreenSignature(List<MessageCandidate> candidates) {
        StringBuilder sb = new StringBuilder();
        for (MessageCandidate c : candidates) {
            sb.append(c.minutes).append('|').append(c.stableId).append('|').append(compact(c.preview)).append(";;");
        }
        return sb.toString();
    }

    private String todayString() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(new Date());
    }

    private void log(String message) {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA).format(new Date());
        LogRepository.append(this, time + " | " + message + "\n");
    }

    private static String compact(String s) {
        if (s == null) return "";
        String oneLine = s.replace('\n', ' ').replace('\r', ' ').trim();
        if (oneLine.length() > 120) return oneLine.substring(0, 120) + "...";
        return oneLine;
    }

    @Override
    public void onInterrupt() {
        log("Accessibility service interrupted");
    }
}
