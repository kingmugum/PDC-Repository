package com.example.suresoftmessengercollector;

import android.content.Context;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class CollectionRepository {
    private static final Object LOCK = new Object();
    private static final String FILE_NAME = "collected_messages.tsv";

    private CollectionRepository() {}

    public static final class Record {
        public final int order;
        public final long epochMillis;
        public final String text;

        Record(int order, long epochMillis, String text) {
            this.order = order;
            this.epochMillis = epochMillis;
            this.text = text;
        }
    }

    private static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    public static void clear(Context context) {
        synchronized (LOCK) {
            try (FileOutputStream fos = new FileOutputStream(file(context), false)) {
                fos.write(new byte[0]);
            } catch (Exception ignored) {}
        }
    }

    public static boolean add(Context context, int order, long epochMillis, String text) {
        if (text == null || text.trim().isEmpty()) return false;
        synchronized (LOCK) {
            String uniqueKey = epochMillis + "|" + text;
            Set<String> existing = new HashSet<>();
            for (Record r : readInternal(context)) {
                existing.add(r.epochMillis + "|" + r.text);
            }
            if (existing.contains(uniqueKey)) return false;

            String encoded = Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            String line = order + "\t" + epochMillis + "\t" + encoded + "\n";
            try (FileOutputStream fos = new FileOutputStream(file(context), true)) {
                fos.write(line.getBytes(StandardCharsets.UTF_8));
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    public static List<Record> readChronological(Context context) {
        synchronized (LOCK) {
            List<Record> list = readInternal(context);
            Collections.sort(list, new Comparator<Record>() {
                @Override
                public int compare(Record a, Record b) {
                    int byTime = Long.compare(a.epochMillis, b.epochMillis);
                    if (byTime != 0) return byTime;
                    // Collection proceeds old -> new. For identical minute values preserve the
                    // original capture order instead of reversing same-minute bubbles.
                    return Integer.compare(a.order, b.order);
                }
            });
            return list;
        }
    }


    public static boolean hasCapturedPreview(Context context, long epochMillis, String preview) {
        if (preview == null || preview.trim().isEmpty()) return false;
        String normalizedPreview = preview.trim();
        // v0.9: only an exact short/full-text preview is safe for pre-copy dedupe. Long messenger
        // previews are truncated and different split bubbles can share the same prefix.
        if (normalizedPreview.length() >= 300) return false;
        synchronized (LOCK) {
            for (Record r : readInternal(context)) {
                if (r.epochMillis != epochMillis) continue;
                String full = r.text == null ? "" : r.text.trim();
                if (full.equals(normalizedPreview)) return true;
            }
        }
        return false;
    }

    public static String shortTextHash(String text) {
        if (text == null) return "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(8, digest.length); i++) {
                sb.append(String.format(Locale.ROOT, "%02x", digest[i] & 0xff));
            }
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(text.hashCode());
        }
    }

    public static int count(Context context) {
        synchronized (LOCK) {
            return readInternal(context).size();
        }
    }

    public static String exportText(Context context, String date, int startMin, int endMin) {
        StringBuilder sb = new StringBuilder();
        sb.append("Suresoft Messenger Collector v1.0\n");
        sb.append("Target chat: 박동천 (나와의 대화)\n");
        sb.append("Date: ").append(date).append('\n');
        sb.append("Range: ").append(formatMinutes(startMin)).append(" ~ ").append(formatMinutes(endMin)).append('\n');
        sb.append("Attachments: SKIPPED\n");
        sb.append("Internet permission: NONE\n\n");

        List<Record> records = readChronological(context);
        SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.KOREA);
        for (int i = 0; i < records.size(); i++) {
            Record r = records.get(i);
            sb.append("[").append(timeFmt.format(new Date(r.epochMillis))).append("]\n\n");
            sb.append(r.text.trim()).append("\n");
            if (i < records.size() - 1) {
                sb.append("\n--------------------------------------------------\n\n");
            }
        }
        return sb.toString();
    }

    private static List<Record> readInternal(Context context) {
        List<Record> list = new ArrayList<>();
        File f = file(context);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\t", 3);
                if (parts.length != 3) continue;
                int order = Integer.parseInt(parts[0]);
                long epoch = Long.parseLong(parts[1]);
                String text = new String(Base64.decode(parts[2], Base64.NO_WRAP), StandardCharsets.UTF_8);
                list.add(new Record(order, epoch, text));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static String formatMinutes(int minutes) {
        int h = Math.max(0, Math.min(23, minutes / 60));
        int m = Math.max(0, Math.min(59, minutes % 60));
        return String.format(Locale.KOREA, "%02d:%02d", h, m);
    }
}
