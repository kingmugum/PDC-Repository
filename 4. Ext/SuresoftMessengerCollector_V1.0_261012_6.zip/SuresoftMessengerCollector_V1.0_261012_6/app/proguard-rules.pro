# v0.1 PoC - no shrinking rules required.
