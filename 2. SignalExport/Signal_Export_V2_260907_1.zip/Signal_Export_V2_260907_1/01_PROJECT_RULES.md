# 01_PROJECT_RULES.md — Signal Export V2

> **Project:** Signal Export V2  
> **Document Version:** v1.0  
> **Effective Date:** 2026-09-07  
> **Role:** Signal Export V2에만 적용되는 개발·요구사항·배포 운영 규칙  
> **Governance Parent:** `00_AI_DEVELOPMENT_CONSTITUTION.md`

---

## 1. 목적

이 문서는 사용자가 Signal Export 기능 추가·수정·삭제를 요청할 때 AI가 매번 같은 관리 지시를 다시 요구하지 않고 자동으로 적용할 프로젝트 고유 규칙을 정의한다.

사용자가 다음과 같이 기능만 요청해도:

> `XX 기능을 추가해줘.`  
> `이 동작을 수정해줘.`  
> `이 기능은 삭제해줘.`

AI는 개발헌법, 본 문서와 최신 Requirements Excel을 먼저 확인하고 요구사항·코드·시험·배포를 하나의 변경 작업으로 관리한다.

---

## 2. 문서 권한과 역할

1. 사용자의 현재 명시적 지시
2. `SignalAuto_Requirements_Management_revXX_V2.xlsx` — 기능·동작의 Single Source of Truth
3. `00_AI_DEVELOPMENT_CONSTITUTION.md` — 공통 개발 절차와 AI 행동 원칙
4. `01_PROJECT_RULES.md` — Signal Export 고유 규칙
5. 검증된 기존 코드와 회귀 결과
6. `package_manifest.json`, 안내문, 과거 패키지

기능·입력·출력·판정·예외는 최신 승인 Requirements를 따른다. 패키지명, 모듈 선택, DBC 매핑, 카테고리와 배포 구성은 본 문서를 따른다.

---

## 3. 요구사항 이중 계층 구조

### 3.1 1층 — 사람용 사용자 시나리오

시트명: `사용자 시나리오`

열:

1. 시나리오 ID
2. 시나리오명
3. 사용자 목적·상황
4. 사용자 시나리오
5. 기대 결과
6. 관련 FR ID
7. 현황

시나리오명에는 `[설정]`, `[Step1]`, `[AI]`, `[GUI]`, `[배포]`처럼 짧은 분류를 포함한다. 별도의 기능 분류 열은 만들지 않는다.

현황 값은 `일치`, `검토중`, `불일치`, `미확인`, `폐기`만 사용한다. FR에서 역추적한 시나리오는 사람 승인 전까지 `검토중`으로 유지한다.

### 3.2 2층 — AI용 상세 계층

- `AI_01_문서목적·운영규칙`
- `AI_02_요구사항목록`
- `AI_03_판정기준`
- `AI_04_실패상황`
- `AI_05_변경금지조건`
- `AI_06_디버깅체크`
- `AI_07_회귀테스트`
- `AI_08_코드근거`
- `AI_09_AI작업규칙`
- `AI_10_요구사항충돌검토`

Signal Export Requirements Excel은 위 11개 시트만 기본 구조로 사용한다. 변경영향은 AI_10, 현재 코드 기준선은 AI_08, 배포 규칙은 본 문서와 manifest에서 관리한다.

### 3.3 추적성 규칙

- 모든 유효 FR은 상위 시나리오 하나에 귀속한다.
- 사용자 시나리오의 `관련 FR ID`와 AI_02의 `상위 시나리오 ID`는 서로 일치해야 한다.
- 기존 FR ID와 원문은 이중계층화만을 이유로 수정·재번호하지 않는다.
- 삭제·대체 시 기존 ID를 재사용하지 않고 유효성, 대체 ID와 변경 근거를 기록한다.
- rev57에서 사용되지 않은 `FR-023, 041, 042, 044, 051, 053, 060, 071, 073`은 과거 이력이 확인되기 전까지 재사용하지 않는다.
- 다음 신규 요구사항은 `FR-152`부터 부여한다.

---

## 4. 기능 변경 시 자동 작업 순서

```text
00_AI_DEVELOPMENT_CONSTITUTION.md 확인
        ↓
01_PROJECT_RULES.md 확인
        ↓
최신 Requirements Excel 확인
        ↓
관련 사용자 시나리오 확인
        ↓
관련 FR / 판정 / 실패상황 확인
        ↓
변경금지조건(LOCK) 확인
        ↓
영향 Module / Interface / Data 분석
        ↓
충돌·중복·회귀 영향 검토
        ↓
Requirements Excel 갱신
        ↓
코드 최소 변경
        ↓
변경 기능 Test + 관련 Regression
        ↓
코드근거 / 회귀테스트 / 충돌검토 갱신
        ↓
패키지 생성 및 무결성 확인
```

코드만 수정하거나 Excel만 수정한 상태를 완료로 처리하지 않는다.

---

## 5. ZIP 패키지 명명 규칙

전체 배포 패키지는 항상 다음 형식을 사용한다.

`Signal_Export_V2_YYMMDD_N.zip`

규칙:

1. `YYMMDD`는 Asia/Seoul 기준 실제 패키지 생성일이다.
2. `N`은 같은 날짜에 생성한 Signal Export V2 전체 ZIP의 순번이다.
3. 같은 날짜에는 기존 가장 큰 N 다음 번호를 사용한다.
4. 날짜가 바뀌면 `_1`부터 다시 시작한다.
5. 기존 동일 이름 패키지를 조용히 덮어쓰지 않는다.

---

## 6. Revision과 Package Sequence

다음 값은 서로 다른 축이다.

- Requirements document revision: `rev59` 등
- Python/PYW module revision: GUI `rev_23`, Main `rev_15`, Step별 revision 등
- ZIP package sequence: `_1`, `_2`, `_3` 등

규칙:

- Requirements Excel이 변경되면 문서 revision을 증가시킨다.
- 코드가 변경된 모듈만 해당 module revision을 증가시킨다.
- 문서·governance만 변경한 경우 Python module revision을 올리지 않는다.
- ZIP 순번은 문서·코드 revision과 독립적으로 날짜별 생성 횟수로 관리한다.

---

## 7. 배포 ZIP 필수 구성

### Governance

- `00_AI_DEVELOPMENT_CONSTITUTION.md`
- `01_PROJECT_RULES.md`
- `00_PACKAGE_NAMING_RULE.txt` — 과거 패키지 호환용 요약
- `package_manifest.json`

### 개발 기준

- 최신 `SignalAuto_Requirements_Management_revXX_V2.xlsx`
- 현재 GUI·Main·Report·Excel Compat·Step1~7·GLOBAL Step3 Python/PYW 모듈
- 해당 revision 안내문

### 기본 제외

- 회사 또는 고객사 원본 DBC
- 실제 BLF·ASC·TestCase와 사용자 결과 데이터
- API Key·인증정보·PC 고유 설정
- Python cache와 임시 파일

---

## 8. Signal Export Pipeline 경계

- GUI: 사용자 설정, 상태, 로그, 실행 제어
- Main: PipelineConfig의 최종 소유자, 최신 module 선택, 단계 실행
- Step1: BLF→ASC 변환과 파일명 정리
- Step2: DBC 기반 Message Group 생성과 선택적 AI 보강
- Step3: ASC 디코딩과 Message·Signal 변화 추출
- Step4: TestCase 매핑과 AI 문의 생성
- Step5: AI 호출·재시도·응답 정규화
- Step6: 선정 신호의 상세 변화 복원
- Step7: Input·Output·Excluded 분류
- GLOBAL Step3: 전체 ASC 디코딩과 변경 요약
- Report: 현재 산출물과 오류의 보고서 생성
- Excel Compat: XLS/XLSX·보호 문서 입력 처리

각 Step의 `run(config)` 진입점과 Main의 PipelineConfig 중심 전달 구조를 유지한다.

---

## 9. 카테고리 규칙

- 일반 카테고리는 12개를 유지한다.
- CONNECT 정식 prefix는 `12. Connect UX 사양서 기반 TC 검토 초안`이다.
- CONNECT 키워드는 `커넥트`, `UX`, `Connect`, `connect`를 사용한다.
- `connect`는 CONNECT, `connected`는 BLUELINK_CCS로 구분한다.
- GUI, Main, Step1, TestCase 시트 선택의 카테고리 정의를 서로 다르게 하드코딩하지 않는다.
- 기존 sender include 56개, message-name include 36개와 TP/DEV exclude 규칙을 근거 없이 축소·완화하지 않는다.

---

## 10. CAN·DBC 매핑 규칙

- 활성 CAN1~CAN4 각각 정확히 하나의 DBC를 사용한다.
- 애플리케이션은 논리 CAN과 DBC 관계를 관리하며 VN1640A 물리 channel 번호를 자동 추정하지 않는다.
- 자동 감지는 파일명 근거만 사용한다.
- 모든 활성 CAN 매핑이 하나로 확정될 때에만 전체를 일괄 적용한다.
- 누락·중복·모호함이 있으면 일부만 적용하지 않고 기존 설정 전체를 유지한다.
- DBC 내용 유사도, 메시지 포함 여부 또는 물리 CH→CAN 추측으로 매핑하지 않는다.

---

## 11. Step2 AI 보강 규칙

- 기본값은 OFF이다.
- 선택 상태는 다음 실행에 자동 저장하지 않는다.
- AI 후보는 규칙 기반 결과에 추가만 한다.
- Hard Exclude와 기존 제외 정책은 AI보다 우선한다.
- API 실패·응답 오류·정규화 실패 시 규칙 기반 결과로 fallback한다.
- AI가 기존 Rule 후보를 삭제하거나 제외 규칙을 우회하게 하지 않는다.

---

## 12. 파일·데이터·비밀정보 보호

- 원본 BLF·ASC·DBC·TestCase를 직접 수정하지 않는다.
- 산출물은 정의된 결과 폴더에 별도 생성한다.
- 미해결 error·warning을 성공처럼 숨기거나 임의 삭제하지 않는다.
- 성공한 동일 케이스의 stale error만 요구사항에 따라 정리한다.
- API Key를 로그, 설정 미리보기, error, Report에 평문으로 출력하지 않는다.
- 보호되거나 암호화된 Excel을 우회 해제하거나 손상시키지 않는다.

---

## 13. 검증 상태 표현

다음 상태는 서로 다르다.

- 코드 구현 또는 문서 반영
- Python compile 통과
- 정적·합성·함수 확인
- 실제 DBC·BLF·ASC·TestCase 회귀
- 외부 AI API 호출 확인
- 실제 사용자 환경 확인

따라서 `compile PASS` 또는 `정적 감사 PASS`를 전체 기능 검증 PASS로 표현하지 않는다.

rev59 기준 AI_07에는 145개 회귀 항목이 있으며 상태는 다음과 같다.

- 수행 74
- 정적/합성확인 1
- 정적/함수확인 3
- 정적확인 4
- 부분수행 12
- 미수행 51

부분수행·미수행은 후속 검증 대상으로 유지한다.

---

## 14. AI 자동 준수 선언

향후 ZIP에 개발헌법과 본 문서가 포함되어 있으면 AI는 다음 지시를 별도로 요구하지 않는다.

- 요구사항 Excel도 갱신해줘.
- 사용자 시나리오와 FR을 연결해줘.
- 기존 요구사항과 충돌을 확인해줘.
- 변경금지조건과 회귀시험을 확인해줘.
- 코드근거를 갱신해줘.
- 패키지 날짜·순번 규칙을 지켜줘.
- 개발헌법을 준수해줘.

위 항목은 Signal Export 개발의 기본 작업 계약이다.

---

## 15. 완료 조건

- [ ] 개발헌법 확인
- [ ] PROJECT_RULES 확인
- [ ] 최신 Requirements 확인
- [ ] 사용자 시나리오와 관련 FR 영향 확인
- [ ] 변경금지조건 확인
- [ ] 요구사항 충돌·중복 확인
- [ ] 코드 최소 변경
- [ ] 변경 기능 시험
- [ ] 관련 Regression 확인
- [ ] 미수행·부분수행 구분
- [ ] AI_08 코드근거 갱신
- [ ] AI_10 충돌검토 갱신
- [ ] 최신 Requirements ZIP 포함
- [ ] Governance 문서 ZIP 포함
- [ ] ZIP 날짜·순번 확인
- [ ] module rev·Requirements rev·ZIP 순번 분리 확인
- [ ] ZIP 무결성 확인

---

## 16. 현재 기준

2026-09-07 기준:

- Requirements: `SignalAuto_Requirements_Management_rev59_V2.xlsx`
- 기준 배포: `Signal_Export_V2_260907_1.zip`
- 코드 기준: rev57 패키지의 Python/PYW 12개 파일과 동일
- 요구사항 구조: 사용자 시나리오 1층 + AI_01~AI_10 2층
- 사용자 시나리오: 24개, 모두 `검토중`
- 활성 FR: 142개
- 다음 신규 FR: `FR-152`
- 기능 논리 충돌: 0건
- 과거 미사용 FR 번호 이력 확인: 1건

이 값은 다음 승인 변경 및 배포에서 갱신한다.
