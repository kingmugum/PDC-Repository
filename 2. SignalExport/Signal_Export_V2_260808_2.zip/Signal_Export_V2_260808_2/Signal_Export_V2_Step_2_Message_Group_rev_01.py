# -*- coding: utf-8 -*-
"""
step_2_group_message_export.py

목적
- DBC 파일들을 스캔하여 message_group txt 생성
- 모든 설정은 main.py에서 관리
- 이 파일은 순수 실행 모듈 역할만 수행

사전 설치
    py -m pip install cantools
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable
import re
import cantools


def compile_token_regexes(keywords: Iterable[str], ignore_case: bool) -> list[re.Pattern]:
    flags = re.IGNORECASE if ignore_case else 0
    return [
        re.compile(rf"(^|_){re.escape(str(kw))}(_|$)", flags)
        for kw in keywords
        if str(kw).strip()
    ]


def token_match_any(text: str, token_regexes: list[re.Pattern]) -> bool:
    return any(rx.search(text) for rx in token_regexes)


def resolve_dbc_paths(base_dir: Path, dbc_files: list[str]) -> list[Path]:
    dbc_paths = []

    if not dbc_files:
        raise FileNotFoundError("dbc_files_step2가 비어 있음")

    for name in dbc_files:
        p = Path(name)
        if not p.is_absolute():
            p = base_dir / name

        if not p.exists():
            raise FileNotFoundError(f"DBC 파일을 찾지 못했습니다: {p}")

        dbc_paths.append(p)

    return dbc_paths


def export_message_group(
    base_dir: Path,
    include_keywords: list[str],
    include_message_name_keywords: list[str],
    exclude_keywords: list[str],
    include_ignore_case: bool,
    include_message_name_ignore_case: bool,
    dbc_files: list[str],
    output_txt: str,
) -> Path:
    """
    DBC들을 스캔하여 message_group txt 생성
    """
    include_sender_rxs = compile_token_regexes(include_keywords, include_ignore_case)

    include_msgname_rxs = (
        compile_token_regexes(include_message_name_keywords, include_message_name_ignore_case)
        if include_message_name_keywords
        else []
    )

    # exclude는 항상 대소문자 무시
    exclude_rxs = compile_token_regexes(exclude_keywords, ignore_case=True) if exclude_keywords else []

    dbc_paths = resolve_dbc_paths(base_dir, dbc_files)

    matched_sender_nodes = set()
    selected_names = set()

    # =====================================================
    # 1차: ECU(sender) 이름에 include_keywords가 있는 sender만 수집
    # =====================================================
    for dbc_path in dbc_paths:
        print(f"[SCAN-1] {dbc_path.name} (collect matched ECUs)")
        db = cantools.database.load_file(str(dbc_path))

        for msg in db.messages:
            msg_name = msg.name
            senders = msg.senders or []

            # 제외: 메시지명 또는 sender에 제외 토큰 있으면 스킵
            if exclude_rxs:
                if token_match_any(msg_name, exclude_rxs) or any(token_match_any(s, exclude_rxs) for s in senders):
                    continue

            for s in senders:
                if token_match_any(s, include_sender_rxs):
                    matched_sender_nodes.add(s)

    # =====================================================
    # 2차:
    # - matched_sender_nodes가 송신자인 모든 메시지 포함
    # - 또는 메시지명에 include_message_name_keywords가 있으면 그 메시지만 추가 포함
    # =====================================================
    for dbc_path in dbc_paths:
        print(f"[SCAN-2] {dbc_path.name} (include all msgs of matched ECUs + matched msg names)")
        db = cantools.database.load_file(str(dbc_path))

        for msg in db.messages:
            msg_name = msg.name
            senders = msg.senders or []

            if exclude_rxs:
                if token_match_any(msg_name, exclude_rxs) or any(token_match_any(s, exclude_rxs) for s in senders):
                    continue

            ecu_matched = any(s in matched_sender_nodes for s in senders)
            msgname_matched = token_match_any(msg_name, include_msgname_rxs) if include_msgname_rxs else False

            if ecu_matched or msgname_matched:
                selected_names.add(msg_name)

    sorted_names = sorted(selected_names, key=str.upper)

    out_path = base_dir / output_txt
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"#INCLUDE(sender only): {', '.join(include_keywords)}\n")

        if include_message_name_keywords:
            f.write(f"#INCLUDE(message name only): {', '.join(include_message_name_keywords)}\n")

        if exclude_keywords:
            f.write(f"#EXCLUDE(case-insensitive): {', '.join(exclude_keywords)}\n")

        for p in dbc_paths:
            f.write(f"#DBC: {p.name}\n")

        if matched_sender_nodes:
            f.write("#Matched ECU(Transmitter): " + ", ".join(sorted(matched_sender_nodes)) + "\n")

        for name in sorted_names:
            f.write(name + "\n")

    print(f"[OK] saved: {out_path}")
    print(f"[OK] matched ECU count: {len(matched_sender_nodes)}")
    print(f"[OK] unique message count: {len(sorted_names)}")

    return out_path


def run(config) -> None:
    """
    main.py에서 호출하는 진입점
    """
    base_dir = Path(config.base_dir)

    include_keywords = list(config.include_keywords)
    include_message_name_keywords = list(config.include_message_name_keywords)
    exclude_keywords = list(config.exclude_keywords)

    include_ignore_case = bool(config.include_ignore_case)
    include_message_name_ignore_case = bool(config.include_message_name_ignore_case)

    dbc_files = list(config.dbc_files_step2)
    output_txt = config.output_txt_step2

    print(f"[INFO] ACTIVE_CATEGORY = {config.active_category}")
    print(f"[INFO] INCLUDE_KEYWORDS = {include_keywords}")
    print(f"[INFO] INCLUDE_MESSAGE_NAME_KEYWORDS = {include_message_name_keywords}")
    print(f"[INFO] EXCLUDE_KEYWORDS = {exclude_keywords}")
    print(f"[INFO] INCLUDE_IGNORE_CASE = {include_ignore_case}")
    print(f"[INFO] INCLUDE_MESSAGE_NAME_IGNORE_CASE = {include_message_name_ignore_case}")
    print(f"[INFO] OUTPUT_TXT = {output_txt}")

    if not include_keywords and not include_message_name_keywords:
        print("[WARN] include 키워드가 비어 있음. 결과가 비어 있을 수 있음.")

    export_message_group(
        base_dir=base_dir,
        include_keywords=include_keywords,
        include_message_name_keywords=include_message_name_keywords,
        exclude_keywords=exclude_keywords,
        include_ignore_case=include_ignore_case,
        include_message_name_ignore_case=include_message_name_ignore_case,
        dbc_files=dbc_files,
        output_txt=output_txt,
    )



def _load_latest_v2_main_module():
    """같은 폴더의 Signal_Export_V2_Main_rev_xx.py 중 가장 높은 rev를 로드한다."""
    import importlib.util
    import re as _re
    import sys as _sys
    code_dir = Path(__file__).resolve().parent
    base = "Signal_Export_V2_Main"
    rx = _re.compile(rf"^{_re.escape(base)}(?:[_\-.])rev(?:[_\-.])?(\d+)\.py$", _re.IGNORECASE)
    best = None
    for path in code_dir.glob(f"{base}*.py"):
        m = rx.match(path.name)
        if not m:
            continue
        rev = int(m.group(1))
        if best is None or rev > best[0]:
            best = (rev, path)
    selected = best[1] if best else code_dir / f"{base}.py"
    if not selected.is_file():
        raise FileNotFoundError(f"{base}_rev_xx.py를 찾지 못했습니다: {code_dir}")
    module_name = f"_dyn_{base}_{selected.stem}"
    spec = importlib.util.spec_from_file_location(module_name, str(selected))
    if spec is None or spec.loader is None:
        raise ImportError(f"Main 모듈 spec 생성 실패: {selected}")
    module = importlib.util.module_from_spec(spec)
    _sys.modules[module_name] = module
    spec.loader.exec_module(module)
    print(f"[INFO] Selected latest V2 Main: {selected.name}")
    return module


def main() -> None:
    main_module = _load_latest_v2_main_module()
    run(main_module.build_config())


if __name__ == "__main__":
    main()
