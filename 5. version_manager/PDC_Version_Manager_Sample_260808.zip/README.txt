PDC Version Manager - Sample
============================

목적
----
여러 PC에서 개인 프로그램 프로젝트를 Git 원격 저장소로 동기화하고,
YYMMDD_N 형식으로 버전 이력을 자동 관리하는 GUI 샘플입니다.

예시 버전
---------
260808_1
260808_2
260808_3
260809_1

필요 조건
---------
1. Windows PC
2. Python 3.x
3. Git for Windows
4. GitHub/GitLab 등의 원격 저장소
5. Git 인증이 PC에 구성되어 있어야 함
   - HTTPS + Git Credential Manager 또는
   - SSH

실행
----
python pdc_version_manager_sample.py

처음 사용할 PC
--------------
방법 A) 이미 로컬에 Git 프로젝트가 있는 경우
1. 프로그램 실행
2. "로컬 프로젝트 등록"
3. 프로젝트 폴더 선택
4. 해당 저장소에 origin이 이미 연결되어 있으면 바로 사용

방법 B) 다른 PC에서 처음 받는 경우
1. 프로그램 실행
2. "원격 저장소 Clone"
3. GitHub/GitLab 저장소 URL 입력
4. 저장할 상위 폴더 선택
5. 이후 목록에서 프로젝트를 선택하여 사용

주요 버튼
---------
[최신 버전 받기]
- git fetch origin --tags
- git pull --ff-only
- 로컬 수정이 있거나 Git 이력이 분기된 경우 자동 병합하지 않고 중단

[새 버전 업로드]
- 원격 최신 상태 확인
- 오늘 날짜 기준 다음 버전 자동 계산 (예: 260808_3)
- git add -A
- git commit
- git tag -a 260808_3
- git push
- git push origin 260808_3

[이력 보기]
- 최근 100개 커밋/태그/변경내용 표시

최초 설정도 GUI에서 가능
------------------------
[Git 사용자 설정]
- Git 사용자 이름/이메일을 전역 설정으로 저장

[원격 연결 설정]
- 선택한 로컬 프로젝트에 GitHub/GitLab의 origin URL 등록 또는 변경

새 프로젝트를 GitHub와 연결하는 기본 예
--------------------------------------
1. GitHub에서 빈 Private Repository 생성
2. PDC Version Manager에서 로컬 프로젝트 등록
3. "원격 연결 설정" 버튼으로 저장소 URL 입력
4. 파일을 수정한 뒤 "새 버전 업로드"

주의
----
- 이 샘플은 merge conflict를 자동 해결하지 않습니다.
- .py, .json, .md 같은 텍스트 파일 관리에 가장 적합합니다.
- .zip, .exe, 대용량 로그, BLF/ASC 등은 필요하면 .gitignore로 제외하는 것을 권장합니다.
- 이미 다른 PC에서 수정한 내용이 원격에 올라간 상태라면 먼저 "최신 버전 받기"를 실행하십시오.
