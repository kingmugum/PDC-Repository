# BoardRepo 260809_5 (Technical v0.19)

## 이번 보정

이번 버전은 `260809_4` 실사용 로그에서 확인된 Ext 중복검사의 마지막 문제를 보정합니다.

기존 로그:

```text
정확제목=있음
파일명=있음
행링크=없음
→ 기존 게시글 상세 진입 실패
→ SHA-256 확인 불가
→ CONFLICT
```

즉 BoardRepo가 **기존 Ext 게시글이 있다는 사실은 정확히 찾았지만**, 게시판 행에
일반적인 `/post/...` href가 노출되지 않아 본문 SHA를 읽지 못했습니다.

`260809_5`부터는 다운로드에서 실제로 성공한 게시글 진입 방식을 공용화하여
업로드 Ext 중복검사에서도 동일하게 사용합니다.

---

## 공용 게시글 상세 진입

신규 공용 모듈:

```text
function/board_post_navigation.py
```

다운로드와 업로드 Ext 중복검사가 모두 이 모듈을 사용합니다.

상세 진입 순서:

```text
정확한 BoardRepo 제목 확인
        ↓
실제 /post/ href가 있나?
        ├─ YES → 해당 상세 URL 사용
        └─ NO
             ↓
        같은 제목의 게시판 행 확인
             ↓
        제목 셀 자체 클릭
             ↓
        실제 게시글 상세 진입 확인
```

화면에서 제목이 줄바꿈된 경우에도 공백을 무시하고 논리 제목을 비교합니다.

---

## Ext 중복검사

예:

```text
로컬:
인공지능 검증 논문.pdf
SHA-256 = 835cd8...

게시판:
[BoardRepo][Ext] 인공지능 검증 논문.pdf
```

동작:

```text
동일 제목 행 발견
→ 공용 제목행 상세 진입
→ 기존 게시글 본문 읽기
→ 기존 SHA-256 추출
→ 현재 파일 SHA와 비교
```

결과:

```text
SHA 동일
→ DUPLICATE
→ 신규 업로드 안 함

SHA 다름
→ CONFLICT
→ 확인 필요 Skip

SHA 확인 불가
→ CONFLICT
→ 확인 필요 Skip
```

---

## 기대 로그

정상적으로 기존 Ext 글에 들어간다면 다음과 같은 로그가 추가됩니다.

```text
게시글 상세 탐색 [Ext] 1차: 제목 일치 행=1
게시글 상세 진입 성공: 제목 셀 클릭 (.../board/376/post/...)
Ext 기존 게시글 상세 진입 [인공지능 검증 논문.pdf]: .../post/...
Ext 기존 SHA 확인 [인공지능 검증 논문.pdf]: 835cd8895127...

원격 중복검사 [Ext] 인공지능 검증 논문.pdf:
DUPLICATE - 동일 파일명 Ext 게시글의 SHA-256이 현재 파일과 일치합니다.
```

이 경우 `확인 필요 Skip`이 아니라 정상적인 `중복 Skip`으로 분류됩니다.

---

## 다운로드도 같은 공용 모듈 사용

기존 다운로드의:

```text
게시판 제목 선택
→ href가 없으면 제목 셀 클릭
→ 상세 글 진입
```

동작도 이제 동일한 `board_post_navigation.py`를 호출합니다.

PassFail / SignalExport / Backup / Ext의 원격 최신판 선택 및 로컬 비교 정책 자체는
변경하지 않았습니다.

---

## 기존 업로드 작성 엔진

다음 실제 글쓰기 엔진은 변경하지 않았습니다.

```text
function/browser_automation.py
```

로그인, DEXT5 본문 입력, 파일 첨부, 등록, 게시글 확인 로직은 기존 성공본을 유지합니다.

---

## 사용자 폴더

```text
1. PassFail
2. SignalExport
3. Ext
4. Backup
```

번호형 폴더/UI 정책도 그대로 유지됩니다.

---

## 현재 배포

```text
Package Release   : 260809_5
Technical Version : v0.19
Distribution      : BoardRepo_260809_5.zip
```
