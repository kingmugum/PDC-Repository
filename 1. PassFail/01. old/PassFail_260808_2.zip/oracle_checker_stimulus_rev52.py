# -*- coding: utf-8 -*-
"""
oracle_checker_stimulus_rev52.py

Oracle Checker experimental stimulus engine (isolated module).

Design rules
- This module is the ONLY rev52 module that writes CANoe bus Signal.Value.
- It does not import the Pass/Fail core, GUI, report, or multiple modules.
- It never creates/dispatches a CANoe instance. A connected CANoeClient-like object is injected by the GUI.
- It does not start/stop Measurement by itself.
- One execution handles one CAN signal only.
- Before writing, it reads the current value and ALWAYS attempts to restore that original value in finally.
- It does not calculate CRC/Alive/E2E and must therefore be blocked by the caller for such messages.
- Whether assigning CANoe Signal.Value results in a physical bus transmission depends on the active CANoe Configuration/IL/simulation setup.

rev52 is an experimental PoC. It is intentionally not a general CAN message transmitter.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import datetime as _dt
import json
from pathlib import Path
import threading
import time
from typing import Any, Dict, Optional, Tuple


class StimulusError(RuntimeError):
    pass


class StimulusValidationError(StimulusError):
    pass


@dataclass(frozen=True)
class StimulusProfile:
    tc_no: str
    channel: int
    message: str
    signal: str
    active_value: Any
    hold_sec: float = 0.5
    bus_name: str = "CAN"
    source: str = "Oracle input condition"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StimulusExecutionResult:
    ok: bool
    started_at: str
    finished_at: str
    tc_no: str
    channel: int
    message: str
    signal: str
    original_value: Any = None
    active_value: Any = None
    active_readback: Any = None
    restored_value: Any = None
    restore_ok: bool = False
    stopped_early: bool = False
    error: str = ""
    trace_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def coerce_numeric_value(value: Any) -> Any:
    """rev52 PoC only accepts numeric signal values."""
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else value
    text = str(value if value is not None else '').strip()
    if not text:
        raise StimulusValidationError('입력 Active Value가 비어 있습니다.')
    compact = text.replace(' ', '')
    try:
        if compact.lower().startswith(('0x', '+0x', '-0x')):
            sign = -1 if compact.startswith('-') else 1
            raw = compact[3:] if compact[0] in '+-' else compact[2:]
            return sign * int(raw, 16)
        if re_full_int(compact):
            return int(compact, 10)
        f = float(compact)
        return int(f) if f.is_integer() else f
    except Exception as e:
        raise StimulusValidationError(
            f'rev52 입력 1회 테스트는 숫자형 Active Value만 지원합니다: {text}'
        ) from e


def re_full_int(text: str) -> bool:
    if not text:
        return False
    if text[0] in '+-':
        return len(text) > 1 and text[1:].isdigit()
    return text.isdigit()


class StimulusExecutor:
    MIN_HOLD_SEC = 0.05
    MAX_HOLD_SEC = 5.0

    def __init__(self, trace_dir: Optional[str | Path] = None):
        self.trace_dir = Path(trace_dir) if trace_dir else None

    def _bus_candidates(self, client: Any, profile: StimulusProfile):
        names = []
        try:
            for x in client._bus_name_candidates():
                if x and x not in names:
                    names.append(x)
        except Exception:
            pass
        for x in (profile.bus_name, 'CAN'):
            x = str(x or '').strip()
            if x and x not in names:
                names.append(x)
        return names or ['CAN']

    def _get_signal_object(self, client: Any, profile: StimulusProfile) -> Tuple[Any, str]:
        app = getattr(client, 'app', None)
        if app is None:
            raise StimulusValidationError('주입된 CANoe client에 활성 app 객체가 없습니다.')
        last_error = None
        for bus_name in self._bus_candidates(client, profile):
            try:
                bus = app.GetBus(bus_name)
                sig = bus.GetSignal(int(profile.channel), str(profile.message), str(profile.signal))
                _ = sig.Value
                return sig, bus_name
            except Exception as e:
                last_error = e
        raise StimulusValidationError(
            f'CANoe Signal 객체 접근 실패: channel={profile.channel}, '
            f'message={profile.message}, signal={profile.signal}, 원인={last_error}'
        )

    def validate(self, client: Any, profile: StimulusProfile) -> Dict[str, Any]:
        if client is None:
            raise StimulusValidationError('CANoe client가 없습니다.')
        try:
            if not bool(client.is_connected()):
                raise StimulusValidationError('CANoe 연결이 없습니다.')
        except StimulusValidationError:
            raise
        except Exception as e:
            raise StimulusValidationError(f'CANoe 연결 상태 확인 실패: {e}') from e
        try:
            if not bool(client.is_measurement_running()):
                raise StimulusValidationError('CANoe Measurement가 실행 중이 아닙니다.')
        except StimulusValidationError:
            raise
        except Exception as e:
            raise StimulusValidationError(f'Measurement 상태 확인 실패: {e}') from e

        if int(profile.channel) <= 0:
            raise StimulusValidationError('유효한 CAN 채널이 아닙니다.')
        if not str(profile.message).strip() or not str(profile.signal).strip():
            raise StimulusValidationError('Message/Signal 이름이 비어 있습니다.')
        hold = float(profile.hold_sec)
        if hold < self.MIN_HOLD_SEC or hold > self.MAX_HOLD_SEC:
            raise StimulusValidationError(
                f'Hold time은 {self.MIN_HOLD_SEC:.2f}~{self.MAX_HOLD_SEC:.1f}s 범위만 허용합니다.'
            )
        active = coerce_numeric_value(profile.active_value)
        sig, bus_name = self._get_signal_object(client, profile)
        original = sig.Value
        if original is None:
            raise StimulusValidationError('실행 전 Signal 원래 값을 읽지 못해 안전한 원복 기준을 확보할 수 없습니다.')
        return {
            'bus_name': bus_name,
            'original_value': original,
            'active_value': active,
            'hold_sec': hold,
        }

    def execute_once(
        self,
        client: Any,
        profile: StimulusProfile,
        stop_event: Optional[threading.Event] = None,
    ) -> StimulusExecutionResult:
        started = _dt.datetime.now()
        result = StimulusExecutionResult(
            ok=False,
            started_at=started.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
            finished_at='',
            tc_no=str(profile.tc_no or ''),
            channel=int(profile.channel),
            message=str(profile.message),
            signal=str(profile.signal),
            active_value=profile.active_value,
        )

        signal_obj = None
        original = None
        try:
            checked = self.validate(client, profile)
            active = checked['active_value']
            signal_obj, _ = self._get_signal_object(client, profile)
            original = checked['original_value']
            result.original_value = original
            result.active_value = active

            # rev52's sole intentional write operation.
            signal_obj.Value = active
            try:
                result.active_readback = signal_obj.Value
            except Exception:
                result.active_readback = None

            deadline = time.monotonic() + float(checked['hold_sec'])
            while time.monotonic() < deadline:
                if stop_event is not None and stop_event.is_set():
                    result.stopped_early = True
                    break
                time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
            result.ok = True
        except Exception as e:
            result.error = f'{type(e).__name__}: {e}'
        finally:
            # Rollback is mandatory and independent of success/failure after the write.
            if signal_obj is not None and original is not None:
                try:
                    signal_obj.Value = original
                    try:
                        result.restored_value = signal_obj.Value
                    except Exception:
                        result.restored_value = original
                    result.restore_ok = True
                except Exception as restore_error:
                    result.restore_ok = False
                    suffix = f'원래 값 복원 실패: {type(restore_error).__name__}: {restore_error}'
                    result.error = f'{result.error} / {suffix}'.strip(' /')
                    result.ok = False
            result.finished_at = _dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            result.trace_path = self._append_trace(profile, result)
        return result

    def _append_trace(self, profile: StimulusProfile, result: StimulusExecutionResult) -> str:
        if self.trace_dir is None:
            return ''
        try:
            self.trace_dir.mkdir(parents=True, exist_ok=True)
            path = self.trace_dir / f"stimulus_execution_{_dt.datetime.now().strftime('%Y%m%d')}.jsonl"
            record = {
                'profile': profile.to_dict(),
                'result': result.to_dict(),
            }
            with path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(record, ensure_ascii=False, default=str) + '\n')
            return str(path)
        except Exception:
            return ''
