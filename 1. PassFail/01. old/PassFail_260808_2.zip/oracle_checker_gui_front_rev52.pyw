# -*- coding: utf-8 -*-
"""
oracle_checker_gui_front_rev52.pyw

Oracle Checker GUI front launcher
- oracle_checker_gui_onebyone_rev52.py : 단일 TC 실행 GUI 본체
- oracle_checker_gui_multiple_rev52.py : 다중 실행 탭/동작 mixin
- oracle_checker_gui_txrx_rev52.py     : 차량 송수신 테스트 탭/진단 mixin
- oracle_checker_main_rev52.py         : 판정 core (자동 최신 rev 로드)
- oracle_checker_stimulus_rev52.py     : 실험용 입력 자극 엔진(선택 모듈, TX/RX에서만 호출)

같은 폴더에 위 파일들을 두고 이 front 파일을 실행합니다.

rev52:
- rev50 단일/다중/차량 송수신 및 CANoe COM 진단 기능 유지
- 구성 모듈명을 rev52으로 동기화
- CAN 네트워크명 근거 기반 DBC 자동 매핑 기능 연동
- 실험용 실제 입력 기능은 oracle_checker_stimulus_rev52.py로 완전 분리
  * Stimulus 모듈이 없어도 기존 단일/다중 Pass/Fail GUI는 정상 실행
  * TX/RX 탭이 연결된 기존 CANoe client를 주입하여 1 Signal/1회 테스트만 호출
  * CANoe Configuration / ASC / 로그 파일명에서 CAN1~CAN3 ↔ XXX-CAN 명시 근거 탐색
  * DBC 자동 설정 폴더에서 유일 후보만 자동 적용
  * 미식별/충돌/0개/복수 후보는 기존 수동 DBC 값 보존
"""

from __future__ import annotations

import sys
import atexit
import shutil
from pathlib import Path

# __pycache__ 생성 억제 및 기존 캐시 폴더 정리
sys.dont_write_bytecode = True


def _cleanup_pycache(base_dir=None):
    try:
        root = Path(base_dir) if base_dir is not None else Path(__file__).resolve().parent
        for p in root.glob("__pycache__"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


_cleanup_pycache()
atexit.register(_cleanup_pycache)


# Windows에서 .py로 잘못 실행해도 가능하면 콘솔 노출을 줄이기 위한 시도
# .pyw 실행이 가장 권장됩니다.
def _try_hide_console():
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
    except Exception:
        pass


_try_hide_console()

from oracle_checker_gui_onebyone_rev52 import OracleCheckerOneByOneGui, CORE_MODULE_PATH
from oracle_checker_gui_multiple_rev52 import MultipleExecutionMixin
from oracle_checker_gui_txrx_rev52 import TxRxTestMixin


class OracleCheckerFrontGui(TxRxTestMixin, MultipleExecutionMixin, OracleCheckerOneByOneGui):
    def __init__(self):
        super().__init__()
        self.title(f"Oracle Checker - 단일/다중/차량 송수신 TC 수행 | core={CORE_MODULE_PATH.name}")


def main():
    app = OracleCheckerFrontGui()

    def _on_close():
        try:
            # rev52: 창 종료 중 Stimulus가 실행 중이면 먼저 stop_event를 보내
            # worker finally의 original value 원복 기회를 보장한다.
            try:
                if hasattr(app, "_txrx_stop_stimulus"):
                    app._txrx_stop_stimulus()
                th = getattr(app, "txrx_stimulus_thread", None)
                if th is not None and th.is_alive():
                    th.join(timeout=1.0)
            except Exception:
                pass
            if hasattr(app, "_save_current_user_settings"):
                app._save_current_user_settings()
            app.destroy()
        finally:
            _cleanup_pycache()

    try:
        app.protocol("WM_DELETE_WINDOW", _on_close)
    except Exception:
        pass

    try:
        app.mainloop()
    finally:
        _cleanup_pycache()


if __name__ == "__main__":
    main()
