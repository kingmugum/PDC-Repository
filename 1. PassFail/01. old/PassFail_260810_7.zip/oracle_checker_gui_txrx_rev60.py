# -*- coding: utf-8 -*-
"""
oracle_checker_gui_txrx_rev60.py

목적
- Oracle Checker GUI에 "차량 송수신 테스트" 탭을 추가하기 위한 mixin 모듈
- 기존 자동화 가능성 분석/실험 기록을 유지하면서, 독립 Stimulus 모듈을 통해 제한된 실제 입력 PoC를 수행한다.
- 선택 TC 단일 Signal 테스트와 수동 후보 Signal 묶음 테스트 외의 일반 CAN 송신/Replay 자동화는 비활성이다.

기능
- 기존 Excel/DBC/채널 설정 및 condition_rows를 재사용
- 선택 TC의 입력 조건을 "송신 대상"으로 Preview
- 출력 조건을 "차량 반응 수신/감시 대상"으로 Preview
- DBC 기준 Message/Signal 존재 여부 검사
- CAN1/CAN2/CAN3 채널 매핑 확인
- CRC/Alive/Counter류 Signal 포함 여부를 탐지하여 "확인 필요"로 표시
- 일반 송신/Replay 버튼은 안전상 비활성화 상태로 유지한다.
- 실제 입력 PoC는 명시적 Stimulus 활성화 + 확인 팝업을 통과한 제한 경로로만 제공한다.

rev60:
- rev49 차량 송수신 테스트 탭/실험 관리 기능을 그대로 유지
- 일반 CANoe 송신/Replay 자동화는 계속 비활성
- 실험용 입력 1회 테스트만 oracle_checker_stimulus_rev60.py 독립 모듈을 선택적으로 호출
- Stimulus 모듈 부재/오류가 기존 단일/다중 Pass/Fail 기능에 영향을 주지 않도록 optional import
- 기존 선택-TC 입력은 단일 Signal 1회 PoC로 유지하며 원래 Signal 값으로 반드시 원복
- rev60은 회사 Excel 등에서 복사한 후보 Signal 1~8개를 수동 붙여넣기하여 묶음 1회 테스트하는 기능을 추가
- 수동 후보 묶음은 모든 Signal을 사전검증한 뒤 적용하고, 실제 write된 모든 Signal을 finally에서 원래 값으로 복원
- CRC/Alive/Counter는 자동 계산하지 않으며, DBC에서 감지되면 기본 차단하고 사용자가 경고 허용을 명시한 경우에만 정적 값 시험을 허용
- Vector CANoe/CANalyzer COM 진단 기능은 공통 onebyone/main rev60에서 제공
- TX/RX 탭 전체 세로 스크롤은 마우스 휠을 지원하며, 내부 Treeview/ScrolledText 위에서는 내부 스크롤을 우선하고 경계에 도달하면 전체 스크롤로 넘긴다.
"""

from __future__ import annotations

import atexit
import csv
import datetime as _dt
import re
import shutil
import sys
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter.scrolledtext import ScrolledText

sys.dont_write_bytecode = True


def _cleanup_pycache(base_dir=None):
    try:
        root = Path(base_dir) if base_dir is not None else Path(__file__).resolve().parent
        for p in root.glob("__pycache__"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


_cleanup_pycache()
atexit.register(_cleanup_pycache)

import oracle_checker_gui_onebyone_rev60 as _onebyone

core = _onebyone.core

# rev60: 실험용 실제 입력 엔진은 선택 모듈이다.
# import 실패가 전체 GUI/기존 PassFail을 깨지 않도록 반드시 optional로 유지한다.
try:
    import oracle_checker_stimulus_rev60 as _stimulus
    STIMULUS_AVAILABLE = True
    STIMULUS_IMPORT_ERROR = ""
except Exception as _stimulus_import_error:
    _stimulus = None
    STIMULUS_AVAILABLE = False
    STIMULUS_IMPORT_ERROR = f"{type(_stimulus_import_error).__name__}: {_stimulus_import_error}"


class TxRxTestMixin:
    """차량 송수신 테스트 탭/동작을 추가하는 mixin."""

    TXRX_STATUS_UNCHECKED = "미검사"
    TXRX_STATUS_OK = "가능"
    TXRX_STATUS_WARN = "확인 필요"
    TXRX_STATUS_BAD = "불가"

    TXRX_METHOD_CAN = "CAN Signal 송신 후보"
    TXRX_METHOD_REPLAY = "로그 Replay 후보"
    TXRX_METHOD_PHYSICAL = "물리 입력/릴레이 필요"
    TXRX_METHOD_MANUAL = "수동 확인 필요"
    TXRX_METHOD_EXCLUDE = "초기 자동화 제외"
    TXRX_METHOD_UNKNOWN = "미분류"

    def _build_ui(self):
        super()._build_ui()
        self._init_txrx_state()
        self._build_txrx_tab()

    def _init_txrx_state(self):
        self.txrx_tab = None
        self.txrx_tree = None
        self.txrx_preview_text = None
        self.txrx_status_text = None
        self.txrx_result_tree = None
        self.txrx_log_text = None
        self.txrx_experiment_tree = None
        self.txrx_experiment_memo_text = None
        self.txrx_scroll_canvas = None
        self.txrx_outer_scrollbar = None
        self.txrx_scroll_content = None
        self.txrx_scroll_window = None
        self.txrx_inner_scroll_widgets = []
        self.txrx_status_var = tk.StringVar(value="대기중")
        self.txrx_selected_tc_var = tk.StringVar(value="선택 TC: -")
        self.txrx_summary_var = tk.StringVar(value="송신 가능성: 미검사")
        self.txrx_tx_enable_var = tk.BooleanVar(value=False)
        self.txrx_tx_mode_var = tk.StringVar(value="주기 송신")
        self.txrx_period_ms_var = tk.StringVar(value="100")
        self.txrx_duration_mode_var = tk.StringVar(value="수행 완료/중단까지")
        self.txrx_duration_sec_var = tk.StringVar(value="3.0")
        self.txrx_confirm_before_send_var = tk.BooleanVar(value=True)
        self.txrx_auto_stop_var = tk.BooleanVar(value=True)
        self.txrx_wait_sec_var = tk.StringVar(value="30")
        self.txrx_between_tc_delay_var = tk.StringVar(value="1.0")
        self.txrx_fail_policy_var = tk.StringVar(value="Fail 후 다음 TC 진행")
        # rev60: 실제 자동화 가능성을 한땀한땀 검증하기 위한 실험 기록 상태
        self.txrx_experiment_method_var = tk.StringVar(value="수동 기록")
        self.txrx_vehicle_reaction_var = tk.StringVar(value="미확인")
        self.txrx_output_judge_var = tk.StringVar(value="미확인")
        self.txrx_experiment_result_var = tk.StringVar(value="분석필요")
        self.txrx_cause_vars: Dict[str, tk.BooleanVar] = {
            "입력 Signal 부족 의심": tk.BooleanVar(value=False),
            "CRC/Alive 의심": tk.BooleanVar(value=False),
            "사전조건 부족 의심": tk.BooleanVar(value=False),
            "채널/DBC 매핑 의심": tk.BooleanVar(value=False),
            "실제 ECU 중복 송신 의심": tk.BooleanVar(value=False),
            "물리 버튼/릴레이 필요 의심": tk.BooleanVar(value=False),
            "출력 조건 재검토 필요": tk.BooleanVar(value=False),
        }
        self.txrx_experiment_records: List[Dict[str, Any]] = []
        self.txrx_selected_index: Optional[int] = None
        self.txrx_analysis_by_index: Dict[int, Dict[str, Any]] = {}
        # rev60 isolated experimental stimulus state
        self.txrx_stimulus_enable_var = tk.BooleanVar(value=False)
        self.txrx_stimulus_hold_sec_var = tk.StringVar(value="0.5")
        self.txrx_stimulus_status_var = tk.StringVar(
            value="Stimulus: 사용 가능" if STIMULUS_AVAILABLE else "Stimulus: 모듈 없음(기존 P/F 영향 없음)"
        )
        self.txrx_stimulus_stop_event = threading.Event()
        self.txrx_stimulus_thread: Optional[threading.Thread] = None
        # rev60: 현장 Excel에서 후보 Signal을 그대로 복사/붙여넣기하여 시험하기 위한 상태
        self.txrx_manual_candidate_text = None
        self.txrx_manual_candidate_status_var = tk.StringVar(value="수동 후보: 미검증")
        self.txrx_manual_crc_override_var = tk.BooleanVar(value=False)
        # rev60 CANalyzer CAPL backend safety gate: actual injection only after user confirms original sender is isolated/disabled.
        self.txrx_canalyzer_source_isolated_var = tk.BooleanVar(value=False)

    def _build_txrx_tab(self):
        if self.notebook is None:
            return

        self.txrx_tab = ttk.Frame(self.notebook, padding=6)
        self.notebook.add(self.txrx_tab, text="차량 송수신 테스트")

        # rev60: TX/RX 탭 전체를 하나의 세로 스크롤 작업면으로 구성한다.
        # 고DPI/작은 모니터에서도 상단 TC 목록과 하단 실험/로그 영역이 0 높이로 눌리지 않도록
        # 각 섹션은 자연 높이를 유지하고, 화면을 초과한 세로 길이는 우측 스크롤바로 탐색한다.
        self.txrx_tab.columnconfigure(0, weight=1)
        self.txrx_tab.rowconfigure(0, weight=1)

        scroll_host = ttk.Frame(self.txrx_tab)
        scroll_host.grid(row=0, column=0, sticky="nsew")
        scroll_host.columnconfigure(0, weight=1)
        scroll_host.rowconfigure(0, weight=1)

        self.txrx_scroll_canvas = tk.Canvas(scroll_host, highlightthickness=0, borderwidth=0)
        self.txrx_outer_scrollbar = ttk.Scrollbar(
            scroll_host, orient="vertical", command=self.txrx_scroll_canvas.yview
        )
        self.txrx_scroll_canvas.configure(yscrollcommand=self.txrx_outer_scrollbar.set)
        self.txrx_scroll_canvas.grid(row=0, column=0, sticky="nsew")
        self.txrx_outer_scrollbar.grid(row=0, column=1, sticky="ns")

        self.txrx_scroll_content = ttk.Frame(self.txrx_scroll_canvas, padding=(0, 0, 4, 8))
        self.txrx_scroll_window = self.txrx_scroll_canvas.create_window(
            (0, 0), window=self.txrx_scroll_content, anchor="nw"
        )

        def _sync_txrx_scrollregion(_event=None):
            bbox = self.txrx_scroll_canvas.bbox("all")
            if bbox:
                self.txrx_scroll_canvas.configure(scrollregion=bbox)

        def _sync_txrx_content_width(event):
            # 외부 가로 스크롤은 만들지 않고 현재 탭 폭을 그대로 사용한다.
            self.txrx_scroll_canvas.itemconfigure(self.txrx_scroll_window, width=max(1, event.width))

        self.txrx_scroll_content.bind("<Configure>", _sync_txrx_scrollregion, add="+")
        self.txrx_scroll_canvas.bind("<Configure>", _sync_txrx_content_width, add="+")

        parent = self.txrx_scroll_content
        parent.columnconfigure(0, weight=1)

        # 1) 상단 TC 목록
        list_frame = ttk.LabelFrame(parent, text="TC 목록 / 송신 가능성 목록")
        list_frame.grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 6))
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)

        columns = ("tc_no", "subcategory", "input", "output", "method", "feasibility", "experiment", "reason")
        self.txrx_tree = ttk.Treeview(list_frame, columns=columns, show="headings", selectmode="browse", height=12)
        headings = {
            "tc_no": "TC 번호",
            "subcategory": "소분류",
            "input": "입력 송신 대상",
            "output": "출력 감시 대상",
            "method": "자동화 방식 추천",
            "feasibility": "프리테스트 적합성",
            "experiment": "최근 실험결과",
            "reason": "진단 사유",
        }
        widths = {
            "tc_no": 90,
            "subcategory": 180,
            "input": 430,
            "output": 430,
            "method": 170,
            "feasibility": 120,
            "experiment": 120,
            "reason": 520,
        }
        anchors = {"tc_no": "center", "method": "center", "feasibility": "center", "experiment": "center"}
        for c in columns:
            self.txrx_tree.heading(c, text=headings[c])
            self.txrx_tree.column(c, width=widths[c], anchor=anchors.get(c, "w"), stretch=True)

        self.txrx_tree.tag_configure("unchecked", background="#FFFFFF", foreground="#111827")
        self.txrx_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_tree.tag_configure("bad", background="#FEE2E2", foreground="#991B1B")
        self.txrx_tree.tag_configure("selected", background="#DBEAFE", foreground="#111827")

        yscroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.txrx_tree.yview)
        xscroll = ttk.Scrollbar(list_frame, orient="horizontal", command=self.txrx_tree.xview)
        self.txrx_tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.txrx_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        self.txrx_tree.bind("<<TreeviewSelect>>", self._on_txrx_tree_select, add="+")
        self.txrx_tree.bind("<ButtonRelease-1>", self._on_txrx_tree_click, add="+")

        # 2) 중단 Preview + 설정/버튼
        middle = ttk.Frame(parent)
        middle.grid(row=1, column=0, sticky="nsew", padx=0, pady=(0, 6))
        middle.columnconfigure(0, weight=7)
        middle.columnconfigure(1, weight=4)
        middle.rowconfigure(0, weight=1)

        preview_frame = ttk.LabelFrame(middle, text="선택 TC 입력 송신 Preview")
        preview_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        self.txrx_preview_text = ScrolledText(preview_frame, height=16, wrap=tk.WORD)
        self.txrx_preview_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.txrx_preview_text.insert("1.0", "TC를 선택하면 입력 송신 대상과 출력 감시 대상 Preview가 표시됩니다.\n")

        control_frame = ttk.LabelFrame(middle, text="송신 설정 / 실행 버튼")
        control_frame.grid(row=0, column=1, sticky="nsew")
        for c in range(4):
            control_frame.columnconfigure(c, weight=1)

        warn_text = (
            "rev60은 기존 Pass/Fail과 분리된 실험용 Stimulus 모듈 PoC를 포함합니다.\n"
            "일반 송신/Replay 자동화는 계속 비활성이고, 선택 TC 1회 또는 수동 후보 1~8개 묶음만 명시적으로 실행합니다.\n"
            "CANoe는 Signal.Value 후 시작값 원복, CANalyzer는 수동 설치한 CAPL Bridge output() 후 baseline release Frame 방식입니다. "
            "CANalyzer 실제 송신 전에는 동일 Message 기존 송신원 분리·비활성 확인이 필수입니다."
        )
        tk.Label(
            control_frame,
            text=warn_text,
            anchor="w",
            justify="left",
            bg="#FEF3C7",
            fg="#92400E",
            padx=8,
            pady=6,
            font=("맑은 고딕", 9, "bold"),
        ).grid(row=0, column=0, columnspan=4, sticky="ew", padx=6, pady=(6, 4))

        ttk.Checkbutton(control_frame, text="입력 신호 송신 사용", variable=self.txrx_tx_enable_var, state="disabled").grid(
            row=1, column=0, columnspan=2, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="송신 방식").grid(row=2, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_tx_mode_var,
            values=["1회 송신", "주기 송신"],
            state="disabled",
            width=14,
        ).grid(row=2, column=1, sticky="w", padx=6, pady=3)
        ttk.Label(control_frame, text="송신 주기(ms)").grid(row=2, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_period_ms_var, width=10, state="disabled").grid(
            row=2, column=3, sticky="w", padx=6, pady=3
        )

        ttk.Label(control_frame, text="송신 지속시간").grid(row=3, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_duration_mode_var,
            values=["출력 PASS까지", "지정 시간", "수행 완료/중단까지"],
            state="disabled",
            width=18,
        ).grid(row=3, column=1, sticky="w", padx=6, pady=3)
        ttk.Label(control_frame, text="지정 시간(sec)").grid(row=3, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_duration_sec_var, width=10, state="disabled").grid(
            row=3, column=3, sticky="w", padx=6, pady=3
        )

        ttk.Checkbutton(control_frame, text="송신 전 확인 팝업 표시", variable=self.txrx_confirm_before_send_var, state="disabled").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=6, pady=3
        )
        ttk.Checkbutton(control_frame, text="수행 완료/중단 시 송신 자동 정지", variable=self.txrx_auto_stop_var, state="disabled").grid(
            row=4, column=2, columnspan=2, sticky="w", padx=6, pady=3
        )

        ttk.Label(control_frame, text="각 TC 출력 대기(sec)").grid(row=5, column=0, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_wait_sec_var, width=10, state="disabled").grid(
            row=5, column=1, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="TC 간 대기(sec)").grid(row=5, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_between_tc_delay_var, width=10, state="disabled").grid(
            row=5, column=3, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="Fail 처리 기준").grid(row=6, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_fail_policy_var,
            values=["Fail 후 다음 TC 진행", "Fail 시 전체 중단"],
            state="disabled",
            width=18,
        ).grid(row=6, column=1, columnspan=2, sticky="w", padx=6, pady=3)

        button_row = ttk.Frame(control_frame)
        button_row.grid(row=7, column=0, columnspan=4, sticky="ew", padx=6, pady=(8, 4))
        for c in range(5):
            button_row.columnconfigure(c, weight=1)
        ttk.Button(button_row, text="TC 목록 새로고침", command=self._refresh_txrx_tree).grid(
            row=0, column=0, sticky="ew", padx=(0, 4)
        )
        ttk.Button(button_row, text="선택 TC 검사", command=self._check_txrx_selected).grid(
            row=0, column=1, sticky="ew", padx=4
        )
        ttk.Button(button_row, text="전체 가능성 검사", command=self._check_txrx_all).grid(
            row=0, column=2, sticky="ew", padx=4
        )
        ttk.Button(button_row, text="입력 1회 테스트", command=self._txrx_stimulus_test_once).grid(
            row=0, column=3, sticky="ew", padx=4
        )
        ttk.Button(button_row, text="입력 즉시 원복/중단", command=self._txrx_stop_stimulus).grid(
            row=0, column=4, sticky="ew", padx=(4, 0)
        )
        ttk.Checkbutton(
            button_row, text="실험용 Stimulus 사용(명시적 활성화)", variable=self.txrx_stimulus_enable_var
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=(0, 4), pady=(6, 0))
        ttk.Label(button_row, text="Hold(sec)").grid(row=1, column=2, sticky="e", padx=4, pady=(6, 0))
        ttk.Entry(button_row, textvariable=self.txrx_stimulus_hold_sec_var, width=8).grid(
            row=1, column=3, sticky="w", padx=4, pady=(6, 0)
        )
        ttk.Label(button_row, textvariable=self.txrx_stimulus_status_var).grid(
            row=1, column=4, sticky="w", padx=(4, 0), pady=(6, 0)
        )

        tk.Label(
            control_frame,
            textvariable=self.txrx_status_var,
            anchor="center",
            relief="solid",
            bd=1,
            bg="#E5E7EB",
            fg="#111827",
            padx=8,
            pady=6,
            font=("맑은 고딕", 11, "bold"),
        ).grid(row=8, column=0, columnspan=4, sticky="ew", padx=6, pady=(8, 3))
        ttk.Label(control_frame, textvariable=self.txrx_selected_tc_var).grid(
            row=9, column=0, columnspan=4, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, textvariable=self.txrx_summary_var).grid(
            row=10, column=0, columnspan=4, sticky="w", padx=6, pady=(3, 6)
        )

        # rev60: 회사 Excel 등에서 후보 Signal 여러 행을 직접 붙여넣어 시험하는 독립 실험 영역
        candidate_frame = ttk.LabelFrame(control_frame, text="수동 후보 Signal 묶음 테스트 (rev60)")
        candidate_frame.grid(row=11, column=0, columnspan=4, sticky="ew", padx=6, pady=(4, 6))
        candidate_frame.columnconfigure(0, weight=1)
        ttk.Label(
            candidate_frame,
            text="Excel에서 4열을 복사해 붙여넣기: CAN1 | Message | Signal | ActiveValue  (1~8행)",
        ).grid(row=0, column=0, sticky="w", padx=5, pady=(4, 2))
        self.txrx_manual_candidate_text = ScrolledText(candidate_frame, height=7, wrap=tk.NONE)
        self.txrx_manual_candidate_text.grid(row=1, column=0, sticky="ew", padx=5, pady=3)
        candidate_buttons = ttk.Frame(candidate_frame)
        candidate_buttons.grid(row=2, column=0, sticky="ew", padx=5, pady=(2, 5))
        for c in range(4):
            candidate_buttons.columnconfigure(c, weight=1)
        ttk.Button(candidate_buttons, text="형식 예시", command=self._txrx_manual_candidate_example).grid(
            row=0, column=0, sticky="ew", padx=(0, 3)
        )
        ttk.Button(candidate_buttons, text="후보 검증", command=self._txrx_validate_manual_candidates_ui).grid(
            row=0, column=1, sticky="ew", padx=3
        )
        ttk.Button(candidate_buttons, text="후보 묶음 1회 테스트", command=self._txrx_manual_candidate_test_once).grid(
            row=0, column=2, sticky="ew", padx=3
        )
        ttk.Label(candidate_buttons, textvariable=self.txrx_manual_candidate_status_var).grid(
            row=0, column=3, sticky="w", padx=(3, 0)
        )
        ttk.Button(
            candidate_buttons, text="CANalyzer CAPL Bridge 생성", command=self._txrx_generate_canalyzer_capl_bridge
        ).grid(row=1, column=0, columnspan=2, sticky="ew", padx=(0, 3), pady=(4, 0))
        ttk.Label(
            candidate_buttons, text="생성 후 CANalyzer의 해당 CAN SEND branch에 수동 삽입 → Compile → Measurement 재시작"
        ).grid(row=1, column=2, columnspan=2, sticky="w", padx=3, pady=(4, 0))
        ttk.Checkbutton(
            candidate_frame,
            text="CRC/Alive/Counter 경고가 있어도 시험 허용 (자동 계산 안 함 / 정적 값만 사용)",
            variable=self.txrx_manual_crc_override_var,
        ).grid(row=3, column=0, sticky="w", padx=5, pady=(0, 3))
        ttk.Checkbutton(
            candidate_frame,
            text="CANalyzer 실제 송신 전: 동일 Message 기존 송신원(ECU/Generator) 분리·비활성 확인",
            variable=self.txrx_canalyzer_source_isolated_var,
        ).grid(row=4, column=0, sticky="w", padx=5, pady=(0, 5))

        # rev60: 실제 자동화 가능성을 하나씩 검증하기 위한 실험 결과 기록 영역
        experiment_frame = ttk.LabelFrame(control_frame, text="실험 결과 기록(수동)")
        experiment_frame.grid(row=12, column=0, columnspan=4, sticky="ew", padx=6, pady=(4, 6))
        for c in range(4):
            experiment_frame.columnconfigure(c, weight=1)

        ttk.Label(experiment_frame, text="실험 방식").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_experiment_method_var,
            values=["수동 기록", "CAN Signal 송신 후보", "로그 Replay 후보", "CAPL 송신 후보", "물리 입력/릴레이 필요"],
            state="readonly",
            width=20,
        ).grid(row=0, column=1, sticky="ew", padx=5, pady=3)
        ttk.Label(experiment_frame, text="차량 실제 반응").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_vehicle_reaction_var,
            values=["미확인", "움직임 확인", "움직임 없음", "일부 반응", "판단 불가"],
            state="readonly",
            width=14,
        ).grid(row=0, column=3, sticky="ew", padx=5, pady=3)

        ttk.Label(experiment_frame, text="출력 Signal 판정").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_output_judge_var,
            values=["미확인", "PASS", "FAIL", "N/A"],
            state="readonly",
            width=14,
        ).grid(row=1, column=1, sticky="ew", padx=5, pady=3)
        ttk.Label(experiment_frame, text="최종 실험 결과").grid(row=1, column=2, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_experiment_result_var,
            values=["OK", "NG", "PARTIAL", "수동필요", "Replay권장", "릴레이필요", "분석필요", "초기제외"],
            state="readonly",
            width=14,
        ).grid(row=1, column=3, sticky="ew", padx=5, pady=3)

        cause_frame = ttk.Frame(experiment_frame)
        cause_frame.grid(row=2, column=0, columnspan=4, sticky="ew", padx=5, pady=(3, 1))
        for i in range(4):
            cause_frame.columnconfigure(i, weight=1)
        for i, (label, var) in enumerate(self.txrx_cause_vars.items()):
            ttk.Checkbutton(cause_frame, text=label, variable=var).grid(
                row=i // 4, column=i % 4, sticky="w", padx=3, pady=1
            )

        ttk.Label(experiment_frame, text="실험 메모").grid(row=4, column=0, sticky="nw", padx=5, pady=(4, 3))
        self.txrx_experiment_memo_text = ScrolledText(experiment_frame, height=4, wrap=tk.WORD)
        self.txrx_experiment_memo_text.grid(row=4, column=1, columnspan=3, sticky="ew", padx=5, pady=(4, 3))

        experiment_buttons = ttk.Frame(experiment_frame)
        experiment_buttons.grid(row=5, column=0, columnspan=4, sticky="ew", padx=5, pady=(3, 5))
        for c in range(4):
            experiment_buttons.columnconfigure(c, weight=1)
        ttk.Button(experiment_buttons, text="실험 기록 저장", command=self._save_txrx_experiment_record).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(experiment_buttons, text="기록 CSV 저장", command=self._export_txrx_experiment_csv).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(experiment_buttons, text="입력 초기화", command=self._clear_txrx_experiment_inputs).grid(row=0, column=2, sticky="ew", padx=4)
        ttk.Button(experiment_buttons, text="기록 전체 초기화", command=self._reset_txrx_experiment_records).grid(row=0, column=3, sticky="ew", padx=(4, 0))

        # 3) 하단 상태/수신 결과
        lower = ttk.Frame(parent)
        lower.grid(row=2, column=0, sticky="nsew", padx=0, pady=(0, 6))
        lower.columnconfigure(0, weight=4)
        lower.columnconfigure(1, weight=7)
        lower.rowconfigure(0, weight=1)

        status_frame = ttk.LabelFrame(lower, text="송신 상태 / 실험 기록")
        status_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        status_frame.columnconfigure(0, weight=1)
        status_frame.rowconfigure(0, weight=1)
        status_frame.rowconfigure(1, weight=1)
        self.txrx_status_text = ScrolledText(status_frame, height=6, wrap=tk.WORD)
        self.txrx_status_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=(6, 3))
        self.txrx_status_text.insert(
            "1.0",
            "상태: 대기중\nrev60 일반 송신/Replay 자동화는 비활성입니다.\n"
            "선택 TC의 단일 입력 Signal에 한해 독립 Stimulus 모듈로 1회 시험 가능하며 실행 후 시작 전 값으로 원복합니다.\n",
        )

        exp_cols = ("time", "tc", "method", "reaction", "judge", "result")
        self.txrx_experiment_tree = ttk.Treeview(status_frame, columns=exp_cols, show="headings", height=7)
        exp_heads = {
            "time": "시각", "tc": "TC", "method": "방식", "reaction": "실제반응",
            "judge": "출력판정", "result": "실험결과"
        }
        exp_widths = {"time": 80, "tc": 80, "method": 130, "reaction": 90, "judge": 80, "result": 90}
        for c in exp_cols:
            self.txrx_experiment_tree.heading(c, text=exp_heads[c])
            self.txrx_experiment_tree.column(c, width=exp_widths[c], anchor="center", stretch=True)
        self.txrx_experiment_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_experiment_tree.tag_configure("ng", background="#FEE2E2", foreground="#991B1B")
        self.txrx_experiment_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_experiment_tree.tag_configure("neutral", background="#F9FAFB", foreground="#111827")
        self.txrx_experiment_tree.grid(row=1, column=0, sticky="nsew", padx=6, pady=(3, 6))

        result_frame = ttk.LabelFrame(lower, text="차량 출력 수신 결과 Preview")
        result_frame.grid(row=0, column=1, sticky="nsew")
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)
        rcols = ("kind", "message", "signal", "expected", "channel", "status", "reason")
        self.txrx_result_tree = ttk.Treeview(result_frame, columns=rcols, show="headings", height=12)
        rheads = {
            "kind": "구분",
            "message": "Message",
            "signal": "Signal",
            "expected": "Expected",
            "channel": "Channel 후보",
            "status": "상태",
            "reason": "사유",
        }
        rwidths = {
            "kind": 70,
            "message": 180,
            "signal": 260,
            "expected": 100,
            "channel": 120,
            "status": 90,
            "reason": 380,
        }
        for c in rcols:
            self.txrx_result_tree.heading(c, text=rheads[c])
            self.txrx_result_tree.column(c, width=rwidths[c], anchor="center" if c in ("kind", "expected", "channel", "status") else "w", stretch=True)
        self.txrx_result_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_result_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_result_tree.tag_configure("bad", background="#FEE2E2", foreground="#991B1B")
        self.txrx_result_tree.grid(row=0, column=0, sticky="nsew")
        rscroll = ttk.Scrollbar(result_frame, orient="vertical", command=self.txrx_result_tree.yview)
        self.txrx_result_tree.configure(yscrollcommand=rscroll.set)
        rscroll.grid(row=0, column=1, sticky="ns")

        # 4) 맨 아래 실행 로그
        log_frame = ttk.LabelFrame(parent, text="TX/RX 실행 로그")
        log_frame.grid(row=3, column=0, sticky="nsew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.txrx_log_text = ScrolledText(log_frame, height=10, wrap=tk.WORD)
        self.txrx_log_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self._txrx_log(f"[TXRX] rev60 초기화: Stimulus optional module={STIMULUS_AVAILABLE}. 모듈 부재/오류는 기존 P/F에 영향 없음.\n")

        # rev60: TX/RX 전체 세로 스크롤에 마우스 휠을 연결한다.
        # 내부 Treeview/ScrolledText가 실제로 더 스크롤될 수 있으면 내부를 우선하고,
        # 내부 스크롤이 끝에 도달했거나 내용이 짧으면 outer Canvas로 자연스럽게 넘긴다.
        self.txrx_inner_scroll_widgets = [
            w for w in (
                self.txrx_tree,
                self.txrx_preview_text,
                self.txrx_manual_candidate_text,
                self.txrx_experiment_memo_text,
                self.txrx_status_text,
                self.txrx_experiment_tree,
                self.txrx_result_tree,
                self.txrx_log_text,
            ) if w is not None
        ]
        self._bind_txrx_mousewheel()

        self._refresh_txrx_tree()

    def _txrx_widget_is_descendant(self, widget, ancestor) -> bool:
        current = widget
        while current is not None:
            if current is ancestor:
                return True
            current = getattr(current, "master", None)
        return False

    def _txrx_tab_is_active(self) -> bool:
        try:
            return self.notebook is not None and self.txrx_tab is not None and self.notebook.select() == str(self.txrx_tab)
        except Exception:
            return False

    def _txrx_mousewheel_units(self, event) -> int:
        # Windows/macOS: <MouseWheel> delta. X11/Linux: Button-4/5.
        num = getattr(event, "num", None)
        if num == 4:
            return -3
        if num == 5:
            return 3

        delta = int(getattr(event, "delta", 0) or 0)
        if delta == 0:
            return 0
        notches = max(1, min(4, abs(delta) // 120 if abs(delta) >= 120 else 1))
        return (-3 if delta > 0 else 3) * notches

    def _scroll_txrx_outer(self, units: int):
        if units == 0 or self.txrx_scroll_canvas is None:
            return
        try:
            self.txrx_scroll_canvas.yview_scroll(int(units), "units")
        except Exception:
            pass

    def _on_txrx_inner_mousewheel(self, event, widget=None):
        if not self._txrx_tab_is_active():
            return None
        target = widget or getattr(event, "widget", None)
        units = self._txrx_mousewheel_units(event)
        if target is None or units == 0:
            return "break"

        # yview()=(first,last). 해당 방향으로 내부에 더 볼 내용이 있으면 내부를 우선한다.
        try:
            first, last = target.yview()
            direction_down = units > 0
            can_scroll_inner = (last < 0.999999) if direction_down else (first > 0.000001)
        except Exception:
            can_scroll_inner = False

        if can_scroll_inner:
            try:
                target.yview_scroll(units, "units")
            except Exception:
                pass
        else:
            self._scroll_txrx_outer(units)
        return "break"

    def _on_txrx_outer_mousewheel(self, event):
        if not self._txrx_tab_is_active() or self.txrx_tab is None:
            return None
        widget = getattr(event, "widget", None)
        if widget is None or not self._txrx_widget_is_descendant(widget, self.txrx_tab):
            return None
        units = self._txrx_mousewheel_units(event)
        if units == 0:
            return None
        self._scroll_txrx_outer(units)
        return "break"

    def _bind_txrx_mousewheel(self):
        if self.txrx_tab is None:
            return

        # 내부 스크롤 가능 위젯은 widget binding에서 먼저 처리하여 class 기본 스크롤과
        # outer bind_all이 동시에 움직이는 이중 스크롤을 막는다.
        for widget in self.txrx_inner_scroll_widgets:
            widget.bind(
                "<MouseWheel>",
                lambda event, target=widget: self._on_txrx_inner_mousewheel(event, target),
                add="+",
            )
            widget.bind(
                "<Button-4>",
                lambda event, target=widget: self._on_txrx_inner_mousewheel(event, target),
                add="+",
            )
            widget.bind(
                "<Button-5>",
                lambda event, target=widget: self._on_txrx_inner_mousewheel(event, target),
                add="+",
            )

        # 버튼/라벨/빈 공간 등 자체 스크롤이 없는 영역에서는 TX/RX 탭 전체를 스크롤한다.
        # bind_all을 쓰되 현재 선택 탭 및 event.widget ancestry를 검사하여 다른 탭에는 영향이 없다.
        self.txrx_tab.bind_all("<MouseWheel>", self._on_txrx_outer_mousewheel, add="+")
        self.txrx_tab.bind_all("<Button-4>", self._on_txrx_outer_mousewheel, add="+")
        self.txrx_tab.bind_all("<Button-5>", self._on_txrx_outer_mousewheel, add="+")

    def _load_conditions(self):
        super()._load_conditions()
        self.txrx_selected_index = None
        self.txrx_analysis_by_index.clear()
        self._refresh_txrx_tree()
        self._show_txrx_preview(None)

    def _short_expectations_text(self, expectations: List[Any], max_items: int = 2) -> str:
        items = []
        for exp in expectations or []:
            items.append(f"{exp.message}:{exp.signal}={exp.expected_value_raw}")
        if len(items) > max_items:
            return " / ".join(items[:max_items]) + f" / ... +{len(items) - max_items}"
        return " / ".join(items) if items else "-"

    def _latest_txrx_experiment_record(self, idx: int) -> Optional[Dict[str, Any]]:
        for record in reversed(self.txrx_experiment_records):
            if record.get("row_index") == idx:
                return record
        return None

    def _latest_txrx_experiment_result_text(self, idx: int) -> str:
        record = self._latest_txrx_experiment_record(idx)
        if not record:
            return "-"
        return str(record.get("final_result") or "-")

    def _refresh_txrx_tree(self):
        if self.txrx_tree is None:
            return
        self.txrx_tree.delete(*self.txrx_tree.get_children())
        for idx, row in enumerate(getattr(self, "condition_rows", [])):
            if not row.is_valid or row.condition is None:
                continue
            c = row.condition
            analysis = self.txrx_analysis_by_index.get(idx, {})
            status = analysis.get("status") or self.TXRX_STATUS_UNCHECKED
            reason = analysis.get("summary") or "프리테스트 분류/송신 가능성 검사를 수행하지 않았습니다."
            method = analysis.get("method") or self.TXRX_METHOD_UNKNOWN
            tag = "unchecked"
            if idx == self.txrx_selected_index:
                tag = "selected"
            elif status == self.TXRX_STATUS_OK:
                tag = "ok"
            elif status == self.TXRX_STATUS_WARN:
                tag = "warn"
            elif status == self.TXRX_STATUS_BAD:
                tag = "bad"
            self.txrx_tree.insert(
                "",
                tk.END,
                iid=str(idx),
                tags=(tag,),
                values=(
                    c.tc_no,
                    c.subcategory,
                    self._short_expectations_text(c.input_conditions),
                    self._short_expectations_text(c.output_conditions),
                    method,
                    status,
                    self._latest_txrx_experiment_result_text(idx),
                    reason,
                ),
            )

    def _on_txrx_tree_select(self, event=None):
        if self.txrx_tree is None:
            return
        sel = self.txrx_tree.selection()
        if not sel:
            return
        try:
            idx = int(sel[0])
        except Exception:
            return
        self.txrx_selected_index = idx
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)

    def _on_txrx_tree_click(self, event=None):
        if self.txrx_tree is None:
            return
        row_id = self.txrx_tree.identify_row(getattr(event, "y", 0)) if event is not None else ""
        if not row_id:
            return
        try:
            idx = int(row_id)
        except Exception:
            return
        self.txrx_selected_index = idx
        self.txrx_tree.selection_set(row_id)
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)

    def _get_txrx_selected_condition(self):
        idx = self.txrx_selected_index
        if idx is None:
            return None, None
        if 0 <= idx < len(getattr(self, "condition_rows", [])):
            row = self.condition_rows[idx]
            if row.is_valid and row.condition is not None:
                return idx, row.condition
        return None, None

    def _txrx_log(self, text: str):
        if self.txrx_log_text is not None:
            self.txrx_log_text.insert(tk.END, text)
            self.txrx_log_text.see(tk.END)
        try:
            self._log(text)
        except Exception:
            pass

    def _ch_label_for_int(self, ch: int) -> str:
        for can_name in getattr(self, "can_names", []):
            if self._ch_text_to_int(self.can_ch_vars[can_name].get()) == int(ch):
                return f"{can_name}/Ch{int(ch)}"
        return f"Ch{int(ch)}"

    def _find_expectation_locations(self, db_by_ch: Dict[int, Any], expectation: Any) -> List[Dict[str, Any]]:
        matches: List[Dict[str, Any]] = []
        msg_name = str(getattr(expectation, "message", "") or "").strip()
        sig_name = str(getattr(expectation, "signal", "") or "").strip()
        if not msg_name or not sig_name:
            return matches
        for ch, db in sorted((db_by_ch or {}).items(), key=lambda x: int(x[0])):
            try:
                msg_obj = db.get_message_by_name(msg_name)
            except Exception:
                continue
            signal_obj = None
            try:
                signal_obj = msg_obj.get_signal_by_name(sig_name)
            except Exception:
                try:
                    signal_obj = next((s for s in getattr(msg_obj, "signals", []) if getattr(s, "name", "") == sig_name), None)
                except Exception:
                    signal_obj = None
            matches.append({
                "channel": int(ch),
                "channel_label": self._ch_label_for_int(int(ch)),
                "message": msg_obj,
                "signal": signal_obj,
                "signal_found": signal_obj is not None,
            })
        return matches

    def _message_cycle_ms(self, msg_obj: Any, msg_name: str) -> Optional[int]:
        try:
            cycle = getattr(msg_obj, "cycle_time", None)
            if cycle is not None:
                cycle_int = int(cycle)
                if cycle_int > 0:
                    return cycle_int
        except Exception:
            pass
        m = re.search(r"(?:^|[_\-])(?P<ms>\d{1,5})\s*ms(?:$|[_\-])", str(msg_name or ""), re.IGNORECASE)
        if m:
            try:
                return int(m.group("ms"))
            except Exception:
                pass
        return None

    def _detect_crc_alive_signals(self, msg_obj: Any) -> List[str]:
        suspicious: List[str] = []
        keywords = ("crc", "checksum", "chksum", "alive", "alv", "counter", "rolling")
        try:
            for sig in getattr(msg_obj, "signals", []) or []:
                name = str(getattr(sig, "name", "") or "")
                low = name.lower()
                if any(k in low for k in keywords):
                    suspicious.append(name)
        except Exception:
            pass
        return suspicious

    def _condition_text_blob(self, condition: Any) -> str:
        parts: List[str] = [
            str(getattr(condition, "tc_no", "") or ""),
            str(getattr(condition, "subcategory", "") or ""),
            str(getattr(condition, "tc_content", "") or ""),
            str(getattr(condition, "tc_expected_result", "") or ""),
        ]
        for exp in list(getattr(condition, "input_conditions", []) or []) + list(getattr(condition, "output_conditions", []) or []):
            parts.extend([
                str(getattr(exp, "message", "") or ""),
                str(getattr(exp, "signal", "") or ""),
                str(getattr(exp, "expected_value_raw", "") or ""),
            ])
        return " ".join(parts).lower()

    def _is_safety_excluded_tc(self, condition: Any) -> bool:
        text = self._condition_text_blob(condition)
        safety_keywords = (
            "brake", "brk", "steer", "str", "eps", "airbag", "srs", "torque", "tq", "accel", "throttle",
            "shift", "gear", "sbw", "hv", "highvoltage", "charging", "charge", "adas", "aeb", "lkas", "scc",
            "제동", "브레이크", "조향", "스티어", "에어백", "토크", "구동", "가속", "변속", "기어", "고전압", "충전", "운전자보조",
        )
        return any(k in text for k in safety_keywords)

    def _is_physical_or_switch_tc(self, condition: Any) -> bool:
        text = self._condition_text_blob(condition)
        physical_keywords = (
            "seat", "switch", "sw", "button", "btn", "window", "wiper", "mirror", "sunroof", "door", "tailgate",
            "시트", "스위치", "버튼", "윈도우", "와이퍼", "미러", "선루프", "도어", "테일게이트", "물리", "접점",
        )
        return any(k in text for k in physical_keywords)

    def _classify_txrx_method(self, condition: Any, analysis: Dict[str, Any]) -> Tuple[str, str]:
        """차량 송수신 테스트를 전체 자동화가 아닌 예비 프리테스트 관점으로 분류한다."""
        if self._is_safety_excluded_tc(condition):
            return self.TXRX_METHOD_EXCLUDE, "제동/조향/구동/에어백/충전/ADAS 등 안전 영향 가능성이 있어 초기 자동 송신/Replay 대상에서 제외 권장"

        if analysis.get("errors"):
            return self.TXRX_METHOD_MANUAL, "입력 Message/Signal 또는 DBC/채널 정보가 부족하여 자동 자극 구성이 어려움"

        all_input_rows = analysis.get("input_rows", []) or []
        has_crc_alive = any(row.get("crc_alive") for row in all_input_rows)
        has_physical = self._is_physical_or_switch_tc(condition)

        if has_physical and has_crc_alive:
            return self.TXRX_METHOD_PHYSICAL, "버튼/스위치류 물리 입력 가능성과 CRC/Alive 포함 가능성이 있어 릴레이/VT System 또는 실제 조작 로그 Replay 우선 권장"
        if has_physical:
            return self.TXRX_METHOD_PHYSICAL, "버튼/스위치류 TC는 CAN 일부 Signal 송신만으로 실제 조작을 대체하기 어려울 수 있어 물리 입력 자동화 또는 로그 Replay 권장"
        if has_crc_alive:
            return self.TXRX_METHOD_REPLAY, "CRC/Alive/Counter 포함 가능성이 있어 직접 Signal 합성보다 실제 조작 로그 Replay 또는 CAPL 계산 로직 필요"

        if analysis.get("warnings"):
            return self.TXRX_METHOD_REPLAY, "정적 검사상 확인 필요 항목이 있어 우선 로그 Replay 후보로 분류"

        return self.TXRX_METHOD_CAN, "입력 Message/Signal이 DBC에서 확인되며 CRC/Alive 의심 항목이 없어 제한적 CAN Signal 송신 프리테스트 후보"

    def _analyze_condition_txrx(self, condition: Any) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "status": self.TXRX_STATUS_UNCHECKED,
            "summary": "",
            "input_rows": [],
            "output_rows": [],
            "details": [],
            "warnings": [],
            "errors": [],
            "recommended_period_ms": None,
            "method": self.TXRX_METHOD_UNKNOWN,
            "method_reason": "",
            "pretest_meaning": "자동 예비 프리테스트는 가능한 TC만 선별하기 위한 참고 결과이며, 자동 FAIL은 기능 FAIL 확정이 아닙니다.",
        }

        try:
            dbc_mapping = self._collect_dbc_mapping()
        except Exception as e:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = f"DBC/채널 설정 수집 실패: {e}"
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "DBC/채널 설정을 먼저 보완해야 합니다."
            return result

        if not dbc_mapping:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = "유효한 DBC/채널 매핑이 없습니다. 설정 탭에서 CAN1/2/3 채널과 DBC를 지정하세요."
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "DBC/채널 매핑이 없어 자동 프리테스트 분류가 불가합니다."
            return result

        try:
            db_by_ch = core.load_dbc_map(dbc_mapping)
        except Exception as e:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = f"DBC 로드 실패: {type(e).__name__}: {e}"
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "DBC 로드 실패로 자동 프리테스트 분류가 불가합니다."
            return result

        if not db_by_ch:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = "유효한 DBC를 1개도 로드하지 못했습니다."
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "유효 DBC가 없어 자동 프리테스트 분류가 불가합니다."
            return result

        recommended_cycles: List[int] = []

        # 입력 조건: 향후 송신 대상
        for pos, exp in enumerate(getattr(condition, "input_conditions", []) or [], start=1):
            locations = self._find_expectation_locations(db_by_ch, exp)
            row = {
                "role": "입력",
                "pos": pos,
                "expectation": exp,
                "status": self.TXRX_STATUS_UNCHECKED,
                "channel": "-",
                "reason": "",
                "locations": locations,
                "cycle_ms": None,
                "crc_alive": [],
            }
            if not locations:
                row["status"] = self.TXRX_STATUS_BAD
                row["reason"] = f"DBC에서 Message를 찾지 못함: {exp.message}"
                result["errors"].append(row["reason"])
            elif not any(x.get("signal_found") for x in locations):
                row["status"] = self.TXRX_STATUS_BAD
                row["channel"] = ", ".join(x.get("channel_label", "") for x in locations)
                row["reason"] = f"DBC Message는 있으나 Signal을 찾지 못함: {exp.signal}"
                result["errors"].append(row["reason"])
            else:
                found = [x for x in locations if x.get("signal_found")]
                row["channel"] = ", ".join(x.get("channel_label", "") for x in found)
                first_msg = found[0].get("message")
                cycle = self._message_cycle_ms(first_msg, exp.message)
                row["cycle_ms"] = cycle
                if cycle:
                    recommended_cycles.append(cycle)
                crc_alive = self._detect_crc_alive_signals(first_msg)
                row["crc_alive"] = crc_alive
                warnings = []
                if len(found) >= 2:
                    warnings.append("동일 Message/Signal이 복수 채널 DBC에서 발견됨")
                if crc_alive:
                    warnings.append("CRC/Alive/Counter류 Signal 포함 가능성: " + ", ".join(crc_alive[:6]))
                if warnings:
                    row["status"] = self.TXRX_STATUS_WARN
                    row["reason"] = " / ".join(warnings)
                    result["warnings"].extend(warnings)
                else:
                    row["status"] = self.TXRX_STATUS_OK
                    row["reason"] = "DBC Message/Signal 확인 OK"
            result["input_rows"].append(row)

        # 출력 조건: 향후 수신/감시 대상 Preview. 수신 자체는 기존 P/F 로직을 재사용하지만 DBC 존재 여부도 같이 확인한다.
        for pos, exp in enumerate(getattr(condition, "output_conditions", []) or [], start=1):
            locations = self._find_expectation_locations(db_by_ch, exp)
            row = {
                "role": "출력",
                "pos": pos,
                "expectation": exp,
                "status": self.TXRX_STATUS_UNCHECKED,
                "channel": "-",
                "reason": "",
                "locations": locations,
            }
            if not locations:
                row["status"] = self.TXRX_STATUS_WARN
                row["reason"] = f"DBC에서 출력 Message를 찾지 못함: {exp.message}"
                result["warnings"].append(row["reason"])
            elif not any(x.get("signal_found") for x in locations):
                row["status"] = self.TXRX_STATUS_WARN
                row["channel"] = ", ".join(x.get("channel_label", "") for x in locations)
                row["reason"] = f"출력 Message는 있으나 Signal을 찾지 못함: {exp.signal}"
                result["warnings"].append(row["reason"])
            else:
                found = [x for x in locations if x.get("signal_found")]
                row["channel"] = ", ".join(x.get("channel_label", "") for x in found)
                row["status"] = self.TXRX_STATUS_OK
                row["reason"] = "수신/로그 검토용 DBC Message/Signal 확인 OK"
            result["output_rows"].append(row)

        if recommended_cycles:
            # 가장 빠른 주기를 기본 추천값으로 사용한다.
            result["recommended_period_ms"] = min(recommended_cycles)

        # 실제 버스 중복 송신 여부는 정적 DBC 검사만으로 확정할 수 없다.
        if result["input_rows"] and not result["errors"]:
            bus_warning = "실제 차량 버스에 동일 Message ID가 이미 송신 중인지 별도 로그/버스 상태 확인 필요"
            result["warnings"].append(bus_warning)

        if result["errors"]:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = result["errors"][0]
        elif result["warnings"]:
            result["status"] = self.TXRX_STATUS_WARN
            result["summary"] = result["warnings"][0]
        else:
            result["status"] = self.TXRX_STATUS_OK
            result["summary"] = "입력 Message/Signal 송신 Preview 가능"

        method, method_reason = self._classify_txrx_method(condition, result)
        result["method"] = method
        result["method_reason"] = method_reason
        if method in (self.TXRX_METHOD_MANUAL, self.TXRX_METHOD_PHYSICAL, self.TXRX_METHOD_EXCLUDE):
            if result["status"] == self.TXRX_STATUS_OK:
                result["status"] = self.TXRX_STATUS_WARN
            if result.get("summary") in ("입력 Message/Signal 송신 Preview 가능", ""):
                result["summary"] = method_reason

        return result

    def _check_txrx_selected(self):
        idx, cond = self._get_txrx_selected_condition()
        if cond is None:
            messagebox.showwarning("TC 선택 필요", "차량 송수신 테스트할 TC를 먼저 선택하세요.")
            return
        analysis = self._analyze_condition_txrx(cond)
        self.txrx_analysis_by_index[idx] = analysis
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)
        self._txrx_log(f"[TXRX] 선택 TC 검사 완료: TC={cond.tc_no}, status={analysis.get('status')}, reason={analysis.get('summary')}\n")

    def _check_txrx_all(self):
        count = 0
        bad = warn = ok = 0
        for idx, row in enumerate(getattr(self, "condition_rows", [])):
            if not row.is_valid or row.condition is None:
                continue
            analysis = self._analyze_condition_txrx(row.condition)
            self.txrx_analysis_by_index[idx] = analysis
            count += 1
            if analysis.get("status") == self.TXRX_STATUS_OK:
                ok += 1
            elif analysis.get("status") == self.TXRX_STATUS_WARN:
                warn += 1
            elif analysis.get("status") == self.TXRX_STATUS_BAD:
                bad += 1
        self._refresh_txrx_tree()
        if self.txrx_selected_index is not None:
            self._show_txrx_preview(self.txrx_selected_index)
        self.txrx_status_var.set(f"검사 완료: 전체 {count}개 / 가능 {ok} / 확인 필요 {warn} / 불가 {bad}")
        self._txrx_log(f"[TXRX] 전체 가능성 검사 완료: total={count}, ok={ok}, warn={warn}, bad={bad}\n")

    def _txrx_result_tag(self, result: str) -> str:
        s = str(result or "").upper()
        if s == "OK":
            return "ok"
        if s == "NG":
            return "ng"
        if s in ("PARTIAL", "수동필요", "REPLAY권장", "릴레이필요", "분석필요"):
            return "warn"
        return "neutral"

    def _selected_txrx_causes(self) -> List[str]:
        return [label for label, var in self.txrx_cause_vars.items() if bool(var.get())]

    def _clear_txrx_experiment_inputs(self):
        self.txrx_vehicle_reaction_var.set("미확인")
        self.txrx_output_judge_var.set("미확인")
        self.txrx_experiment_result_var.set("분석필요")
        for var in self.txrx_cause_vars.values():
            var.set(False)
        if self.txrx_experiment_memo_text is not None:
            self.txrx_experiment_memo_text.configure(state="normal")
            self.txrx_experiment_memo_text.delete("1.0", tk.END)
        self._txrx_log("[TXRX][EXP] 실험 결과 입력값 초기화\n")

    def _save_txrx_experiment_record(self):
        idx, cond = self._get_txrx_selected_condition()
        if cond is None or idx is None:
            messagebox.showwarning("TC 선택 필요", "실험 결과를 기록할 TC를 먼저 선택하세요.")
            return

        memo = ""
        if self.txrx_experiment_memo_text is not None:
            try:
                memo = self.txrx_experiment_memo_text.get("1.0", tk.END).strip()
            except Exception:
                memo = ""

        analysis = self.txrx_analysis_by_index.get(idx, {})
        now = _dt.datetime.now()
        record = {
            "created_at": now.strftime("%Y-%m-%d %H:%M:%S"),
            "time_short": now.strftime("%H:%M:%S"),
            "row_index": idx,
            "tc_no": getattr(cond, "tc_no", ""),
            "subcategory": getattr(cond, "subcategory", ""),
            "experiment_method": self.txrx_experiment_method_var.get(),
            "vehicle_reaction": self.txrx_vehicle_reaction_var.get(),
            "output_judge": self.txrx_output_judge_var.get(),
            "final_result": self.txrx_experiment_result_var.get(),
            "causes": "; ".join(self._selected_txrx_causes()),
            "memo": memo,
            "analysis_status": analysis.get("status", "미검사"),
            "analysis_method": analysis.get("method", "미분류"),
            "analysis_summary": analysis.get("summary", ""),
        }
        self.txrx_experiment_records.append(record)
        self._refresh_txrx_experiment_tree()
        self._refresh_txrx_tree()
        self._txrx_log(
            f"[TXRX][EXP] 실험 기록 저장: TC={record['tc_no']}, result={record['final_result']}, "
            f"reaction={record['vehicle_reaction']}, judge={record['output_judge']}\n"
        )
        self.txrx_status_var.set(f"실험 기록 저장: {record['tc_no']} / {record['final_result']}")

    def _refresh_txrx_experiment_tree(self):
        if self.txrx_experiment_tree is None:
            return
        self.txrx_experiment_tree.delete(*self.txrx_experiment_tree.get_children())
        for i, record in enumerate(self.txrx_experiment_records[-200:], start=1):
            result = str(record.get("final_result", ""))
            self.txrx_experiment_tree.insert(
                "",
                tk.END,
                iid=f"exp:{i}",
                tags=(self._txrx_result_tag(result),),
                values=(
                    record.get("time_short", ""),
                    record.get("tc_no", ""),
                    record.get("experiment_method", ""),
                    record.get("vehicle_reaction", ""),
                    record.get("output_judge", ""),
                    result,
                ),
            )

    def _reset_txrx_experiment_records(self):
        if not self.txrx_experiment_records:
            messagebox.showinfo("기록 없음", "초기화할 실험 기록이 없습니다.")
            return
        if not messagebox.askyesno("실험 기록 초기화", "현재 세션의 차량 송수신 실험 기록을 모두 초기화할까요?"):
            return
        self.txrx_experiment_records.clear()
        self._refresh_txrx_experiment_tree()
        self._refresh_txrx_tree()
        self._txrx_log("[TXRX][EXP] 실험 기록 전체 초기화\n")

    def _export_txrx_experiment_csv(self):
        if not self.txrx_experiment_records:
            messagebox.showwarning("기록 없음", "CSV로 저장할 실험 기록이 없습니다.")
            return
        default_name = f"txrx_experiment_records_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        try:
            initial_dir = str(getattr(self, "_app_dir", Path.cwd()))
        except Exception:
            initial_dir = str(Path.cwd())
        path = filedialog.asksaveasfilename(
            title="차량 송수신 실험 기록 CSV 저장",
            defaultextension=".csv",
            initialdir=initial_dir,
            initialfile=default_name,
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        fields = [
            "created_at", "tc_no", "subcategory", "experiment_method", "vehicle_reaction",
            "output_judge", "final_result", "causes", "memo", "analysis_status", "analysis_method", "analysis_summary",
        ]
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
                for record in self.txrx_experiment_records:
                    writer.writerow({k: record.get(k, "") for k in fields})
            messagebox.showinfo("CSV 저장 완료", f"실험 기록을 저장했습니다.\n{path}")
            self._txrx_log(f"[TXRX][EXP] CSV 저장 완료: {path}\n")
        except Exception as e:
            messagebox.showerror("CSV 저장 실패", str(e))
            self._txrx_log(f"[TXRX][EXP][ERROR] CSV 저장 실패: {e}\n")

    def _txrx_manual_candidate_example(self):
        if self.txrx_manual_candidate_text is None:
            return
        example = (
            "CAN1\tSeat_Message_01\tSeatForwardReq\t1\n"
            "CAN1\tSeat_Message_01\tSeatEnable\t1\n"
        )
        self.txrx_manual_candidate_text.delete("1.0", tk.END)
        self.txrx_manual_candidate_text.insert("1.0", example)
        self.txrx_manual_candidate_status_var.set("수동 후보: 예시 입력됨")

    def _manual_candidate_logical_to_channel(self, token: str) -> Tuple[str, int]:
        text = str(token or "").strip().upper().replace(" ", "")
        if text in getattr(self, "can_names", []):
            ch = self._ch_text_to_int(self.can_ch_vars[text].get())
            if ch is None or int(ch) <= 0:
                raise ValueError(f"{text}의 물리 채널 설정이 유효하지 않습니다: {self.can_ch_vars[text].get()}")
            return text, int(ch)
        m = re.fullmatch(r"CH([1-9]\d*)", text)
        if m:
            ch = int(m.group(1))
            return f"Ch{ch}", ch
        if text.isdigit() and int(text) > 0:
            ch = int(text)
            return f"Ch{ch}", ch
        raise ValueError(f"CAN 열은 CAN1/CAN2/CAN3 또는 Ch1 형식이어야 합니다: {token}")

    def _parse_manual_stimulus_candidates(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            raise RuntimeError(
                "oracle_checker_stimulus_rev60.py를 사용할 수 없습니다. "
                f"기존 Pass/Fail은 정상 사용 가능합니다. import={STIMULUS_IMPORT_ERROR or '-'}"
            )
        if self.txrx_manual_candidate_text is None:
            raise ValueError("수동 후보 입력창이 없습니다.")
        raw = self.txrx_manual_candidate_text.get("1.0", tk.END)
        lines = [x.strip() for x in raw.splitlines() if x.strip() and not x.lstrip().startswith("#")]
        if not lines:
            raise ValueError("수동 후보 Signal을 입력하세요. Excel 4열(CAN, Message, Signal, Value)을 그대로 붙여넣을 수 있습니다.")
        if len(lines) > _stimulus.StimulusExecutor.MAX_GROUP_ITEMS:
            raise ValueError(
                f"rev60 수동 후보 묶음은 최대 {_stimulus.StimulusExecutor.MAX_GROUP_ITEMS}행만 허용합니다. 현재={len(lines)}행"
            )

        candidates = []
        safety_keywords = (
            "brake", "brk", "steer", "str", "eps", "airbag", "srs", "torque", "tq", "accel", "throttle",
            "shift", "gear", "sbw", "hv", "highvoltage", "charging", "charge", "adas", "aeb", "lkas", "scc",
            "제동", "브레이크", "조향", "스티어", "에어백", "토크", "구동", "가속", "변속", "기어", "고전압", "충전", "운전자보조",
        )
        for lineno, line in enumerate(lines, start=1):
            if "\t" in line:
                parts = [x.strip() for x in line.split("\t")]
            elif "," in line:
                parts = [x.strip() for x in line.split(",")]
            elif ";" in line:
                parts = [x.strip() for x in line.split(";")]
            else:
                parts = re.split(r"\s+", line, maxsplit=3)
                parts = [x.strip() for x in parts]
            if len(parts) != 4:
                raise ValueError(
                    f"{lineno}행 형식 오류: CAN / Message / Signal / ActiveValue 4개 열이 필요합니다. 입력={line}"
                )
            can_token, message, signal, value = parts
            logical_can, channel = self._manual_candidate_logical_to_channel(can_token)
            blob = f"{message} {signal}".lower()
            if any(k in blob for k in safety_keywords):
                raise ValueError(f"{lineno}행은 rev60 안전 차단 키워드가 포함되어 수동 Stimulus 대상에서 제외합니다: {message}.{signal}")
            candidates.append(
                _stimulus.StimulusCandidate(
                    logical_can=logical_can,
                    channel=channel,
                    message=message,
                    signal=signal,
                    active_value=value,
                    bus_name="CAN",
                )
            )
        hold_sec = float(self.txrx_stimulus_hold_sec_var.get().strip() or "0.5")
        name = "Manual Candidate Set"
        idx, cond = self._get_txrx_selected_condition()
        if cond is not None:
            name = f"{str(getattr(cond, 'tc_no', '') or 'Selected TC')} manual candidates"
        return _stimulus.StimulusGroupProfile(
            name=name,
            candidates=candidates,
            hold_sec=hold_sec,
            source="Manual pasted candidates / rev60",
        )

    def _build_stimulus_dbc_resolver(self):
        """Return a strict in-memory DBC resolver for the isolated Stimulus module."""
        mapping = self._collect_dbc_mapping()
        if not mapping:
            return None
        db_by_ch = core.load_dbc_map(mapping)

        def resolver(channel: int, message_name: str):
            db = db_by_ch.get(int(channel))
            if db is None:
                return None
            try:
                return db.get_message_by_name(str(message_name))
            except Exception:
                return None

        return resolver

    def _make_stimulus_executor(self):
        trace_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "stimulus_logs"
        resolver = None
        try:
            resolver = self._build_stimulus_dbc_resolver()
        except Exception as e:
            self._txrx_log(f"[STIMULUS][DBC][WARN] DBC resolver 생성 실패: {e}\n")
        return _stimulus.StimulusExecutor(trace_dir=trace_dir, dbc_resolver=resolver)

    def _vector_product_name(self, client) -> str:
        try:
            info = client.get_application_info() if hasattr(client, "get_application_info") else {}
            return str((info or {}).get("product") or "").strip()
        except Exception:
            return ""

    def _require_canalyzer_source_isolated(self, client):
        product = self._vector_product_name(client)
        if product.lower() == "canalyzer" and not bool(self.txrx_canalyzer_source_isolated_var.get()):
            raise ValueError(
                "CANalyzer CAPL output()은 실제 CAN Frame을 송신합니다. 동일 CAN ID를 원래 ECU/Generator가 계속 송신 중이면 "
                "중복 송신 충돌 위험이 있습니다. 실제 송신 전에 원래 송신원을 분리/비활성했음을 확인한 뒤 "
                "[동일 Message 기존 송신원 분리·비활성 확인]을 직접 체크하세요."
            )

    def _profile_for_capl_bridge_generation(self):
        text = ""
        try:
            text = self.txrx_manual_candidate_text.get("1.0", tk.END).strip() if self.txrx_manual_candidate_text else ""
        except Exception:
            text = ""
        if text:
            return self._parse_manual_stimulus_candidates()
        _, _, _, _, single = self._build_selected_stimulus_profile()
        logical = str(single.logical_can or f"Ch{single.channel}")
        return _stimulus.StimulusGroupProfile(
            name=f"{single.tc_no or 'Selected TC'} CAPL bridge",
            candidates=[_stimulus.StimulusCandidate(
                logical_can=logical,
                channel=int(single.channel),
                message=str(single.message),
                signal=str(single.signal),
                active_value=single.active_value,
                bus_name=single.bus_name,
            )],
            hold_sec=float(single.hold_sec),
            source="Selected TC / CAPL bridge generation",
        )

    def _txrx_generate_canalyzer_capl_bridge(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            messagebox.showerror("CAPL Bridge 생성 불가", f"Stimulus 모듈 없음: {STIMULUS_IMPORT_ERROR or '-'}")
            return
        try:
            profile = self._profile_for_capl_bridge_generation()
            resolver = self._build_stimulus_dbc_resolver()
            if resolver is None:
                raise ValueError("CANalyzer CAPL Bridge 생성에는 대상 CAN의 DBC 설정이 필요합니다.")
            out_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "canalyzer_capl_bridge"
            paths = _stimulus.generate_canalyzer_capl_bridges(profile, resolver, out_dir, revision="rev60")
            self.txrx_manual_candidate_status_var.set(f"CAPL Bridge 생성 {len(paths)}개")
            self._txrx_log("[STIMULUS][CAPL] 생성: " + " | ".join(paths) + "\n")
            messagebox.showinfo(
                "CANalyzer CAPL Bridge 생성 완료",
                "\n".join([
                    f"생성 파일 {len(paths)}개:",
                    *[f"- {x}" for x in paths],
                    "",
                    "각 파일을 해당 논리 CAN이 연결된 CANalyzer Measurement Setup의 SEND branch에 CAPL node로 수동 삽입하세요.",
                    "그 다음 Compile 후 Measurement를 Stop→Start하고 [후보 검증]을 다시 실행하세요.",
                    "PassFail은 CANalyzer Configuration을 자동 수정하지 않습니다.",
                ]),
            )
        except Exception as e:
            self.txrx_manual_candidate_status_var.set("CAPL Bridge 생성 실패")
            self._txrx_log(f"[STIMULUS][CAPL][BLOCK] {e}\n")
            messagebox.showerror("CANalyzer CAPL Bridge 생성 실패", str(e))

    def _manual_candidate_dbc_preflight(self, profile):
        """DBC가 있으면 후보 존재/CRC·Alive sibling을 확인한다. DBC가 없으면 COM validate가 최종 존재검사를 담당한다."""
        notes: List[str] = []
        crc_messages: List[str] = []
        missing: List[str] = []
        try:
            mapping = self._collect_dbc_mapping()
            db_by_ch = core.load_dbc_map(mapping) if mapping else {}
        except Exception as e:
            notes.append(f"DBC 사전검사 생략: {type(e).__name__}: {e}")
            return notes, crc_messages, missing

        for item in profile.candidates:
            db = db_by_ch.get(int(item.channel))
            if db is None:
                notes.append(f"{item.logical_can}/Ch{item.channel}: DBC 없음 - Vector COM에서 직접 확인")
                continue
            try:
                msg = db.get_message_by_name(str(item.message))
            except Exception:
                missing.append(f"{item.logical_can}/Ch{item.channel}: Message 없음 {item.message}")
                continue
            try:
                sig = msg.get_signal_by_name(str(item.signal))
            except Exception:
                sig = None
            if sig is None:
                missing.append(f"{item.logical_can}/Ch{item.channel}: Signal 없음 {item.message}.{item.signal}")
            suspicious = self._detect_crc_alive_signals(msg)
            if suspicious:
                crc_messages.append(
                    f"{item.logical_can}/Ch{item.channel} {item.message}: " + ", ".join(sorted(set(suspicious)))
                )
        return notes, sorted(set(crc_messages)), missing

    def _prepare_manual_candidate_execution(self, for_execution: bool = False):
        if not bool(self.txrx_stimulus_enable_var.get()):
            raise ValueError("실험용 입력은 기본 OFF입니다. [실험용 Stimulus 사용]을 먼저 체크하세요.")
        if self.txrx_stimulus_thread is not None and self.txrx_stimulus_thread.is_alive():
            raise ValueError("이미 Stimulus 입력 테스트가 진행 중입니다.")
        profile = self._parse_manual_stimulus_candidates()
        client = self._ensure_client(show_popup=False)
        if not client.is_measurement_running():
            client.start_measurement(wait_sec=0.0)
            try:
                self.measurement_status_var.set("Measurement: 실행 중")
                self._refresh_status_badges()
            except Exception:
                pass
        executor = self._make_stimulus_executor()
        checked = executor.validate_group(client, profile)
        if for_execution:
            self._require_canalyzer_source_isolated(client)
        notes, crc_messages, missing = self._manual_candidate_dbc_preflight(profile)
        if missing:
            raise ValueError("DBC 후보 검증 실패:\n- " + "\n- ".join(missing))
        if crc_messages and not bool(self.txrx_manual_crc_override_var.get()):
            raise ValueError(
                "DBC에서 CRC/Alive/Counter류 Signal이 같은 Message에 존재합니다.\n"
                "rev60은 이를 자동 계산하지 않습니다. 우선 현재 후보만 시험하려면 "
                "[CRC/Alive/Counter 경고가 있어도 시험 허용]을 직접 체크해야 합니다.\n\n- "
                + "\n- ".join(crc_messages)
            )
        return profile, client, executor, checked, notes, crc_messages

    def _txrx_validate_manual_candidates_ui(self):
        try:
            profile, client, executor, checked, notes, crc_messages = self._prepare_manual_candidate_execution()
            lines = [
                f"후보 {len(checked.get('items', []))}개 / Hold {checked.get('hold_sec')} sec",
            ]
            for item in checked.get('items', []):
                lines.append(
                    f"- {item['logical_can']}/Ch{item['channel']} {item['message']}.{item['signal']}: "
                    f"현재={item['original_value']} → 입력={item['active_value']}"
                )
            if crc_messages:
                lines.append("CRC/Alive/Counter 경고(자동 계산 안 함):")
                lines.extend(f"- {x}" for x in crc_messages)
            lines.extend(notes)
            self.txrx_manual_candidate_status_var.set(f"수동 후보: 검증 OK ({len(checked.get('items', []))}개)")
            self._txrx_log("[STIMULUS][MANUAL][CHECK] " + " | ".join(lines) + "\n")
            messagebox.showinfo("수동 후보 검증 완료", "\n".join(lines))
        except Exception as e:
            self.txrx_manual_candidate_status_var.set("수동 후보: 검증 실패")
            self._txrx_log(f"[STIMULUS][MANUAL][BLOCK] {e}\n")
            messagebox.showerror("수동 후보 검증 실패", str(e))

    def _txrx_manual_candidate_test_once(self):
        try:
            profile, client, executor, checked, notes, crc_messages = self._prepare_manual_candidate_execution(for_execution=True)
        except Exception as e:
            self.txrx_manual_candidate_status_var.set("수동 후보: 실행 차단")
            self._txrx_log(f"[STIMULUS][MANUAL][BLOCK] {e}\n")
            messagebox.showerror("후보 묶음 테스트 실행 불가", str(e))
            return

        detail = []
        for item in checked.get('items', []):
            detail.append(
                f"{item['logical_can']}/Ch{item['channel']}  {item['message']}.{item['signal']}  "
                f"{item['original_value']} → {item['active_value']}"
            )
        crc_note = ""
        if crc_messages:
            crc_note = (
                "\n\n※ DBC에 CRC/Alive/Counter가 감지되었지만 사용자가 경고를 허용했습니다. "
                "rev60은 CRC/Alive를 계산하거나 갱신하지 않으므로 ECU가 이 입력을 무시할 수 있습니다."
            )
        backend = str(checked.get("backend") or "")
        if backend.startswith("CANalyzer"):
            backend_note = (
                "\n\nBackend: CANalyzer CAPL output()\n"
                "DBC/현재 Signal 값으로 전체 payload를 재구성하여 CAPL Bridge가 실제 CAN Frame을 주기 송신합니다. "
                "Hold 종료/중단 시 시작 전 값으로 재구성한 release Frame을 송신합니다. "
                "원래 ECU/Generator 송신원 분리·비활성 확인이 필수입니다."
            )
            trace_note = "\n\nCANalyzer Trace에서 TX Frame을 함께 확인하면서 실행하시겠습니까?"
        else:
            backend_note = (
                "\n\nBackend: CANoe Signal.Value\n"
                "모든 후보를 먼저 검증한 뒤 Signal.Value를 순차 적용하며 실제 write된 Signal은 시작 전 값으로 원복합니다."
            )
            trace_note = "\n\nCANoe Trace를 함께 확인하면서 실행하시겠습니까?"
        confirm = (
            "[rev60 수동 후보 Signal 묶음 1회 테스트]\n\n"
            + "\n".join(detail)
            + f"\n\nHold: {checked.get('hold_sec')} sec"
            + backend_note
            + crc_note
            + trace_note
        )
        if not messagebox.askyesno("수동 후보 묶음 입력 확인", confirm):
            self._txrx_log("[STIMULUS][MANUAL] 사용자 취소\n")
            return

        self.txrx_stimulus_stop_event.clear()
        self.txrx_stimulus_status_var.set("Stimulus: 수동 후보 실행 중")
        self.txrx_manual_candidate_status_var.set("수동 후보: 실행 중")
        self.txrx_status_var.set("수동 후보 Signal 묶음 테스트")
        self._txrx_log(
            f"[STIMULUS][MANUAL] START name={profile.name}, items={len(profile.candidates)}, hold={profile.hold_sec}s\n"
        )

        def worker():
            result = executor.execute_group_once(client, profile, stop_event=self.txrx_stimulus_stop_event)
            try:
                self.after(0, lambda: self._finish_txrx_manual_stimulus(result))
            except Exception:
                pass

        self.txrx_stimulus_thread = threading.Thread(target=worker, daemon=True)
        self.txrx_stimulus_thread.start()

    def _finish_txrx_manual_stimulus(self, result):
        try:
            restored = all(x.restore_ok for x in (result.items or []) if x.write_ok)
            if result.ok and restored:
                status = "중단 후 원복" if result.stopped_early else "완료/원복"
                self.txrx_stimulus_status_var.set(f"Stimulus: {status}")
                self.txrx_manual_candidate_status_var.set(f"수동 후보: {status}")
                self.txrx_status_var.set(f"수동 후보 테스트 {status}")
            else:
                self.txrx_stimulus_status_var.set("Stimulus: 오류")
                self.txrx_manual_candidate_status_var.set("수동 후보: 오류/원복 확인")
                self.txrx_status_var.set("수동 후보 테스트 오류")
            for item in result.items or []:
                self._txrx_log(
                    f"[STIMULUS][MANUAL][ITEM] {item.logical_can}/Ch{item.channel} "
                    f"{item.message}.{item.signal}: original={item.original_value}, active={item.active_value}, "
                    f"readback={item.active_readback}, restored={item.restored_value}, "
                    f"write_ok={item.write_ok}, restore_ok={item.restore_ok}, error={item.error or '-'}\n"
                )
            self._txrx_log(
                f"[STIMULUS][MANUAL] END ok={result.ok}, stopped={result.stopped_early}, "
                f"backend={getattr(result, 'backend', '-')}, frames={getattr(result, 'frame_count', 0)}, restore_ok={result.restore_ok}, error={result.error or '-'}, trace={result.trace_path or '-'}\n"
            )
            if not restored:
                messagebox.showerror(
                    "수동 후보 원복 확인 필요",
                    "후보 묶음 입력 후 일부 Signal의 시작 전 값 복원이 확인되지 않았습니다.\n"
                    "Vector Trace와 실제 차량 상태를 즉시 확인하세요.\n\n"
                    f"{result.error or '-'}",
                )
            elif result.error:
                messagebox.showwarning("후보 묶음 테스트 완료(오류 있음)", result.error)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _txrx_send_not_implemented(self):
        messagebox.showinfo(
            "일반 송신 비활성",
            "rev60에서도 일반 CAN 송신/로그 Replay 자동화는 활성화하지 않습니다.\n\n"
            "실제 입력 PoC는 별도 oracle_checker_stimulus_rev60.py 모듈의 [입력 1회 테스트] 또는 "
            "[수동 후보 Signal 묶음 테스트]만 허용합니다.",
        )

    def _txrx_stop_stimulus(self):
        """현재 1회 Stimulus hold를 중단시킨다. worker의 finally에서 원래 값으로 복원된다."""
        try:
            self.txrx_stimulus_stop_event.set()
            self.txrx_stimulus_status_var.set("Stimulus: 중단/원복 요청")
            self._txrx_log("[STIMULUS] 즉시 중단/원복 요청\n")
        except Exception as e:
            self._txrx_log(f"[STIMULUS][WARN] 중단 요청 실패: {e}\n")

    def _build_selected_stimulus_profile(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            raise RuntimeError(
                "oracle_checker_stimulus_rev60.py를 사용할 수 없습니다. "
                f"기존 Pass/Fail은 정상 사용 가능합니다. import={STIMULUS_IMPORT_ERROR or '-'}"
            )
        idx, cond = self._get_txrx_selected_condition()
        if cond is None or idx is None:
            raise ValueError("차량 송수신 테스트할 TC를 먼저 선택하세요.")
        if self._is_safety_excluded_tc(cond):
            raise ValueError("rev60 Stimulus PoC에서는 제동/조향/구동/에어백/충전/ADAS 등 안전 영향 TC 입력을 차단합니다.")

        inputs = list(getattr(cond, "input_conditions", []) or [])
        if len(inputs) != 1:
            raise ValueError(f"rev60 Stimulus PoC는 입력 조건이 정확히 1개인 TC만 허용합니다. 현재={len(inputs)}개")

        analysis = self.txrx_analysis_by_index.get(idx)
        if analysis is None:
            analysis = self._analyze_condition_txrx(cond)
            self.txrx_analysis_by_index[idx] = analysis
            self._refresh_txrx_tree()

        input_rows = analysis.get("input_rows", []) or []
        if len(input_rows) != 1:
            raise ValueError("입력 조건 정적 분석 결과가 1개가 아니어서 실행을 차단합니다.")
        row = input_rows[0]
        if row.get("status") == self.TXRX_STATUS_BAD:
            raise ValueError(f"입력 정적 분석이 불가 상태입니다: {row.get('reason', '-')}")
        if row.get("crc_alive"):
            raise ValueError("CRC/Alive/Counter류 Signal이 포함된 Message는 rev60 직접 Signal 입력 대상에서 제외합니다.")
        found = [x for x in (row.get("locations") or []) if x.get("signal_found")]
        if len(found) != 1:
            raise ValueError(f"Message/Signal이 물리 채널에서 유일하게 식별되지 않았습니다. 후보={len(found)}개")

        exp = inputs[0]
        hold_sec = float(self.txrx_stimulus_hold_sec_var.get().strip() or "0.5")
        channel_value = int(found[0]["channel"])
        channel_label = str(found[0].get("channel_label") or self._ch_label_for_int(channel_value))
        logical_can = channel_label.split("/", 1)[0] if channel_label.upper().startswith("CAN") else f"Ch{channel_value}"
        profile = _stimulus.StimulusProfile(
            tc_no=str(getattr(cond, "tc_no", "") or ""),
            channel=channel_value,
            message=str(getattr(exp, "message", "") or "").strip(),
            signal=str(getattr(exp, "signal", "") or "").strip(),
            active_value=getattr(exp, "expected_value_raw", None),
            hold_sec=hold_sec,
            bus_name="CAN",
            source="Oracle input condition / TXRX selected TC",
            logical_can=logical_can,
        )
        return idx, cond, analysis, row, profile

    def _txrx_stimulus_test_once(self):
        if not bool(self.txrx_stimulus_enable_var.get()):
            messagebox.showwarning(
                "Stimulus 비활성",
                "실험용 입력은 기본 OFF입니다.\n[실험용 Stimulus 사용]을 직접 체크한 뒤 다시 실행하세요.",
            )
            return
        if self.txrx_stimulus_thread is not None and self.txrx_stimulus_thread.is_alive():
            messagebox.showinfo("Stimulus 실행 중", "이미 입력 1회 테스트가 진행 중입니다.")
            return

        try:
            idx, cond, analysis, input_row, profile = self._build_selected_stimulus_profile()
            client = self._ensure_client(show_popup=False)
            if not client.is_measurement_running():
                client.start_measurement(wait_sec=0.0)
                try:
                    self.measurement_status_var.set("Measurement: 실행 중")
                    self._refresh_status_badges()
                except Exception:
                    pass

            executor = self._make_stimulus_executor()
            checked = executor.validate(client, profile)
            self._require_canalyzer_source_isolated(client)
        except Exception as e:
            self.txrx_stimulus_status_var.set("Stimulus: 실행 차단")
            self._txrx_log(f"[STIMULUS][BLOCK] {e}\n")
            messagebox.showerror("입력 1회 테스트 실행 불가", str(e))
            return

        physical_note = ""
        if self._is_physical_or_switch_tc(cond):
            physical_note = (
                "\n\n※ 이 TC는 Seat/Switch/Button 등 물리 입력 가능성이 있는 항목입니다. "
                "CAN Signal/CAPL 입력만으로 실제 물리 조작이 재현되지 않을 수 있습니다."
            )
        confirm_text = (
            "[rev60 실험용 Stimulus 1회 테스트]\n\n"
            f"TC: {profile.tc_no}\n"
            f"대상: CAN Ch{profile.channel} / {profile.message} / {profile.signal}\n"
            f"시작 전 값: {checked.get('original_value')}\n"
            f"입력 값: {checked.get('active_value')}\n"
            f"Hold: {checked.get('hold_sec')} sec\n\n"
            f"Backend: {checked.get('backend', '-')}\n"
            "실행 후 성공/오류/중단 여부와 무관하게 시작 전 상태로 복원을 시도합니다.\n"
            "CANalyzer CAPL backend에서는 실제 Frame을 송신하므로 동일 Message ID의 기존 ECU/Generator 송신원이 반드시 분리/비활성되어야 합니다. "
            "CANoe backend에서는 Signal.Value가 실제 버스 송신으로 이어지는지가 Configuration/IL 구성에 따라 달라질 수 있습니다."
            + physical_note
            + "\n\n실행할까요?"
        )
        if not messagebox.askyesno("실험용 입력 확인", confirm_text):
            self._txrx_log("[STIMULUS] 사용자 취소\n")
            return

        self.txrx_stimulus_stop_event.clear()
        self.txrx_stimulus_status_var.set("Stimulus: 실행 중")
        self.txrx_status_var.set(f"입력 1회 테스트: {profile.tc_no}")
        self._txrx_log(
            f"[STIMULUS] START TC={profile.tc_no}, Ch={profile.channel}, "
            f"{profile.message}.{profile.signal}={checked.get('active_value')}, hold={checked.get('hold_sec')}s, "
            f"original={checked.get('original_value')}\n"
        )

        def worker():
            result = executor.execute_once(client, profile, stop_event=self.txrx_stimulus_stop_event)
            try:
                self.after(0, lambda: self._finish_txrx_stimulus(result))
            except Exception:
                pass

        self.txrx_stimulus_thread = threading.Thread(target=worker, daemon=True)
        self.txrx_stimulus_thread.start()

    def _finish_txrx_stimulus(self, result):
        try:
            if result.ok and result.restore_ok:
                status = "중단 후 원복" if result.stopped_early else "완료/원복"
                self.txrx_stimulus_status_var.set(f"Stimulus: {status}")
                self.txrx_status_var.set(f"입력 1회 테스트 {status}")
            else:
                self.txrx_stimulus_status_var.set("Stimulus: 오류")
                self.txrx_status_var.set("입력 1회 테스트 오류")
            self._txrx_log(
                f"[STIMULUS] END ok={result.ok}, stopped={result.stopped_early}, "
                f"active_readback={result.active_readback}, restored={result.restored_value}, "
                f"backend={getattr(result, 'backend', '-')}, frames={getattr(result, 'frame_count', 0)}, restore_ok={result.restore_ok}, error={result.error or '-'}, trace={result.trace_path or '-'}\n"
            )
            if not result.restore_ok:
                messagebox.showerror(
                    "Stimulus 원복 확인 필요",
                    "입력 테스트 후 시작 전 값 자동 복원이 확인되지 않았습니다.\n"
                    "Vector Trace/실제 차량 상태를 즉시 확인하세요.\n\n"
                    f"{result.error or '-'}",
                )
            elif result.error:
                messagebox.showwarning("입력 테스트 완료(오류 있음)", result.error)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _show_txrx_preview(self, idx: Optional[int]):
        if self.txrx_preview_text is None:
            return
        lines: List[str] = []
        result_rows: List[Tuple[str, str, str, str, str, str, str, str]] = []

        if idx is None or not (0 <= idx < len(getattr(self, "condition_rows", []))):
            self.txrx_selected_tc_var.set("선택 TC: -")
            self.txrx_summary_var.set("송신 가능성: 미검사")
            lines.append("TC를 선택하면 입력 송신 대상과 출력 감시 대상 Preview가 표시됩니다.")
            self._write_txrx_preview(lines)
            self._refresh_txrx_result_tree([])
            return

        row = self.condition_rows[idx]
        if not row.is_valid or row.condition is None:
            self.txrx_selected_tc_var.set("선택 TC: -")
            self.txrx_summary_var.set("송신 가능성: 불가")
            lines.append("선택한 행은 유효한 TC가 아닙니다.")
            lines.append(row.error_reason or "-")
            self._write_txrx_preview(lines)
            self._refresh_txrx_result_tree([])
            return

        cond = row.condition
        analysis = self.txrx_analysis_by_index.get(idx)
        if analysis is None:
            analysis = {"status": self.TXRX_STATUS_UNCHECKED, "summary": "프리테스트 분류/송신 가능성 검사를 수행하지 않았습니다.", "input_rows": [], "output_rows": [], "method": self.TXRX_METHOD_UNKNOWN, "method_reason": "검사 전"}

        self.txrx_selected_tc_var.set(f"선택 TC: {cond.tc_no} / {cond.subcategory}")
        self.txrx_summary_var.set(f"송신 가능성: {analysis.get('status')} - {analysis.get('summary')}")
        self.txrx_status_var.set(f"선택 TC Preview: {cond.tc_no}")

        if analysis.get("recommended_period_ms"):
            try:
                self.txrx_period_ms_var.set(str(int(analysis.get("recommended_period_ms"))))
            except Exception:
                pass
        if analysis.get("method") and analysis.get("method") != self.TXRX_METHOD_UNKNOWN:
            # 실험 방식 기본값은 자동화 추천을 참고하되 사용자가 수동으로 바꿀 수 있다.
            try:
                self.txrx_experiment_method_var.set(str(analysis.get("method")))
            except Exception:
                pass

        lines.extend([
            f"TC 번호: {cond.tc_no}",
            f"소분류: {cond.subcategory}",
            f"대기 시간: {cond.timeout_sec}s",
            f"자동화 방식 추천: {analysis.get('method', self.TXRX_METHOD_UNKNOWN)}",
            f"추천 사유: {analysis.get('method_reason', '-')}",
            "",
            "[TC 내용]",
            cond.tc_content or "-",
            "",
            "[TC 예상 결과]",
            cond.tc_expected_result or "-",
            "",
            "[입력 조건: 자동 자극 후보(CAN 송신/로그 Replay/물리 입력)]",
        ])

        if cond.input_conditions:
            for pos, exp in enumerate(cond.input_conditions, start=1):
                row_analysis = self._find_row_analysis(analysis, "input_rows", pos)
                channel = row_analysis.get("channel", "-") if row_analysis else "-"
                status = row_analysis.get("status", self.TXRX_STATUS_UNCHECKED) if row_analysis else self.TXRX_STATUS_UNCHECKED
                reason = row_analysis.get("reason", "검사 전") if row_analysis else "검사 전"
                cycle = row_analysis.get("cycle_ms") if row_analysis else None
                lines.append(f"{pos}. Message: {exp.message}")
                lines.append(f"   Signal : {exp.signal}")
                lines.append(f"   Value  : {exp.expected_value_raw}")
                lines.append(f"   Channel 후보: {channel}")
                lines.append(f"   송신 주기 후보: {cycle if cycle else '-'} ms")
                lines.append(f"   상태: {status} / {reason}")
                result_rows.append(("입력", exp.message, exp.signal, exp.expected_value_raw, channel, status, reason, self._tag_for_txrx_status(status)))
        else:
            lines.append("-")

        lines.extend(["", "[출력 조건: 차량 반응 수신/감시 대상]"])
        if cond.output_conditions:
            for pos, exp in enumerate(cond.output_conditions, start=1):
                row_analysis = self._find_row_analysis(analysis, "output_rows", pos)
                channel = row_analysis.get("channel", "-") if row_analysis else "-"
                status = row_analysis.get("status", self.TXRX_STATUS_UNCHECKED) if row_analysis else self.TXRX_STATUS_UNCHECKED
                reason = row_analysis.get("reason", "검사 전") if row_analysis else "검사 전"
                lines.append(f"{pos}. Message: {exp.message}")
                lines.append(f"   Signal : {exp.signal}")
                lines.append(f"   Expected: {exp.expected_value_raw}")
                lines.append(f"   Channel 후보: {channel}")
                lines.append(f"   상태: {status} / {reason}")
                result_rows.append(("출력", exp.message, exp.signal, exp.expected_value_raw, channel, status, reason, self._tag_for_txrx_status(status)))
        else:
            lines.append("-")

        lines.extend([
            "",
            "[rev60 실험 관리 / Stimulus 격리 기준]",
            "- 기존 OneByOne/Multiple PassFail은 관측/판정 기능 그대로 유지하며 실제 입력 쓰기 로직을 포함하지 않습니다.",
            "- 실제 Stimulus는 oracle_checker_stimulus_rev60.py 안에서만 수행합니다(CANoe=Signal.Value, CANalyzer=CAPL output()).",
            "- Stimulus 모듈이 없거나 실패해도 기존 Pass/Fail 기능은 계속 사용할 수 있습니다.",
            "- 선택 TC 입력 1회 테스트는 기존 단일 Signal 제한을 유지합니다.",
            "- rev60 수동 후보 묶음 테스트는 Excel 등에서 CAN/Message/Signal/Value 1~8행을 붙여넣어 시험합니다. CANoe는 Signal 원복, CANalyzer는 release Frame 송신으로 시작 전 상태 복원을 시도합니다.",
            "- CRC/Alive/Counter는 자동 계산하지 않습니다. DBC에서 감지되면 기본 차단하며 사용자가 경고 허용을 명시한 경우 정적 값 시험만 가능합니다.",
            "- 실행 직전 Signal 값을 읽어 저장하고 성공/실패/중단과 무관하게 finally에서 해당 값으로 원복합니다.",
            "- Seat/Switch 같은 물리 입력 TC는 경고 후 실험할 수 있으나 CAN Signal 변경만으로 실제 물리 조작이 재현되지 않을 수 있습니다.",
            "- 일반 다중 Signal 송신/로그 Replay 자동화는 여전히 비활성입니다.",
            "- 동일 Message ID가 실제 차량 버스에서 이미 송신 중이면 충돌 위험이 있습니다.",
            "- CRC/Alive/Counter가 포함된 메시지는 기본 차단하며 override는 정적 값 탐색 시험만 허용합니다. CANalyzer CAPL backend도 CRC를 자동 계산하지 않습니다.",
        ])

        self._write_txrx_preview(lines)
        self._refresh_txrx_result_tree(result_rows)
        self._write_txrx_status_text(cond, analysis)

    def _find_row_analysis(self, analysis: Dict[str, Any], key: str, pos: int) -> Dict[str, Any]:
        for item in analysis.get(key, []) or []:
            if item.get("pos") == pos:
                return item
        return {}

    def _tag_for_txrx_status(self, status: str) -> str:
        if status == self.TXRX_STATUS_OK:
            return "ok"
        if status == self.TXRX_STATUS_WARN:
            return "warn"
        if status == self.TXRX_STATUS_BAD:
            return "bad"
        return ""

    def _write_txrx_preview(self, lines: List[str]):
        self.txrx_preview_text.configure(state="normal")
        self.txrx_preview_text.delete("1.0", tk.END)
        self.txrx_preview_text.insert("1.0", "\n".join(lines))
        self.txrx_preview_text.configure(state="normal")

    def _refresh_txrx_result_tree(self, rows: List[Tuple[str, str, str, str, str, str, str, str]]):
        if self.txrx_result_tree is None:
            return
        self.txrx_result_tree.delete(*self.txrx_result_tree.get_children())
        for i, (kind, msg, sig, exp, ch, status, reason, tag) in enumerate(rows, start=1):
            self.txrx_result_tree.insert(
                "",
                tk.END,
                iid=f"txrx:{i}",
                tags=(tag,) if tag else (),
                values=(kind, msg, sig, exp, ch, status, reason),
            )

    def _write_txrx_status_text(self, cond: Any, analysis: Dict[str, Any]):
        if self.txrx_status_text is None:
            return
        lines = [
            f"상태: {analysis.get('status', self.TXRX_STATUS_UNCHECKED)}",
            f"현재 송신 TC: {cond.tc_no}",
            f"송신 시작 시각: -",
            f"마지막 송신 시각: -",
            f"송신 횟수: -",
            "",
            "[자동화 방식 추천]",
            analysis.get("method") or self.TXRX_METHOD_UNKNOWN,
            analysis.get("method_reason") or "-",
            "",
            "[권장 프리테스트 정책 Preview]",
            f"출력 대기시간(sec): {self.txrx_wait_sec_var.get()}",
            f"TC 간 대기(sec): {self.txrx_between_tc_delay_var.get()}",
            f"Fail 처리: {self.txrx_fail_policy_var.get()}",
            f"송신 방식 후보: {self.txrx_tx_mode_var.get()}",
            f"송신 주기(ms) 후보: {self.txrx_period_ms_var.get()}",
            "",
            "[결과 해석]",
            "OK: 현재 자극 가설로 반응 확인 / NG: 기능 FAIL 확정이 아니라 입력조건·자극방식 보완 또는 수동 확인 필요",
            "",
            "[진단 요약]",
            analysis.get("summary") or "-",
            "",
            "[Stimulus 모듈]",
            self.txrx_stimulus_status_var.get(),
            "실제 Stimulus 동작은 독립 oracle_checker_stimulus_rev60.py에서만 수행",
        ]
        if analysis.get("errors"):
            lines.append("")
            lines.append("[불가 사유]")
            for item in analysis.get("errors", [])[:10]:
                lines.append(f"- {item}")
        if analysis.get("warnings"):
            lines.append("")
            lines.append("[확인 필요]")
            for item in analysis.get("warnings", [])[:10]:
                lines.append(f"- {item}")

        self.txrx_status_text.configure(state="normal")
        self.txrx_status_text.delete("1.0", tk.END)
        self.txrx_status_text.insert("1.0", "\n".join(lines))
        self.txrx_status_text.configure(state="normal")
