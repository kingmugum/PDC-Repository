# -*- coding: utf-8 -*-
"""
oracle_checker_main_rev53.py

변경 사항:
- done_event 추가
  * stop_event: 진짜 중단
  * done_event: 사용자가 "수행 완료"를 눌러 현재 시점 기준으로 실시간 판정을 마감하고
                이후 로그 재검토 단계로 자연스럽게 넘어가게 하는 신호
- 실시간 입력/출력 판정 루프에서 done_event를 인식
- 수행 완료 시점의 관측 결과를 최대한 result에 반영
- 기존 export / Excel / DBC / ASC / BLF 로직은 유지
- rev20: CANoe COM 재연결/Measurement Stop-Start 안정화
- rev21: __pycache__ 생성 억제 및 종료 시 자동 삭제
- rev22: CANoe 미실행 상태에서 연결됨처럼 보이는 문제 완화
- rev23: 입력 다중 조건 지원
- rev24: 실행 중인 CANoe COM 객체 연결 및 유효성 검증
- rev25:
  * CANoe COM 연결 모드 분리 및 유효성 검증 강화
- rev26:
  * 누락된 CANoeClient 클래스 복구
  * 기본 연결은 GetActiveObject only로 동작하여 실행 중인 CANoe에만 연결
- rev37:
  * rev36 기능 유지
  * 실행 중인 CANoe COM 객체의 Version/FullName 검증 강화
- rev40:
  * CANoe 15 고정 버전 검증 해제
  * 실행 중인 CANoe가 있으면 CANoe 10/15/기타 버전 모두 연결 가능
  * 버전 제한이 필요한 경우에만 connect(expected_version_keyword=...)로 별도 지정
- rev42:
  * GUI rev42의 다중 실행 UI/상태 유지 개선과 연동되는 core 계약 유지
  * CheckResult/FinalCheckResult 데이터 구조는 하위 호환을 위해 변경하지 않음
- rev44:
  * GUI 탭명/배치/열 폭 조정 요청 대응용 버전명 갱신
  * Core 판정 계약 및 CheckResult/FinalCheckResult 데이터 구조 변경 없음
- rev45:
  * 다중 TC 로그 검토용 review_conditions_in_log_batch 추가
  * 여러 TC/시그널을 ASC 1회 스캔으로 일괄 확인하여 대용량 로그 반복 스캔 부담 완화
  * CANoe 연결은 GetActiveObject only로 고정
  * 실시간 PASS는 로그 재검토 결과와 무관하게 최종 PASS 유지
- rev53:
  * 기존 판정 Core/CANoeClient는 관측(read) 역할 유지; 실제 Signal write API는 추가하지 않음
  * 실제 입력 PoC는 독립 oracle_checker_stimulus_rev53.py에서만 수행
  * rev50 기능/판정 계약 및 CANoe COM 진단 유지
  * GetActiveObject only 연결 정책은 변경하지 않음
  * CAN 네트워크명 근거 기반 DBC 자동 매핑 유틸 추가
    - ASC/로그 파일명/CANoe Configuration 파일의 명시적 CAN1~CAN4 ↔ XXX-CAN 근거만 사용
    - P-CAN과 P1-CAN 별칭 정규화
    - DBC 폴더에서 파일명 후보가 정확히 1개일 때만 자동 선택
    - 근거 충돌/DBC 0개/복수 후보는 자동 선택하지 않음
  * rev50에서 추가된 CANoe COM 연결 실패 read-only 진단 기능 유지
    - Python 실행 정보/관리자 권한/bitness
    - 실행 중 CANoe 프로세스 및 실행 경로
    - CANoe.Application ProgID/CLSID/LocalServer32 등록 정보(32/64-bit view)
    - GetActiveObject 재확인 결과와 HRESULT/예외 chain
  * 진단 정보는 CANoe 실행/COM 등록을 변경하지 않고 TXT로 저장 가능
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple
import datetime as _dt
import math
import re
import threading
import time
import traceback
import subprocess
import sys
import atexit
import shutil
import os
import json
import platform
import tempfile


# =========================================================
# __pycache__ 생성 억제 및 기존 캐시 폴더 정리
# =========================================================
sys.dont_write_bytecode = True

def _cleanup_pycache(base_dir=None):
    try:
        root = Path(base_dir) if base_dir is not None else Path(__file__).resolve().parent
        for p in root.glob("__pycache__"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass

_cleanup_pycache()
atexit.register(_cleanup_pycache)


# =========================================================
# 공통 유틸
# =========================================================
_HEX_RE = re.compile(r"^[-+]?0x[0-9a-fA-F]+$")
_INT_RE = re.compile(r"^[-+]?\d+$")
_FLOAT_RE = re.compile(r"^[-+]?\d+\.\d+$")

DEBUG_ENABLED = False
_COM_THREAD_STATE = threading.local()


def debug_print(msg: str) -> None:
    if DEBUG_ENABLED:
        ts = _dt.datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"[DEBUG {ts}] {msg}", flush=True)


def _hidden_subprocess_kwargs() -> Dict[str, Any]:
    """Windows .pyw 실행 중 subprocess 호출 시 검은 콘솔창이 뜨지 않도록 한다."""
    if not sys.platform.startswith("win"):
        return {}

    kwargs: Dict[str, Any] = {}
    try:
        create_no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if create_no_window:
            kwargs["creationflags"] = create_no_window

        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
        kwargs["startupinfo"] = startupinfo
    except Exception:
        pass
    return kwargs



# =========================================================
# CANoe COM read-only diagnostics (rev53)
# =========================================================
def _exception_chain_details(error: Optional[BaseException]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    cur = error
    while cur is not None and id(cur) not in seen and len(out) < 8:
        seen.add(id(cur))
        hresult = getattr(cur, "hresult", None)
        if hresult is None:
            try:
                if getattr(cur, "args", None) and isinstance(cur.args[0], int):
                    hresult = int(cur.args[0])
            except Exception:
                pass
        item: Dict[str, Any] = {
            "type": type(cur).__name__,
            "message": str(cur),
            "args": repr(getattr(cur, "args", ())),
        }
        if hresult is not None:
            try:
                hr = int(hresult)
                item["hresult"] = hr
                item["hresult_hex"] = f"0x{(hr & 0xFFFFFFFF):08X}"
            except Exception:
                item["hresult"] = str(hresult)
        out.append(item)
        cur = getattr(cur, "__cause__", None) or getattr(cur, "__context__", None)
    return out


def _python_is_admin() -> Optional[bool]:
    if not sys.platform.startswith("win"):
        return None
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return None


def _collect_canoe_processes() -> Dict[str, Any]:
    result: Dict[str, Any] = {"method": "", "items": [], "error": ""}
    if not sys.platform.startswith("win"):
        result["error"] = "Windows가 아니므로 CANoe 프로세스 조회를 수행하지 않음"
        return result

    # ExecutablePath/FileVersion까지 얻기 위해 PowerShell/CIM을 우선 사용한다.
    ps_script = (
        "$ErrorActionPreference='SilentlyContinue'; "
        "$x=Get-CimInstance Win32_Process | Where-Object {$_.Name -like 'CANoe*.exe'} | "
        "ForEach-Object { $v=''; if ($_.ExecutablePath) { try { $v=(Get-Item $_.ExecutablePath).VersionInfo.FileVersion } catch {} }; "
        "[PSCustomObject]@{ProcessId=$_.ProcessId;Name=$_.Name;ExecutablePath=$_.ExecutablePath;CommandLine=$_.CommandLine;FileVersion=$v} }; "
        "$x | ConvertTo-Json -Compress"
    )
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=8,
            **_hidden_subprocess_kwargs(),
        )
        raw = (completed.stdout or "").strip()
        if completed.returncode == 0:
            result["method"] = "PowerShell Get-CimInstance"
            if raw:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    parsed = [parsed]
                if isinstance(parsed, list):
                    result["items"] = parsed
            return result
        result["error"] = (completed.stderr or "").strip() or f"PowerShell returncode={completed.returncode}"
    except Exception as e:
        result["error"] = f"PowerShell 조회 실패: {type(e).__name__}: {e}"

    # PowerShell이 정책상 차단된 PC를 위한 최소 fallback.
    try:
        completed = subprocess.run(
            ["tasklist.exe", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True,
            timeout=5,
            **_hidden_subprocess_kwargs(),
        )
        lines = []
        for line in (completed.stdout or "").splitlines():
            if "canoe" in line.lower():
                lines.append(line.strip())
        result["method"] = "tasklist fallback"
        result["items"] = [{"raw": x} for x in lines]
    except Exception as e:
        result["error"] = (result.get("error") + " | " if result.get("error") else "") + f"tasklist 실패: {type(e).__name__}: {e}"
    return result


def _registry_read_default(winreg, root, path: str, access: int) -> str:
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ | access) as key:
            value, _ = winreg.QueryValueEx(key, "")
            return str(value)
    except Exception:
        return ""


def _registry_collect_view(view_name: str, root_name: str, classes_path: str, wow_flag: int = 0) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "view": view_name,
        "root": root_name,
        "prog_id": "CANoe.Application",
        "description": "",
        "clsid": "",
        "curver": "",
        "local_server32": "",
        "versioned_progids": [],
        "error": "",
    }
    try:
        import winreg
        root = winreg.HKEY_LOCAL_MACHINE if root_name == "HKLM" else winreg.HKEY_CURRENT_USER
        prefix = classes_path.rstrip("\\")
        base = prefix + r"\CANoe.Application"
        result["description"] = _registry_read_default(winreg, root, base, wow_flag)
        result["clsid"] = _registry_read_default(winreg, root, base + r"\CLSID", wow_flag)
        result["curver"] = _registry_read_default(winreg, root, base + r"\CurVer", wow_flag)
        if result["clsid"]:
            result["local_server32"] = _registry_read_default(
                winreg, root, prefix + "\\CLSID\\" + result["clsid"] + "\\LocalServer32", wow_flag
            )

        # CANoe.Application.<version> 형태를 함께 수집해 다중 버전 설치 흔적을 확인한다.
        with winreg.OpenKey(root, prefix, 0, winreg.KEY_READ | wow_flag) as classes_key:
            i = 0
            while i < 50000 and len(result["versioned_progids"]) < 40:
                try:
                    name = winreg.EnumKey(classes_key, i)
                except OSError:
                    break
                i += 1
                low = name.lower()
                if not (low == "canoe.application" or low.startswith("canoe.application.")):
                    continue
                sub = prefix + "\\" + name
                clsid = _registry_read_default(winreg, root, sub + r"\CLSID", wow_flag)
                curver = _registry_read_default(winreg, root, sub + r"\CurVer", wow_flag)
                server = ""
                if clsid:
                    server = _registry_read_default(winreg, root, prefix + "\\CLSID\\" + clsid + "\\LocalServer32", wow_flag)
                result["versioned_progids"].append({
                    "progid": name,
                    "clsid": clsid,
                    "curver": curver,
                    "local_server32": server,
                })
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
    return result


def _collect_canoe_registry() -> List[Dict[str, Any]]:
    if not sys.platform.startswith("win"):
        return [{"view": "N/A", "error": "Windows가 아니므로 Registry 조회를 수행하지 않음"}]
    try:
        import winreg
        view64 = getattr(winreg, "KEY_WOW64_64KEY", 0)
        view32 = getattr(winreg, "KEY_WOW64_32KEY", 0)
    except Exception as e:
        return [{"view": "Registry", "error": f"winreg import 실패: {e}"}]

    return [
        _registry_collect_view("HKLM 64-bit", "HKLM", r"SOFTWARE\Classes", view64),
        _registry_collect_view("HKLM 32-bit", "HKLM", r"SOFTWARE\Classes", view32),
        _registry_collect_view("HKCU user classes", "HKCU", r"Software\Classes", 0),
    ]


def _active_object_probe() -> Dict[str, Any]:
    out: Dict[str, Any] = {"success": False, "error": "", "exception_chain": []}
    if not sys.platform.startswith("win"):
        out["error"] = "Windows가 아니므로 GetActiveObject probe를 수행하지 않음"
        return out
    try:
        _ensure_com_initialized()
        import win32com.client
        app = win32com.client.GetActiveObject("CANoe.Application")
        out["success"] = True
        try:
            out["version"] = str(app.Version)
        except Exception:
            out["version"] = ""
        try:
            out["fullname"] = str(app.FullName)
        except Exception:
            out["fullname"] = ""
        try:
            out["configuration"] = str(app.Configuration.FullName)
        except Exception:
            out["configuration"] = ""
        try:
            out["measurement_running"] = bool(app.Measurement.Running)
        except Exception as e:
            out["measurement_error"] = f"{type(e).__name__}: {e}"
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
        out["exception_chain"] = _exception_chain_details(e)
    return out


def _extract_registered_server_paths(registry_views: List[Dict[str, Any]]) -> List[str]:
    paths: List[str] = []
    for view in registry_views or []:
        for raw in [view.get("local_server32", "")]:
            if raw and raw not in paths:
                paths.append(str(raw))
        for item in view.get("versioned_progids", []) or []:
            raw = item.get("local_server32", "")
            if raw and raw not in paths:
                paths.append(str(raw))
    return paths


def _build_canoe_diag_interpretation(diag: Dict[str, Any]) -> List[str]:
    notes: List[str] = []
    processes = (diag.get("canoe_processes") or {}).get("items") or []
    active = diag.get("active_object_probe") or {}
    registry = diag.get("registry") or []
    servers = _extract_registered_server_paths(registry)

    if active.get("success"):
        notes.append("GetActiveObject 재확인 성공: 진단 시점에는 CANoe COM 활성 객체를 찾았습니다. 최초 실패가 일시적/타이밍성인지 확인하세요.")
    elif processes:
        notes.append("CANoe 프로세스는 실행 중이지만 GetActiveObject가 실패했습니다. ROT 등록 상태, Python/CANoe 권한 수준, 다중 버전 COM 등록 불일치를 우선 확인하세요.")
    else:
        notes.append("진단 시점에 CANoe 프로세스를 찾지 못했습니다. CANoe 실행/프로세스명/보안 정책을 먼저 확인하세요.")

    if not servers:
        notes.append("CANoe.Application의 LocalServer32 등록 경로를 찾지 못했습니다. COM 등록 누락/Registry view 불일치 가능성이 있습니다.")
    else:
        process_paths = []
        for item in processes:
            path = str(item.get("ExecutablePath") or item.get("executable_path") or "").strip()
            if path:
                process_paths.append(path.lower())
        if process_paths:
            if not any(any(pp in server.lower() or server.lower().strip(' \"') in pp for server in servers) for pp in process_paths):
                notes.append("실행 중 CANoe 경로와 수집된 COM LocalServer32 경로가 일치하지 않아 보입니다. 다중 CANoe 버전 설치/등록 상태를 확인하세요.")

    py_admin = (diag.get("python") or {}).get("is_admin")
    if py_admin is True:
        notes.append("Oracle Checker(Python)는 관리자 권한으로 실행 중입니다. CANoe도 동일한 권한 수준인지 현장에서 확인하세요.")
    elif py_admin is False:
        notes.append("Oracle Checker(Python)는 일반 권한으로 실행 중입니다. CANoe도 일반 권한인지 현장에서 확인하세요.")
    else:
        notes.append("Python 관리자 권한 상태를 자동 판별하지 못했습니다.")

    notes.append("이 진단은 read-only입니다. Dispatch/새 CANoe 실행/Registry 수정/-regserver 수행을 하지 않습니다.")
    return notes


def collect_canoe_com_diagnostics(trigger_error: Optional[BaseException] = None) -> Dict[str, Any]:
    """CANoe COM 연결 실패 분석용 정보를 read-only로 수집한다.

    GetActiveObject only 정책을 유지하며, CANoe 실행/COM 등록/Registry를 변경하지 않는다.
    """
    diag: Dict[str, Any] = {
        "diagnostic_version": "rev53",
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "platform": platform.platform(),
        "python": {
            "executable": sys.executable,
            "version": sys.version.replace("\n", " "),
            "bitness": 64 if sys.maxsize > 2**32 else 32,
            "pid": os.getpid(),
            "is_admin": _python_is_admin(),
        },
        "trigger_exception_chain": _exception_chain_details(trigger_error),
        "canoe_processes": _collect_canoe_processes(),
        "registry": _collect_canoe_registry(),
        "active_object_probe": _active_object_probe(),
    }
    diag["interpretation"] = _build_canoe_diag_interpretation(diag)
    return diag


def format_canoe_com_diagnostics(diag: Dict[str, Any]) -> str:
    lines: List[str] = []
    lines.append("Oracle Checker - CANoe COM 연결 진단")
    lines.append("=" * 72)
    lines.append(f"진단 버전: {diag.get('diagnostic_version', '-')}")
    lines.append(f"생성 시각: {diag.get('created_at', '-')}")
    lines.append(f"OS: {diag.get('platform', '-')}")
    py = diag.get("python") or {}
    lines.append(f"Python: {py.get('version', '-')}")
    lines.append(f"Python executable: {py.get('executable', '-')}")
    lines.append(f"Python bitness: {py.get('bitness', '-')} bit")
    lines.append(f"Python PID: {py.get('pid', '-')}")
    lines.append(f"Python 관리자 권한: {py.get('is_admin', '-')}")

    lines.append("")
    lines.append("[1] 최초 오류 / HRESULT")
    chain = diag.get("trigger_exception_chain") or []
    if not chain:
        lines.append("- 수동 진단 또는 최초 오류 정보 없음")
    for i, item in enumerate(chain, start=1):
        lines.append(f"- #{i} {item.get('type')}: {item.get('message')}")
        if item.get("hresult_hex"):
            lines.append(f"  HRESULT: {item.get('hresult')} ({item.get('hresult_hex')})")
        lines.append(f"  args: {item.get('args', '-')}")

    lines.append("")
    lines.append("[2] 실행 중 CANoe 프로세스")
    proc = diag.get("canoe_processes") or {}
    lines.append(f"조회 방식: {proc.get('method', '-')}")
    if proc.get("error"):
        lines.append(f"조회 경고: {proc.get('error')}")
    items = proc.get("items") or []
    if not items:
        lines.append("- CANoe 프로세스 미검출")
    for item in items:
        if "raw" in item:
            lines.append(f"- {item.get('raw')}")
        else:
            lines.append(
                f"- PID={item.get('ProcessId', '-')} | Name={item.get('Name', '-')} | "
                f"Version={item.get('FileVersion', '-') } | Path={item.get('ExecutablePath', '-') }"
            )
            if item.get("CommandLine"):
                lines.append(f"  CommandLine={item.get('CommandLine')}")

    lines.append("")
    lines.append("[3] CANoe.Application COM Registry")
    for view in diag.get("registry") or []:
        lines.append(f"- {view.get('view', '-')} / {view.get('root', '-')}")
        if view.get("error"):
            lines.append(f"  error={view.get('error')}")
        lines.append(f"  CLSID={view.get('clsid') or '-'}")
        lines.append(f"  CurVer={view.get('curver') or '-'}")
        lines.append(f"  LocalServer32={view.get('local_server32') or '-'}")
        for item in view.get("versioned_progids", []) or []:
            lines.append(
                f"  * {item.get('progid')} | CLSID={item.get('clsid') or '-'} | "
                f"CurVer={item.get('curver') or '-'} | LocalServer32={item.get('local_server32') or '-'}"
            )

    lines.append("")
    lines.append("[4] GetActiveObject 재확인")
    active = diag.get("active_object_probe") or {}
    lines.append(f"성공 여부: {active.get('success', False)}")
    if active.get("success"):
        lines.append(f"Version: {active.get('version') or '-'}")
        lines.append(f"FullName: {active.get('fullname') or '-'}")
        lines.append(f"Configuration: {active.get('configuration') or '-'}")
        lines.append(f"Measurement.Running: {active.get('measurement_running', '-')}")
        if active.get("measurement_error"):
            lines.append(f"Measurement 접근 오류: {active.get('measurement_error')}")
    else:
        lines.append(f"오류: {active.get('error') or '-'}")
        for item in active.get("exception_chain", []) or []:
            hr = f" / HRESULT={item.get('hresult_hex')}" if item.get("hresult_hex") else ""
            lines.append(f"- {item.get('type')}: {item.get('message')}{hr}")

    lines.append("")
    lines.append("[5] 자동 해석 / 현장 확인 포인트")
    for note in diag.get("interpretation") or []:
        lines.append(f"- {note}")

    lines.append("")
    lines.append("[주의] 본 진단 기능은 상태 조회만 수행하며 COM 등록/Windows Registry/CANoe 프로세스를 변경하지 않습니다.")
    return "\n".join(lines) + "\n"


def save_canoe_com_diagnostic_report(
    output_dir: str | Path,
    diag: Dict[str, Any],
    prefix: str = "canoe_com_diagnostic",
) -> Path:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    report_text = format_canoe_com_diagnostics(diag)
    primary = Path(output_dir)
    try:
        primary.mkdir(parents=True, exist_ok=True)
        path = primary / f"{prefix}_{stamp}.txt"
        path.write_text(report_text, encoding="utf-8-sig")
        return path
    except Exception as primary_error:
        # 프로그램 폴더가 쓰기 금지인 현장 PC를 위한 fallback.
        fallback = Path(tempfile.gettempdir()) / "OracleCheckerDiagnostics"
        fallback.mkdir(parents=True, exist_ok=True)
        path = fallback / f"{prefix}_{stamp}.txt"
        path.write_text(
            report_text + f"\n[저장 참고] 프로그램 폴더 저장 실패: {type(primary_error).__name__}: {primary_error}\n",
            encoding="utf-8-sig",
        )
        return path


# =========================================================
# CAN network name / DBC auto mapping utilities (rev53)
# =========================================================
_CAN_LOGICAL_RE = re.compile(r"(?<![A-Z0-9])CAN\s*([1-4])(?![0-9])", re.IGNORECASE)
_CH_LOGICAL_RE = re.compile(r"(?<![A-Z0-9])CH(?:ANNEL)?\s*([1-4])(?![0-9])", re.IGNORECASE)
_CHANNEL_NETWORK_PAIR_RE = re.compile(
    r"(?<![A-Z0-9])(?:CAN|CH(?:ANNEL)?)\s*([1-4])(?![0-9])"
    r"[\s:=><|/_-]{0,16}"
    r"([A-Z][A-Z0-9]{0,12}[\s_.-]*CAN)(?![A-Z0-9])",
    re.IGNORECASE,
)
_NETWORK_TOKEN_RE = re.compile(
    r"(?<![A-Z0-9])([A-Z][A-Z0-9]{0,12}[\s_.-]*CAN)(?![A-Z0-9])",
    re.IGNORECASE,
)


def normalize_can_network_name(raw: Any) -> str:
    """네트워크 표시명을 비교용 표준 이름으로 정규화한다.

    예: P CAN/P-CAN/P1_CAN -> P1-CAN, M_CAN -> M-CAN.
    사용자 운용상 P-CAN과 P1-CAN은 동일 네트워크 별칭으로 취급한다.
    """
    text = str(raw or "").strip().upper()
    if not text:
        return ""
    text = text.strip("'\"[](){}")
    compact = re.sub(r"[^A-Z0-9]", "", text)
    if not compact:
        return ""

    aliases = {
        "PCAN": "P1-CAN",
        "P1CAN": "P1-CAN",
        "BCAN": "B-CAN",
        "B1CAN": "B1-CAN",
        "B2CAN": "B2-CAN",
        "ECAN": "E-CAN",
        "MCAN": "M-CAN",
    }
    if compact in aliases:
        return aliases[compact]

    # 일반적인 XXX-CAN 명명도 지원한다. 단 CAN1/CAN2 같은 논리 채널명은 제외한다.
    if compact.startswith("CAN") and compact[3:].isdigit():
        return ""
    if compact.endswith("CAN") and len(compact) > 3:
        prefix = compact[:-3]
        if prefix and not prefix.isdigit():
            return f"{prefix}-CAN"
    return ""


def _network_match_keys(network_name: str) -> List[str]:
    norm = normalize_can_network_name(network_name)
    if not norm:
        return []
    compact = re.sub(r"[^A-Z0-9]", "", norm.upper())
    keys = [compact]
    # 사용자 운용 정책: P-CAN == P1-CAN
    if compact == "P1CAN":
        keys.append("PCAN")
    return keys


def _candidate_network_tokens(text: str) -> List[str]:
    out: List[str] = []
    for m in _NETWORK_TOKEN_RE.finditer(str(text or "")):
        norm = normalize_can_network_name(m.group(1))
        if norm and norm not in out:
            out.append(norm)
    return out


def extract_can_network_mappings_from_text(text: str, source_label: str = "") -> Dict[str, Any]:
    """텍스트/파일명에서 CAN1~CAN4와 네트워크명 동시 등장 근거를 추출한다.

    추론은 하지 않는다. 같은 줄/짧은 문맥에 CANx(또는 CHx)와 명시적 XXX-CAN 토큰이
    함께 있을 때만 evidence로 인정한다. 동일 채널에 서로 다른 이름이 잡히면 conflict로 남긴다.
    """
    evidence: Dict[str, List[Dict[str, str]]] = {f"CAN{i}": [] for i in range(1, 5)}
    lines = str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")

    for line_no, line in enumerate(lines, start=1):
        if not line.strip():
            continue

        # 1) CAN1=P1-CAN / CAN1_P1-CAN_CAN2_M-CAN 같은 명시적 pair를 우선 추출한다.
        paired = []
        for m in _CHANNEL_NETWORK_PAIR_RE.finditer(line):
            ch = int(m.group(1))
            network = normalize_can_network_name(m.group(2))
            if network:
                paired.append((ch, network))
                can_name = f"CAN{ch}"
                item = {
                    "network": network,
                    "source": source_label or "text",
                    "line": str(line_no),
                    "evidence": line.strip()[:500],
                }
                if item not in evidence[can_name]:
                    evidence[can_name].append(item)
        if paired:
            continue

        # 2) 명시 pair가 없으면 한 줄에 채널 1개 + 네트워크 1개일 때만 근거로 인정한다.
        channels = set()
        for m in _CAN_LOGICAL_RE.finditer(line):
            channels.add(int(m.group(1)))
        for m in _CH_LOGICAL_RE.finditer(line):
            channels.add(int(m.group(1)))
        networks = _candidate_network_tokens(line)
        if len(channels) != 1 or len(networks) != 1:
            continue
        ch = next(iter(channels))
        network = networks[0]
        can_name = f"CAN{ch}"
        item = {
            "network": network,
            "source": source_label or "text",
            "line": str(line_no),
            "evidence": line.strip()[:500],
        }
        if item not in evidence[can_name]:
            evidence[can_name].append(item)

    mapping: Dict[str, str] = {}
    conflicts: Dict[str, List[str]] = {}
    for can_name, items in evidence.items():
        names = []
        for item in items:
            n = item.get("network", "")
            if n and n not in names:
                names.append(n)
        if len(names) == 1:
            mapping[can_name] = names[0]
        elif len(names) > 1:
            conflicts[can_name] = names

    return {
        "source": source_label,
        "mapping": mapping,
        "conflicts": conflicts,
        "evidence": evidence,
    }


def read_text_probe(path: str | Path, max_bytes: int = 5_000_000, max_lines: int = 1200) -> str:
    """ASC/CANoe cfg 등에서 네트워크명 탐색에 필요한 범위만 best-effort로 읽는다."""
    p = Path(path)
    if not p.is_file():
        return ""
    try:
        raw = p.read_bytes()[: max(1, int(max_bytes))]
    except Exception:
        return ""

    candidates: List[str] = []
    for enc in ("utf-8-sig", "utf-16", "cp949", "cp1252", "latin1"):
        try:
            decoded = raw.decode(enc, errors="ignore")
            if decoded and decoded not in candidates:
                candidates.append(decoded)
        except Exception:
            pass
    if not candidates:
        return ""

    # CAN/Network 관련 문자가 가장 많이 살아있는 decode 결과를 선택한다.
    def score(t: str) -> int:
        up = t.upper()
        return up.count("CAN1") + up.count("CAN2") + up.count("CAN3") + up.count("CAN4") + up.count("-CAN")
    text = max(candidates, key=score)
    if max_lines > 0:
        text = "\n".join(text.splitlines()[:max_lines])
    return text


def find_dbc_candidates_for_network(dbc_dir: str | Path, network_name: str) -> List[Path]:
    """DBC 폴더에서 네트워크명과 파일명이 명시적으로 일치하는 후보만 반환한다."""
    folder = Path(dbc_dir)
    if not folder.is_dir():
        return []
    keys = _network_match_keys(network_name)
    if not keys:
        return []
    found: List[Path] = []
    try:
        dbcs = sorted((x for x in folder.rglob("*.dbc") if x.is_file()), key=lambda x: str(x).lower())
    except Exception:
        return []
    for dbc in dbcs:
        stem_compact = re.sub(r"[^A-Z0-9]", "", dbc.stem.upper())
        if any(key and key in stem_compact for key in keys):
            found.append(dbc)
    return found


def _active_canoe_configuration_path_readonly() -> Dict[str, Any]:
    """GetActiveObject only로 현재 Configuration.FullName만 best-effort 조회한다."""
    out: Dict[str, Any] = {"success": False, "configuration": "", "error": ""}
    if not sys.platform.startswith("win"):
        out["error"] = "Windows가 아님"
        return out
    try:
        _ensure_com_initialized()
        import win32com.client
        app = win32com.client.GetActiveObject("CANoe.Application")
        out["configuration"] = str(app.Configuration.FullName)
        out["success"] = bool(out["configuration"])
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
    return out


def auto_map_dbc_by_network_sources(
    dbc_dir: str | Path,
    source_paths: Optional[List[str | Path]] = None,
    source_texts: Optional[List[Tuple[str, str]]] = None,
    include_active_canoe_config: bool = True,
) -> Dict[str, Any]:
    """네트워크명 근거를 수집해 CAN1~CAN3 DBC 자동 매핑 후보를 만든다.

    안전 정책:
    - DBC 내용 유사도나 Message 겹침으로 네트워크를 추정하지 않는다.
    - 동일 CAN에 서로 다른 네트워크 근거가 있으면 conflict 처리한다.
    - DBC 파일 후보가 정확히 1개일 때만 selected에 넣는다.
    - 0개/복수 후보는 unresolved로 남긴다.
    """
    folder = Path(dbc_dir)
    result: Dict[str, Any] = {
        "dbc_dir": str(folder),
        "network_by_can": {},
        "evidence_by_can": {f"CAN{i}": [] for i in range(1, 4)},
        "conflicts": {},
        "dbc_candidates_by_can": {},
        "selected_dbc_by_can": {},
        "unresolved": {},
        "sources": [],
        "active_canoe_config": {},
    }
    if not folder.is_dir():
        result["unresolved"]["GLOBAL"] = f"DBC 자동 설정 폴더가 유효하지 않음: {folder}"
        return result

    all_source_texts: List[Tuple[str, str]] = list(source_texts or [])
    for raw_path in source_paths or []:
        p = Path(raw_path)
        if not p.is_file():
            continue
        label = str(p)
        # 파일명 자체에도 CAN1/P1-CAN 같은 명시 정보가 있을 수 있어 함께 검사한다.
        all_source_texts.append((f"filename:{p.name}", p.name))
        text = read_text_probe(p)
        if text:
            all_source_texts.append((label, text))

    if include_active_canoe_config:
        active = _active_canoe_configuration_path_readonly()
        result["active_canoe_config"] = active
        cfg = str(active.get("configuration") or "").strip()
        if cfg:
            p = Path(cfg)
            all_source_texts.append((f"configuration-filename:{p.name}", p.name))
            text = read_text_probe(p)
            if text:
                all_source_texts.append((f"configuration:{p}", text))

    aggregate: Dict[str, List[Dict[str, str]]] = {f"CAN{i}": [] for i in range(1, 4)}
    for label, text in all_source_texts:
        parsed = extract_can_network_mappings_from_text(text, source_label=label)
        result["sources"].append({
            "label": label,
            "mapping": parsed.get("mapping") or {},
            "conflicts": parsed.get("conflicts") or {},
        })
        for can_name in aggregate:
            for item in (parsed.get("evidence") or {}).get(can_name, []) or []:
                if item not in aggregate[can_name]:
                    aggregate[can_name].append(item)

    for can_name, items in aggregate.items():
        names: List[str] = []
        for item in items:
            name = normalize_can_network_name(item.get("network"))
            if name and name not in names:
                names.append(name)
        result["evidence_by_can"][can_name] = items
        if len(names) == 1:
            result["network_by_can"][can_name] = names[0]
        elif len(names) > 1:
            result["conflicts"][can_name] = names
            result["unresolved"][can_name] = "네트워크명 근거 충돌: " + ", ".join(names)
        else:
            result["unresolved"][can_name] = "CAN 네트워크명을 명시적으로 식별할 근거 없음"

    for can_name, network in result["network_by_can"].items():
        if can_name in result["conflicts"]:
            continue
        candidates = find_dbc_candidates_for_network(folder, network)
        result["dbc_candidates_by_can"][can_name] = [str(x) for x in candidates]
        if len(candidates) == 1:
            result["selected_dbc_by_can"][can_name] = str(candidates[0])
            result["unresolved"].pop(can_name, None)
        elif len(candidates) == 0:
            result["unresolved"][can_name] = f"{network} 일치 DBC 후보 없음"
        else:
            result["unresolved"][can_name] = f"{network} 일치 DBC 후보 {len(candidates)}개 - 자동 선택 안 함"

    return result


# =========================================================
# CANoe COM Client
# =========================================================
def _ensure_com_initialized() -> None:
    """현재 스레드에서 pywin32 COM 사용 준비."""
    if not sys.platform.startswith("win"):
        raise RuntimeError("CANoe COM 연결은 Windows 환경에서만 사용할 수 있습니다.")

    if getattr(_COM_THREAD_STATE, "initialized", False):
        return

    try:
        import pythoncom
    except Exception as e:
        raise ImportError("pywin32가 필요합니다. py -m pip install pywin32") from e

    pythoncom.CoInitialize()
    _COM_THREAD_STATE.initialized = True


class CANoeClient:
    """
    CANoe COM 연결 래퍼.

    rev53 연결 정책:
    - GetActiveObject("CANoe.Application")만 사용한다.
    - 실행 중인 CANoe COM 객체를 찾지 못하면 즉시 연결 실패로 처리한다.
    - 기본적으로 CANoe 10/15/기타 버전을 제한하지 않는다.
    - 특정 버전 제한이 필요하면 connect(expected_version_keyword=..., expected_exe_keyword=...)를 명시한다.
    """

    DEFAULT_EXPECTED_VERSION_KEYWORD = None
    DEFAULT_EXPECTED_EXE_KEYWORD = None

    def __init__(self, bus_name: str = "CAN"):
        self.bus_name = (bus_name or "CAN").strip() or "CAN"
        self.app = None
        self._connected_by = ""
        self._app_version = ""
        self._app_fullname = ""
        self._cfg_fullname = ""

    def _read_application_info(self) -> Dict[str, str]:
        version = ""
        fullname = ""
        cfg_fullname = ""
        if self.app is not None:
            try:
                version = str(self.app.Version)
            except Exception:
                pass
            try:
                fullname = str(self.app.FullName)
            except Exception:
                pass
            try:
                cfg_fullname = str(self.app.Configuration.FullName)
            except Exception:
                pass
        self._app_version = version
        self._app_fullname = fullname
        self._cfg_fullname = cfg_fullname
        return {
            "connected_by": self._connected_by,
            "version": version,
            "fullname": fullname,
            "configuration": cfg_fullname,
        }

    def get_application_info(self) -> Dict[str, str]:
        return self._read_application_info()

    def connect(
        self,
        expected_version_keyword: Optional[str] = None,
        expected_exe_keyword: Optional[str] = None,
        expected_cfg_path: Optional[str | Path] = None,
    ) -> "CANoeClient":
        """실행 중인 CANoe COM 객체에 GetActiveObject only로 연결한다."""
        _ensure_com_initialized()

        try:
            import win32com.client
        except Exception as e:
            raise ImportError("pywin32가 필요합니다. py -m pip install pywin32") from e

        try:
            self.app = win32com.client.GetActiveObject("CANoe.Application")
            self._connected_by = "GetActiveObject"
        except Exception as e:
            self.app = None
            raise RuntimeError(
                "실행 중인 CANoe 인스턴스를 GetActiveObject로 찾지 못했습니다.\n"
                "사용하려는 CANoe를 먼저 실행하고 Configuration을 연 뒤 다시 시도하세요.\n"
                "Python과 CANoe의 관리자 권한 수준도 동일해야 합니다.\n"
                f"원인: {type(e).__name__}: {e}"
            ) from e

        expected_version_keyword = (
            expected_version_keyword
            if expected_version_keyword is not None
            else self.DEFAULT_EXPECTED_VERSION_KEYWORD
        )
        expected_exe_keyword = (
            expected_exe_keyword
            if expected_exe_keyword is not None
            else self.DEFAULT_EXPECTED_EXE_KEYWORD
        )

        self._validate_application(
            expected_version_keyword=expected_version_keyword,
            expected_exe_keyword=expected_exe_keyword,
            expected_cfg_path=expected_cfg_path,
        )
        return self

    def _validate_application(
        self,
        expected_version_keyword: Optional[str] = None,
        expected_exe_keyword: Optional[str] = None,
        expected_cfg_path: Optional[str | Path] = None,
    ) -> None:
        if self.app is None:
            raise RuntimeError("CANoe COM 객체가 없습니다.")

        try:
            measurement = self.app.Measurement
            _ = bool(measurement.Running)
        except Exception as e:
            self.app = None
            raise RuntimeError(
                "CANoe COM 객체는 찾았지만 Measurement 상태를 읽지 못했습니다.\n"
                "CANoe가 정상 실행 중인지, Python/CANoe 관리자 권한이 서로 다른지, "
                "CANoe Configuration이 열린 상태인지 확인하세요.\n"
                f"원인: {type(e).__name__}: {e}"
            ) from e

        info = self._read_application_info()
        version = info.get("version", "")
        fullname = info.get("fullname", "")
        cfg_fullname = info.get("configuration", "")

        if expected_version_keyword and expected_version_keyword not in version:
            self.app = None
            raise RuntimeError(
                "CANoe 버전이 예상과 다릅니다.\n"
                f"예상 버전 키워드: {expected_version_keyword}\n"
                f"실제 Version: {version or '-'}\n"
                f"실제 실행 파일: {fullname or '-'}\n"
                f"현재 Configuration: {cfg_fullname or '-'}\n"
                "사용하려는 CANoe 버전과 Configuration을 확인하세요."
            )

        if expected_exe_keyword and expected_exe_keyword.lower() not in (fullname or "").lower():
            self.app = None
            raise RuntimeError(
                "CANoe 실행 파일 경로가 예상과 다릅니다.\n"
                f"예상 경로 키워드: {expected_exe_keyword}\n"
                f"실제 실행 파일: {fullname or '-'}\n"
                f"실제 Version: {version or '-'}\n"
                f"현재 Configuration: {cfg_fullname or '-'}\n"
                "잘못된 CANoe 버전에 연결되는 것을 방지하기 위해 중단합니다."
            )

        if expected_cfg_path:
            try:
                expected_cfg_norm = str(Path(expected_cfg_path).resolve()).lower()
                actual_cfg_norm = str(Path(cfg_fullname).resolve()).lower()
            except Exception:
                expected_cfg_norm = str(expected_cfg_path).strip().lower()
                actual_cfg_norm = str(cfg_fullname).strip().lower()
            if expected_cfg_norm != actual_cfg_norm:
                self.app = None
                raise RuntimeError(
                    "CANoe Configuration이 예상과 다릅니다.\n"
                    f"예상 cfg: {expected_cfg_path}\n"
                    f"실제 cfg: {cfg_fullname or '-'}"
                )

    def is_connected(self) -> bool:
        if self.app is None:
            return False
        try:
            _ = bool(self.app.Measurement.Running)
            return True
        except Exception:
            self.app = None
            return False

    def is_measurement_running(self) -> bool:
        if not self.is_connected():
            raise RuntimeError("CANoe 연결이 없습니다.")
        return bool(self.app.Measurement.Running)

    def start_measurement(self, wait_sec: float = 0.0, start_timeout_sec: float = 5.0) -> None:
        if not self.is_connected():
            raise RuntimeError("CANoe 연결이 없습니다.")
        measurement = self.app.Measurement
        if not bool(measurement.Running):
            measurement.Start()
            deadline = time.time() + max(0.5, float(start_timeout_sec))
            while time.time() <= deadline:
                try:
                    if bool(measurement.Running):
                        break
                except Exception:
                    pass
                time.sleep(0.1)
            if not bool(measurement.Running):
                raise RuntimeError("CANoe Measurement 시작 요청 후에도 Running=True가 되지 않았습니다.")
        if wait_sec and float(wait_sec) > 0:
            time.sleep(float(wait_sec))

    def stop_measurement(self, stop_timeout_sec: float = 5.0) -> None:
        if not self.is_connected():
            raise RuntimeError("CANoe 연결이 없습니다.")
        measurement = self.app.Measurement
        if bool(measurement.Running):
            measurement.Stop()
            deadline = time.time() + max(0.5, float(stop_timeout_sec))
            while time.time() <= deadline:
                try:
                    if not bool(measurement.Running):
                        break
                except Exception:
                    break
                time.sleep(0.1)

    def _bus_name_candidates(self) -> List[str]:
        raw = (self.bus_name or "CAN").strip()
        candidates: List[str] = []
        for name in (raw, raw.replace(" ", ""), "CAN"):
            if name and name not in candidates:
                candidates.append(name)
        return candidates

    def get_signal_value(self, channel: int, message_name: str, signal_name: str) -> Any:
        if not self.is_connected():
            raise RuntimeError("CANoe 연결이 없습니다.")

        last_error = None
        ch = int(channel)
        msg = str(message_name).strip()
        sig = str(signal_name).strip()

        for bus_name in self._bus_name_candidates():
            try:
                bus = self.app.GetBus(bus_name)
                signal = bus.GetSignal(ch, msg, sig)
                return signal.Value
            except Exception as e:
                last_error = e
                continue

        raise RuntimeError(
            f"Signal 읽기 실패: bus 후보={self._bus_name_candidates()}, channel={ch}, "
            f"message={msg}, signal={sig}, 원인={last_error}"
        )


def normalize_value(value: Any) -> Any:
    if value is None:
        return None

    if isinstance(value, bool):
        return int(value)

    if isinstance(value, int):
        return value

    if isinstance(value, float):
        if math.isfinite(value) and value.is_integer():
            return int(value)
        return value

    s = str(value).strip()
    if not s:
        return None

    s = s.replace(" ", "")

    try:
        if _HEX_RE.match(s):
            return int(s, 16)
        if _INT_RE.match(s):
            return int(s, 10)
        if _FLOAT_RE.match(s):
            f = float(s)
            if f.is_integer():
                return int(f)
            return f
    except Exception:
        pass

    return s


def values_equal(expected: Any, observed: Any) -> bool:
    e = normalize_value(expected)
    o = normalize_value(observed)

    if isinstance(e, float) or isinstance(o, float):
        try:
            return abs(float(e) - float(o)) < 1e-9
        except Exception:
            return False

    return e == o


def split_multiline_cell(value: Any) -> List[str]:
    if value is None:
        return []
    text = str(value).replace("\r\n", "\n").replace("\r", "\n")
    return [line.strip() for line in text.split("\n") if line.strip()]


def join_expectation_field(expectations: List["SignalExpectation"], field_name: str) -> str:
    out = []
    for exp in expectations:
        out.append(str(getattr(exp, field_name, "") or ""))
    return "\n".join(out)


# =========================================================
# 신호 조건 데이터 구조
# =========================================================
@dataclass
class SignalExpectation:
    message: str
    signal: str
    expected_value_raw: str

    @property
    def expected_value_norm(self):
        return normalize_value(self.expected_value_raw)


@dataclass
class LogReviewSample:
    timestamp: float
    value: Any


@dataclass
class LogReviewOutcome:
    status: str
    message: str
    source: str = "log_review"
    observed_value_raw: Optional[Any] = None
    observed_value_norm: Optional[Any] = None
    observed_time: Optional[float] = None
    elapsed_sec: Optional[float] = None
    asc_path: Optional[str] = None
    matched_channel: Optional[int] = None
    matched_frame_id: Optional[int] = None
    samples: List[Tuple[float, Any]] = field(default_factory=list)


@dataclass
class SingleExpectationCheck:
    expectation: SignalExpectation
    status: str = "대기중"
    observed_value_raw: Optional[Any] = None
    observed_value_norm: Optional[Any] = None
    observed_time: Optional[float] = None
    observed_channel: Optional[int] = None
    message: str = ""
    samples: List[Tuple[float, Any]] = field(default_factory=list)


@dataclass
class OracleCondition:
    row_index: int
    tc_no: str
    subcategory: str
    tc_content: str
    tc_expected_result: str

    input_conditions: List[SignalExpectation] = field(default_factory=list)
    output_conditions: List[SignalExpectation] = field(default_factory=list)

    judge_mode: str = "once"
    timeout_sec: float = 30.0
    use_yn: str = "Y"
    note: str = ""
    condition_id: str = ""
    tc_logic: str = "all"
    revision: str = ""

    @property
    def display_id(self) -> str:
        if self.condition_id:
            return self.condition_id
        return f"{self.tc_no}-{self.row_index}"

    @property
    def enabled(self) -> bool:
        s = str(self.use_yn or "Y").strip().upper()
        return s not in ("N", "NO", "FALSE", "0", "미사용")


@dataclass
class OracleRowLoadResult:
    row_index: int
    tc_no: str = ""
    subcategory: str = ""
    tc_content: str = ""
    tc_expected_result: str = ""

    input_message: str = ""
    input_signal: str = ""
    input_expected_value_raw: str = ""

    output_message_raw: str = ""
    output_signal_raw: str = ""
    output_expected_value_raw: str = ""

    is_valid: bool = False
    status: str = "ERROR"
    error_reason: str = ""
    condition: Optional[OracleCondition] = None


@dataclass
class CheckResult:
    condition: OracleCondition
    status: str = "대기중"
    source: str = ""
    started_at: Optional[_dt.datetime] = None
    ended_at: Optional[_dt.datetime] = None
    elapsed_sec: Optional[float] = None
    message: str = ""

    input_results: List[SingleExpectationCheck] = field(default_factory=list)
    output_results: List[SingleExpectationCheck] = field(default_factory=list)

    observed_value_raw: Optional[Any] = None
    observed_value_norm: Optional[Any] = None
    observed_time: Optional[float] = None
    observed_channel: Optional[int] = None
    samples: List[Tuple[float, Any]] = field(default_factory=list)

    def to_row(self) -> List[Any]:
        c = self.condition

        return [
            c.tc_no,
            c.subcategory,
            c.tc_content,
            c.tc_expected_result,
            join_expectation_field(c.input_conditions, "message"),
            join_expectation_field(c.input_conditions, "signal"),
            join_expectation_field(c.input_conditions, "expected_value_raw"),
            join_expectation_field(c.output_conditions, "message"),
            join_expectation_field(c.output_conditions, "signal"),
            join_expectation_field(c.output_conditions, "expected_value_raw"),
            c.judge_mode,
            c.timeout_sec,
            c.use_yn,
            c.note,
            c.condition_id,
            c.tc_logic,
            c.revision,
            self.status,
            self.source,
            self.observed_value_raw,
            self.observed_time,
            self.observed_channel,
            self.elapsed_sec,
            self.message,
        ]


@dataclass
class FinalCheckResult:
    condition: OracleCondition
    realtime_result: Optional[CheckResult] = None
    log_result: Optional[CheckResult] = None
    final_status: str = "대기중"
    final_message: str = ""
    final_observed_value_raw: Optional[Any] = None
    final_observed_value_norm: Optional[Any] = None
    final_observed_time: Optional[float] = None
    final_observed_channel: Optional[int] = None
    used_log_path: Optional[str] = None
    started_at: Optional[_dt.datetime] = None
    ended_at: Optional[_dt.datetime] = None
    elapsed_sec: Optional[float] = None

    def to_row(self) -> List[Any]:
        c = self.condition

        return [
            c.tc_no,
            c.subcategory,
            c.tc_content,
            c.tc_expected_result,
            join_expectation_field(c.input_conditions, "message"),
            join_expectation_field(c.input_conditions, "signal"),
            join_expectation_field(c.input_conditions, "expected_value_raw"),
            join_expectation_field(c.output_conditions, "message"),
            join_expectation_field(c.output_conditions, "signal"),
            join_expectation_field(c.output_conditions, "expected_value_raw"),
            c.judge_mode,
            c.timeout_sec,
            c.use_yn,
            c.note,
            c.condition_id,
            c.tc_logic,
            c.revision,
            self.realtime_result.status if self.realtime_result else "",
            self.log_result.status if self.log_result else "",
            self.final_status,
            self.final_observed_value_raw,
            self.final_observed_time,
            self.final_observed_channel,
            self.used_log_path or "",
            self.final_message,
        ]


# =========================================================
# Excel Oracle 로딩
# =========================================================
DEFAULT_COLUMN_MAP = {
    "tc_no": 1,
    "subcategory": 2,
    "tc_content": 3,
    "tc_expected_result": 4,
    "input_message": 5,
    "input_signal": 6,
    "input_expected_value": 7,
    "output_message": 8,
    "output_signal": 9,
    "output_expected_value": 10,
    "judge_mode": 11,
    "timeout_sec": 12,
    "use_yn": 13,
    "note": 14,
    "condition_id": 15,
    "tc_logic": 16,
    "revision": 17,
}


def _cell_text(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _float_or_default(v: Any, default: float) -> float:
    s = _cell_text(v)
    if not s:
        return default
    try:
        return float(s)
    except Exception:
        return default


def list_excel_sheets(excel_path: str | Path) -> List[str]:
    from openpyxl import load_workbook

    wb = load_workbook(excel_path, read_only=True, data_only=True)
    try:
        return list(wb.sheetnames)
    finally:
        wb.close()


def load_oracle_conditions_with_diagnostics(
    excel_path: str | Path,
    sheet_name: str,
    include_disabled: bool = False,
    default_timeout_sec: float = 30.0,
) -> List[OracleRowLoadResult]:
    from openpyxl import load_workbook

    excel_path = Path(excel_path)
    if not excel_path.exists():
        raise FileNotFoundError(f"Oracle Excel 파일을 찾지 못했습니다: {excel_path}")

    wb = load_workbook(excel_path, read_only=True, data_only=True)
    try:
        if sheet_name not in wb.sheetnames:
            raise ValueError(f"시트를 찾지 못했습니다: {sheet_name}. 사용 가능: {wb.sheetnames}")

        ws = wb[sheet_name]
        start_row = 2

        results: List[OracleRowLoadResult] = []

        last_tc_no = ""
        last_subcategory = ""
        last_tc_content = ""
        last_tc_expected_result = ""

        for r in range(start_row, ws.max_row + 1):
            tc_no = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["tc_no"]).value) or last_tc_no
            subcategory = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["subcategory"]).value) or last_subcategory
            tc_content = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["tc_content"]).value) or last_tc_content
            tc_expected_result = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["tc_expected_result"]).value) or last_tc_expected_result

            input_message_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["input_message"]).value)
            input_signal_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["input_signal"]).value)
            input_expected_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["input_expected_value"]).value)

            output_message_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["output_message"]).value)
            output_signal_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["output_signal"]).value)
            output_expected_raw = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["output_expected_value"]).value)

            judge_mode = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["judge_mode"]).value) or "once"
            timeout_sec = _float_or_default(ws.cell(r, DEFAULT_COLUMN_MAP["timeout_sec"]).value, default_timeout_sec)
            use_yn = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["use_yn"]).value) or "Y"
            note = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["note"]).value)
            condition_id = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["condition_id"]).value)
            tc_logic = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["tc_logic"]).value) or "all"
            revision = _cell_text(ws.cell(r, DEFAULT_COLUMN_MAP["revision"]).value)

            if tc_no:
                last_tc_no = tc_no
            if subcategory:
                last_subcategory = subcategory
            if tc_content:
                last_tc_content = tc_content
            if tc_expected_result:
                last_tc_expected_result = tc_expected_result

            if not any([
                tc_no, subcategory, tc_content, tc_expected_result,
                input_message_raw, input_signal_raw, input_expected_raw,
                output_message_raw, output_signal_raw, output_expected_raw
            ]):
                continue

            errors: List[str] = []

            in_msgs = split_multiline_cell(input_message_raw)
            in_sigs = split_multiline_cell(input_signal_raw)
            in_exps = split_multiline_cell(input_expected_raw)

            if not in_msgs:
                errors.append("입력 Message 비어 있음")
            if not in_sigs:
                errors.append("입력 Signal 비어 있음")
            if not in_exps:
                errors.append("입력 Expected Value 비어 있음")

            if in_msgs or in_sigs or in_exps:
                if not (len(in_msgs) == len(in_sigs) == len(in_exps)):
                    errors.append("입력 Message/Signal/Expected Value 줄 수가 서로 다름")

            out_msgs = split_multiline_cell(output_message_raw)
            out_sigs = split_multiline_cell(output_signal_raw)
            out_exps = split_multiline_cell(output_expected_raw)

            if not out_msgs:
                errors.append("출력 Message 비어 있음")
            if not out_sigs:
                errors.append("출력 Signal 비어 있음")
            if not out_exps:
                errors.append("출력 Expected Value 비어 있음")

            if out_msgs or out_sigs or out_exps:
                if not (len(out_msgs) == len(out_sigs) == len(out_exps)):
                    errors.append("출력 Message/Signal/Expected Value 줄 수가 서로 다름")

            input_conditions: List[SignalExpectation] = []
            output_conditions: List[SignalExpectation] = []

            if not errors:
                for m, s, e in zip(in_msgs, in_sigs, in_exps):
                    input_conditions.append(
                        SignalExpectation(message=m, signal=s, expected_value_raw=e)
                    )

                for m, s, e in zip(out_msgs, out_sigs, out_exps):
                    output_conditions.append(
                        SignalExpectation(message=m, signal=s, expected_value_raw=e)
                    )

                if not input_conditions:
                    errors.append("입력 조건이 1개 이상 필요함")
                if not output_conditions:
                    errors.append("출력 조건이 1개 이상 필요함")

            if errors:
                results.append(
                    OracleRowLoadResult(
                        row_index=r,
                        tc_no=tc_no,
                        subcategory=subcategory,
                        tc_content=tc_content,
                        tc_expected_result=tc_expected_result,
                        input_message=input_message_raw,
                        input_signal=input_signal_raw,
                        input_expected_value_raw=input_expected_raw,
                        output_message_raw=output_message_raw,
                        output_signal_raw=output_signal_raw,
                        output_expected_value_raw=output_expected_raw,
                        is_valid=False,
                        status="ERROR",
                        error_reason=" / ".join(errors),
                        condition=None,
                    )
                )
                continue

            cond = OracleCondition(
                row_index=r,
                tc_no=tc_no,
                subcategory=subcategory,
                tc_content=tc_content,
                tc_expected_result=tc_expected_result,
                input_conditions=input_conditions,
                output_conditions=output_conditions,
                judge_mode=judge_mode,
                timeout_sec=timeout_sec,
                use_yn=use_yn,
                note=note,
                condition_id=condition_id,
                tc_logic=tc_logic,
                revision=revision,
            )

            if cond.enabled or include_disabled:
                results.append(
                    OracleRowLoadResult(
                        row_index=r,
                        tc_no=tc_no,
                        subcategory=subcategory,
                        tc_content=tc_content,
                        tc_expected_result=tc_expected_result,
                        input_message=input_message_raw,
                        input_signal=input_signal_raw,
                        input_expected_value_raw=input_expected_raw,
                        output_message_raw=output_message_raw,
                        output_signal_raw=output_signal_raw,
                        output_expected_value_raw=output_expected_raw,
                        is_valid=True,
                        status="Ready",
                        error_reason="",
                        condition=cond,
                    )
                )

        return results
    finally:
        wb.close()


def load_oracle_conditions(
    excel_path: str | Path,
    sheet_name: str,
    include_disabled: bool = False,
    default_timeout_sec: float = 30.0,
) -> List[OracleCondition]:
    rows = load_oracle_conditions_with_diagnostics(
        excel_path=excel_path,
        sheet_name=sheet_name,
        include_disabled=include_disabled,
        default_timeout_sec=default_timeout_sec,
    )
    return [x.condition for x in rows if x.is_valid and x.condition is not None]


# =========================================================
# 버스/채널 probe 유틸
# =========================================================
def build_default_bus_channel_candidates(channels: List[int]) -> List[Tuple[str, int]]:
    normalized = []
    seen = set()
    for ch in channels:
        try:
            ch_int = int(ch)
        except Exception:
            continue
        if ch_int not in seen:
            seen.add(ch_int)
            normalized.append(ch_int)

    # 실제 진단 결과 GetBus("CAN")만 유효했던 환경을 기준으로,
    # bus 이름은 CAN으로 고정하고 채널 번호만 바꿔 probe한다.
    return [("CAN", ch) for ch in normalized]


def debug_probe_signal(
    expectation: SignalExpectation,
    bus_channel_candidates: List[Tuple[str, int]],
) -> List[Tuple[str, int, bool, Optional[Any], Optional[str]]]:
    results = []
    client_cache: Dict[str, CANoeClient] = {}

    for bus_name, ch in bus_channel_candidates:
        client = client_cache.get(bus_name)
        if client is None:
            try:
                client = CANoeClient(bus_name=bus_name).connect()
                client_cache[bus_name] = client
            except Exception as e:
                msg = f"connect fail: {type(e).__name__}: {e}"
                results.append((bus_name, ch, False, None, msg))
                continue

        try:
            value = client.get_signal_value(ch, expectation.message, expectation.signal)
            results.append((bus_name, ch, True, value, None))
        except Exception as e:
            msg = f"{type(e).__name__}: {e}"
            results.append((bus_name, ch, False, None, msg))

    return results


# =========================================================
# 로그 자동 탐색 유틸
# =========================================================
def find_latest_log_file(
    log_dir: str | Path,
    after_ts: Optional[float] = None,
    wait_timeout: float = 5.0,
    poll_interval: float = 0.5,
    exts: Tuple[str, ...] = (".blf", ".asc"),
) -> Optional[Path]:
    folder = Path(log_dir)
    if not folder.exists():
        raise FileNotFoundError(f"로그 폴더를 찾지 못했습니다: {folder}")
    if not folder.is_dir():
        raise NotADirectoryError(f"로그 폴더가 아닙니다: {folder}")

    deadline = time.time() + max(0.1, float(wait_timeout))

    while time.time() <= deadline:
        candidates: List[Tuple[float, Path]] = []
        for ext in exts:
            for p in folder.glob(f"*{ext}"):
                try:
                    mtime = p.stat().st_mtime
                    if after_ts is None or mtime >= after_ts:
                        candidates.append((mtime, p))
                except FileNotFoundError:
                    pass

        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            return candidates[0][1]

        time.sleep(max(0.1, float(poll_interval)))

    return None


def wait_until_file_stable(
    path: str | Path,
    stable_sec: float = 1.0,
    timeout: float = 5.0,
    poll_interval: float = 0.2,
) -> bool:
    p = Path(path)
    deadline = time.time() + max(0.1, float(timeout))
    last_size = None
    last_change = None

    while time.time() <= deadline:
        if not p.exists():
            time.sleep(poll_interval)
            continue

        try:
            size = p.stat().st_size
        except FileNotFoundError:
            time.sleep(poll_interval)
            continue

        if last_size is None or size != last_size:
            last_size = size
            last_change = time.time()
        else:
            if last_change is not None and (time.time() - last_change) >= stable_sec:
                return True

        time.sleep(poll_interval)

    return p.exists()


# =========================================================
# BLF -> ASC
# =========================================================
def convert_blf_to_asc(input_blf: str | Path, output_asc: Optional[str | Path] = None) -> Path:
    try:
        import can
    except Exception as e:
        raise ImportError("python-can이 필요합니다. py -m pip install python-can") from e

    input_blf = Path(input_blf)
    if not input_blf.exists():
        raise FileNotFoundError(f"BLF 파일을 찾지 못했습니다: {input_blf}")

    if output_asc is None:
        output_asc = input_blf.with_suffix(".asc")
    output_asc = Path(output_asc)

    with can.BLFReader(str(input_blf)) as reader:
        with can.ASCWriter(str(output_asc)) as writer:
            for msg in reader:
                writer.on_message_received(msg)

    return output_asc


def ensure_asc_path(log_path: str | Path) -> Path:
    p = Path(log_path)
    if not p.exists():
        raise FileNotFoundError(f"로그 파일을 찾지 못했습니다: {p}")

    ext = p.suffix.lower()

    if ext == ".asc":
        return p
    if ext == ".blf":
        return convert_blf_to_asc(p)

    raise ValueError(f"지원하지 않는 로그 확장자입니다: {ext} (허용: .asc, .blf)")


# =========================================================
# ASC Parser
# =========================================================
HEAD_RE = re.compile(
    r"^\s*(?P<time>\d+\.\d+)\s+(?P<bus>CANFD|CAN)\s+(?P<ch>\d+)\s+(?P<dir>Rx|Tx)\s+(?P<id>[0-9A-Fa-f]+x?)\s+",
    re.IGNORECASE,
)
HEXBYTE_RE = re.compile(r"^[0-9A-Fa-f]{2}$")
BASE_RE = re.compile(r"\bbase\s+(hex|dec)\b", re.IGNORECASE)
DATA_MARKERS = {"a", "b", "c", "d"}


def detect_asc_base(path: str | Path, max_lines: int = 200) -> int:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f):
            if i >= max_lines:
                break
            m = BASE_RE.search(line)
            if m:
                return 16 if m.group(1).lower() == "hex" else 10
    return 16


def parse_can_id(id_str: str, default_base: int) -> int:
    s = id_str.strip().lower()

    if s.endswith("x"):
        return int(s[:-1], 16)
    if s.startswith("0x"):
        return int(s, 16)
    if re.search(r"[a-f]", s):
        return int(s, 16)

    return int(s, default_base)


def _is_uint_token(tok: str) -> bool:
    return bool(re.fullmatch(r"\d+", tok))


def _is_hexbyte_token(tok: str) -> bool:
    return bool(HEXBYTE_RE.fullmatch(tok))


def _collect_hexbytes(tokens: List[str], start_idx: int) -> List[str]:
    out: List[str] = []
    for tok in tokens[start_idx:]:
        if _is_hexbyte_token(tok):
            out.append(tok)
        else:
            if out:
                break
    return out


def _try_marker_mode(tokens: List[str]) -> Tuple[bool, Optional[int], List[str]]:
    for i, tok in enumerate(tokens):
        if tok.lower() in DATA_MARKERS and i + 1 < len(tokens) and _is_uint_token(tokens[i + 1]):
            length = int(tokens[i + 1])
            if not (0 <= length <= 64):
                return False, None, []

            data_tokens = _collect_hexbytes(tokens, i + 2)
            if len(data_tokens) < length:
                return False, length, data_tokens

            return True, length, data_tokens[:length]

    return False, None, []


def _try_numeric_head_mode(tokens: List[str]) -> Tuple[bool, Optional[int], List[str]]:
    for i, tok in enumerate(tokens):
        if not _is_uint_token(tok):
            continue

        length = int(tok)
        if not (0 <= length <= 64):
            continue

        data_tokens = _collect_hexbytes(tokens, i + 1)
        if len(data_tokens) >= length:
            return True, length, data_tokens[:length]

    return False, None, []


def _parse_vector_payload_tokens(tokens: List[str]) -> Tuple[bool, Optional[int], List[str]]:
    ok, length, data_tokens = _try_marker_mode(tokens)
    if ok:
        return ok, length, data_tokens

    ok, length, data_tokens = _try_numeric_head_mode(tokens)
    if ok:
        return ok, length, data_tokens

    return False, None, []


def read_frames_from_asc(path: str | Path):
    default_base = detect_asc_base(path)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            m = HEAD_RE.match(line)
            if not m:
                continue

            direction = m.group("dir")
            if direction.lower() != "rx":
                continue

            t = float(m.group("time"))
            ch = int(m.group("ch"))
            can_id = parse_can_id(m.group("id"), default_base)

            rest = line[m.end():].strip()
            tokens = rest.split()

            ok, length, data_tokens = _parse_vector_payload_tokens(tokens)
            if not ok or length is None:
                continue

            if len(data_tokens) < length:
                continue

            try:
                data = bytes(int(b, 16) for b in data_tokens[:length])
            except Exception:
                continue

            yield t, ch, can_id, data


# =========================================================
# DBC 로드
# =========================================================
def load_dbc_map(dbc_path_by_channel: Dict[int, str | Path]):
    try:
        import cantools
    except Exception as e:
        raise ImportError("cantools가 필요합니다. py -m pip install cantools") from e

    db_by_ch = {}
    for ch, dbc_path in dbc_path_by_channel.items():
        p = Path(dbc_path)
        if not p.exists():
            continue
        db_by_ch[int(ch)] = cantools.database.load_file(str(p))

    return db_by_ch


def lookup_dbc_choice_text(
    db_by_ch: Dict[int, Any],
    message_name: str,
    signal_name: str,
    raw_value: Any,
    max_len: int = 24,
) -> str:
    """DBC choice/value table에서 Expected Value의 표시명을 찾는다.

    예: expected=0x01, DBC choice={1: "up"}이면 "up" 반환.
    찾지 못하거나 cantools/DBC 구조가 맞지 않으면 "-"를 반환한다.
    """
    try:
        msg_name = str(message_name or "").strip()
        sig_name = str(signal_name or "").strip()
        if not msg_name or not sig_name or not db_by_ch:
            return "-"

        norm = normalize_value(raw_value)
        candidates: List[Any] = []
        if norm is not None:
            candidates.append(norm)
            try:
                f = float(norm)
                if math.isfinite(f) and f.is_integer():
                    candidates.append(int(f))
            except Exception:
                pass
        raw_text = str(raw_value or "").strip()
        if raw_text:
            candidates.append(raw_text)

        deduped: List[Any] = []
        for item in candidates:
            if item not in deduped:
                deduped.append(item)

        for _ch, db in sorted(db_by_ch.items(), key=lambda x: int(x[0])):
            try:
                msg = db.get_message_by_name(msg_name)
            except Exception:
                continue

            signal_obj = None
            try:
                signal_obj = msg.get_signal_by_name(sig_name)
            except Exception:
                try:
                    signal_obj = next((s for s in getattr(msg, "signals", []) if getattr(s, "name", "") == sig_name), None)
                except Exception:
                    signal_obj = None

            choices = getattr(signal_obj, "choices", None) if signal_obj is not None else None
            if not choices:
                continue

            for key in deduped:
                try:
                    if key in choices:
                        label = str(choices[key])
                        return (label[: max_len - 3] + "...") if len(label) > max_len else label
                except Exception:
                    pass

            # 일부 DBC/라이브러리 버전에서 key 타입이 다르게 들어오는 경우를 대비한 완화 비교
            for choice_key, choice_val in choices.items():
                try:
                    if normalize_value(choice_key) == norm:
                        label = str(choice_val)
                        return (label[: max_len - 3] + "...") if len(label) > max_len else label
                except Exception:
                    continue

        return "-"
    except Exception:
        return "-"


def build_target_message_map(
    db_by_ch: Dict[int, Any],
    expectations: List[SignalExpectation],
) -> Tuple[Dict[Tuple[int, str], int], Dict[Tuple[int, str], Any]]:
    target_frame_ids: Dict[Tuple[int, str], int] = {}
    target_msgs: Dict[Tuple[int, str], Any] = {}

    unique_msg_names = sorted(set(exp.message for exp in expectations if exp.message))

    for ch, db in db_by_ch.items():
        for msg_name in unique_msg_names:
            try:
                msg = db.get_message_by_name(msg_name)
                target_frame_ids[(int(ch), msg_name)] = int(msg.frame_id)
                target_msgs[(int(ch), msg_name)] = msg
            except Exception:
                continue

    return target_frame_ids, target_msgs


# =========================================================
# 단일 기대조건 검사
# =========================================================
ProgressCallback = Callable[[str, Optional["CheckResult"]], None]


def _normalize_channels(channel) -> List[int]:
    if isinstance(channel, (list, tuple, set)):
        out = []
        for ch in channel:
            try:
                ch_int = int(ch)
            except Exception:
                continue
            if ch_int not in out:
                out.append(ch_int)
        return out
    try:
        return [int(channel)]
    except Exception:
        return []


def _read_expectation_with_existing_client(
    client: CANoeClient,
    expectation: SignalExpectation,
    channels: List[int],
) -> Tuple[List[Tuple[str, int, Any]], List[str]]:
    """
    이미 연결된 CANoeClient 하나만 사용해 선택 채널에서 신호를 읽는다.

    과거 로직은 이 함수 안에서 CANoeClient(...).connect()를 다시 호출했기 때문에
    PC의 COM 등록 상태에 따라 CANoe 10 같은 다른 버전으로 빠질 수 있었다.
    이 함수는 TC Start/Worker에서 확보한 Active CANoe 인스턴스만 사용한다.
    """
    readings: List[Tuple[str, int, Any]] = []
    errors: List[str] = []

    if client is None or not client.is_connected():
        return [], ["CANoe 연결이 없습니다."]

    bus_label = getattr(client, "bus_name", "CAN") or "CAN"

    for ch in channels:
        try:
            ch_int = int(ch)
        except Exception:
            errors.append(f"CH{ch}: 잘못된 채널 번호")
            continue

        try:
            raw = client.get_signal_value(ch_int, expectation.message, expectation.signal)
            readings.append((bus_label, ch_int, raw))
        except Exception as e:
            errors.append(f"{bus_label}/CH{ch_int}: {type(e).__name__}: {e}")

    return readings, errors


def wait_for_expectation_realtime(
    client: CANoeClient,
    expectation: SignalExpectation,
    channels: List[int],
    timeout_sec: float,
    stop_event: Optional[threading.Event] = None,
    done_event: Optional[threading.Event] = None,
    poll_interval_sec: float = 0.05,
) -> SingleExpectationCheck:
    stop_event = stop_event or threading.Event()
    done_event = done_event or threading.Event()

    res = SingleExpectationCheck(
        expectation=expectation,
        status="검토중",
        message=f"실시간 확인 시작: {expectation.message}:{expectation.signal} == {expectation.expected_value_raw}",
    )

    # 채널 후보별로 새 COM 연결을 만들지 않고, 인자로 받은 client 하나만 사용한다.

    start = time.perf_counter()
    first_successful_read = False
    last_errors: List[str] = []

    while True:
        if stop_event.is_set():
            res.status = "N/A"
            res.message = "사용자 중지"
            return res

        elapsed = time.perf_counter() - start

        if timeout_sec > 0 and elapsed > timeout_sec:
            break

        readings, errors = _read_expectation_with_existing_client(
            client=client,
            expectation=expectation,
            channels=channels,
        )

        if readings:
            first_successful_read = True
            for bus_name, ch, raw in readings:
                res.observed_value_raw = raw
                res.observed_value_norm = normalize_value(raw)
                res.observed_time = elapsed
                res.observed_channel = ch
                if len(res.samples) < 100:
                    res.samples.append((elapsed, f"{bus_name}/CH{ch}={raw}"))

                if values_equal(expectation.expected_value_raw, raw):
                    res.status = "PASS"
                    res.message = f"Expected Value 관측 | {bus_name}/CH{ch}"
                    return res
        else:
            last_errors = errors
            if elapsed >= min(1.0, timeout_sec if timeout_sec > 0 else 1.0):
                res.status = "ERROR"
                res.message = "선택된 모든 버스/채널 후보에서 Signal 읽기 실패: " + " | ".join(last_errors[:6])
                return res

        if done_event.is_set():
            if first_successful_read:
                res.status = "FAIL"
                res.message = "수행 완료 시점까지 예상 결과값 미관측"
            else:
                res.status = "N/A"
                res.message = "수행 완료 시점까지 신호 미관측"
            return res

        time.sleep(max(0.005, float(poll_interval_sec)))

    if first_successful_read:
        res.status = "FAIL"
        res.message = f"제한시간 {timeout_sec:.1f}초 내 예상 결과값 미관측"
    else:
        res.status = "N/A"
        res.message = "신호 읽기 성공 없이 제한시간 종료"

    return res


# =========================================================
# 로그에서 단일 기대조건 재검토
# =========================================================
def review_single_expectation_in_log_robust(
    expectation: SignalExpectation,
    log_path: str | Path,
    dbc_path_by_channel: Dict[int, str | Path],
    drop_first_seconds: float = 0.0,
    max_samples: int = 100,
) -> LogReviewOutcome:
    started = time.perf_counter()

    result = LogReviewOutcome(
        status="ERROR",
        message="초기화됨",
    )

    try:
        asc_path = ensure_asc_path(log_path)
        result.asc_path = str(asc_path)

        db_by_ch = load_dbc_map(dbc_path_by_channel)
        if not db_by_ch:
            result.status = "ERROR"
            result.message = "유효한 DBC를 1개도 로드하지 못했습니다."
            return result

        target_frame_ids, target_msgs = build_target_message_map(db_by_ch, [expectation])

        if not target_frame_ids:
            result.status = "ERROR"
            result.message = f"DBC에서 Message를 찾지 못함: {expectation.message}"
            return result

        last_observed = None
        last_observed_time = None
        last_ch = None
        last_frame_id = None

        for t, ch, can_id, data in read_frames_from_asc(asc_path):
            if t < float(drop_first_seconds):
                continue

            key = (ch, expectation.message)
            if key not in target_frame_ids:
                continue

            if can_id != target_frame_ids[key]:
                continue

            msg = target_msgs[key]
            try:
                decoded = msg.decode(data, decode_choices=False)
            except Exception:
                continue

            if expectation.signal not in decoded:
                continue

            val = decoded[expectation.signal]
            last_observed = val
            last_observed_time = t
            last_ch = ch
            last_frame_id = can_id

            if len(result.samples) < max_samples:
                result.samples.append((t, val))

            result.observed_value_raw = val
            result.observed_value_norm = normalize_value(val)
            result.observed_time = t
            result.matched_channel = ch
            result.matched_frame_id = can_id

            if values_equal(expectation.expected_value_raw, val):
                result.status = "PASS"
                result.message = f"로그에서 예상 결과값 관측: {Path(log_path).name}"
                return result

        result.observed_value_raw = last_observed
        result.observed_value_norm = normalize_value(last_observed)
        result.observed_time = last_observed_time
        result.matched_channel = last_ch
        result.matched_frame_id = last_frame_id
        result.status = "FAIL"
        result.message = f"로그 재검토에서도 예상 결과값 미관측: {Path(log_path).name}"
        return result

    except Exception as e:
        result.status = "ERROR"
        result.message = f"로그 재검토 오류: {e}\n{traceback.format_exc()}"
        return result

    finally:
        result.elapsed_sec = time.perf_counter() - started




# =========================================================
# 대용량 로그 일괄 재검토: 여러 TC/시그널을 ASC 1회 스캔으로 확인
# =========================================================
def _make_error_log_check_result(condition: OracleCondition, message: str) -> CheckResult:
    check = CheckResult(
        condition=condition,
        status="ERROR",
        source="multi_log_batch_review",
        started_at=_dt.datetime.now(),
        ended_at=_dt.datetime.now(),
        message=message,
        input_results=[],
        output_results=[],
    )
    check.input_results = [
        SingleExpectationCheck(expectation=exp, status="ERROR", message=message)
        for exp in condition.input_conditions
    ]
    check.output_results = [
        SingleExpectationCheck(expectation=exp, status="ERROR", message=message)
        for exp in condition.output_conditions
    ]
    return check


def _set_check_result_last_observed_from_items(check: CheckResult) -> None:
    for one in list(check.output_results or [])[::-1] + list(check.input_results or [])[::-1]:
        if one.observed_value_raw is not None:
            check.observed_value_raw = one.observed_value_raw
            check.observed_value_norm = one.observed_value_norm
            check.observed_time = one.observed_time
            check.observed_channel = one.observed_channel
            check.samples = list(one.samples or [])
            return


def review_conditions_in_log_batch(
    conditions: Iterable[OracleCondition],
    log_path: str | Path,
    dbc_path_by_channel: Dict[int, str | Path],
    drop_first_seconds: float = 0.0,
    max_samples_per_expectation: int = 100,
    stop_event: Optional[threading.Event] = None,
    progress_callback: Optional[Callable[[str], None]] = None,
) -> List[CheckResult]:
    """여러 TC의 입력/출력 기대조건을 로그 파일 1회 스캔으로 재검토한다.

    기존 review_single_expectation_in_log_robust()는 조건 1개마다 ASC를 처음부터 읽는다.
    다중 TC 수행 후 로그 증적 확인에서는 조건 수가 많아질 수 있으므로, 이 함수는
    모든 대상 Message/Signal/Expected를 먼저 모은 뒤 ASC를 한 번만 순회한다.
    """
    stop_event = stop_event or threading.Event()
    conditions = [c for c in (conditions or []) if c is not None]
    if not conditions:
        return []

    started_at = _dt.datetime.now()
    started_perf = time.perf_counter()
    log_name = Path(log_path).name if log_path else "-"

    try:
        asc_path = ensure_asc_path(log_path)
        db_by_ch = load_dbc_map(dbc_path_by_channel)
        if not db_by_ch:
            return [_make_error_log_check_result(c, "유효한 DBC를 1개도 로드하지 못했습니다.") for c in conditions]

        all_expectations: List[SignalExpectation] = []
        for c in conditions:
            all_expectations.extend(list(c.input_conditions or []))
            all_expectations.extend(list(c.output_conditions or []))

        target_frame_ids, target_msgs = build_target_message_map(db_by_ch, all_expectations)

        # (channel, frame_id) -> [(message_name, cantools_message)]
        frame_targets: Dict[Tuple[int, int], List[Tuple[str, Any]]] = {}
        for (ch, msg_name), frame_id in target_frame_ids.items():
            msg_obj = target_msgs.get((ch, msg_name))
            if msg_obj is None:
                continue
            frame_targets.setdefault((int(ch), int(frame_id)), []).append((msg_name, msg_obj))

        checks: List[CheckResult] = []
        watch_by_sig: Dict[Tuple[int, str, str], List[SingleExpectationCheck]] = {}
        all_single_checks: List[SingleExpectationCheck] = []

        for c in conditions:
            check = CheckResult(
                condition=c,
                status="검토중",
                source="multi_log_batch_review",
                started_at=started_at,
                message=f"다중 TC 로그 일괄 재검토 시작: {log_name}",
            )

            def _make_one(exp: SignalExpectation) -> SingleExpectationCheck:
                one = SingleExpectationCheck(
                    expectation=exp,
                    status="검토중",
                    message="로그 일괄 재검토 대기",
                )
                matched_channels = [
                    int(ch) for (ch, msg_name), _frame_id in target_frame_ids.items()
                    if msg_name == exp.message
                ]
                if not matched_channels:
                    one.status = "ERROR"
                    one.message = f"DBC에서 Message를 찾지 못함: {exp.message}"
                else:
                    for ch in matched_channels:
                        watch_by_sig.setdefault((ch, exp.message, exp.signal), []).append(one)
                all_single_checks.append(one)
                return one

            check.input_results = [_make_one(exp) for exp in c.input_conditions]
            check.output_results = [_make_one(exp) for exp in c.output_conditions]
            checks.append(check)

        if progress_callback:
            progress_callback(f"로그 일괄 재검토 시작: {log_name}")

        for t, ch, can_id, data in read_frames_from_asc(asc_path):
            if stop_event.is_set():
                break
            if t < float(drop_first_seconds):
                continue

            targets = frame_targets.get((int(ch), int(can_id)))
            if not targets:
                continue

            for msg_name, msg_obj in targets:
                try:
                    decoded = msg_obj.decode(data, decode_choices=False)
                except Exception:
                    continue

                for sig_name, val in decoded.items():
                    watchers = watch_by_sig.get((int(ch), msg_name, sig_name))
                    if not watchers:
                        continue
                    for one in watchers:
                        if one.status == "PASS":
                            continue
                        one.observed_value_raw = val
                        one.observed_value_norm = normalize_value(val)
                        one.observed_time = t
                        one.observed_channel = int(ch)
                        if len(one.samples) < max_samples_per_expectation:
                            one.samples.append((t, val))
                        if values_equal(one.expectation.expected_value_raw, val):
                            one.status = "PASS"
                            one.message = f"로그에서 예상 결과값 관측: {log_name}"

        if stop_event.is_set():
            for one in all_single_checks:
                if one.status == "검토중":
                    one.status = "N/A"
                    one.message = "사용자 중단으로 로그 재검토 미완료"

        for one in all_single_checks:
            if one.status == "검토중":
                one.status = "FAIL"
                one.message = f"로그 재검토에서도 예상 결과값 미관측: {log_name}"

        ended_at = _dt.datetime.now()
        elapsed_sec = time.perf_counter() - started_perf

        for check in checks:
            check.ended_at = ended_at
            check.elapsed_sec = elapsed_sec
            inputs = list(check.input_results or [])
            outputs = list(check.output_results or [])
            all_items = inputs + outputs
            any_error = any(x.status == "ERROR" for x in all_items)
            inputs_ok = bool(inputs) and all(x.status == "PASS" for x in inputs)
            outputs_ok = bool(outputs) and all(x.status == "PASS" for x in outputs)

            if stop_event.is_set():
                check.status = "N/A"
                check.message = "사용자 중단으로 로그 재검토 미완료"
            elif any_error:
                check.status = "ERROR"
                check.message = "로그 재검토 중 DBC/Message 매핑 오류 발생"
            elif inputs_ok and outputs_ok:
                check.status = "PASS"
                check.message = "로그 일괄 재검토에서 모든 입력 및 모든 출력 조건 PASS"
            elif not inputs_ok:
                check.status = "FAIL"
                check.message = "로그 일괄 재검토에서도 입력 조건 일부 또는 전체 미관측"
            else:
                check.status = "FAIL"
                check.message = "로그 일괄 재검토에서도 출력 조건 일부 미관측"
            _set_check_result_last_observed_from_items(check)

        if progress_callback:
            progress_callback(f"로그 일괄 재검토 완료: {len(checks)}개 TC")
        return checks

    except Exception as e:
        msg = f"로그 일괄 재검토 오류: {e}\n{traceback.format_exc()}"
        return [_make_error_log_check_result(c, msg) for c in conditions]


# =========================================================
# 실시간 판정: 입력 다중 + 출력 다중(AND)
# =========================================================
def check_condition_realtime(
    client: CANoeClient,
    condition: OracleCondition,
    channel,
    stop_event: Optional[threading.Event] = None,
    done_event: Optional[threading.Event] = None,
    poll_interval_sec: float = 0.05,
    progress_callback: Optional[ProgressCallback] = None,
) -> CheckResult:
    stop_event = stop_event or threading.Event()
    done_event = done_event or threading.Event()
    channels = _normalize_channels(channel)

    result = CheckResult(
        condition=condition,
        status="검토중",
        source="realtime",
        started_at=_dt.datetime.now(),
        message=f"실시간 감시 시작 | channels={channels}",
    )

    if not channels:
        result.status = "ERROR"
        result.message = "감시할 물리 채널이 지정되지 않았습니다."
        result.ended_at = _dt.datetime.now()
        result.elapsed_sec = 0.0
        return result

    if progress_callback:
        progress_callback("검토중", result)

    started_perf = time.perf_counter()

    try:
        timeout_sec = max(0.0, float(condition.timeout_sec or 0.0))

        if not condition.input_conditions:
            result.status = "ERROR"
            result.message = "입력 조건이 없습니다."
            return result

        input_results: List[SingleExpectationCheck] = []
        for exp in condition.input_conditions:
            one = wait_for_expectation_realtime(
                client=client,
                expectation=exp,
                channels=channels,
                timeout_sec=timeout_sec,
                stop_event=stop_event,
                done_event=done_event,
                poll_interval_sec=poll_interval_sec,
            )
            input_results.append(one)
            result.input_results = list(input_results)
            result.observed_value_raw = one.observed_value_raw
            result.observed_value_norm = one.observed_value_norm
            result.observed_time = one.observed_time
            result.observed_channel = one.observed_channel
            result.samples.extend(one.samples[:20])

            if progress_callback:
                progress_callback("검토중", result)

            if one.status != "PASS":
                result.status = "ERROR" if one.status == "ERROR" else one.status
                result.message = f"입력 조건 미충족: {exp.message}:{exp.signal} / {one.message}"
                return result

        if not condition.output_conditions:
            result.status = "ERROR"
            result.message = "출력 조건이 없습니다."
            return result

        output_results: List[SingleExpectationCheck] = []
        for exp in condition.output_conditions:
            if stop_event.is_set():
                result.status = "N/A"
                result.message = "사용자 중지"
                result.output_results = output_results
                return result

            one = wait_for_expectation_realtime(
                client=client,
                expectation=exp,
                channels=channels,
                timeout_sec=timeout_sec,
                stop_event=stop_event,
                done_event=done_event,
                poll_interval_sec=poll_interval_sec,
            )
            output_results.append(one)
            result.output_results = list(output_results)
            result.observed_value_raw = one.observed_value_raw
            result.observed_value_norm = one.observed_value_norm
            result.observed_time = one.observed_time
            result.observed_channel = one.observed_channel
            result.samples.extend(one.samples[:20])

            if progress_callback:
                progress_callback("검토중", result)

            if one.status != "PASS":
                result.status = "ERROR" if one.status == "ERROR" else one.status
                result.message = f"출력 조건 미충족: {exp.message}:{exp.signal} / {one.message}"
                return result

        result.status = "PASS"
        result.message = "모든 입력 조건 및 모든 출력 조건 PASS"
        return result

    except Exception as e:
        result.status = "ERROR"
        result.source = "error"
        result.message = f"실시간 감시 오류: {e}"
        return result

    finally:
        result.ended_at = _dt.datetime.now()
        result.elapsed_sec = time.perf_counter() - started_perf
        if progress_callback:
            progress_callback(result.status, result)


# =========================================================
# 로그 재검토 조립
# =========================================================
def _log_outcome_to_single_check(exp: SignalExpectation, lr: LogReviewOutcome) -> SingleExpectationCheck:
    return SingleExpectationCheck(
        expectation=exp,
        status=lr.status,
        observed_value_raw=lr.observed_value_raw,
        observed_value_norm=lr.observed_value_norm,
        observed_time=lr.observed_time,
        observed_channel=lr.matched_channel,
        message=lr.message,
        samples=list(lr.samples),
    )


# =========================================================
# 공통 최종 판정 보정: 실시간 + 로그 결과 결합
# =========================================================
def apply_log_result_to_final(
    final: FinalCheckResult,
    log_result: Optional[CheckResult],
    strict_log_reflect: bool = False,
    context_label: str = "로그 재검토",
) -> FinalCheckResult:
    """GUI 종류와 무관하게 동일한 실시간/로그 최종 판정 정책을 적용한다."""
    final.log_result = log_result
    if log_result is None:
        return final

    rt = final.realtime_result
    rt_status = getattr(rt, "status", "")
    log_name = Path(final.used_log_path).name if final.used_log_path else "-"

    # 실시간 PASS는 가장 우선하는 판정 근거다. 로그는 보조 증적으로만 기록한다.
    if rt_status == "PASS":
        final.final_status = "PASS"
        if rt is not None:
            final.final_observed_value_raw = rt.observed_value_raw
            final.final_observed_value_norm = rt.observed_value_norm
            final.final_observed_time = rt.observed_time
            final.final_observed_channel = rt.observed_channel

        if log_result.status == "PASS":
            final.final_message = f"실시간 PASS 우선 유지 / {context_label} PASS: {log_name}"
        else:
            final.final_message = (
                f"실시간 PASS 우선 유지 / {context_label} {log_result.status}: {log_result.message}"
            )
        return final

    # 실시간 미통과 시에는 로그의 마지막 관측값을 최종 표시값으로 사용할 수 있다.
    for seq in (getattr(log_result, "output_results", None), getattr(log_result, "input_results", None)):
        for one in list(seq or [])[::-1]:
            if getattr(one, "observed_value_raw", None) is not None:
                final.final_observed_value_raw = one.observed_value_raw
                final.final_observed_value_norm = one.observed_value_norm
                final.final_observed_time = one.observed_time
                final.final_observed_channel = one.observed_channel
                break
        else:
            continue
        break

    if log_result.status == "PASS":
        final.final_status = "PASS"
        final.final_message = f"실시간 미관측 조건을 {context_label}에서 PASS: {log_name}"
        return final

    if strict_log_reflect and log_result.status in ("FAIL", "N/A", "ERROR"):
        final.final_status = log_result.status
        final.final_message = f"{context_label} 결과 {log_result.status}: {log_result.message}"
        return final

    if final.final_status == "검토중":
        final.final_status = log_result.status
        final.final_message = log_result.message
    return final


# =========================================================
# 최종 판정: 실시간 + 자동 로그 재검토(입력 다중 + 출력 다중)
# =========================================================
def check_condition_with_log_fallback(
    client: CANoeClient,
    condition: OracleCondition,
    channel,
    stop_event: Optional[threading.Event] = None,
    done_event: Optional[threading.Event] = None,
    poll_interval_sec: float = 0.05,
    progress_callback: Optional[ProgressCallback] = None,
    log_path: Optional[str] = None,
    log_dir: Optional[str] = None,
    tc_start_ts: Optional[float] = None,
    dbc_path_by_channel: Optional[Dict[int, str]] = None,
    auto_log_review: bool = True,
    auto_find_latest_log: bool = True,
    auto_stop_measurement: bool = True,
    skip_log_review_on_pass: bool = True,
    log_wait_timeout: float = 5.0,
    drop_first_seconds: float = 0.0,
) -> FinalCheckResult:
    started = _dt.datetime.now()

    final = FinalCheckResult(
        condition=condition,
        started_at=started,
    )

    rt = check_condition_realtime(
        client=client,
        condition=condition,
        channel=channel,
        stop_event=stop_event,
        done_event=done_event,
        poll_interval_sec=poll_interval_sec,
        progress_callback=progress_callback,
    )
    final.realtime_result = rt

    if rt.status == "PASS" and skip_log_review_on_pass:
        if auto_stop_measurement:
            try:
                client.stop_measurement()
            except Exception:
                pass
        final.final_status = "PASS"
        final.final_message = "실시간 감시 PASS - Measurement Stop 후 로그 재검토 생략"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    if rt.status == "PASS" and not skip_log_review_on_pass:
        if auto_stop_measurement:
            try:
                client.stop_measurement()
            except Exception:
                pass
        # 사용자가 PASS 시 로그 검토 생략 옵션을 해제한 경우에는 아래 로그 재검토 흐름을 그대로 탄다.

    if stop_event is not None and stop_event.is_set():
        final.final_status = "N/A"
        final.final_message = "사용자 중지"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    if rt.status == "ERROR" and not auto_log_review:
        final.final_status = "ERROR"
        final.final_message = rt.message
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    if not auto_log_review:
        final.final_status = rt.status
        final.final_message = f"로그 재검토 미사용: {rt.message}"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    if not dbc_path_by_channel:
        final.final_status = rt.status
        final.final_message = f"로그 재검토용 DBC 미지정: {rt.message}"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    selected_log_path: Optional[Path] = None

    if log_path:
        p = Path(log_path)
        if p.exists():
            selected_log_path = p

    if selected_log_path is None and auto_find_latest_log and log_dir:
        if auto_stop_measurement:
            try:
                client.stop_measurement()
            except Exception:
                pass

        latest = find_latest_log_file(
            log_dir=log_dir,
            after_ts=tc_start_ts,
            wait_timeout=log_wait_timeout,
            poll_interval=0.5,
            exts=(".blf", ".asc"),
        )
        if latest is not None:
            wait_until_file_stable(
                latest,
                stable_sec=1.0,
                timeout=min(max(2.0, log_wait_timeout), 10.0),
                poll_interval=0.2,
            )
            selected_log_path = latest

    if selected_log_path is None:
        final.final_status = rt.status
        final.final_message = f"로그 파일을 찾지 못함: {rt.message}"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    final.used_log_path = str(selected_log_path)

    log_check = CheckResult(
        condition=condition,
        status="검토중",
        source="log_review",
        started_at=started,
        message="로그 재검토 시작",
    )

    input_log_results: List[SingleExpectationCheck] = []
    for exp in condition.input_conditions:
        lr = review_single_expectation_in_log_robust(
            expectation=exp,
            log_path=str(selected_log_path),
            dbc_path_by_channel=dbc_path_by_channel,
            drop_first_seconds=drop_first_seconds,
        )
        one = _log_outcome_to_single_check(exp, lr)
        input_log_results.append(one)

    log_check.input_results = input_log_results

    output_log_results: List[SingleExpectationCheck] = []
    for exp in condition.output_conditions:
        lr = review_single_expectation_in_log_robust(
            expectation=exp,
            log_path=str(selected_log_path),
            dbc_path_by_channel=dbc_path_by_channel,
            drop_first_seconds=drop_first_seconds,
        )
        one = _log_outcome_to_single_check(exp, lr)
        output_log_results.append(one)

        log_check.observed_value_raw = one.observed_value_raw
        log_check.observed_value_norm = one.observed_value_norm
        log_check.observed_time = one.observed_time
        log_check.observed_channel = one.observed_channel

    log_check.output_results = output_log_results
    log_check.ended_at = _dt.datetime.now()
    log_check.elapsed_sec = (log_check.ended_at - started).total_seconds()

    inputs_pass = (
        input_log_results
        and len(input_log_results) == len(condition.input_conditions)
        and all(x.status == "PASS" for x in input_log_results)
    )
    outputs_pass = (
        output_log_results
        and len(output_log_results) == len(condition.output_conditions)
        and all(x.status == "PASS" for x in output_log_results)
    )

    # 최우선 판정 정책: 실시간 PASS는 로그 결과가 FAIL/N/A/ERROR여도 최종 PASS를 유지한다.
    # 로그 재검토는 보조 증적이며, 최종 Observed 값도 실시간 PASS 관측값을 보존한다.
    if rt.status == "PASS":
        failed_input = next((x for x in input_log_results if x.status != "PASS"), None)
        failed_output = next((x for x in output_log_results if x.status != "PASS"), None)

        if inputs_pass and outputs_pass:
            log_check.status = "PASS"
            log_check.message = "로그 재검토에서도 모든 입력 및 모든 출력 조건 PASS"
            final.final_message = f"실시간 PASS 우선 유지 / 로그 재검토 PASS: {selected_log_path.name}"
        elif failed_input is not None:
            log_check.status = "ERROR" if failed_input.status == "ERROR" else failed_input.status
            log_check.message = failed_input.message
            final.final_message = (
                f"실시간 PASS 우선 유지 / 입력 로그 재검토 {log_check.status}: {failed_input.message}"
            )
        elif failed_output is not None:
            log_check.status = "ERROR" if failed_output.status == "ERROR" else failed_output.status
            log_check.message = failed_output.message
            final.final_message = (
                f"실시간 PASS 우선 유지 / 출력 로그 재검토 {log_check.status}: {failed_output.message}"
            )
        else:
            log_check.status = "FAIL"
            log_check.message = "로그 재검토 실패"
            final.final_message = f"실시간 PASS 우선 유지 / 로그 재검토 FAIL: {selected_log_path.name}"

        final.log_result = log_check
        final.final_status = "PASS"
        final.final_observed_value_raw = rt.observed_value_raw
        final.final_observed_value_norm = rt.observed_value_norm
        final.final_observed_time = rt.observed_time
        final.final_observed_channel = rt.observed_channel
        final.ended_at = _dt.datetime.now()
        final.elapsed_sec = (final.ended_at - started).total_seconds()
        return final

    if inputs_pass and outputs_pass:
        log_check.status = "PASS"
        log_check.message = "로그 재검토에서 모든 입력 및 모든 출력 조건 PASS"
        final.final_status = "PASS"
        final.final_message = f"실시간 미관측이었지만 로그 재검토에서 PASS: {selected_log_path.name}"
        if output_log_results:
            last = output_log_results[-1]
        else:
            last = input_log_results[-1]
        final.final_observed_value_raw = last.observed_value_raw
        final.final_observed_value_norm = last.observed_value_norm
        final.final_observed_time = last.observed_time
        final.final_observed_channel = last.observed_channel
    else:
        failed_input = next((x for x in input_log_results if x.status != "PASS"), None)
        failed_output = next((x for x in output_log_results if x.status != "PASS"), None)

        if failed_input is not None:
            if failed_input.status == "ERROR":
                log_check.status = "ERROR"
                log_check.message = failed_input.message
                final.final_status = "ERROR"
                final.final_message = f"입력 조건 로그 재검토 오류: {failed_input.message} | log={selected_log_path}"
            else:
                log_check.status = "FAIL"
                log_check.message = failed_input.message
                final.final_status = "FAIL"
                final.final_message = f"실시간/로그 재검토 모두 입력 예상 결과값 미관측: {selected_log_path.name}"

            final.final_observed_value_raw = failed_input.observed_value_raw
            final.final_observed_value_norm = failed_input.observed_value_norm
            final.final_observed_time = failed_input.observed_time
            final.final_observed_channel = failed_input.observed_channel

        elif failed_output is not None:
            if failed_output.status == "ERROR":
                log_check.status = "ERROR"
                log_check.message = failed_output.message
                final.final_status = "ERROR"
                final.final_message = f"{failed_output.message} | log={selected_log_path}"
            else:
                log_check.status = "FAIL"
                log_check.message = failed_output.message
                final.final_status = "FAIL"
                final.final_message = f"실시간/로그 재검토 모두 예상 결과값 미관측: {selected_log_path.name}"

            final.final_observed_value_raw = failed_output.observed_value_raw
            final.final_observed_value_norm = failed_output.observed_value_norm
            final.final_observed_time = failed_output.observed_time
            final.final_observed_channel = failed_output.observed_channel
        else:
            log_check.status = "FAIL"
            log_check.message = "로그 재검토 실패"
            final.final_status = "FAIL"
            final.final_message = f"실시간/로그 재검토 모두 실패: {selected_log_path.name}"

    final.log_result = log_check
    final.ended_at = _dt.datetime.now()
    final.elapsed_sec = (final.ended_at - started).total_seconds()
    return final


# =========================================================
# 결과 저장
# =========================================================
def export_results_to_excel(results: Iterable[CheckResult], output_path: str | Path) -> Path:
    from openpyxl import Workbook

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Result"

    headers = [
        "TC 번호", "소분류", "TC 내용", "TC 예상 결과",
        "입력 Message", "입력 Signal", "입력 Expected Value",
        "출력 Message", "출력 Signal", "출력 Expected Value",
        "판정 방식", "대기 시간", "사용 여부", "비고", "조건 ID", "TC Logic", "Revision",
        "최종 상태", "출처", "Observed Value", "Observed Time", "Observed Channel", "Elapsed Sec", "비고(결과)",
    ]
    ws.append(headers)

    for r in results:
        ws.append(r.to_row())

    wb.save(output_path)
    return output_path


def export_final_results_to_excel(results: Iterable[FinalCheckResult], output_path: str | Path) -> Path:
    from openpyxl import Workbook

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "FinalResult"

    headers = [
        "TC 번호", "소분류", "TC 내용", "TC 예상 결과",
        "입력 Message", "입력 Signal", "입력 Expected Value",
        "출력 Message", "출력 Signal", "출력 Expected Value",
        "판정 방식", "대기 시간", "사용 여부", "비고", "조건 ID", "TC Logic", "Revision",
        "실시간 결과", "로그 재검토 결과", "최종 결과",
        "최종 Observed Value", "최종 Observed Time", "최종 Observed Channel", "사용 로그 파일", "최종 메시지",
    ]
    ws.append(headers)

    for r in results:
        ws.append(r.to_row())

    wb.save(output_path)
    return output_path


# =========================================================
# 최신 GUI 실행
# =========================================================
_COUNTERPART_REV_RE = re.compile(
    r"^(?P<base>{base})"
    r"(?:(?P<sep>[_\-.])rev(?P<sep2>[_\-.])?(?P<num>\d+))?$",
    re.IGNORECASE,
)


def find_latest_rev_file(base_dir: str | Path, base_name: str) -> Path:
    base_dir = Path(base_dir)
    pattern = _COUNTERPART_REV_RE.pattern.format(base=re.escape(base_name))
    rx = re.compile(pattern, re.IGNORECASE)

    candidates: List[Tuple[int, Path]] = []
    seen_paths = set()
    for glob_pat in (f"{base_name}*.py", f"{base_name}*.pyw"):
        for p in base_dir.glob(glob_pat):
            if not p.is_file() or p in seen_paths:
                continue
            seen_paths.add(p)
            m = rx.match(p.stem)
            if not m:
                continue
            num = m.group("num")
            rev = int(num) if num is not None else -1
            candidates.append((rev, p))

    if not candidates:
        raise FileNotFoundError(
            f"{base_name} 계열 파일을 찾지 못했습니다. 예: {base_name}.py / {base_name}_rev02.py"
        )

    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def launch_latest_gui() -> int:
    base_dir = Path(__file__).resolve().parent
    gui_path = find_latest_rev_file(base_dir, "oracle_checker_gui")
    return subprocess.call([sys.executable, str(gui_path)], cwd=str(base_dir))


def _demo_print_excel(excel_path: str, sheet_name: str):
    rows = load_oracle_conditions_with_diagnostics(excel_path, sheet_name)
    print(f"Loaded rows: {len(rows)}")
    for r in rows[:10]:
        print(r)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Oracle Checker main utility")
    parser.add_argument("--excel", help="TestCase_Oracle.xlsx path")
    parser.add_argument("--sheet", help="Sheet name")
    parser.add_argument(
        "--no-gui",
        action="store_true",
        help="인자 없이 실행했을 때 최신 GUI를 자동 실행하지 않고 안내만 출력",
    )
    args = parser.parse_args()

    if args.excel and args.sheet:
        _demo_print_excel(args.excel, args.sheet)
    elif args.no_gui:
        print("oracle_checker_main*.py loaded. GUI에서 사용하는 모듈입니다.")
    else:
        raise SystemExit(launch_latest_gui())

