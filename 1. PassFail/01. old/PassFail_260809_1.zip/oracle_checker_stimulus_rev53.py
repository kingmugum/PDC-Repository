# -*- coding: utf-8 -*-
"""
oracle_checker_stimulus_rev53.py

Oracle Checker experimental stimulus engine (isolated module).

Design rules
- This module is the ONLY rev53 module that writes CANoe bus Signal.Value.
- It does not import the Pass/Fail core, GUI, report, or multiple modules.
- It never creates/dispatches a CANoe instance. A connected CANoeClient-like object is injected by the GUI.
- It does not start/stop Measurement by itself.
- Existing selected-TC PoC still supports one CAN signal only.
- rev53 adds a manual candidate-set PoC for 1~8 explicitly entered signals.
- Group execution pre-validates every signal before the first write, captures each original value,
  applies all candidate values, holds briefly, and restores every written signal in reverse order in finally.
- It does not calculate CRC/Alive/E2E. The GUI must block those rows for rev53.
- Whether assigning CANoe Signal.Value results in a physical bus transmission depends on the active
  CANoe Configuration/IL/simulation setup.

rev53 remains an experimental PoC. It is intentionally not a general CAN message transmitter.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import datetime as _dt
import json
from pathlib import Path
import threading
import time
from typing import Any, Dict, List, Optional, Tuple


class StimulusError(RuntimeError):
    pass


class StimulusValidationError(StimulusError):
    pass


@dataclass(frozen=True)
class StimulusProfile:
    tc_no: str
    channel: int
    message: str
    signal: str
    active_value: Any
    hold_sec: float = 0.5
    bus_name: str = "CAN"
    source: str = "Oracle input condition"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class StimulusCandidate:
    logical_can: str
    channel: int
    message: str
    signal: str
    active_value: Any
    bus_name: str = "CAN"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class StimulusGroupProfile:
    name: str
    candidates: List[StimulusCandidate]
    hold_sec: float = 0.5
    source: str = "Manual candidate set"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "candidates": [x.to_dict() for x in self.candidates],
            "hold_sec": self.hold_sec,
            "source": self.source,
        }


@dataclass
class StimulusExecutionResult:
    ok: bool
    started_at: str
    finished_at: str
    tc_no: str
    channel: int
    message: str
    signal: str
    original_value: Any = None
    active_value: Any = None
    active_readback: Any = None
    restored_value: Any = None
    restore_ok: bool = False
    stopped_early: bool = False
    error: str = ""
    trace_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StimulusCandidateResult:
    logical_can: str
    channel: int
    message: str
    signal: str
    original_value: Any = None
    active_value: Any = None
    active_readback: Any = None
    restored_value: Any = None
    write_ok: bool = False
    restore_ok: bool = False
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StimulusGroupExecutionResult:
    ok: bool
    started_at: str
    finished_at: str
    name: str
    stopped_early: bool = False
    restore_ok: bool = False
    error: str = ""
    items: Optional[List[StimulusCandidateResult]] = None
    trace_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["items"] = [x.to_dict() for x in (self.items or [])]
        return data


def coerce_numeric_value(value: Any) -> Any:
    """rev53 PoC accepts numeric signal values only."""
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else value
    text = str(value if value is not None else '').strip()
    if not text:
        raise StimulusValidationError('입력 Active Value가 비어 있습니다.')
    compact = text.replace(' ', '')
    try:
        if compact.lower().startswith(('0x', '+0x', '-0x')):
            sign = -1 if compact.startswith('-') else 1
            raw = compact[3:] if compact[0] in '+-' else compact[2:]
            return sign * int(raw, 16)
        if re_full_int(compact):
            return int(compact, 10)
        f = float(compact)
        return int(f) if f.is_integer() else f
    except Exception as e:
        raise StimulusValidationError(
            f'rev53 입력 테스트는 숫자형 Active Value만 지원합니다: {text}'
        ) from e


def re_full_int(text: str) -> bool:
    if not text:
        return False
    if text[0] in '+-':
        return len(text) > 1 and text[1:].isdigit()
    return text.isdigit()


class StimulusExecutor:
    MIN_HOLD_SEC = 0.05
    MAX_HOLD_SEC = 5.0
    MAX_GROUP_ITEMS = 8

    def __init__(self, trace_dir: Optional[str | Path] = None):
        self.trace_dir = Path(trace_dir) if trace_dir else None

    def _bus_candidates(self, client: Any, bus_name: str = "CAN") -> List[str]:
        names: List[str] = []
        try:
            for x in client._bus_name_candidates():
                if x and x not in names:
                    names.append(x)
        except Exception:
            pass
        for x in (bus_name, 'CAN'):
            x = str(x or '').strip()
            if x and x not in names:
                names.append(x)
        return names or ['CAN']

    def _get_signal_object_raw(
        self, client: Any, channel: int, message: str, signal: str, bus_name: str = "CAN"
    ) -> Tuple[Any, str]:
        app = getattr(client, 'app', None)
        if app is None:
            raise StimulusValidationError('주입된 CANoe client에 활성 app 객체가 없습니다.')
        last_error = None
        for candidate_bus in self._bus_candidates(client, bus_name):
            try:
                bus = app.GetBus(candidate_bus)
                sig = bus.GetSignal(int(channel), str(message), str(signal))
                _ = sig.Value
                return sig, candidate_bus
            except Exception as e:
                last_error = e
        raise StimulusValidationError(
            f'CANoe Signal 객체 접근 실패: channel={channel}, message={message}, signal={signal}, 원인={last_error}'
        )

    def _get_signal_object(self, client: Any, profile: StimulusProfile) -> Tuple[Any, str]:
        return self._get_signal_object_raw(
            client, profile.channel, profile.message, profile.signal, profile.bus_name
        )

    def _validate_client_and_hold(self, client: Any, hold_sec: float) -> float:
        if client is None:
            raise StimulusValidationError('CANoe client가 없습니다.')
        try:
            if not bool(client.is_connected()):
                raise StimulusValidationError('CANoe 연결이 없습니다.')
        except StimulusValidationError:
            raise
        except Exception as e:
            raise StimulusValidationError(f'CANoe 연결 상태 확인 실패: {e}') from e
        try:
            if not bool(client.is_measurement_running()):
                raise StimulusValidationError('CANoe Measurement가 실행 중이 아닙니다.')
        except StimulusValidationError:
            raise
        except Exception as e:
            raise StimulusValidationError(f'Measurement 상태 확인 실패: {e}') from e

        hold = float(hold_sec)
        if hold < self.MIN_HOLD_SEC or hold > self.MAX_HOLD_SEC:
            raise StimulusValidationError(
                f'Hold time은 {self.MIN_HOLD_SEC:.2f}~{self.MAX_HOLD_SEC:.1f}s 범위만 허용합니다.'
            )
        return hold

    def validate(self, client: Any, profile: StimulusProfile) -> Dict[str, Any]:
        hold = self._validate_client_and_hold(client, profile.hold_sec)
        if int(profile.channel) <= 0:
            raise StimulusValidationError('유효한 CAN 채널이 아닙니다.')
        if not str(profile.message).strip() or not str(profile.signal).strip():
            raise StimulusValidationError('Message/Signal 이름이 비어 있습니다.')
        active = coerce_numeric_value(profile.active_value)
        sig, bus_name = self._get_signal_object(client, profile)
        original = sig.Value
        if original is None:
            raise StimulusValidationError('실행 전 Signal 원래 값을 읽지 못해 안전한 원복 기준을 확보할 수 없습니다.')
        return {
            'bus_name': bus_name,
            'original_value': original,
            'active_value': active,
            'hold_sec': hold,
        }

    def validate_group(self, client: Any, profile: StimulusGroupProfile) -> Dict[str, Any]:
        hold = self._validate_client_and_hold(client, profile.hold_sec)
        items = list(profile.candidates or [])
        if not items:
            raise StimulusValidationError('수동 후보 Signal이 없습니다.')
        if len(items) > self.MAX_GROUP_ITEMS:
            raise StimulusValidationError(
                f'rev53 수동 후보 묶음은 최대 {self.MAX_GROUP_ITEMS}개 Signal만 허용합니다. 현재={len(items)}개'
            )

        seen = set()
        checked_items: List[Dict[str, Any]] = []
        for idx, item in enumerate(items, start=1):
            channel = int(item.channel)
            message = str(item.message or '').strip()
            signal = str(item.signal or '').strip()
            logical_can = str(item.logical_can or '').strip().upper()
            if channel <= 0:
                raise StimulusValidationError(f'{idx}행: 유효한 CAN 채널이 아닙니다.')
            if not message or not signal:
                raise StimulusValidationError(f'{idx}행: Message/Signal이 비어 있습니다.')
            key = (channel, message.lower(), signal.lower())
            if key in seen:
                raise StimulusValidationError(f'{idx}행: 동일 Signal이 중복 입력되었습니다: Ch{channel}/{message}/{signal}')
            seen.add(key)
            active = coerce_numeric_value(item.active_value)
            sig, bus_name = self._get_signal_object_raw(client, channel, message, signal, item.bus_name)
            original = sig.Value
            if original is None:
                raise StimulusValidationError(
                    f'{idx}행: 시작 전 값을 읽지 못해 원복 기준을 확보할 수 없습니다: Ch{channel}/{message}/{signal}'
                )
            checked_items.append({
                'logical_can': logical_can,
                'channel': channel,
                'message': message,
                'signal': signal,
                'active_value': active,
                'original_value': original,
                'bus_name': bus_name,
            })
        return {'hold_sec': hold, 'items': checked_items}

    def execute_once(
        self,
        client: Any,
        profile: StimulusProfile,
        stop_event: Optional[threading.Event] = None,
    ) -> StimulusExecutionResult:
        started = _dt.datetime.now()
        result = StimulusExecutionResult(
            ok=False,
            started_at=started.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
            finished_at='',
            tc_no=str(profile.tc_no or ''),
            channel=int(profile.channel),
            message=str(profile.message),
            signal=str(profile.signal),
            active_value=profile.active_value,
        )

        signal_obj = None
        original = None
        try:
            checked = self.validate(client, profile)
            active = checked['active_value']
            signal_obj, _ = self._get_signal_object(client, profile)
            original = checked['original_value']
            result.original_value = original
            result.active_value = active

            # Intentional write operation, isolated in this module.
            signal_obj.Value = active
            try:
                result.active_readback = signal_obj.Value
            except Exception:
                result.active_readback = None

            deadline = time.monotonic() + float(checked['hold_sec'])
            while time.monotonic() < deadline:
                if stop_event is not None and stop_event.is_set():
                    result.stopped_early = True
                    break
                time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
            result.ok = True
        except Exception as e:
            result.error = f'{type(e).__name__}: {e}'
        finally:
            if signal_obj is not None and original is not None:
                try:
                    signal_obj.Value = original
                    try:
                        result.restored_value = signal_obj.Value
                    except Exception:
                        result.restored_value = original
                    result.restore_ok = True
                except Exception as restore_error:
                    result.restore_ok = False
                    suffix = f'원래 값 복원 실패: {type(restore_error).__name__}: {restore_error}'
                    result.error = f'{result.error} / {suffix}'.strip(' /')
                    result.ok = False
            result.finished_at = _dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            result.trace_path = self._append_trace(profile.to_dict(), result.to_dict(), 'single')
        return result

    def execute_group_once(
        self,
        client: Any,
        profile: StimulusGroupProfile,
        stop_event: Optional[threading.Event] = None,
    ) -> StimulusGroupExecutionResult:
        started = _dt.datetime.now()
        result = StimulusGroupExecutionResult(
            ok=False,
            started_at=started.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
            finished_at='',
            name=str(profile.name or 'Manual Candidate Set'),
            items=[],
        )
        written: List[Tuple[Any, StimulusCandidateResult]] = []
        try:
            checked = self.validate_group(client, profile)
            # Resolve all signal objects again immediately before any write and capture originals again.
            prepared: List[Tuple[Any, StimulusCandidateResult]] = []
            for item in checked['items']:
                sig, _ = self._get_signal_object_raw(
                    client, item['channel'], item['message'], item['signal'], item.get('bus_name', 'CAN')
                )
                original = sig.Value
                if original is None:
                    raise StimulusValidationError(
                        f"실행 직전 원래 값 읽기 실패: Ch{item['channel']}/{item['message']}/{item['signal']}"
                    )
                item_result = StimulusCandidateResult(
                    logical_can=item['logical_can'],
                    channel=item['channel'],
                    message=item['message'],
                    signal=item['signal'],
                    original_value=original,
                    active_value=item['active_value'],
                )
                result.items.append(item_result)
                prepared.append((sig, item_result))

            # Apply candidates only after every row has passed preflight.
            for sig, item_result in prepared:
                sig.Value = item_result.active_value
                item_result.write_ok = True
                written.append((sig, item_result))
                try:
                    item_result.active_readback = sig.Value
                except Exception:
                    item_result.active_readback = None

            deadline = time.monotonic() + float(checked['hold_sec'])
            while time.monotonic() < deadline:
                if stop_event is not None and stop_event.is_set():
                    result.stopped_early = True
                    break
                time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
            result.ok = True
        except Exception as e:
            result.error = f'{type(e).__name__}: {e}'
            result.ok = False
        finally:
            restore_errors: List[str] = []
            for sig, item_result in reversed(written):
                try:
                    sig.Value = item_result.original_value
                    try:
                        item_result.restored_value = sig.Value
                    except Exception:
                        item_result.restored_value = item_result.original_value
                    item_result.restore_ok = True
                except Exception as restore_error:
                    item_result.restore_ok = False
                    item_result.error = f'{type(restore_error).__name__}: {restore_error}'
                    restore_errors.append(
                        f"Ch{item_result.channel}/{item_result.message}/{item_result.signal}: {item_result.error}"
                    )
            # Items never written are not overwritten during rollback.
            result.restore_ok = bool(written) and all(x.restore_ok for _, x in written)
            if restore_errors:
                suffix = '원복 실패: ' + ' | '.join(restore_errors)
                result.error = f'{result.error} / {suffix}'.strip(' /')
                result.ok = False
            result.finished_at = _dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            result.trace_path = self._append_trace(profile.to_dict(), result.to_dict(), 'group')
        return result

    def _append_trace(self, profile_data: Dict[str, Any], result_data: Dict[str, Any], mode: str) -> str:
        if self.trace_dir is None:
            return ''
        try:
            self.trace_dir.mkdir(parents=True, exist_ok=True)
            path = self.trace_dir / f"stimulus_execution_{_dt.datetime.now().strftime('%Y%m%d')}.jsonl"
            record = {
                'mode': mode,
                'profile': profile_data,
                'result': result_data,
            }
            with path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(record, ensure_ascii=False, default=str) + '\n')
            return str(path)
        except Exception:
            return ''
