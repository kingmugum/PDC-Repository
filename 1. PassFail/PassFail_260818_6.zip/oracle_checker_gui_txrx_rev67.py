# -*- coding: utf-8 -*-
"""
oracle_checker_gui_txrx_rev67.py

목적
- Oracle Checker GUI에 "차량 송수신 테스트" 탭을 추가하기 위한 mixin 모듈
- 기존 자동화 가능성 분석/실험 기록을 유지하면서, 독립 Stimulus 모듈을 통해 제한된 실제 입력 PoC를 수행한다.
- 선택 TC 단일 Signal 테스트와 수동 후보 Signal 묶음 테스트 외의 일반 CAN 송신/Replay 자동화는 비활성이다.

기능
- 기존 Excel/DBC 및 CANoe 논리 CAN 설정과 condition_rows를 재사용
- 선택 TC의 입력 조건을 "송신 대상"으로 Preview
- 출력 조건을 "차량 반응 수신/감시 대상"으로 Preview
- DBC 기준 Message/Signal 존재 여부 검사
- CAN1/CAN2/CAN3 채널 매핑 확인
- CRC/Alive/Counter류 Signal 포함 여부를 탐지하여 "확인 필요"로 표시
- 일반 송신/Replay 버튼은 안전상 비활성화 상태로 유지한다.
- 실제 입력 PoC는 명시적 Stimulus 활성화 + 확인 팝업을 통과한 제한 경로로만 제공한다.

rev67:
- rev49 차량 송수신 테스트 탭/실험 관리 기능을 그대로 유지
- 일반 CANoe 송신/Replay 자동화는 계속 비활성
- 실험용 입력 1회 테스트만 oracle_checker_stimulus_rev67.py 독립 모듈을 선택적으로 호출
- Stimulus 모듈 부재/오류가 기존 단일/다중 Pass/Fail 기능에 영향을 주지 않도록 optional import
- 기존 선택-TC 입력은 단일 Signal 1회 PoC로 유지하며 원래 Signal 값으로 반드시 원복
- rev67은 회사 Excel 등에서 복사한 후보 Signal 1~8개를 수동 붙여넣기하여 묶음 1회 테스트하는 기능을 추가
- 수동 후보 묶음은 모든 Signal을 사전검증한 뒤 적용하고, 실제 write된 모든 Signal을 finally에서 원래 값으로 복원
- CRC/Alive/Counter는 자동 계산하지 않으며, DBC에서 감지되면 기본 차단하고 사용자가 경고 허용을 명시한 경우에만 정적 값 시험을 허용
- Vector CANoe/CANalyzer COM 진단 기능은 공통 onebyone/main rev67에서 제공
- TX/RX 탭은 rev67 공통 Notebook X/Y scroll wrapper를 사용하여 가로/세로 전체 스크롤을 지원한다.
- rev60 전용 TX/RX bind_all은 제거하고 공통 active-tab wheel handler를 사용하여 중복 스크롤을 방지한다.
"""

from __future__ import annotations

import atexit
import csv
import datetime as _dt
import json
import queue
import re
import shutil
import sys
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter.scrolledtext import ScrolledText

sys.dont_write_bytecode = True


def _cleanup_pycache(base_dir=None):
    try:
        root = Path(base_dir) if base_dir is not None else Path(__file__).resolve().parent
        for p in root.glob("__pycache__"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


_cleanup_pycache()
atexit.register(_cleanup_pycache)

import oracle_checker_gui_onebyone_rev67 as _onebyone

core = _onebyone.core

# rev67: 실험용 실제 입력 엔진은 선택 모듈이다.
# import 실패가 전체 GUI/기존 PassFail을 깨지 않도록 반드시 optional로 유지한다.
try:
    import oracle_checker_stimulus_rev67 as _stimulus
    STIMULUS_AVAILABLE = True
    STIMULUS_IMPORT_ERROR = ""
except Exception as _stimulus_import_error:
    _stimulus = None
    STIMULUS_AVAILABLE = False
    STIMULUS_IMPORT_ERROR = f"{type(_stimulus_import_error).__name__}: {_stimulus_import_error}"


class TxRxTestMixin:
    """차량 송수신 테스트 탭/동작을 추가하는 mixin."""

    TXRX_STATUS_UNCHECKED = "미검사"
    TXRX_STATUS_OK = "가능"
    TXRX_STATUS_WARN = "확인 필요"
    TXRX_STATUS_BAD = "불가"

    TXRX_METHOD_CAN = "CAN Signal 송신 후보"
    TXRX_METHOD_REPLAY = "로그 Replay 후보"
    TXRX_METHOD_PHYSICAL = "물리 입력/릴레이 필요"
    TXRX_METHOD_MANUAL = "수동 확인 필요"
    TXRX_METHOD_EXCLUDE = "초기 자동화 제외"
    TXRX_METHOD_UNKNOWN = "미분류"

    def _build_ui(self):
        super()._build_ui()
        self._init_txrx_state()
        self._build_txrx_tab()
        if not self._txrx_async_poll_started:
            self._txrx_async_poll_started = True
            self.after(100, self._poll_txrx_async_queue)

    def _init_txrx_state(self):
        self.txrx_tab = None
        self.txrx_tree = None
        self.txrx_preview_text = None
        self.txrx_status_text = None
        self.txrx_result_tree = None
        self.txrx_log_text = None
        self.txrx_experiment_tree = None
        self.txrx_experiment_memo_text = None
        self.txrx_scroll_canvas = None
        self.txrx_outer_scrollbar = None
        self.txrx_outer_hscrollbar = None
        self.txrx_scroll_content = None
        self.txrx_scroll_window = None
        self.txrx_inner_scroll_widgets = []
        self.txrx_status_var = tk.StringVar(value="대기중")
        self.txrx_selected_tc_var = tk.StringVar(value="선택 TC: -")
        self.txrx_summary_var = tk.StringVar(value="송신 가능성: 미검사")
        self.txrx_tx_enable_var = tk.BooleanVar(value=False)
        self.txrx_tx_mode_var = tk.StringVar(value="주기 송신")
        self.txrx_period_ms_var = tk.StringVar(value="100")
        self.txrx_duration_mode_var = tk.StringVar(value="수행 완료/중단까지")
        self.txrx_duration_sec_var = tk.StringVar(value="3.0")
        self.txrx_confirm_before_send_var = tk.BooleanVar(value=True)
        self.txrx_auto_stop_var = tk.BooleanVar(value=True)
        self.txrx_wait_sec_var = tk.StringVar(value="30")
        self.txrx_between_tc_delay_var = tk.StringVar(value="1.0")
        self.txrx_fail_policy_var = tk.StringVar(value="Fail 후 다음 TC 진행")
        # rev67: 실제 자동화 가능성을 한땀한땀 검증하기 위한 실험 기록 상태
        self.txrx_experiment_method_var = tk.StringVar(value="수동 기록")
        self.txrx_vehicle_reaction_var = tk.StringVar(value="미확인")
        self.txrx_output_judge_var = tk.StringVar(value="미확인")
        self.txrx_experiment_result_var = tk.StringVar(value="분석필요")
        self.txrx_cause_vars: Dict[str, tk.BooleanVar] = {
            "입력 Signal 부족 의심": tk.BooleanVar(value=False),
            "CRC/Alive 의심": tk.BooleanVar(value=False),
            "사전조건 부족 의심": tk.BooleanVar(value=False),
            "채널/DBC 매핑 의심": tk.BooleanVar(value=False),
            "실제 ECU 중복 송신 의심": tk.BooleanVar(value=False),
            "물리 버튼/릴레이 필요 의심": tk.BooleanVar(value=False),
            "출력 조건 재검토 필요": tk.BooleanVar(value=False),
        }
        self.txrx_experiment_records: List[Dict[str, Any]] = []
        self.txrx_selected_index: Optional[int] = None
        self.txrx_analysis_by_index: Dict[int, Dict[str, Any]] = {}
        # rev67 isolated experimental stimulus state
        self.txrx_stimulus_enable_var = tk.BooleanVar(value=False)
        self.txrx_stimulus_hold_sec_var = tk.StringVar(value="0.5")
        self.txrx_stimulus_status_var = tk.StringVar(
            value="Stimulus: 사용 가능" if STIMULUS_AVAILABLE else "Stimulus: 모듈 없음(기존 P/F 영향 없음)"
        )
        self.txrx_stimulus_stop_event = threading.Event()
        self.txrx_stimulus_thread: Optional[threading.Thread] = None
        # rev67: 현장 Excel에서 후보 Signal을 그대로 복사/붙여넣기하여 시험하기 위한 상태
        self.txrx_manual_candidate_text = None
        self.txrx_manual_candidate_status_var = tk.StringVar(value="수동 후보: 미검증")
        self.txrx_manual_crc_override_var = tk.BooleanVar(value=False)
        # rev67 CAPL frame backend safety gate: actual injection only after user confirms original sender is isolated/disabled.
        self.txrx_canalyzer_source_isolated_var = tk.BooleanVar(value=False)
        # rev67: CANoe direct Signal.Value requires an Interaction Layer signal driver.
        # Actual reverse-send tests default to CAPL frame output so a missing signal driver does not create a false success.
        self.txrx_canoe_backend_var = tk.StringVar(value="CAPL Frame (권장)")
        self.txrx_stop_measurement_after_stimulus_var = tk.BooleanVar(value=True)
        self.txrx_autofill_manual_from_selection_var = tk.BooleanVar(value=True)
        # rev67: 하나의 Message/Signal이 CAN1~CAN3 여러 DBC에 존재할 수 있으므로
        # 복수 논리 CAN은 오류가 아니라 OR 후보군으로 유지하고 실제 송신 시 1개를 선택한다.
        self.txrx_selected_can_candidate_var = tk.StringVar(value="")
        self.txrx_selected_can_candidate_values: List[str] = []
        self.txrx_selected_can_candidate_status_var = tk.StringVar(value="송신 CAN 후보: TC 선택 필요")
        self.txrx_selected_can_combobox = None
        # rev67: DBC 분석 캐시 / 비동기 전체검사 / 수동 후보 검증 캐시
        self.txrx_dbc_cache_signature = None
        self.txrx_dbc_cache_by_ch: Dict[int, Any] = {}
        self.txrx_all_check_thread: Optional[threading.Thread] = None
        self.txrx_check_all_button = None
        self.txrx_manual_validation_cache: Optional[Dict[str, Any]] = None
        self.txrx_async_queue: queue.Queue = queue.Queue()
        self._txrx_async_poll_started = False

    def _build_txrx_tab(self):
        if self.notebook is None:
            return

        # rev67: TX/RX도 다른 탭과 동일한 공통 X/Y scroll wrapper를 사용한다.
        # rev59~60의 전용 세로 Canvas를 공통 wrapper로 흡수하여 가로 스크롤까지 제공한다.
        self.txrx_tab, self.txrx_scroll_content = self._create_scrollable_notebook_tab(
            "차량 송수신 테스트", padding=6
        )
        _scroll_info = self._tab_scroll_registry.get(str(self.txrx_tab), {})
        self.txrx_scroll_canvas = _scroll_info.get("canvas")
        self.txrx_outer_scrollbar = _scroll_info.get("vbar")
        self.txrx_outer_hscrollbar = _scroll_info.get("hbar")
        self.txrx_scroll_window = _scroll_info.get("window")

        parent = self.txrx_scroll_content
        parent.columnconfigure(0, weight=1)

        # 1) 상단 TC 목록
        list_frame = ttk.LabelFrame(parent, text="TC 목록 / 송신 가능성 목록")
        list_frame.grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 6))
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)

        columns = ("tc_no", "subcategory", "input", "output", "method", "feasibility", "experiment", "reason")
        self.txrx_tree = ttk.Treeview(list_frame, columns=columns, show="headings", selectmode="browse", height=12)
        headings = {
            "tc_no": "TC 번호",
            "subcategory": "소분류",
            "input": "입력 송신 대상",
            "output": "출력 감시 대상",
            "method": "자동화 방식 추천",
            "feasibility": "프리테스트 적합성",
            "experiment": "최근 실험결과",
            "reason": "진단 사유",
        }
        widths = {
            "tc_no": 90,
            "subcategory": 180,
            "input": 430,
            "output": 430,
            "method": 170,
            "feasibility": 120,
            "experiment": 120,
            "reason": 520,
        }
        anchors = {"tc_no": "center", "method": "center", "feasibility": "center", "experiment": "center"}
        for c in columns:
            self.txrx_tree.heading(c, text=headings[c])
            self.txrx_tree.column(c, width=widths[c], anchor=anchors.get(c, "w"), stretch=True)

        self.txrx_tree.tag_configure("unchecked", background="#FFFFFF", foreground="#111827")
        self.txrx_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_tree.tag_configure("bad", background="#FEE2E2", foreground="#991B1B")
        self.txrx_tree.tag_configure("selected", background="#DBEAFE", foreground="#111827")

        yscroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.txrx_tree.yview)
        xscroll = ttk.Scrollbar(list_frame, orient="horizontal", command=self.txrx_tree.xview)
        self.txrx_tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.txrx_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        self.txrx_tree.bind("<<TreeviewSelect>>", self._on_txrx_tree_select, add="+")
        self.txrx_tree.bind("<ButtonRelease-1>", self._on_txrx_tree_click, add="+")

        # 2) 중단 Preview + 설정/버튼
        middle = ttk.Frame(parent)
        middle.grid(row=1, column=0, sticky="nsew", padx=0, pady=(0, 6))
        middle.columnconfigure(0, weight=7)
        middle.columnconfigure(1, weight=4)
        middle.rowconfigure(0, weight=1)

        preview_frame = ttk.LabelFrame(middle, text="선택 TC 입력 송신 Preview")
        preview_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        self.txrx_preview_text = ScrolledText(preview_frame, height=16, wrap=tk.WORD)
        self.txrx_preview_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.txrx_preview_text.insert("1.0", "TC를 선택하면 입력 송신 대상과 출력 감시 대상 Preview가 표시됩니다.\n")

        control_frame = ttk.LabelFrame(middle, text="송신 설정 / 실행 버튼")
        control_frame.grid(row=0, column=1, sticky="nsew")
        for c in range(4):
            control_frame.columnconfigure(c, weight=1)

        warn_text = (
            "rev67은 기존 Pass/Fail과 분리된 실험용 Stimulus 모듈 PoC를 포함합니다.\n"
            "CANoe 실제 역송신은 CAPL Frame output()을 기본 권장합니다. Signal.Value 방식은 CANoe Interaction Layer signal driver가 있을 때만 실제 Frame 송신이 보장됩니다.\n"
            "Write 창에 01-0083 'no signal driver is available'가 보이면 Signal.Value가 아니라 Vector CAPL Bridge를 사용하세요. "
            "CAPL Frame 실제 송신 전에는 동일 Message 기존 송신원 분리·비활성 확인이 필수입니다."
        )
        tk.Label(
            control_frame,
            text=warn_text,
            anchor="w",
            justify="left",
            bg="#FEF3C7",
            fg="#92400E",
            padx=8,
            pady=6,
            font=("맑은 고딕", 9, "bold"),
        ).grid(row=0, column=0, columnspan=4, sticky="ew", padx=6, pady=(6, 4))

        ttk.Checkbutton(control_frame, text="입력 신호 송신 사용", variable=self.txrx_tx_enable_var, state="disabled").grid(
            row=1, column=0, columnspan=2, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="송신 방식").grid(row=2, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_tx_mode_var,
            values=["1회 송신", "주기 송신"],
            state="disabled",
            width=14,
        ).grid(row=2, column=1, sticky="w", padx=6, pady=3)
        ttk.Label(control_frame, text="송신 주기(ms)").grid(row=2, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_period_ms_var, width=10, state="disabled").grid(
            row=2, column=3, sticky="w", padx=6, pady=3
        )

        ttk.Label(control_frame, text="송신 지속시간").grid(row=3, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_duration_mode_var,
            values=["출력 PASS까지", "지정 시간", "수행 완료/중단까지"],
            state="disabled",
            width=18,
        ).grid(row=3, column=1, sticky="w", padx=6, pady=3)
        ttk.Label(control_frame, text="지정 시간(sec)").grid(row=3, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_duration_sec_var, width=10, state="disabled").grid(
            row=3, column=3, sticky="w", padx=6, pady=3
        )

        ttk.Checkbutton(control_frame, text="송신 전 확인 팝업 표시", variable=self.txrx_confirm_before_send_var, state="disabled").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=6, pady=3
        )
        ttk.Checkbutton(control_frame, text="수행 완료/중단 시 송신 자동 정지", variable=self.txrx_auto_stop_var, state="disabled").grid(
            row=4, column=2, columnspan=2, sticky="w", padx=6, pady=3
        )

        ttk.Label(control_frame, text="각 TC 출력 대기(sec)").grid(row=5, column=0, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_wait_sec_var, width=10, state="disabled").grid(
            row=5, column=1, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="TC 간 대기(sec)").grid(row=5, column=2, sticky="w", padx=6, pady=3)
        ttk.Entry(control_frame, textvariable=self.txrx_between_tc_delay_var, width=10, state="disabled").grid(
            row=5, column=3, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, text="Fail 처리 기준").grid(row=6, column=0, sticky="w", padx=6, pady=3)
        ttk.Combobox(
            control_frame,
            textvariable=self.txrx_fail_policy_var,
            values=["Fail 후 다음 TC 진행", "Fail 시 전체 중단"],
            state="disabled",
            width=18,
        ).grid(row=6, column=1, columnspan=2, sticky="w", padx=6, pady=3)

        button_row = ttk.Frame(control_frame)
        button_row.grid(row=7, column=0, columnspan=4, sticky="ew", padx=6, pady=(8, 4))
        for c in range(5):
            button_row.columnconfigure(c, weight=1)
        ttk.Button(button_row, text="TC 목록 새로고침", command=self._refresh_txrx_tree).grid(
            row=0, column=0, sticky="ew", padx=(0, 4)
        )
        ttk.Button(button_row, text="선택 TC 검사", command=self._check_txrx_selected).grid(
            row=0, column=1, sticky="ew", padx=4
        )
        self.txrx_check_all_button = ttk.Button(button_row, text="전체 가능성 검사", command=self._check_txrx_all)
        self.txrx_check_all_button.grid(row=0, column=2, sticky="ew", padx=4)
        ttk.Button(button_row, text="입력 1회 테스트", command=self._txrx_stimulus_test_once).grid(
            row=0, column=3, sticky="ew", padx=4
        )
        ttk.Button(button_row, text="입력 즉시 원복/중단", command=self._txrx_stop_stimulus).grid(
            row=0, column=4, sticky="ew", padx=(4, 0)
        )
        ttk.Checkbutton(
            button_row, text="실험용 Stimulus 사용(명시적 활성화)", variable=self.txrx_stimulus_enable_var
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=(0, 4), pady=(6, 0))
        ttk.Label(button_row, text="Hold(sec)").grid(row=1, column=2, sticky="e", padx=4, pady=(6, 0))
        ttk.Entry(button_row, textvariable=self.txrx_stimulus_hold_sec_var, width=8).grid(
            row=1, column=3, sticky="w", padx=4, pady=(6, 0)
        )
        ttk.Label(button_row, textvariable=self.txrx_stimulus_status_var).grid(
            row=1, column=4, sticky="w", padx=(4, 0), pady=(6, 0)
        )

        tk.Label(
            control_frame,
            textvariable=self.txrx_status_var,
            anchor="center",
            relief="solid",
            bd=1,
            bg="#E5E7EB",
            fg="#111827",
            padx=8,
            pady=6,
            font=("맑은 고딕", 11, "bold"),
        ).grid(row=8, column=0, columnspan=4, sticky="ew", padx=6, pady=(8, 3))
        ttk.Label(control_frame, textvariable=self.txrx_selected_tc_var).grid(
            row=9, column=0, columnspan=4, sticky="w", padx=6, pady=3
        )
        ttk.Label(control_frame, textvariable=self.txrx_summary_var).grid(
            row=10, column=0, columnspan=4, sticky="w", padx=6, pady=(3, 6)
        )

        # rev67: 회사 Excel 등에서 후보 Signal 여러 행을 직접 붙여넣어 시험하는 독립 실험 영역
        candidate_frame = ttk.LabelFrame(control_frame, text="수동 후보 Signal 묶음 테스트 (rev67 / TC OR-CAN 선택 지원)")
        candidate_frame.grid(row=11, column=0, columnspan=4, sticky="ew", padx=6, pady=(4, 6))
        candidate_frame.columnconfigure(0, weight=1)
        ttk.Label(
            candidate_frame,
            text="Excel에서 4열을 복사해 붙여넣기: CAN1 | Message | Signal | ActiveValue  (1~8행)",
        ).grid(row=0, column=0, sticky="w", padx=5, pady=(4, 2))
        self.txrx_manual_candidate_text = ScrolledText(candidate_frame, height=7, wrap=tk.NONE)
        self.txrx_manual_candidate_text.grid(row=1, column=0, sticky="ew", padx=5, pady=3)
        candidate_buttons = ttk.Frame(candidate_frame)
        candidate_buttons.grid(row=2, column=0, sticky="ew", padx=5, pady=(2, 5))
        for c in range(4):
            candidate_buttons.columnconfigure(c, weight=1)
        ttk.Button(candidate_buttons, text="형식 예시", command=self._txrx_manual_candidate_example).grid(
            row=0, column=0, sticky="ew", padx=(0, 3)
        )
        ttk.Button(candidate_buttons, text="후보 검증", command=self._txrx_validate_manual_candidates_ui).grid(
            row=0, column=1, sticky="ew", padx=3
        )
        ttk.Button(candidate_buttons, text="후보 묶음 1회 테스트", command=self._txrx_manual_candidate_test_once).grid(
            row=0, column=2, sticky="ew", padx=3
        )
        ttk.Label(candidate_buttons, textvariable=self.txrx_manual_candidate_status_var).grid(
            row=0, column=3, sticky="w", padx=(3, 0)
        )
        ttk.Button(
            candidate_buttons, text="Vector CAPL Bridge 생성", command=self._txrx_generate_canalyzer_capl_bridge
        ).grid(row=1, column=0, columnspan=2, sticky="ew", padx=(0, 3), pady=(4, 0))
        ttk.Label(
            candidate_buttons, text="CANoe/CANalyzer 해당 CAN의 SEND/Simulation branch에 수동 삽입 → Compile → Measurement 재시작"
        ).grid(row=1, column=2, columnspan=2, sticky="w", padx=3, pady=(4, 0))
        ttk.Checkbutton(
            candidate_frame,
            text="상단 TC 클릭 시 입력 송신 후보 자동 채우기",
            variable=self.txrx_autofill_manual_from_selection_var,
        ).grid(row=3, column=0, sticky="w", padx=5, pady=(0, 3))

        or_can_row = ttk.Frame(candidate_frame)
        or_can_row.grid(row=4, column=0, sticky="ew", padx=5, pady=(0, 4))
        ttk.Label(or_can_row, text="선택 TC 송신 CAN (OR 후보)").pack(side=tk.LEFT)
        self.txrx_selected_can_combobox = ttk.Combobox(
            or_can_row,
            textvariable=self.txrx_selected_can_candidate_var,
            values=[],
            state="readonly",
            width=12,
        )
        self.txrx_selected_can_combobox.pack(side=tk.LEFT, padx=(6, 10))
        self.txrx_selected_can_combobox.bind(
            "<<ComboboxSelected>>", self._on_txrx_selected_can_candidate_changed, add="+"
        )
        ttk.Label(or_can_row, textvariable=self.txrx_selected_can_candidate_status_var).pack(side=tk.LEFT)

        ttk.Checkbutton(
            candidate_frame,
            text="CRC/Alive/Counter 경고가 있어도 시험 허용 (자동 계산 안 함 / 정적 값만 사용)",
            variable=self.txrx_manual_crc_override_var,
        ).grid(row=5, column=0, sticky="w", padx=5, pady=(0, 3))
        ttk.Checkbutton(
            candidate_frame,
            text="CAPL Frame 실제 송신 전: 동일 Message 기존 송신원(ECU/Generator) 분리·비활성 확인",
            variable=self.txrx_canalyzer_source_isolated_var,
        ).grid(row=6, column=0, sticky="w", padx=5, pady=(0, 3))
        backend_row = ttk.Frame(candidate_frame)
        backend_row.grid(row=7, column=0, sticky="ew", padx=5, pady=(0, 5))
        ttk.Label(backend_row, text="CANoe 송신 방식").pack(side=tk.LEFT)
        ttk.Combobox(
            backend_row, textvariable=self.txrx_canoe_backend_var,
            values=["CAPL Frame (권장)", "Signal.Value (IL driver 필요)"], state="readonly", width=28
        ).pack(side=tk.LEFT, padx=(5, 12))
        ttk.Checkbutton(
            backend_row, text="테스트 완료/원복 후 Measurement Stop",
            variable=self.txrx_stop_measurement_after_stimulus_var,
        ).pack(side=tk.LEFT)

        # rev67: 실제 자동화 가능성을 하나씩 검증하기 위한 실험 결과 기록 영역
        experiment_frame = ttk.LabelFrame(control_frame, text="실험 결과 기록(수동)")
        experiment_frame.grid(row=12, column=0, columnspan=4, sticky="ew", padx=6, pady=(4, 6))
        for c in range(4):
            experiment_frame.columnconfigure(c, weight=1)

        ttk.Label(experiment_frame, text="실험 방식").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_experiment_method_var,
            values=["수동 기록", "CAN Signal 송신 후보", "로그 Replay 후보", "CAPL 송신 후보", "물리 입력/릴레이 필요"],
            state="readonly",
            width=20,
        ).grid(row=0, column=1, sticky="ew", padx=5, pady=3)
        ttk.Label(experiment_frame, text="차량 실제 반응").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_vehicle_reaction_var,
            values=["미확인", "움직임 확인", "움직임 없음", "일부 반응", "판단 불가"],
            state="readonly",
            width=14,
        ).grid(row=0, column=3, sticky="ew", padx=5, pady=3)

        ttk.Label(experiment_frame, text="출력 Signal 판정").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_output_judge_var,
            values=["미확인", "PASS", "FAIL", "N/A"],
            state="readonly",
            width=14,
        ).grid(row=1, column=1, sticky="ew", padx=5, pady=3)
        ttk.Label(experiment_frame, text="최종 실험 결과").grid(row=1, column=2, sticky="w", padx=5, pady=3)
        ttk.Combobox(
            experiment_frame,
            textvariable=self.txrx_experiment_result_var,
            values=["OK", "NG", "PARTIAL", "수동필요", "Replay권장", "릴레이필요", "분석필요", "초기제외"],
            state="readonly",
            width=14,
        ).grid(row=1, column=3, sticky="ew", padx=5, pady=3)

        cause_frame = ttk.Frame(experiment_frame)
        cause_frame.grid(row=2, column=0, columnspan=4, sticky="ew", padx=5, pady=(3, 1))
        for i in range(4):
            cause_frame.columnconfigure(i, weight=1)
        for i, (label, var) in enumerate(self.txrx_cause_vars.items()):
            ttk.Checkbutton(cause_frame, text=label, variable=var).grid(
                row=i // 4, column=i % 4, sticky="w", padx=3, pady=1
            )

        ttk.Label(experiment_frame, text="실험 메모").grid(row=4, column=0, sticky="nw", padx=5, pady=(4, 3))
        self.txrx_experiment_memo_text = ScrolledText(experiment_frame, height=4, wrap=tk.WORD)
        self.txrx_experiment_memo_text.grid(row=4, column=1, columnspan=3, sticky="ew", padx=5, pady=(4, 3))

        experiment_buttons = ttk.Frame(experiment_frame)
        experiment_buttons.grid(row=5, column=0, columnspan=4, sticky="ew", padx=5, pady=(3, 5))
        for c in range(4):
            experiment_buttons.columnconfigure(c, weight=1)
        ttk.Button(experiment_buttons, text="실험 기록 저장", command=self._save_txrx_experiment_record).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(experiment_buttons, text="기록 CSV 저장", command=self._export_txrx_experiment_csv).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(experiment_buttons, text="입력 초기화", command=self._clear_txrx_experiment_inputs).grid(row=0, column=2, sticky="ew", padx=4)
        ttk.Button(experiment_buttons, text="기록 전체 초기화", command=self._reset_txrx_experiment_records).grid(row=0, column=3, sticky="ew", padx=(4, 0))

        # 3) 하단 상태/수신 결과
        lower = ttk.Frame(parent)
        lower.grid(row=2, column=0, sticky="nsew", padx=0, pady=(0, 6))
        lower.columnconfigure(0, weight=4)
        lower.columnconfigure(1, weight=7)
        lower.rowconfigure(0, weight=1)

        status_frame = ttk.LabelFrame(lower, text="송신 상태 / 실험 기록")
        status_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        status_frame.columnconfigure(0, weight=1)
        status_frame.rowconfigure(0, weight=1)
        status_frame.rowconfigure(1, weight=1)
        self.txrx_status_text = ScrolledText(status_frame, height=6, wrap=tk.WORD)
        self.txrx_status_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=(6, 3))
        self.txrx_status_text.insert(
            "1.0",
            "상태: 대기중\nrev67 일반 송신/Replay 자동화는 비활성입니다.\n"
            "선택 TC의 단일 입력 Signal에 한해 독립 Stimulus 모듈로 1회 시험 가능하며 실행 후 시작 전 값으로 원복합니다.\n",
        )

        exp_cols = ("time", "tc", "method", "reaction", "judge", "result")
        self.txrx_experiment_tree = ttk.Treeview(status_frame, columns=exp_cols, show="headings", height=7)
        exp_heads = {
            "time": "시각", "tc": "TC", "method": "방식", "reaction": "실제반응",
            "judge": "출력판정", "result": "실험결과"
        }
        exp_widths = {"time": 80, "tc": 80, "method": 130, "reaction": 90, "judge": 80, "result": 90}
        for c in exp_cols:
            self.txrx_experiment_tree.heading(c, text=exp_heads[c])
            self.txrx_experiment_tree.column(c, width=exp_widths[c], anchor="center", stretch=True)
        self.txrx_experiment_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_experiment_tree.tag_configure("ng", background="#FEE2E2", foreground="#991B1B")
        self.txrx_experiment_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_experiment_tree.tag_configure("neutral", background="#F9FAFB", foreground="#111827")
        self.txrx_experiment_tree.grid(row=1, column=0, sticky="nsew", padx=6, pady=(3, 6))

        result_frame = ttk.LabelFrame(lower, text="차량 출력 수신 결과 Preview")
        result_frame.grid(row=0, column=1, sticky="nsew")
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)
        rcols = ("kind", "message", "signal", "expected", "channel", "status", "reason")
        self.txrx_result_tree = ttk.Treeview(result_frame, columns=rcols, show="headings", height=12)
        rheads = {
            "kind": "구분",
            "message": "Message",
            "signal": "Signal",
            "expected": "Expected",
            "channel": "Channel 후보",
            "status": "상태",
            "reason": "사유",
        }
        rwidths = {
            "kind": 70,
            "message": 180,
            "signal": 260,
            "expected": 100,
            "channel": 120,
            "status": 90,
            "reason": 380,
        }
        for c in rcols:
            self.txrx_result_tree.heading(c, text=rheads[c])
            self.txrx_result_tree.column(c, width=rwidths[c], anchor="center" if c in ("kind", "expected", "channel", "status") else "w", stretch=True)
        self.txrx_result_tree.tag_configure("ok", background="#DCFCE7", foreground="#166534")
        self.txrx_result_tree.tag_configure("warn", background="#FEF3C7", foreground="#92400E")
        self.txrx_result_tree.tag_configure("bad", background="#FEE2E2", foreground="#991B1B")
        self.txrx_result_tree.grid(row=0, column=0, sticky="nsew")
        rscroll = ttk.Scrollbar(result_frame, orient="vertical", command=self.txrx_result_tree.yview)
        self.txrx_result_tree.configure(yscrollcommand=rscroll.set)
        rscroll.grid(row=0, column=1, sticky="ns")

        # 4) 맨 아래 실행 로그
        log_frame = ttk.LabelFrame(parent, text="TX/RX 실행 로그")
        log_frame.grid(row=3, column=0, sticky="nsew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.txrx_log_text = ScrolledText(log_frame, height=10, wrap=tk.WORD)
        self.txrx_log_text.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self._txrx_log(f"[TXRX] rev67 초기화: Stimulus optional module={STIMULUS_AVAILABLE}. 모듈 부재/오류는 기존 P/F에 영향 없음.\n")

        # rev67: TX/RX 전체 세로 스크롤에 마우스 휠을 연결한다.
        # 내부 Treeview/ScrolledText가 실제로 더 스크롤될 수 있으면 내부를 우선하고,
        # 내부 스크롤이 끝에 도달했거나 내용이 짧으면 outer Canvas로 자연스럽게 넘긴다.
        self.txrx_inner_scroll_widgets = [
            w for w in (
                self.txrx_tree,
                self.txrx_preview_text,
                self.txrx_manual_candidate_text,
                self.txrx_experiment_memo_text,
                self.txrx_status_text,
                self.txrx_experiment_tree,
                self.txrx_result_tree,
                self.txrx_log_text,
            ) if w is not None
        ]
        self._bind_txrx_mousewheel()

        self._refresh_txrx_tree()

    def _txrx_widget_is_descendant(self, widget, ancestor) -> bool:
        current = widget
        while current is not None:
            if current is ancestor:
                return True
            current = getattr(current, "master", None)
        return False

    def _txrx_tab_is_active(self) -> bool:
        try:
            return self.notebook is not None and self.txrx_tab is not None and self.notebook.select() == str(self.txrx_tab)
        except Exception:
            return False

    def _txrx_mousewheel_units(self, event) -> int:
        # Windows/macOS: <MouseWheel> delta. X11/Linux: Button-4/5.
        num = getattr(event, "num", None)
        if num == 4:
            return -3
        if num == 5:
            return 3

        delta = int(getattr(event, "delta", 0) or 0)
        if delta == 0:
            return 0
        notches = max(1, min(4, abs(delta) // 120 if abs(delta) >= 120 else 1))
        return (-3 if delta > 0 else 3) * notches

    def _scroll_txrx_outer(self, units: int):
        if units == 0 or self.txrx_scroll_canvas is None:
            return
        try:
            self.txrx_scroll_canvas.yview_scroll(int(units), "units")
        except Exception:
            pass

    def _on_txrx_inner_mousewheel(self, event, widget=None):
        if not self._txrx_tab_is_active():
            return None
        target = widget or getattr(event, "widget", None)
        units = self._txrx_mousewheel_units(event)
        if target is None or units == 0:
            return "break"

        # yview()=(first,last). 해당 방향으로 내부에 더 볼 내용이 있으면 내부를 우선한다.
        try:
            first, last = target.yview()
            direction_down = units > 0
            can_scroll_inner = (last < 0.999999) if direction_down else (first > 0.000001)
        except Exception:
            can_scroll_inner = False

        if can_scroll_inner:
            try:
                target.yview_scroll(units, "units")
            except Exception:
                pass
        else:
            self._scroll_txrx_outer(units)
        return "break"

    def _on_txrx_outer_mousewheel(self, event):
        if not self._txrx_tab_is_active() or self.txrx_tab is None:
            return None
        widget = getattr(event, "widget", None)
        if widget is None or not self._txrx_widget_is_descendant(widget, self.txrx_tab):
            return None
        units = self._txrx_mousewheel_units(event)
        if units == 0:
            return None
        self._scroll_txrx_outer(units)
        return "break"

    def _bind_txrx_mousewheel(self):
        """rev67: 공통 Notebook wheel handler가 모든 탭을 담당한다.

        기존 rev60 전용 bind_all을 중복 등록하면 TX/RX에서 outer가 두 번 움직일 수 있으므로
        이 호환 메서드는 의도적으로 별도 binding을 추가하지 않는다.
        """
        return

    def _poll_txrx_async_queue(self):
        try:
            while True:
                item = self.txrx_async_queue.get_nowait()
                kind = item[0]
                if kind == "ALL_PROGRESS":
                    self.txrx_status_var.set(f"전체 가능성 검사 중: {item[1]}/{item[2]}")
                elif kind == "ALL_DONE":
                    self._finish_txrx_all_check(item[1], item[2], item[3], item[4], item[5])
                elif kind == "ALL_ERROR":
                    self._finish_txrx_all_check_error(item[1])
                elif kind == "MANUAL_DONE":
                    self._finish_txrx_manual_stimulus(item[1])
                elif kind == "MANUAL_ERROR":
                    self._finish_txrx_manual_stimulus_error(item[1])
                elif kind == "SINGLE_DONE":
                    self._finish_txrx_stimulus(item[1])
                elif kind == "SINGLE_ERROR":
                    self._finish_txrx_stimulus_worker_error(item[1])
        except queue.Empty:
            pass
        try:
            self.after(100, self._poll_txrx_async_queue)
        except Exception:
            pass

    def _load_conditions(self):
        super()._load_conditions()
        self.txrx_selected_index = None
        self.txrx_analysis_by_index.clear()
        self.txrx_manual_validation_cache = None
        self._refresh_txrx_tree()
        self._show_txrx_preview(None)

    def _short_expectations_text(self, expectations: List[Any], max_items: int = 2) -> str:
        items = []
        for exp in expectations or []:
            items.append(f"{exp.message}:{exp.signal}={exp.expected_value_raw}")
        if len(items) > max_items:
            return " / ".join(items[:max_items]) + f" / ... +{len(items) - max_items}"
        return " / ".join(items) if items else "-"

    def _latest_txrx_experiment_record(self, idx: int) -> Optional[Dict[str, Any]]:
        for record in reversed(self.txrx_experiment_records):
            if record.get("row_index") == idx:
                return record
        return None

    def _latest_txrx_experiment_result_text(self, idx: int) -> str:
        record = self._latest_txrx_experiment_record(idx)
        if not record:
            return "-"
        return str(record.get("final_result") or "-")

    def _refresh_txrx_tree(self):
        if self.txrx_tree is None:
            return
        self.txrx_tree.delete(*self.txrx_tree.get_children())
        for idx, row in enumerate(getattr(self, "condition_rows", [])):
            if not row.is_valid or row.condition is None:
                continue
            c = row.condition
            analysis = self.txrx_analysis_by_index.get(idx, {})
            status = analysis.get("status") or self.TXRX_STATUS_UNCHECKED
            reason = analysis.get("summary") or "프리테스트 분류/송신 가능성 검사를 수행하지 않았습니다."
            method = analysis.get("method") or self.TXRX_METHOD_UNKNOWN
            tag = "unchecked"
            if idx == self.txrx_selected_index:
                tag = "selected"
            elif status == self.TXRX_STATUS_OK:
                tag = "ok"
            elif status == self.TXRX_STATUS_WARN:
                tag = "warn"
            elif status == self.TXRX_STATUS_BAD:
                tag = "bad"
            self.txrx_tree.insert(
                "",
                tk.END,
                iid=str(idx),
                tags=(tag,),
                values=(
                    c.tc_no,
                    c.subcategory,
                    self._short_expectations_text(c.input_conditions),
                    self._short_expectations_text(c.output_conditions),
                    method,
                    status,
                    self._latest_txrx_experiment_result_text(idx),
                    reason,
                ),
            )

    def _on_txrx_tree_select(self, event=None):
        if self.txrx_tree is None:
            return
        sel = self.txrx_tree.selection()
        if not sel:
            return
        try:
            idx = int(sel[0])
        except Exception:
            return
        self.txrx_selected_index = idx
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)
        self._txrx_autofill_manual_candidate_from_selected(silent=True)

    def _on_txrx_tree_click(self, event=None):
        if self.txrx_tree is None:
            return
        row_id = self.txrx_tree.identify_row(getattr(event, "y", 0)) if event is not None else ""
        if not row_id:
            return
        try:
            idx = int(row_id)
        except Exception:
            return
        self.txrx_selected_index = idx
        self.txrx_tree.selection_set(row_id)
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)
        self._txrx_autofill_manual_candidate_from_selected(silent=False)

    def _get_txrx_selected_condition(self):
        idx = self.txrx_selected_index
        if idx is None:
            return None, None
        if 0 <= idx < len(getattr(self, "condition_rows", [])):
            row = self.condition_rows[idx]
            if row.is_valid and row.condition is not None:
                return idx, row.condition
        return None, None

    def _txrx_log(self, text: str):
        if self.txrx_log_text is not None:
            self.txrx_log_text.insert(tk.END, text)
            self.txrx_log_text.see(tk.END)
        try:
            self._log(text)
        except Exception:
            pass

    def _ch_label_for_int(self, ch: int) -> str:
        return f"CAN{int(ch)}"

    def _txrx_dbc_mapping_signature(self, mapping: Dict[int, str]) -> Tuple[Any, ...]:
        parts = []
        for ch, raw_path in sorted((mapping or {}).items(), key=lambda x: int(x[0])):
            path = Path(str(raw_path))
            try:
                stat = path.stat()
                parts.append((int(ch), str(path.resolve()), int(stat.st_mtime_ns), int(stat.st_size)))
            except Exception:
                parts.append((int(ch), str(path), None, None))
        return tuple(parts)

    def _get_txrx_cached_dbc_map(self):
        """rev67: 동일 DBC를 TC마다 재로딩하지 않고 mapping signature 기준으로 재사용한다."""
        mapping = self._collect_dbc_mapping()
        signature = self._txrx_dbc_mapping_signature(mapping)
        if signature and signature == self.txrx_dbc_cache_signature and self.txrx_dbc_cache_by_ch:
            return mapping, self.txrx_dbc_cache_by_ch, signature, True
        db_by_ch = core.load_dbc_map(mapping) if mapping else {}
        self.txrx_dbc_cache_signature = signature
        self.txrx_dbc_cache_by_ch = db_by_ch
        return mapping, db_by_ch, signature, False

    def _txrx_pf_worker_busy_reason(self) -> str:
        """Stimulus 실제 송신 전 기존 단일/다중 판정 worker가 완전히 종료되었는지 확인한다."""
        checks = [
            ("단일 TC", getattr(self, "monitor_thread", None)),
            ("다중 TC", getattr(self, "multi_monitor_thread", None)),
        ]
        busy = [name for name, thread in checks if thread is not None and getattr(thread, "is_alive", lambda: False)()]
        if busy:
            return ", ".join(busy) + " 종료 처리 중"
        return ""

    def _manual_profile_fingerprint(self, profile) -> str:
        try:
            payload = profile.to_dict()
        except Exception:
            payload = str(profile)
        try:
            mapping = self._collect_dbc_mapping()
            signature = self._txrx_dbc_mapping_signature(mapping)
        except Exception:
            signature = ()
        try:
            product_pref = self.vector_product_var.get().strip()
            bus_name = self.bus_name_var.get().strip()
        except Exception:
            product_pref, bus_name = "", ""
        return json.dumps(
            {"profile": payload, "dbc": signature, "vector_product": product_pref, "bus_name": bus_name,
             "canoe_backend": self._canoe_backend_mode_key()},
            ensure_ascii=False, sort_keys=True, default=str
        )

    def _find_expectation_locations(self, db_by_ch: Dict[int, Any], expectation: Any) -> List[Dict[str, Any]]:
        matches: List[Dict[str, Any]] = []
        msg_name = str(getattr(expectation, "message", "") or "").strip()
        sig_name = str(getattr(expectation, "signal", "") or "").strip()
        if not msg_name or not sig_name:
            return matches
        for ch, db in sorted((db_by_ch or {}).items(), key=lambda x: int(x[0])):
            try:
                msg_obj = db.get_message_by_name(msg_name)
            except Exception:
                continue
            signal_obj = None
            try:
                signal_obj = msg_obj.get_signal_by_name(sig_name)
            except Exception:
                try:
                    signal_obj = next((s for s in getattr(msg_obj, "signals", []) if getattr(s, "name", "") == sig_name), None)
                except Exception:
                    signal_obj = None
            matches.append({
                "channel": int(ch),
                "channel_label": self._ch_label_for_int(int(ch)),
                "message": msg_obj,
                "signal": signal_obj,
                "signal_found": signal_obj is not None,
            })
        return matches

    def _message_cycle_ms(self, msg_obj: Any, msg_name: str) -> Optional[int]:
        try:
            cycle = getattr(msg_obj, "cycle_time", None)
            if cycle is not None:
                cycle_int = int(cycle)
                if cycle_int > 0:
                    return cycle_int
        except Exception:
            pass
        m = re.search(r"(?:^|[_\-])(?P<ms>\d{1,5})\s*ms(?:$|[_\-])", str(msg_name or ""), re.IGNORECASE)
        if m:
            try:
                return int(m.group("ms"))
            except Exception:
                pass
        return None

    def _detect_crc_alive_signals(self, msg_obj: Any) -> List[str]:
        suspicious: List[str] = []
        keywords = ("crc", "checksum", "chksum", "alive", "alv", "counter", "rolling")
        try:
            for sig in getattr(msg_obj, "signals", []) or []:
                name = str(getattr(sig, "name", "") or "")
                low = name.lower()
                if any(k in low for k in keywords):
                    suspicious.append(name)
        except Exception:
            pass
        return suspicious

    def _condition_text_blob(self, condition: Any) -> str:
        parts: List[str] = [
            str(getattr(condition, "tc_no", "") or ""),
            str(getattr(condition, "subcategory", "") or ""),
            str(getattr(condition, "tc_content", "") or ""),
            str(getattr(condition, "tc_expected_result", "") or ""),
        ]
        for exp in list(getattr(condition, "input_conditions", []) or []) + list(getattr(condition, "output_conditions", []) or []):
            parts.extend([
                str(getattr(exp, "message", "") or ""),
                str(getattr(exp, "signal", "") or ""),
                str(getattr(exp, "expected_value_raw", "") or ""),
            ])
        return " ".join(parts).lower()

    def _is_safety_excluded_tc(self, condition: Any) -> bool:
        text = self._condition_text_blob(condition)
        safety_keywords = (
            "brake", "brk", "steer", "str", "eps", "airbag", "srs", "torque", "tq", "accel", "throttle",
            "shift", "gear", "sbw", "hv", "highvoltage", "charging", "charge", "adas", "aeb", "lkas", "scc",
            "제동", "브레이크", "조향", "스티어", "에어백", "토크", "구동", "가속", "변속", "기어", "고전압", "충전", "운전자보조",
        )
        return any(k in text for k in safety_keywords)

    def _is_physical_or_switch_tc(self, condition: Any) -> bool:
        text = self._condition_text_blob(condition)
        physical_keywords = (
            "seat", "switch", "sw", "button", "btn", "window", "wiper", "mirror", "sunroof", "door", "tailgate",
            "시트", "스위치", "버튼", "윈도우", "와이퍼", "미러", "선루프", "도어", "테일게이트", "물리", "접점",
        )
        return any(k in text for k in physical_keywords)

    def _classify_txrx_method(self, condition: Any, analysis: Dict[str, Any]) -> Tuple[str, str]:
        """차량 송수신 테스트를 전체 자동화가 아닌 예비 프리테스트 관점으로 분류한다."""
        if self._is_safety_excluded_tc(condition):
            return self.TXRX_METHOD_EXCLUDE, "제동/조향/구동/에어백/충전/ADAS 등 안전 영향 가능성이 있어 초기 자동 송신/Replay 대상에서 제외 권장"

        if analysis.get("errors"):
            return self.TXRX_METHOD_MANUAL, "입력 Message/Signal 또는 DBC/채널 정보가 부족하여 자동 자극 구성이 어려움"

        all_input_rows = analysis.get("input_rows", []) or []
        has_crc_alive = any(row.get("crc_alive") for row in all_input_rows)
        has_physical = self._is_physical_or_switch_tc(condition)

        if has_physical and has_crc_alive:
            return self.TXRX_METHOD_PHYSICAL, "버튼/스위치류 물리 입력 가능성과 CRC/Alive 포함 가능성이 있어 릴레이/VT System 또는 실제 조작 로그 Replay 우선 권장"
        if has_physical:
            return self.TXRX_METHOD_PHYSICAL, "버튼/스위치류 TC는 CAN 일부 Signal 송신만으로 실제 조작을 대체하기 어려울 수 있어 물리 입력 자동화 또는 로그 Replay 권장"
        if has_crc_alive:
            return self.TXRX_METHOD_REPLAY, "CRC/Alive/Counter 포함 가능성이 있어 직접 Signal 합성보다 실제 조작 로그 Replay 또는 CAPL 계산 로직 필요"

        if analysis.get("warnings"):
            return self.TXRX_METHOD_REPLAY, "정적 검사상 확인 필요 항목이 있어 우선 로그 Replay 후보로 분류"

        return self.TXRX_METHOD_CAN, "입력 Message/Signal이 DBC에서 확인되며 CRC/Alive 의심 항목이 없어 제한적 CAN Signal 송신 프리테스트 후보"

    def _analyze_condition_txrx(
        self, condition: Any, db_by_ch: Optional[Dict[int, Any]] = None, dbc_mapping: Optional[Dict[int, str]] = None
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "status": self.TXRX_STATUS_UNCHECKED,
            "summary": "",
            "input_rows": [],
            "output_rows": [],
            "details": [],
            "warnings": [],
            "bus_warning": "",
            "errors": [],
            "recommended_period_ms": None,
            "method": self.TXRX_METHOD_UNKNOWN,
            "method_reason": "",
            "pretest_meaning": "자동 예비 프리테스트는 가능한 TC만 선별하기 위한 참고 결과이며, 자동 FAIL은 기능 FAIL 확정이 아닙니다.",
        }

        if dbc_mapping is None:
            try:
                dbc_mapping = self._collect_dbc_mapping()
            except Exception as e:
                result["status"] = self.TXRX_STATUS_BAD
                result["summary"] = f"DBC/논리 CAN 설정 수집 실패: {e}"
                result["errors"].append(result["summary"])
                result["method"] = self.TXRX_METHOD_MANUAL
                result["method_reason"] = "DBC 설정을 먼저 보완해야 합니다."
                return result

        if not dbc_mapping:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = "유효한 DBC/논리 CAN 매핑이 없습니다. 설정 탭에서 CAN1/2/3의 DBC를 지정하세요."
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "DBC/논리 CAN 매핑이 없어 자동 프리테스트 분류가 불가합니다."
            return result

        if db_by_ch is None:
            try:
                _mapping, db_by_ch, _sig, _cached = self._get_txrx_cached_dbc_map()
            except Exception as e:
                result["status"] = self.TXRX_STATUS_BAD
                result["summary"] = f"DBC 로드 실패: {type(e).__name__}: {e}"
                result["errors"].append(result["summary"])
                result["method"] = self.TXRX_METHOD_MANUAL
                result["method_reason"] = "DBC 로드 실패로 자동 프리테스트 분류가 불가합니다."
                return result

        if not db_by_ch:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = "유효한 DBC를 1개도 로드하지 못했습니다."
            result["errors"].append(result["summary"])
            result["method"] = self.TXRX_METHOD_MANUAL
            result["method_reason"] = "유효 DBC가 없어 자동 프리테스트 분류가 불가합니다."
            return result

        recommended_cycles: List[int] = []

        # 입력 조건: 향후 송신 대상
        for pos, exp in enumerate(getattr(condition, "input_conditions", []) or [], start=1):
            locations = self._find_expectation_locations(db_by_ch, exp)
            row = {
                "role": "입력",
                "pos": pos,
                "expectation": exp,
                "status": self.TXRX_STATUS_UNCHECKED,
                "channel": "-",
                "reason": "",
                "locations": locations,
                "cycle_ms": None,
                "crc_alive": [],
            }
            if not locations:
                row["status"] = self.TXRX_STATUS_BAD
                row["reason"] = f"DBC에서 Message를 찾지 못함: {exp.message}"
                result["errors"].append(row["reason"])
            elif not any(x.get("signal_found") for x in locations):
                row["status"] = self.TXRX_STATUS_BAD
                row["channel"] = ", ".join(x.get("channel_label", "") for x in locations)
                row["reason"] = f"DBC Message는 있으나 Signal을 찾지 못함: {exp.signal}"
                result["errors"].append(row["reason"])
            else:
                found = [x for x in locations if x.get("signal_found")]
                row["channel"] = ", ".join(x.get("channel_label", "") for x in found)
                first_msg = found[0].get("message")
                cycle = self._message_cycle_ms(first_msg, exp.message)
                row["cycle_ms"] = cycle
                if cycle:
                    recommended_cycles.append(cycle)
                crc_alive = self._detect_crc_alive_signals(first_msg)
                row["crc_alive"] = crc_alive
                candidate_labels = [
                    str(x.get("channel_label") or f"CAN{x.get('channel')}").split("/", 1)[0].upper()
                    for x in found
                ]
                # rev67: 복수 CAN 자체는 오류/경고가 아니다. 같은 신호가 여러 DBC에 있으면
                # CAN1 OR CAN2 OR CAN3 후보군으로 유지하고 실제 송신 시 사용자가 1개를 선택한다.
                or_note = ""
                if len(candidate_labels) >= 2:
                    or_note = (
                        f"송신 가능 논리 CAN OR 후보 {len(candidate_labels)}개("
                        + " | ".join(candidate_labels)
                        + ") - 실제 실행 시 1개 선택"
                    )
                warnings = []
                if crc_alive:
                    warnings.append("CRC/Alive/Counter류 Signal 포함 가능성: " + ", ".join(crc_alive[:6]))
                if warnings:
                    row["status"] = self.TXRX_STATUS_WARN
                    row["reason"] = " / ".join(([or_note] if or_note else []) + warnings)
                    result["warnings"].extend(warnings)
                else:
                    row["status"] = self.TXRX_STATUS_OK
                    row["reason"] = or_note or "DBC Message/Signal 확인 OK"
            result["input_rows"].append(row)

        # 출력 조건: 향후 수신/감시 대상 Preview. 수신 자체는 기존 P/F 로직을 재사용하지만 DBC 존재 여부도 같이 확인한다.
        for pos, exp in enumerate(getattr(condition, "output_conditions", []) or [], start=1):
            locations = self._find_expectation_locations(db_by_ch, exp)
            row = {
                "role": "출력",
                "pos": pos,
                "expectation": exp,
                "status": self.TXRX_STATUS_UNCHECKED,
                "channel": "-",
                "reason": "",
                "locations": locations,
            }
            if not locations:
                row["status"] = self.TXRX_STATUS_WARN
                row["reason"] = f"DBC에서 출력 Message를 찾지 못함: {exp.message}"
                result["warnings"].append(row["reason"])
            elif not any(x.get("signal_found") for x in locations):
                row["status"] = self.TXRX_STATUS_WARN
                row["channel"] = ", ".join(x.get("channel_label", "") for x in locations)
                row["reason"] = f"출력 Message는 있으나 Signal을 찾지 못함: {exp.signal}"
                result["warnings"].append(row["reason"])
            else:
                found = [x for x in locations if x.get("signal_found")]
                row["channel"] = ", ".join(x.get("channel_label", "") for x in found)
                row["status"] = self.TXRX_STATUS_OK
                row["reason"] = "수신/로그 검토용 DBC Message/Signal 확인 OK"
            result["output_rows"].append(row)

        if recommended_cycles:
            # 가장 빠른 주기를 기본 추천값으로 사용한다.
            result["recommended_period_ms"] = min(recommended_cycles)

        # 실제 버스 중복 송신 여부는 정적 DBC 검사만으로 확정할 수 없다.
        if result["input_rows"] and not result["errors"]:
            # rev67: 공통 버스 주의문은 정적 적합성 상태를 '확인 필요'로 강등하지 않는다.
            # 실제 CAPL 송신 전 source-isolation 확인 gate는 별도로 유지한다.
            result["bus_warning"] = "실제 차량 버스에 동일 Message ID가 이미 송신 중인지 별도 로그/버스 상태 확인 필요"

        if result["errors"]:
            result["status"] = self.TXRX_STATUS_BAD
            result["summary"] = result["errors"][0]
        elif result["warnings"]:
            result["status"] = self.TXRX_STATUS_WARN
            result["summary"] = result["warnings"][0]
        else:
            result["status"] = self.TXRX_STATUS_OK
            result["summary"] = "입력 Message/Signal 송신 Preview 가능"

        method, method_reason = self._classify_txrx_method(condition, result)
        result["method"] = method
        result["method_reason"] = method_reason
        if method in (self.TXRX_METHOD_MANUAL, self.TXRX_METHOD_PHYSICAL, self.TXRX_METHOD_EXCLUDE):
            if result["status"] == self.TXRX_STATUS_OK:
                result["status"] = self.TXRX_STATUS_WARN
            if result.get("summary") in ("입력 Message/Signal 송신 Preview 가능", ""):
                result["summary"] = method_reason

        return result

    def _check_txrx_selected(self):
        idx, cond = self._get_txrx_selected_condition()
        if cond is None:
            messagebox.showwarning("TC 선택 필요", "차량 송수신 테스트할 TC를 먼저 선택하세요.")
            return
        analysis = self._analyze_condition_txrx(cond)
        self.txrx_analysis_by_index[idx] = analysis
        self._refresh_txrx_tree()
        self._show_txrx_preview(idx)
        self._txrx_log(f"[TXRX] 선택 TC 검사 완료: TC={cond.tc_no}, status={analysis.get('status')}, reason={analysis.get('summary')}\n")

    def _check_txrx_all(self):
        """rev67: 전체 가능성 검사는 GUI thread를 점유하지 않고 DBC를 1회만 로드한다."""
        if self.txrx_all_check_thread is not None and self.txrx_all_check_thread.is_alive():
            messagebox.showinfo("전체 검사 진행 중", "이미 전체 가능성 검사가 진행 중입니다.")
            return
        try:
            mapping = self._collect_dbc_mapping()
        except Exception as e:
            messagebox.showerror("전체 검사 불가", f"DBC/논리 CAN 설정 수집 실패: {e}")
            return
        if not mapping:
            messagebox.showwarning("DBC 설정 필요", "설정 탭에서 CAN1/2/3의 DBC를 먼저 지정하세요.")
            return

        targets = [(idx, row.condition) for idx, row in enumerate(getattr(self, "condition_rows", []))
                   if row.is_valid and row.condition is not None]
        if not targets:
            return
        signature = self._txrx_dbc_mapping_signature(mapping)
        cached_db = self.txrx_dbc_cache_by_ch if signature == self.txrx_dbc_cache_signature else None
        self.txrx_status_var.set(f"전체 가능성 검사 중: 0/{len(targets)}")
        if self.txrx_check_all_button is not None:
            self.txrx_check_all_button.configure(state=tk.DISABLED, text="전체 검사 중...")
        self._txrx_log(f"[TXRX] 전체 가능성 검사 시작: total={len(targets)}, DBC cache={'HIT' if cached_db else 'MISS'}\n")

        def worker():
            try:
                db_by_ch = cached_db or core.load_dbc_map(mapping)
                results = {}
                counts = {"ok": 0, "warn": 0, "bad": 0}
                for pos, (idx, cond) in enumerate(targets, start=1):
                    analysis = self._analyze_condition_txrx(cond, db_by_ch=db_by_ch, dbc_mapping=mapping)
                    results[idx] = analysis
                    status = analysis.get("status")
                    if status == self.TXRX_STATUS_OK:
                        counts["ok"] += 1
                    elif status == self.TXRX_STATUS_WARN:
                        counts["warn"] += 1
                    elif status == self.TXRX_STATUS_BAD:
                        counts["bad"] += 1
                    if pos == 1 or pos % 20 == 0 or pos == len(targets):
                        self.txrx_async_queue.put(("ALL_PROGRESS", pos, len(targets)))
                self.txrx_async_queue.put(("ALL_DONE", results, counts, db_by_ch, signature, len(targets)))
            except Exception as e:
                self.txrx_async_queue.put(("ALL_ERROR", str(e)))

        self.txrx_all_check_thread = threading.Thread(target=worker, daemon=True)
        self.txrx_all_check_thread.start()

    def _finish_txrx_all_check(self, results, counts, db_by_ch, signature, total):
        self.txrx_analysis_by_index.update(results or {})
        self.txrx_dbc_cache_signature = signature
        self.txrx_dbc_cache_by_ch = db_by_ch or {}
        self._refresh_txrx_tree()
        if self.txrx_selected_index is not None:
            self._show_txrx_preview(self.txrx_selected_index)
        ok, warn, bad = counts.get("ok", 0), counts.get("warn", 0), counts.get("bad", 0)
        self.txrx_status_var.set(f"검사 완료: 전체 {total}개 / 가능 {ok} / 확인 필요 {warn} / 불가 {bad}")
        self._txrx_log(f"[TXRX] 전체 가능성 검사 완료: total={total}, ok={ok}, warn={warn}, bad={bad}, DBC load=1회\n")
        if self.txrx_check_all_button is not None:
            self.txrx_check_all_button.configure(state=tk.NORMAL, text="전체 가능성 검사")
        self.txrx_all_check_thread = None

    def _finish_txrx_all_check_error(self, message: str):
        self.txrx_status_var.set("전체 가능성 검사 오류")
        self._txrx_log(f"[TXRX][ERROR] 전체 가능성 검사 실패: {message}\n")
        if self.txrx_check_all_button is not None:
            self.txrx_check_all_button.configure(state=tk.NORMAL, text="전체 가능성 검사")
        self.txrx_all_check_thread = None
        messagebox.showerror("전체 가능성 검사 실패", message)

    def _txrx_result_tag(self, result: str) -> str:
        s = str(result or "").upper()
        if s == "OK":
            return "ok"
        if s == "NG":
            return "ng"
        if s in ("PARTIAL", "수동필요", "REPLAY권장", "릴레이필요", "분석필요"):
            return "warn"
        return "neutral"

    def _selected_txrx_causes(self) -> List[str]:
        return [label for label, var in self.txrx_cause_vars.items() if bool(var.get())]

    def _clear_txrx_experiment_inputs(self):
        self.txrx_vehicle_reaction_var.set("미확인")
        self.txrx_output_judge_var.set("미확인")
        self.txrx_experiment_result_var.set("분석필요")
        for var in self.txrx_cause_vars.values():
            var.set(False)
        if self.txrx_experiment_memo_text is not None:
            self.txrx_experiment_memo_text.configure(state="normal")
            self.txrx_experiment_memo_text.delete("1.0", tk.END)
        self._txrx_log("[TXRX][EXP] 실험 결과 입력값 초기화\n")

    def _save_txrx_experiment_record(self):
        idx, cond = self._get_txrx_selected_condition()
        if cond is None or idx is None:
            messagebox.showwarning("TC 선택 필요", "실험 결과를 기록할 TC를 먼저 선택하세요.")
            return

        memo = ""
        if self.txrx_experiment_memo_text is not None:
            try:
                memo = self.txrx_experiment_memo_text.get("1.0", tk.END).strip()
            except Exception:
                memo = ""

        analysis = self.txrx_analysis_by_index.get(idx, {})
        now = _dt.datetime.now()
        record = {
            "created_at": now.strftime("%Y-%m-%d %H:%M:%S"),
            "time_short": now.strftime("%H:%M:%S"),
            "row_index": idx,
            "tc_no": getattr(cond, "tc_no", ""),
            "subcategory": getattr(cond, "subcategory", ""),
            "experiment_method": self.txrx_experiment_method_var.get(),
            "vehicle_reaction": self.txrx_vehicle_reaction_var.get(),
            "output_judge": self.txrx_output_judge_var.get(),
            "final_result": self.txrx_experiment_result_var.get(),
            "causes": "; ".join(self._selected_txrx_causes()),
            "memo": memo,
            "analysis_status": analysis.get("status", "미검사"),
            "analysis_method": analysis.get("method", "미분류"),
            "analysis_summary": analysis.get("summary", ""),
        }
        self.txrx_experiment_records.append(record)
        self._refresh_txrx_experiment_tree()
        self._refresh_txrx_tree()
        self._txrx_log(
            f"[TXRX][EXP] 실험 기록 저장: TC={record['tc_no']}, result={record['final_result']}, "
            f"reaction={record['vehicle_reaction']}, judge={record['output_judge']}\n"
        )
        self.txrx_status_var.set(f"실험 기록 저장: {record['tc_no']} / {record['final_result']}")

    def _refresh_txrx_experiment_tree(self):
        if self.txrx_experiment_tree is None:
            return
        self.txrx_experiment_tree.delete(*self.txrx_experiment_tree.get_children())
        for i, record in enumerate(self.txrx_experiment_records[-200:], start=1):
            result = str(record.get("final_result", ""))
            self.txrx_experiment_tree.insert(
                "",
                tk.END,
                iid=f"exp:{i}",
                tags=(self._txrx_result_tag(result),),
                values=(
                    record.get("time_short", ""),
                    record.get("tc_no", ""),
                    record.get("experiment_method", ""),
                    record.get("vehicle_reaction", ""),
                    record.get("output_judge", ""),
                    result,
                ),
            )

    def _reset_txrx_experiment_records(self):
        if not self.txrx_experiment_records:
            messagebox.showinfo("기록 없음", "초기화할 실험 기록이 없습니다.")
            return
        if not messagebox.askyesno("실험 기록 초기화", "현재 세션의 차량 송수신 실험 기록을 모두 초기화할까요?"):
            return
        self.txrx_experiment_records.clear()
        self._refresh_txrx_experiment_tree()
        self._refresh_txrx_tree()
        self._txrx_log("[TXRX][EXP] 실험 기록 전체 초기화\n")

    def _export_txrx_experiment_csv(self):
        if not self.txrx_experiment_records:
            messagebox.showwarning("기록 없음", "CSV로 저장할 실험 기록이 없습니다.")
            return
        default_name = f"txrx_experiment_records_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        try:
            initial_dir = str(getattr(self, "_app_dir", Path.cwd()))
        except Exception:
            initial_dir = str(Path.cwd())
        path = filedialog.asksaveasfilename(
            title="차량 송수신 실험 기록 CSV 저장",
            defaultextension=".csv",
            initialdir=initial_dir,
            initialfile=default_name,
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        fields = [
            "created_at", "tc_no", "subcategory", "experiment_method", "vehicle_reaction",
            "output_judge", "final_result", "causes", "memo", "analysis_status", "analysis_method", "analysis_summary",
        ]
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
                for record in self.txrx_experiment_records:
                    writer.writerow({k: record.get(k, "") for k in fields})
            messagebox.showinfo("CSV 저장 완료", f"실험 기록을 저장했습니다.\n{path}")
            self._txrx_log(f"[TXRX][EXP] CSV 저장 완료: {path}\n")
        except Exception as e:
            messagebox.showerror("CSV 저장 실패", str(e))
            self._txrx_log(f"[TXRX][EXP][ERROR] CSV 저장 실패: {e}\n")

    def _txrx_or_can_candidates_from_found(self, found: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """rev67: deduplicate/sort logical CAN candidates while preserving each DBC location."""
        by_channel: Dict[int, Dict[str, Any]] = {}
        for item in found or []:
            try:
                ch = int(item.get("channel"))
            except Exception:
                continue
            if ch not in by_channel:
                by_channel[ch] = item
        return [by_channel[ch] for ch in sorted(by_channel)]

    def _set_txrx_or_can_candidates(self, found: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        candidates = self._txrx_or_can_candidates_from_found(found)
        labels = [
            str(x.get("channel_label") or f"CAN{int(x['channel'])}").split("/", 1)[0].upper()
            for x in candidates
        ]
        self.txrx_selected_can_candidate_values = labels
        if self.txrx_selected_can_combobox is not None:
            try:
                self.txrx_selected_can_combobox.configure(values=labels)
            except Exception:
                pass
        current = str(self.txrx_selected_can_candidate_var.get() or "").strip().upper()
        if current not in labels:
            current = labels[0] if labels else ""
            self.txrx_selected_can_candidate_var.set(current)
        if not labels:
            self.txrx_selected_can_candidate_status_var.set("송신 CAN 후보: 없음")
        elif len(labels) == 1:
            self.txrx_selected_can_candidate_status_var.set(f"송신 CAN 후보: {labels[0]} (1개)")
        else:
            self.txrx_selected_can_candidate_status_var.set(
                "송신 CAN OR 후보: " + " | ".join(labels) + f" / 현재 {current}"
            )
        return candidates

    def _selected_txrx_or_can_location(self, found: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        candidates = self._set_txrx_or_can_candidates(found)
        if not candidates:
            return None
        selected = str(self.txrx_selected_can_candidate_var.get() or "").strip().upper()
        for item in candidates:
            label = str(item.get("channel_label") or f"CAN{int(item['channel'])}").split("/", 1)[0].upper()
            if label == selected:
                return item
        return candidates[0]

    def _on_txrx_selected_can_candidate_changed(self, event=None):
        """OR 후보 중 실제 1회 송신할 CAN을 바꾸면 자동 후보 한 줄도 같은 CAN으로 동기화한다."""
        self.txrx_manual_validation_cache = None
        selected = str(self.txrx_selected_can_candidate_var.get() or "").strip().upper()
        if selected:
            self._txrx_log(f"[STIMULUS][OR-CAN] 실제 송신 CAN 선택: {selected}\n")
        self._txrx_autofill_manual_candidate_from_selected(silent=True)

    def _txrx_autofill_manual_candidate_from_selected(self, silent: bool = False) -> bool:
        """rev67: selected TC -> one-line manual candidate with CAN1~CAN3 OR-candidate support.

        Multiple logical CAN locations are not an error. All are retained as OR candidates,
        while the combobox selects exactly one CAN for the actual one-shot Stimulus.
        This method only prepares text and never starts Measurement/Vector COM/write/output.
        """
        if not bool(self.txrx_autofill_manual_from_selection_var.get()):
            return False
        if self.txrx_manual_candidate_text is None:
            return False
        idx, cond = self._get_txrx_selected_condition()
        if cond is None or idx is None:
            return False
        inputs = list(getattr(cond, "input_conditions", []) or [])
        if len(inputs) != 1:
            reason = f"입력 조건 {len(inputs)}개 - 자동 한 줄 후보는 입력 1개 TC만 지원"
            self.txrx_manual_candidate_status_var.set(f"수동 후보: 자동 적용 불가({reason})")
            self.txrx_selected_can_candidate_values = []
            self.txrx_selected_can_candidate_var.set("")
            self.txrx_selected_can_candidate_status_var.set("송신 CAN 후보: 입력 조건 1개 TC만 지원")
            if self.txrx_selected_can_combobox is not None:
                self.txrx_selected_can_combobox.configure(values=[])
            self._txrx_log(f"[STIMULUS][AUTO-FILL][BLOCK] TC={getattr(cond,'tc_no','-')}: {reason}\n")
            if not silent:
                messagebox.showwarning("선택 TC 자동 적용 불가", reason)
            return False
        exp = inputs[0]
        try:
            analysis = self.txrx_analysis_by_index.get(idx)
            if not analysis:
                analysis = self._analyze_condition_txrx(cond)
                self.txrx_analysis_by_index[idx] = analysis
            rows = list(analysis.get("input_rows") or [])
            row = rows[0] if len(rows) == 1 else {}
            found = [x for x in (row.get("locations") or []) if x.get("signal_found")]
        except Exception as e:
            reason = f"DBC 정적 분석 실패: {type(e).__name__}: {e}"
            self.txrx_manual_candidate_status_var.set("수동 후보: 자동 적용 실패")
            self._txrx_log(f"[STIMULUS][AUTO-FILL][ERROR] {reason}\n")
            if not silent:
                messagebox.showerror("선택 TC 자동 적용 실패", reason)
            return False

        candidates = self._set_txrx_or_can_candidates(found)
        if not candidates:
            reason = "논리 CAN 후보 0개"
            self.txrx_manual_candidate_status_var.set(f"수동 후보: 자동 적용 불가({reason})")
            self._txrx_log(f"[STIMULUS][AUTO-FILL][BLOCK] TC={getattr(cond,'tc_no','-')}: {reason}\n")
            if not silent:
                messagebox.showwarning(
                    "선택 TC 자동 적용 불가",
                    f"TC {getattr(cond,'tc_no','-')}의 {exp.message}.{exp.signal}을 DBC에서 찾지 못했습니다.\n"
                    f"{reason}\n[선택 TC 검사] 결과의 Channel/사유를 확인하세요.",
                )
            return False

        chosen = self._selected_txrx_or_can_location(candidates)
        if chosen is None:
            return False
        ch = int(chosen["channel"])
        logical_can = str(chosen.get("channel_label") or f"CAN{ch}").split("/", 1)[0].upper()
        line = (
            f"{logical_can}\t{str(getattr(exp,'message','') or '').strip()}\t"
            f"{str(getattr(exp,'signal','') or '').strip()}\t{getattr(exp,'expected_value_raw','')}"
        )
        self.txrx_manual_candidate_text.delete("1.0", tk.END)
        self.txrx_manual_candidate_text.insert("1.0", line)
        self.txrx_manual_validation_cache = None
        labels = list(self.txrx_selected_can_candidate_values)
        if len(labels) >= 2:
            status = f"수동 후보: TC {getattr(cond,'tc_no','-')} OR 후보 {' | '.join(labels)} / 현재 {logical_can} / 검증 필요"
            self._txrx_log(
                f"[STIMULUS][AUTO-FILL][OR] TC={getattr(cond,'tc_no','-')}: candidates={'|'.join(labels)}, selected={logical_can}, line={line}\n"
            )
        else:
            status = f"수동 후보: TC {getattr(cond,'tc_no','-')} 자동 적용 / {logical_can} / 검증 필요"
            self._txrx_log(f"[STIMULUS][AUTO-FILL] TC={getattr(cond,'tc_no','-')}: {line}\n")
        self.txrx_manual_candidate_status_var.set(status)
        return True

    def _txrx_manual_candidate_example(self):
        if self.txrx_manual_candidate_text is None:
            return
        example = (
            "CAN1\tSeat_Message_01\tSeatForwardReq\t1\n"
            "CAN1\tSeat_Message_01\tSeatEnable\t1\n"
        )
        self.txrx_manual_candidate_text.delete("1.0", tk.END)
        self.txrx_manual_candidate_text.insert("1.0", example)
        self.txrx_manual_candidate_status_var.set("수동 후보: 예시 입력됨")

    def _manual_candidate_logical_to_channel(self, token: str) -> Tuple[str, int]:
        text = str(token or "").strip().upper().replace(" ", "")
        if text in getattr(self, "can_names", []):
            return text, int(self._logical_can_to_channel(text))
        # rev67 backward compatibility: 과거 붙여넣기 CH1/1도 CAN1로 해석하되 GUI에서는 노출하지 않는다.
        m = re.fullmatch(r"CH([1-9]\d*)", text)
        if m:
            ch = int(m.group(1))
            return f"CAN{ch}", ch
        if text.isdigit() and int(text) > 0:
            ch = int(text)
            return f"CAN{ch}", ch
        raise ValueError(f"CAN 열은 CAN1/CAN2/CAN3 형식이어야 합니다: {token}")

    def _parse_manual_stimulus_candidates(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            raise RuntimeError(
                "oracle_checker_stimulus_rev67.py를 사용할 수 없습니다. "
                f"기존 Pass/Fail은 정상 사용 가능합니다. import={STIMULUS_IMPORT_ERROR or '-'}"
            )
        if self.txrx_manual_candidate_text is None:
            raise ValueError("수동 후보 입력창이 없습니다.")
        raw = self.txrx_manual_candidate_text.get("1.0", tk.END)
        lines = [x.strip() for x in raw.splitlines() if x.strip() and not x.lstrip().startswith("#")]
        if not lines:
            raise ValueError("수동 후보 Signal을 입력하세요. Excel 4열(CAN, Message, Signal, Value)을 그대로 붙여넣을 수 있습니다.")
        if len(lines) > _stimulus.StimulusExecutor.MAX_GROUP_ITEMS:
            raise ValueError(
                f"rev67 수동 후보 묶음은 최대 {_stimulus.StimulusExecutor.MAX_GROUP_ITEMS}행만 허용합니다. 현재={len(lines)}행"
            )

        candidates = []
        safety_keywords = (
            "brake", "brk", "steer", "str", "eps", "airbag", "srs", "torque", "tq", "accel", "throttle",
            "shift", "gear", "sbw", "hv", "highvoltage", "charging", "charge", "adas", "aeb", "lkas", "scc",
            "제동", "브레이크", "조향", "스티어", "에어백", "토크", "구동", "가속", "변속", "기어", "고전압", "충전", "운전자보조",
        )
        for lineno, line in enumerate(lines, start=1):
            if "\t" in line:
                parts = [x.strip() for x in line.split("\t")]
            elif "," in line:
                parts = [x.strip() for x in line.split(",")]
            elif ";" in line:
                parts = [x.strip() for x in line.split(";")]
            else:
                parts = re.split(r"\s+", line, maxsplit=3)
                parts = [x.strip() for x in parts]
            if len(parts) != 4:
                raise ValueError(
                    f"{lineno}행 형식 오류: CAN / Message / Signal / ActiveValue 4개 열이 필요합니다. 입력={line}"
                )
            can_token, message, signal, value = parts
            logical_can, channel = self._manual_candidate_logical_to_channel(can_token)
            blob = f"{message} {signal}".lower()
            if any(k in blob for k in safety_keywords):
                raise ValueError(f"{lineno}행은 rev67 안전 차단 키워드가 포함되어 수동 Stimulus 대상에서 제외합니다: {message}.{signal}")
            candidates.append(
                _stimulus.StimulusCandidate(
                    logical_can=logical_can,
                    channel=channel,
                    message=message,
                    signal=signal,
                    active_value=value,
                    bus_name="CAN",
                )
            )
        hold_sec = float(self.txrx_stimulus_hold_sec_var.get().strip() or "0.5")
        name = "Manual Candidate Set"
        idx, cond = self._get_txrx_selected_condition()
        if cond is not None:
            name = f"{str(getattr(cond, 'tc_no', '') or 'Selected TC')} manual candidates"
        return _stimulus.StimulusGroupProfile(
            name=name,
            candidates=candidates,
            hold_sec=hold_sec,
            source="Manual pasted candidates / rev67",
        )

    def _build_stimulus_dbc_resolver(self):
        """Return a strict in-memory DBC resolver for the isolated Stimulus module."""
        mapping, db_by_ch, _signature, _cached = self._get_txrx_cached_dbc_map()
        if not mapping:
            return None

        def resolver(channel: int, message_name: str):
            db = db_by_ch.get(int(channel))
            if db is None:
                return None
            try:
                return db.get_message_by_name(str(message_name))
            except Exception:
                return None

        return resolver

    def _canoe_backend_mode_key(self) -> str:
        try:
            raw = str(self.txrx_canoe_backend_var.get() or "")
        except Exception:
            raw = ""
        return "signal" if raw.lower().startswith("signal") else "capl"

    def _make_stimulus_executor(self):
        trace_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "stimulus_logs"
        resolver = None
        try:
            resolver = self._build_stimulus_dbc_resolver()
        except Exception as e:
            self._txrx_log(f"[STIMULUS][DBC][WARN] DBC resolver 생성 실패: {e}\n")
        return _stimulus.StimulusExecutor(
            trace_dir=trace_dir, dbc_resolver=resolver, canoe_backend_mode=self._canoe_backend_mode_key()
        )

    def _vector_product_name(self, client) -> str:
        try:
            info = client.get_application_info() if hasattr(client, "get_application_info") else {}
            return str((info or {}).get("product") or "").strip()
        except Exception:
            return ""

    def _require_canalyzer_source_isolated(self, client):
        """Compatibility name: rev67 gate applies to any CAPL Frame backend (CANoe/CANalyzer)."""
        product = self._vector_product_name(client)
        uses_capl = product.lower() == "canalyzer" or (product.lower() == "canoe" and self._canoe_backend_mode_key() == "capl")
        if uses_capl and not bool(self.txrx_canalyzer_source_isolated_var.get()):
            raise ValueError(
                f"{product or 'Vector'} CAPL output()은 실제 CAN Frame을 송신합니다. 동일 CAN ID를 원래 ECU/Generator가 계속 송신 중이면 "
                "중복 송신 충돌 위험이 있습니다. 실제 송신 전에 원래 송신원을 분리/비활성했음을 확인한 뒤 "
                "[CAPL Frame 실제 송신 전: 동일 Message 기존 송신원 분리·비활성 확인]을 직접 체크하세요."
            )

    def _profile_for_capl_bridge_generation(self):
        text = ""
        try:
            text = self.txrx_manual_candidate_text.get("1.0", tk.END).strip() if self.txrx_manual_candidate_text else ""
        except Exception:
            text = ""
        if text:
            return self._parse_manual_stimulus_candidates()
        _, _, _, _, single = self._build_selected_stimulus_profile()
        logical = str(single.logical_can or f"CAN{single.channel}")
        return _stimulus.StimulusGroupProfile(
            name=f"{single.tc_no or 'Selected TC'} CAPL bridge",
            candidates=[_stimulus.StimulusCandidate(
                logical_can=logical,
                channel=int(single.channel),
                message=str(single.message),
                signal=str(single.signal),
                active_value=single.active_value,
                bus_name=single.bus_name,
            )],
            hold_sec=float(single.hold_sec),
            source="Selected TC / CAPL bridge generation",
        )

    def _txrx_generate_canalyzer_capl_bridge(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            messagebox.showerror("CAPL Bridge 생성 불가", f"Stimulus 모듈 없음: {STIMULUS_IMPORT_ERROR or '-'}")
            return
        try:
            profile = self._profile_for_capl_bridge_generation()
            resolver = self._build_stimulus_dbc_resolver()
            if resolver is None:
                raise ValueError("Vector CAPL Bridge 생성에는 대상 CAN의 DBC 설정이 필요합니다.")
            out_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "vector_capl_bridge"
            paths = _stimulus.generate_vector_capl_bridges(profile, resolver, out_dir, revision="rev67")
            self.txrx_manual_candidate_status_var.set(f"CAPL Bridge 생성 {len(paths)}개")
            self._txrx_log("[STIMULUS][CAPL] 생성: " + " | ".join(paths) + "\n")
            messagebox.showinfo(
                "Vector CAPL Bridge 생성 완료",
                "\n".join([
                    f"생성 파일 {len(paths)}개:",
                    *[f"- {x}" for x in paths],
                    "",
                    "각 파일을 해당 논리 CAN이 연결된 CANoe/CANalyzer의 SEND/Simulation branch에 CAPL node로 수동 삽입하세요.",
                    "그 다음 Compile하세요. rev67의 [후보 검증]은 DBC 정적검사만 하며, 실제 테스트 worker가 Measurement를 재시작하면서 OnInit에서 CAPL 함수를 획득합니다.",
                    "PassFail은 Vector Configuration을 자동 수정하지 않습니다.",
                ]),
            )
        except Exception as e:
            self.txrx_manual_candidate_status_var.set("CAPL Bridge 생성 실패")
            self._txrx_log(f"[STIMULUS][CAPL][BLOCK] {e}\n")
            messagebox.showerror("Vector CAPL Bridge 생성 실패", str(e))

    def _manual_candidate_dbc_preflight(self, profile):
        """DBC가 있으면 후보 존재/CRC·Alive sibling을 확인한다. DBC가 없으면 COM validate가 최종 존재검사를 담당한다."""
        notes: List[str] = []
        crc_messages: List[str] = []
        missing: List[str] = []
        try:
            mapping, db_by_ch, _signature, _cached = self._get_txrx_cached_dbc_map()
        except Exception as e:
            notes.append(f"DBC 사전검사 생략: {type(e).__name__}: {e}")
            return notes, crc_messages, missing

        for item in profile.candidates:
            db = db_by_ch.get(int(item.channel))
            if db is None:
                notes.append(f"{item.logical_can}: DBC 없음 - Vector COM에서 직접 확인")
                continue
            try:
                msg = db.get_message_by_name(str(item.message))
            except Exception:
                missing.append(f"{item.logical_can}: Message 없음 {item.message}")
                continue
            try:
                sig = msg.get_signal_by_name(str(item.signal))
            except Exception:
                sig = None
            if sig is None:
                missing.append(f"{item.logical_can}: Signal 없음 {item.message}.{item.signal}")
            suspicious = self._detect_crc_alive_signals(msg)
            if suspicious:
                crc_messages.append(
                    f"{item.logical_can} {item.message}: " + ", ".join(sorted(set(suspicious)))
                )
        return notes, sorted(set(crc_messages)), missing

    def _prepare_manual_candidate_static_validation(self):
        """rev67 후보 검증: DBC 정적 검사 전용. Vector COM/Measurement/GetFunction을 호출하지 않는다."""
        profile = self._parse_manual_stimulus_candidates()
        notes, crc_messages, missing = self._manual_candidate_dbc_preflight(profile)
        if missing:
            raise ValueError("DBC 후보 검증 실패:\n- " + "\n- ".join(missing))
        if crc_messages and not bool(self.txrx_manual_crc_override_var.get()):
            raise ValueError(
                "DBC에서 CRC/Alive/Counter류 Signal이 같은 Message에 존재합니다.\n"
                "rev67은 이를 자동 계산하지 않습니다. 우선 현재 후보만 시험하려면 "
                "[CRC/Alive/Counter 경고가 있어도 시험 허용]을 직접 체크해야 합니다.\n\n- "
                + "\n- ".join(crc_messages)
            )
        resolver = self._build_stimulus_dbc_resolver()
        backend_mode = self._canoe_backend_mode_key()
        function_names = []
        if backend_mode == "capl":
            if resolver is None:
                raise ValueError("CAPL Frame 정적 검증에는 대상 CAN의 DBC 설정이 필요합니다.")
            function_names = _stimulus.capl_function_names_for_group(profile, resolver)
        checked_items = []
        for item in profile.candidates:
            checked_items.append({
                "logical_can": item.logical_can,
                "channel": int(item.channel),
                "message": item.message,
                "signal": item.signal,
                "active_value": _stimulus.coerce_numeric_value(item.active_value),
                "original_value": "실행 직전 확인",
            })
        checked = {
            "backend": "CAPL Frame (실행 시 Measurement.OnInit binding)" if backend_mode == "capl" else "CANoe Signal.Value (IL driver 필요)",
            "backend_kind": backend_mode,
            "product": "Vector",
            "hold_sec": float(profile.hold_sec),
            "items": checked_items,
            "capl_function_names": function_names,
        }
        return profile, checked, notes, crc_messages

    def _txrx_validate_manual_candidates_ui(self):
        try:
            profile, checked, notes, crc_messages = self._prepare_manual_candidate_static_validation()
            lines = [
                f"후보 {len(checked.get('items', []))}개 / Hold {checked.get('hold_sec')} sec",
                "※ rev67 후보 검증은 DBC 정적 검사만 수행합니다. Measurement/COM/CAPL GetFunction은 시작하지 않습니다.",
            ]
            for item in checked.get("items", []):
                lines.append(
                    f"- {item['logical_can']} {item['message']}.{item['signal']}: "
                    f"현재=실행 직전 확인 → 입력={item['active_value']}"
                )
            if checked.get("backend_kind") == "capl":
                lines.append(f"CAPL OnInit 함수 준비 대상: {len(checked.get('capl_function_names') or [])}개")
            if crc_messages:
                lines.append("CRC/Alive/Counter 경고(자동 계산 안 함):")
                lines.extend(f"- {x}" for x in crc_messages)
            lines.extend(notes)
            self.txrx_manual_validation_cache = {
                "fingerprint": self._manual_profile_fingerprint(profile),
                "checked": checked,
                "notes": notes,
                "crc_messages": crc_messages,
                "product": "Vector",
            }
            self.txrx_manual_candidate_status_var.set(f"수동 후보: 정적 검증 OK ({len(checked.get('items', []))}개)")
            self._txrx_log("[STIMULUS][MANUAL][STATIC-CHECK] " + " | ".join(lines) + "\n")
            messagebox.showinfo("수동 후보 정적 검증 완료", "\n".join(lines))
        except Exception as e:
            self.txrx_manual_validation_cache = None
            self.txrx_manual_candidate_status_var.set("수동 후보: 검증 실패")
            self._txrx_log(f"[STIMULUS][MANUAL][BLOCK] {e}\n")
            messagebox.showerror("수동 후보 검증 실패", str(e))

    def _txrx_manual_candidate_test_once(self):
        """rev67: 무거운 재검증은 UI thread에서 반복하지 않고, 실제 COM은 worker-owned connection으로 수행한다."""
        if not bool(self.txrx_stimulus_enable_var.get()):
            messagebox.showwarning("Stimulus 비활성", "[실험용 Stimulus 사용]을 먼저 체크하세요.")
            return
        if self.txrx_stimulus_thread is not None and self.txrx_stimulus_thread.is_alive():
            messagebox.showinfo("Stimulus 실행 중", "이미 Stimulus 입력 테스트가 진행 중입니다.")
            return
        busy_reason = self._txrx_pf_worker_busy_reason()
        if busy_reason:
            self.txrx_manual_candidate_status_var.set("수동 후보: 이전 판정 종료 대기")
            messagebox.showinfo(
                "이전 판정 종료 대기",
                f"{busy_reason}입니다.\n다중/단일 판정 worker가 완전히 종료된 뒤 다시 실행하세요. "
                "rev67에서는 COM 충돌을 피하기 위해 실제 Stimulus를 동시에 시작하지 않습니다.",
            )
            return
        try:
            profile = self._parse_manual_stimulus_candidates()
            fingerprint = self._manual_profile_fingerprint(profile)
        except Exception as e:
            messagebox.showerror("후보 묶음 테스트 실행 불가", str(e))
            return
        cache = self.txrx_manual_validation_cache or {}
        if cache.get("fingerprint") != fingerprint:
            self.txrx_manual_candidate_status_var.set("수동 후보: 재검증 필요")
            messagebox.showwarning(
                "후보 검증 필요",
                "후보 내용/DBC/Hold 값이 마지막 검증 이후 변경되었거나 검증 기록이 없습니다.\n"
                "[후보 검증]을 한 번 실행한 뒤 다시 눌러주세요. rev67에서는 실행 버튼에서 무거운 검증을 다시 반복하지 않습니다.",
            )
            return
        checked = cache.get("checked") or {}
        crc_messages = cache.get("crc_messages") or []
        product = str(cache.get("product") or checked.get("product") or "")
        if crc_messages and not bool(self.txrx_manual_crc_override_var.get()):
            messagebox.showerror(
                "CRC/Alive 경고 확인 필요",
                "DBC에 CRC/Alive/Counter류 Signal이 있습니다. [CRC/Alive/Counter 경고가 있어도 시험 허용]을 직접 체크하세요.",
            )
            return
        if "CAPL" in str(checked.get("backend") or "") and not bool(self.txrx_canalyzer_source_isolated_var.get()):
            messagebox.showerror(
                "CAPL Frame 송신원 분리 확인 필요",
                "CAPL 실제 송신 전 동일 Message의 기존 ECU/Generator 송신원 분리·비활성 확인을 체크하세요.",
            )
            return

        detail = [
            f"{item['logical_can']}  {item['message']}.{item['signal']}  {item['original_value']} → {item['active_value']}"
            for item in checked.get('items', [])
        ]
        crc_note = ""
        if crc_messages:
            crc_note = (
                "\n\n※ DBC에 CRC/Alive/Counter가 감지되었지만 사용자가 경고를 허용했습니다. "
                "rev67는 CRC/Alive를 계산하거나 갱신하지 않으므로 ECU가 이 입력을 무시할 수 있습니다."
            )
        backend = str(checked.get("backend") or "")
        backend_note = (
            f"\n\nBackend: {backend}\n실제 CAN Frame을 송신하며 Hold 종료/중단 시 baseline release Frame을 송신합니다."
            if "CAPL" in backend else
            "\n\nBackend: CANoe Signal.Value (IL driver 필요)\n실행 worker가 Signal.Value를 적용하지만 Interaction Layer signal driver가 없으면 실제 Frame은 송신되지 않습니다."
        )
        confirm = (
            "[rev67 수동 후보 Signal 묶음 1회 테스트]\n\n"
            + "\n".join(detail)
            + f"\n\nHold: {checked.get('hold_sec')} sec"
            + backend_note + crc_note
            + "\n\n※ 후보 검증은 정적 검사만 수행했습니다. 현재값/CAPL 함수는 실제 실행 worker가 Measurement.OnInit/실행 직전에 확인합니다.\n\n실행할까요?"
        )
        if not messagebox.askyesno("수동 후보 묶음 입력 확인", confirm):
            self._txrx_log("[STIMULUS][MANUAL] 사용자 취소\n")
            return

        mapping = self._collect_dbc_mapping()
        worker_bus_name = self.bus_name_var.get().strip() or "CAN"
        worker_product = self.vector_product_var.get().strip() or "자동"
        worker_canoe_backend_mode = self._canoe_backend_mode_key()
        auto_stop_after = bool(self.txrx_stop_measurement_after_stimulus_var.get())
        self.txrx_stimulus_stop_event.clear()
        self.txrx_stimulus_status_var.set("Stimulus: worker 연결/실행 준비 중")
        self.txrx_manual_candidate_status_var.set("수동 후보: 실행 준비 중")
        self.txrx_status_var.set("수동 후보 Stimulus 준비 중")
        self._txrx_log(
            f"[STIMULUS][MANUAL] PREPARE name={profile.name}, items={len(profile.candidates)}, hold={profile.hold_sec}s, worker-owned COM=ON\n"
        )

        def worker():
            worker_client = None
            result = None
            worker_error = None
            stop_ok = None
            stop_error = ""
            try:
                worker_client = core.CANoeClient(bus_name=worker_bus_name, product_preference=worker_product).connect(
                    expected_version_keyword=None, expected_exe_keyword=None
                )
                db_by_ch = core.load_dbc_map(mapping) if mapping else {}
                def resolver(channel: int, message_name: str):
                    db = db_by_ch.get(int(channel))
                    if db is None:
                        return None
                    try:
                        return db.get_message_by_name(str(message_name))
                    except Exception:
                        return None
                product = self._vector_product_name(worker_client).lower()
                use_capl = product == "canalyzer" or (product == "canoe" and worker_canoe_backend_mode == "capl")
                capl_registry = {}
                if use_capl:
                    names = _stimulus.capl_function_names_for_group(profile, resolver)
                    capl_registry = worker_client.start_measurement_with_capl_bindings(names, restart_if_running=True)
                elif not worker_client.is_measurement_running():
                    worker_client.start_measurement(wait_sec=0.0)
                trace_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "stimulus_logs"
                executor = _stimulus.StimulusExecutor(
                    trace_dir=trace_dir, dbc_resolver=resolver, canoe_backend_mode=worker_canoe_backend_mode,
                    capl_function_registry=capl_registry,
                )
                result = executor.execute_group_once(worker_client, profile, stop_event=self.txrx_stimulus_stop_event)
            except Exception as e:
                worker_error = f"{type(e).__name__}: {e}"
            finally:
                if auto_stop_after and worker_client is not None:
                    try:
                        worker_client.stop_measurement()
                        stop_ok = True
                    except Exception as e:
                        stop_ok = False
                        stop_error = f"{type(e).__name__}: {e}"
                if result is not None:
                    setattr(result, "measurement_stop_requested", auto_stop_after)
                    setattr(result, "measurement_stop_ok", stop_ok)
                    setattr(result, "measurement_stop_error", stop_error)
                    self.txrx_async_queue.put(("MANUAL_DONE", result))
                else:
                    suffix = f" / Measurement Stop 실패: {stop_error}" if stop_error else ""
                    self.txrx_async_queue.put(("MANUAL_ERROR", f"{worker_error or 'Stimulus worker 실패'}{suffix}"))

        self.txrx_stimulus_thread = threading.Thread(target=worker, daemon=True)
        self.txrx_stimulus_thread.start()

    def _finish_txrx_manual_stimulus_error(self, message: str):
        try:
            self.txrx_stimulus_status_var.set("Stimulus: 오류")
            self.txrx_manual_candidate_status_var.set("수동 후보: 오류")
            self.txrx_status_var.set("수동 후보 테스트 오류")
            self._txrx_log(f"[STIMULUS][MANUAL][ERROR] {message}\n")
            messagebox.showerror("후보 묶음 테스트 오류", message)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _finish_txrx_manual_stimulus(self, result):
        try:
            restored = all(x.restore_ok for x in (result.items or []) if x.write_ok)
            if result.ok and restored:
                status = "중단 후 원복" if result.stopped_early else "완료/원복"
                if "Signal.Value" in str(getattr(result, "backend", "") or ""):
                    status += " (실제 TX 별도확인)"
                self.txrx_stimulus_status_var.set(f"Stimulus: {status}")
                self.txrx_manual_candidate_status_var.set(f"수동 후보: {status}")
                self.txrx_status_var.set(f"수동 후보 테스트 {status}")
            else:
                self.txrx_stimulus_status_var.set("Stimulus: 오류")
                self.txrx_manual_candidate_status_var.set("수동 후보: 오류/원복 확인")
                self.txrx_status_var.set("수동 후보 테스트 오류")
            for item in result.items or []:
                self._txrx_log(
                    f"[STIMULUS][MANUAL][ITEM] {item.logical_can} "
                    f"{item.message}.{item.signal}: original={item.original_value}, active={item.active_value}, "
                    f"readback={item.active_readback}, restored={item.restored_value}, "
                    f"write_ok={item.write_ok}, restore_ok={item.restore_ok}, error={item.error or '-'}\n"
                )
            stop_req = bool(getattr(result, "measurement_stop_requested", False))
            stop_ok = getattr(result, "measurement_stop_ok", None)
            stop_err = str(getattr(result, "measurement_stop_error", "") or "")
            if stop_req and stop_ok is True:
                try:
                    self.measurement_status_var.set("Measurement: 정지")
                    self._refresh_status_badges()
                except Exception:
                    pass
            self._txrx_log(
                f"[STIMULUS][MANUAL] END ok={result.ok}, stopped={result.stopped_early}, "
                f"backend={getattr(result, 'backend', '-')}, frames={getattr(result, 'frame_count', 0)}, restore_ok={result.restore_ok}, "
                f"measurement_stop={stop_ok if stop_req else '미요청'}, stop_error={stop_err or '-'}, error={result.error or '-'}, trace={result.trace_path or '-'}\n"
            )
            if stop_req and stop_ok is False:
                messagebox.showwarning("Measurement Stop 확인 필요", f"Stimulus 원복 후 Measurement Stop에 실패했습니다.\n{stop_err or '-'}")
            if not restored:
                messagebox.showerror(
                    "수동 후보 원복 확인 필요",
                    "후보 묶음 입력 후 일부 Signal의 시작 전 값 복원이 확인되지 않았습니다.\n"
                    "Vector Trace와 실제 차량 상태를 즉시 확인하세요.\n\n"
                    f"{result.error or '-'}",
                )
            elif result.error:
                messagebox.showwarning("후보 묶음 테스트 완료(오류 있음)", result.error)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _txrx_send_not_implemented(self):
        messagebox.showinfo(
            "일반 송신 비활성",
            "rev67에서도 일반 CAN 송신/로그 Replay 자동화는 활성화하지 않습니다.\n\n"
            "실제 입력 PoC는 별도 oracle_checker_stimulus_rev67.py 모듈의 [입력 1회 테스트] 또는 "
            "[수동 후보 Signal 묶음 테스트]만 허용합니다.",
        )

    def _txrx_stop_stimulus(self):
        """현재 1회 Stimulus hold를 중단시킨다. worker의 finally에서 원래 값으로 복원된다."""
        try:
            self.txrx_stimulus_stop_event.set()
            self.txrx_stimulus_status_var.set("Stimulus: 중단/원복 요청")
            self._txrx_log("[STIMULUS] 즉시 중단/원복 요청\n")
        except Exception as e:
            self._txrx_log(f"[STIMULUS][WARN] 중단 요청 실패: {e}\n")

    def _build_selected_stimulus_profile(self):
        if not STIMULUS_AVAILABLE or _stimulus is None:
            raise RuntimeError(
                "oracle_checker_stimulus_rev67.py를 사용할 수 없습니다. "
                f"기존 Pass/Fail은 정상 사용 가능합니다. import={STIMULUS_IMPORT_ERROR or '-'}"
            )
        idx, cond = self._get_txrx_selected_condition()
        if cond is None or idx is None:
            raise ValueError("차량 송수신 테스트할 TC를 먼저 선택하세요.")
        if self._is_safety_excluded_tc(cond):
            raise ValueError("rev67 Stimulus PoC에서는 제동/조향/구동/에어백/충전/ADAS 등 안전 영향 TC 입력을 차단합니다.")

        inputs = list(getattr(cond, "input_conditions", []) or [])
        if len(inputs) != 1:
            raise ValueError(f"rev67 Stimulus PoC는 입력 조건이 정확히 1개인 TC만 허용합니다. 현재={len(inputs)}개")

        analysis = self.txrx_analysis_by_index.get(idx)
        if analysis is None:
            analysis = self._analyze_condition_txrx(cond)
            self.txrx_analysis_by_index[idx] = analysis
            self._refresh_txrx_tree()

        input_rows = analysis.get("input_rows", []) or []
        if len(input_rows) != 1:
            raise ValueError("입력 조건 정적 분석 결과가 1개가 아니어서 실행을 차단합니다.")
        row = input_rows[0]
        if row.get("status") == self.TXRX_STATUS_BAD:
            raise ValueError(f"입력 정적 분석이 불가 상태입니다: {row.get('reason', '-')}")
        if row.get("crc_alive"):
            raise ValueError("CRC/Alive/Counter류 Signal이 포함된 Message는 rev67 직접 Signal 입력 대상에서 제외합니다.")
        found = [x for x in (row.get("locations") or []) if x.get("signal_found")]
        candidates = self._set_txrx_or_can_candidates(found)
        if not candidates:
            raise ValueError("Message/Signal을 송신할 CANoe 논리 CAN 후보가 없습니다.")
        chosen = self._selected_txrx_or_can_location(candidates)
        if chosen is None:
            raise ValueError("송신할 논리 CAN 후보를 선택하지 못했습니다.")

        exp = inputs[0]
        hold_sec = float(self.txrx_stimulus_hold_sec_var.get().strip() or "0.5")
        channel_value = int(chosen["channel"])
        channel_label = str(chosen.get("channel_label") or self._ch_label_for_int(channel_value))
        logical_can = channel_label.split("/", 1)[0] if channel_label.upper().startswith("CAN") else f"CAN{channel_value}"
        profile = _stimulus.StimulusProfile(
            tc_no=str(getattr(cond, "tc_no", "") or ""),
            channel=channel_value,
            message=str(getattr(exp, "message", "") or "").strip(),
            signal=str(getattr(exp, "signal", "") or "").strip(),
            active_value=getattr(exp, "expected_value_raw", None),
            hold_sec=hold_sec,
            bus_name="CAN",
            source="Oracle input condition / TXRX selected TC",
            logical_can=logical_can,
        )
        return idx, cond, analysis, row, profile

    def _txrx_stimulus_test_once(self):
        if not bool(self.txrx_stimulus_enable_var.get()):
            messagebox.showwarning(
                "Stimulus 비활성",
                "실험용 입력은 기본 OFF입니다.\n[실험용 Stimulus 사용]을 직접 체크한 뒤 다시 실행하세요.",
            )
            return
        if self.txrx_stimulus_thread is not None and self.txrx_stimulus_thread.is_alive():
            messagebox.showinfo("Stimulus 실행 중", "이미 입력 1회 테스트가 진행 중입니다.")
            return
        busy_reason = self._txrx_pf_worker_busy_reason()
        if busy_reason:
            messagebox.showinfo(
                "이전 판정 종료 대기",
                f"{busy_reason}입니다.\n다중/단일 판정 worker가 완전히 종료된 뒤 다시 실행하세요. "
                "rev67에서는 COM 충돌을 피하기 위해 실제 Stimulus를 동시에 시작하지 않습니다.",
            )
            return

        try:
            idx, cond, analysis, input_row, profile = self._build_selected_stimulus_profile()
            active = _stimulus.coerce_numeric_value(profile.active_value)
            checked = {
                "original_value": "실행 직전 확인",
                "active_value": active,
                "hold_sec": float(profile.hold_sec),
                "backend": "CAPL Frame (실행 시 Measurement.OnInit binding)" if self._canoe_backend_mode_key() == "capl" else "CANoe Signal.Value (IL driver 필요)",
            }
            if self._canoe_backend_mode_key() == "capl" and not bool(self.txrx_canalyzer_source_isolated_var.get()):
                raise ValueError("CAPL 실제 송신 전 동일 Message 기존 ECU/Generator 송신원 분리·비활성 확인을 체크하세요.")
        except Exception as e:
            self.txrx_stimulus_status_var.set("Stimulus: 실행 차단")
            self._txrx_log(f"[STIMULUS][BLOCK] {e}\n")
            messagebox.showerror("입력 1회 테스트 실행 불가", str(e))
            return

        physical_note = ""
        if self._is_physical_or_switch_tc(cond):
            physical_note = (
                "\n\n※ 이 TC는 Seat/Switch/Button 등 물리 입력 가능성이 있는 항목입니다. "
                "CAN Signal/CAPL 입력만으로 실제 물리 조작이 재현되지 않을 수 있습니다."
            )
        confirm_text = (
            "[rev67 실험용 Stimulus 1회 테스트]\n\n"
            f"TC: {profile.tc_no}\n"
            f"대상: CAN{profile.channel} / {profile.message} / {profile.signal}\n"
            f"시작 전 값: {checked.get('original_value')}\n"
            f"입력 값: {checked.get('active_value')}\n"
            f"Hold: {checked.get('hold_sec')} sec\n\n"
            f"Backend: {checked.get('backend', '-')}\n"
            "실행 후 성공/오류/중단 여부와 무관하게 시작 전 상태로 복원을 시도합니다.\n"
            "CAPL backend는 실제 Frame을 송신하므로 동일 Message ID의 기존 ECU/Generator 송신원이 반드시 분리/비활성되어야 합니다. "
            "CANoe Signal.Value 모드는 Interaction Layer signal driver가 없으면 Write 창 01-0083 경고와 함께 실제 Frame이 송신되지 않을 수 있습니다."
            + physical_note
            + "\n\n실행할까요?"
        )
        if not messagebox.askyesno("실험용 입력 확인", confirm_text):
            self._txrx_log("[STIMULUS] 사용자 취소\n")
            return

        self.txrx_stimulus_stop_event.clear()
        self.txrx_stimulus_status_var.set("Stimulus: 실행 중")
        self.txrx_status_var.set(f"입력 1회 테스트: {profile.tc_no}")
        self._txrx_log(
            f"[STIMULUS] START TC={profile.tc_no}, Ch={profile.channel}, "
            f"{profile.message}.{profile.signal}={checked.get('active_value')}, hold={checked.get('hold_sec')}s, "
            f"original={checked.get('original_value')}\n"
        )

        worker_bus_name = self.bus_name_var.get().strip() or "CAN"
        worker_product = self.vector_product_var.get().strip() or "자동"
        worker_canoe_backend_mode = self._canoe_backend_mode_key()
        auto_stop_after = bool(self.txrx_stop_measurement_after_stimulus_var.get())
        mapping = self._collect_dbc_mapping()

        def worker():
            worker_client = None
            result = None
            worker_error = None
            stop_ok = None
            stop_error = ""
            try:
                # rev67: pywin32 COM 객체는 생성 스레드에서만 사용한다. 실제 Stimulus worker가 자체 재연결한다.
                worker_client = core.CANoeClient(bus_name=worker_bus_name, product_preference=worker_product).connect(
                    expected_version_keyword=None, expected_exe_keyword=None
                )
                db_by_ch = core.load_dbc_map(mapping) if mapping else {}
                def resolver(channel: int, message_name: str):
                    db = db_by_ch.get(int(channel))
                    if db is None:
                        return None
                    try:
                        return db.get_message_by_name(str(message_name))
                    except Exception:
                        return None
                product = self._vector_product_name(worker_client).lower()
                use_capl = product == "canalyzer" or (product == "canoe" and worker_canoe_backend_mode == "capl")
                capl_registry = {}
                if use_capl:
                    names = _stimulus.capl_function_names_for_single(profile, resolver)
                    capl_registry = worker_client.start_measurement_with_capl_bindings(names, restart_if_running=True)
                elif not worker_client.is_measurement_running():
                    worker_client.start_measurement(wait_sec=0.0)
                trace_dir = Path(getattr(self, "_app_dir", Path.cwd())) / "stimulus_logs"
                worker_executor = _stimulus.StimulusExecutor(
                    trace_dir=trace_dir, dbc_resolver=resolver, canoe_backend_mode=worker_canoe_backend_mode,
                    capl_function_registry=capl_registry,
                )
                result = worker_executor.execute_once(worker_client, profile, stop_event=self.txrx_stimulus_stop_event)
            except Exception as e:
                worker_error = f"{type(e).__name__}: {e}"
            finally:
                if auto_stop_after and worker_client is not None:
                    try:
                        worker_client.stop_measurement()
                        stop_ok = True
                    except Exception as e:
                        stop_ok = False
                        stop_error = f"{type(e).__name__}: {e}"
                if result is not None:
                    setattr(result, "measurement_stop_requested", auto_stop_after)
                    setattr(result, "measurement_stop_ok", stop_ok)
                    setattr(result, "measurement_stop_error", stop_error)
                    self.txrx_async_queue.put(("SINGLE_DONE", result))
                else:
                    suffix = f" / Measurement Stop 실패: {stop_error}" if stop_error else ""
                    self.txrx_async_queue.put(("SINGLE_ERROR", f"{worker_error or 'Stimulus worker 실패'}{suffix}"))

        self.txrx_stimulus_thread = threading.Thread(target=worker, daemon=True)
        self.txrx_stimulus_thread.start()

    def _finish_txrx_stimulus_worker_error(self, message: str):
        try:
            self.txrx_stimulus_status_var.set("Stimulus: 오류")
            self.txrx_status_var.set("입력 1회 테스트 오류")
            self._txrx_log(f"[STIMULUS][ERROR] worker-owned COM 실행 실패: {message}\n")
            messagebox.showerror("입력 1회 테스트 오류", message)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _finish_txrx_stimulus(self, result):
        try:
            if result.ok and result.restore_ok:
                status = "중단 후 원복" if result.stopped_early else "완료/원복"
                if "Signal.Value" in str(getattr(result, "backend", "") or ""):
                    status += " (실제 TX 별도확인)"
                self.txrx_stimulus_status_var.set(f"Stimulus: {status}")
                self.txrx_status_var.set(f"입력 1회 테스트 {status}")
            else:
                self.txrx_stimulus_status_var.set("Stimulus: 오류")
                self.txrx_status_var.set("입력 1회 테스트 오류")
            stop_req = bool(getattr(result, "measurement_stop_requested", False))
            stop_ok = getattr(result, "measurement_stop_ok", None)
            stop_err = str(getattr(result, "measurement_stop_error", "") or "")
            if stop_req and stop_ok is True:
                try:
                    self.measurement_status_var.set("Measurement: 정지")
                    self._refresh_status_badges()
                except Exception:
                    pass
            self._txrx_log(
                f"[STIMULUS] END ok={result.ok}, stopped={result.stopped_early}, "
                f"active_readback={result.active_readback}, restored={result.restored_value}, "
                f"backend={getattr(result, 'backend', '-')}, frames={getattr(result, 'frame_count', 0)}, restore_ok={result.restore_ok}, "
                f"measurement_stop={stop_ok if stop_req else '미요청'}, stop_error={stop_err or '-'}, error={result.error or '-'}, trace={result.trace_path or '-'}\n"
            )
            if stop_req and stop_ok is False:
                messagebox.showwarning("Measurement Stop 확인 필요", f"Stimulus 원복 후 Measurement Stop에 실패했습니다.\n{stop_err or '-'}")
            if not result.restore_ok:
                messagebox.showerror(
                    "Stimulus 원복 확인 필요",
                    "입력 테스트 후 시작 전 값 자동 복원이 확인되지 않았습니다.\n"
                    "Vector Trace/실제 차량 상태를 즉시 확인하세요.\n\n"
                    f"{result.error or '-'}",
                )
            elif result.error:
                messagebox.showwarning("입력 테스트 완료(오류 있음)", result.error)
        finally:
            self.txrx_stimulus_thread = None
            self.txrx_stimulus_stop_event.clear()

    def _show_txrx_preview(self, idx: Optional[int]):
        if self.txrx_preview_text is None:
            return
        lines: List[str] = []
        result_rows: List[Tuple[str, str, str, str, str, str, str, str]] = []

        if idx is None or not (0 <= idx < len(getattr(self, "condition_rows", []))):
            self.txrx_selected_tc_var.set("선택 TC: -")
            self.txrx_summary_var.set("송신 가능성: 미검사")
            lines.append("TC를 선택하면 입력 송신 대상과 출력 감시 대상 Preview가 표시됩니다.")
            self._write_txrx_preview(lines)
            self._refresh_txrx_result_tree([])
            return

        row = self.condition_rows[idx]
        if not row.is_valid or row.condition is None:
            self.txrx_selected_tc_var.set("선택 TC: -")
            self.txrx_summary_var.set("송신 가능성: 불가")
            lines.append("선택한 행은 유효한 TC가 아닙니다.")
            lines.append(row.error_reason or "-")
            self._write_txrx_preview(lines)
            self._refresh_txrx_result_tree([])
            return

        cond = row.condition
        analysis = self.txrx_analysis_by_index.get(idx)
        if analysis is None:
            analysis = {"status": self.TXRX_STATUS_UNCHECKED, "summary": "프리테스트 분류/송신 가능성 검사를 수행하지 않았습니다.", "input_rows": [], "output_rows": [], "method": self.TXRX_METHOD_UNKNOWN, "method_reason": "검사 전"}

        self.txrx_selected_tc_var.set(f"선택 TC: {cond.tc_no} / {cond.subcategory}")
        self.txrx_summary_var.set(f"송신 가능성: {analysis.get('status')} - {analysis.get('summary')}")
        self.txrx_status_var.set(f"선택 TC Preview: {cond.tc_no}")

        if analysis.get("recommended_period_ms"):
            try:
                self.txrx_period_ms_var.set(str(int(analysis.get("recommended_period_ms"))))
            except Exception:
                pass
        if analysis.get("method") and analysis.get("method") != self.TXRX_METHOD_UNKNOWN:
            # 실험 방식 기본값은 자동화 추천을 참고하되 사용자가 수동으로 바꿀 수 있다.
            try:
                self.txrx_experiment_method_var.set(str(analysis.get("method")))
            except Exception:
                pass

        lines.extend([
            f"TC 번호: {cond.tc_no}",
            f"소분류: {cond.subcategory}",
            f"대기 시간: {cond.timeout_sec}s",
            f"자동화 방식 추천: {analysis.get('method', self.TXRX_METHOD_UNKNOWN)}",
            f"추천 사유: {analysis.get('method_reason', '-')}",
            "",
            "[TC 내용]",
            cond.tc_content or "-",
            "",
            "[TC 예상 결과]",
            cond.tc_expected_result or "-",
            "",
            "[입력 조건: 자동 자극 후보(CAN 송신/로그 Replay/물리 입력)]",
        ])

        if cond.input_conditions:
            for pos, exp in enumerate(cond.input_conditions, start=1):
                row_analysis = self._find_row_analysis(analysis, "input_rows", pos)
                channel = row_analysis.get("channel", "-") if row_analysis else "-"
                status = row_analysis.get("status", self.TXRX_STATUS_UNCHECKED) if row_analysis else self.TXRX_STATUS_UNCHECKED
                reason = row_analysis.get("reason", "검사 전") if row_analysis else "검사 전"
                cycle = row_analysis.get("cycle_ms") if row_analysis else None
                lines.append(f"{pos}. Message: {exp.message}")
                lines.append(f"   Signal : {exp.signal}")
                lines.append(f"   Value  : {exp.expected_value_raw}")
                lines.append(f"   Channel 후보: {channel}")
                lines.append(f"   송신 주기 후보: {cycle if cycle else '-'} ms")
                lines.append(f"   상태: {status} / {reason}")
                result_rows.append(("입력", exp.message, exp.signal, exp.expected_value_raw, channel, status, reason, self._tag_for_txrx_status(status)))
        else:
            lines.append("-")

        lines.extend(["", "[출력 조건: 차량 반응 수신/감시 대상]"])
        if cond.output_conditions:
            for pos, exp in enumerate(cond.output_conditions, start=1):
                row_analysis = self._find_row_analysis(analysis, "output_rows", pos)
                channel = row_analysis.get("channel", "-") if row_analysis else "-"
                status = row_analysis.get("status", self.TXRX_STATUS_UNCHECKED) if row_analysis else self.TXRX_STATUS_UNCHECKED
                reason = row_analysis.get("reason", "검사 전") if row_analysis else "검사 전"
                lines.append(f"{pos}. Message: {exp.message}")
                lines.append(f"   Signal : {exp.signal}")
                lines.append(f"   Expected: {exp.expected_value_raw}")
                lines.append(f"   Channel 후보: {channel}")
                lines.append(f"   상태: {status} / {reason}")
                result_rows.append(("출력", exp.message, exp.signal, exp.expected_value_raw, channel, status, reason, self._tag_for_txrx_status(status)))
        else:
            lines.append("-")

        lines.extend([
            "",
            "[rev67 실험 관리 / Stimulus 격리 기준]",
            "- 기존 OneByOne/Multiple PassFail은 관측/판정 기능 그대로 유지하며 실제 입력 쓰기 로직을 포함하지 않습니다.",
            "- 실제 Stimulus는 oracle_checker_stimulus_rev67.py 안에서만 수행합니다(CANoe=CAPL Frame 권장/Signal.Value 선택, CANalyzer=CAPL output()).",
            "- Stimulus 모듈이 없거나 실패해도 기존 Pass/Fail 기능은 계속 사용할 수 있습니다.",
            "- 선택 TC 입력 1회 테스트는 기존 단일 Signal 제한을 유지합니다.",
            "- rev67에서는 상단 TC를 클릭하면 입력 1개 TC의 CAN1~CAN3 복수 위치를 OR 후보로 유지하고 선택한 CAN 1개를 수동 후보 4열 형식으로 자동 채울 수 있습니다. CAPL backend는 baseline release Frame, Signal.Value 모드는 시작값 원복을 시도합니다.",
            "- CRC/Alive/Counter는 자동 계산하지 않습니다. DBC에서 감지되면 기본 차단하며 사용자가 경고 허용을 명시한 경우 정적 값 시험만 가능합니다.",
            "- 실행 직전 Signal 값을 읽어 저장하고 성공/실패/중단과 무관하게 finally에서 해당 값으로 원복합니다.",
            "- Seat/Switch 같은 물리 입력 TC는 경고 후 실험할 수 있으나 CAN Signal 변경만으로 실제 물리 조작이 재현되지 않을 수 있습니다.",
            "- 일반 다중 Signal 송신/로그 Replay 자동화는 여전히 비활성입니다.",
            "- 동일 Message ID가 실제 차량 버스에서 이미 송신 중이면 충돌 위험이 있습니다.",
            "- CRC/Alive/Counter가 포함된 메시지는 기본 차단하며 override는 정적 값 탐색 시험만 허용합니다. CAPL backend도 CRC를 자동 계산하지 않습니다.",
        ])

        self._write_txrx_preview(lines)
        self._refresh_txrx_result_tree(result_rows)
        self._write_txrx_status_text(cond, analysis)

    def _find_row_analysis(self, analysis: Dict[str, Any], key: str, pos: int) -> Dict[str, Any]:
        for item in analysis.get(key, []) or []:
            if item.get("pos") == pos:
                return item
        return {}

    def _tag_for_txrx_status(self, status: str) -> str:
        if status == self.TXRX_STATUS_OK:
            return "ok"
        if status == self.TXRX_STATUS_WARN:
            return "warn"
        if status == self.TXRX_STATUS_BAD:
            return "bad"
        return ""

    def _write_txrx_preview(self, lines: List[str]):
        self.txrx_preview_text.configure(state="normal")
        self.txrx_preview_text.delete("1.0", tk.END)
        self.txrx_preview_text.insert("1.0", "\n".join(lines))
        self.txrx_preview_text.configure(state="normal")

    def _refresh_txrx_result_tree(self, rows: List[Tuple[str, str, str, str, str, str, str, str]]):
        if self.txrx_result_tree is None:
            return
        self.txrx_result_tree.delete(*self.txrx_result_tree.get_children())
        for i, (kind, msg, sig, exp, ch, status, reason, tag) in enumerate(rows, start=1):
            self.txrx_result_tree.insert(
                "",
                tk.END,
                iid=f"txrx:{i}",
                tags=(tag,) if tag else (),
                values=(kind, msg, sig, exp, ch, status, reason),
            )

    def _write_txrx_status_text(self, cond: Any, analysis: Dict[str, Any]):
        if self.txrx_status_text is None:
            return
        lines = [
            f"상태: {analysis.get('status', self.TXRX_STATUS_UNCHECKED)}",
            f"현재 송신 TC: {cond.tc_no}",
            f"송신 시작 시각: -",
            f"마지막 송신 시각: -",
            f"송신 횟수: -",
            "",
            "[자동화 방식 추천]",
            analysis.get("method") or self.TXRX_METHOD_UNKNOWN,
            analysis.get("method_reason") or "-",
            "",
            "[권장 프리테스트 정책 Preview]",
            f"출력 대기시간(sec): {self.txrx_wait_sec_var.get()}",
            f"TC 간 대기(sec): {self.txrx_between_tc_delay_var.get()}",
            f"Fail 처리: {self.txrx_fail_policy_var.get()}",
            f"송신 방식 후보: {self.txrx_tx_mode_var.get()}",
            f"송신 주기(ms) 후보: {self.txrx_period_ms_var.get()}",
            "",
            "[결과 해석]",
            "OK: 현재 자극 가설로 반응 확인 / NG: 기능 FAIL 확정이 아니라 입력조건·자극방식 보완 또는 수동 확인 필요",
            "",
            "[진단 요약]",
            analysis.get("summary") or "-",
            "",
            "[Stimulus 모듈]",
            self.txrx_stimulus_status_var.get(),
            "실제 Stimulus 동작은 독립 oracle_checker_stimulus_rev67.py에서만 수행",
        ]
        if analysis.get("errors"):
            lines.append("")
            lines.append("[불가 사유]")
            for item in analysis.get("errors", [])[:10]:
                lines.append(f"- {item}")
        if analysis.get("warnings"):
            lines.append("")
            lines.append("[확인 필요]")
            for item in analysis.get("warnings", [])[:10]:
                lines.append(f"- {item}")
        if analysis.get("bus_warning"):
            lines.append("")
            lines.append("[버스 주의 - 적합성 상태 강등 없음]")
            lines.append(f"- {analysis.get('bus_warning')}")

        self.txrx_status_text.configure(state="normal")
        self.txrx_status_text.delete("1.0", tk.END)
        self.txrx_status_text.insert("1.0", "\n".join(lines))
        self.txrx_status_text.configure(state="normal")
