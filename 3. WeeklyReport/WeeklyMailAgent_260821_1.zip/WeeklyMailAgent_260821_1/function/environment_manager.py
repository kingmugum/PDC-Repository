from __future__ import annotations

import importlib.util
import os
import shutil
import sys
from pathlib import Path
from typing import Any


def _module_ok(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def _playwright_chromium_path() -> str | None:
    if not _module_ok("playwright"):
        return None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            path = Path(p.chromium.executable_path)
            return str(path) if path.exists() else None
    except Exception:
        return None


def _edge_path() -> str | None:
    candidates = [
        shutil.which("msedge"),
        os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for raw in candidates:
        if raw and Path(raw).is_file():
            return str(Path(raw))
    return None


def _selected_browser(chromium_ok: bool, edge_ok: bool, config: dict | None) -> str:
    browser_cfg = (config or {}).get("browser") or {}
    mode = str(browser_cfg.get("mode", "auto")).strip().lower()
    if mode in {"playwright_chromium", "chromium"}:
        return "Playwright Chromium" if chromium_ok else ""
    if mode in {"msedge", "edge"}:
        return "Microsoft Edge" if edge_ok else ""
    order = list(browser_cfg.get("auto_order") or ["playwright_chromium", "msedge"])
    for item in order:
        key = str(item).strip().lower()
        if key in {"playwright_chromium", "chromium"} and chromium_ok:
            return "Playwright Chromium"
        if key in {"msedge", "edge"} and edge_ok:
            return "Microsoft Edge"
    return ""


def check_environment(config: dict | None = None) -> dict[str, Any]:
    chromium_path = _playwright_chromium_path()
    edge_path = _edge_path()
    chromium_ok = bool(chromium_path)
    edge_ok = bool(edge_path)
    selected = _selected_browser(chromium_ok, edge_ok, config)
    return {
        "python": sys.version.split()[0],
        "python_ok": sys.version_info >= (3, 10),
        "keyring_ok": _module_ok("keyring"),
        "playwright_ok": _module_ok("playwright"),
        "chromium_path": chromium_path,
        "chromium_ok": chromium_ok,
        "edge_path": edge_path,
        "edge_ok": edge_ok,
        "selected_browser": selected,
        "browser_ok": bool(selected),
    }
