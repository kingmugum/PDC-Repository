"""WeeklyMailAgent function package."""
