from __future__ import annotations

from typing import Any

from .mail_builder import build_html_body, build_subject, build_text_body
from .models import MailEnvelope, WeeklyReportInput
from .validation import ValidationError, validate_email


def build_envelope(report: WeeklyReportInput, config: dict[str, Any], practice_mode: bool, practice_recipient: str = "") -> MailEnvelope:
    mail_cfg = config["mail"]
    if practice_mode:
        recipient = validate_email(practice_recipient or mail_cfg.get("practice_recipient", ""))
        to = [recipient]
        cc: list[str] = []
    else:
        if not mail_cfg.get("production_send_enabled", False):
            raise ValidationError("이 배포본에서는 정식 발송이 잠겨 있습니다. 먼저 연습 모드 검증을 완료하세요.")
        to = [validate_email(mail_cfg["production_recipient"])]
        cc = [validate_email(x) for x in mail_cfg.get("production_cc", [])]

    return MailEnvelope(
        to=to,
        cc=cc,
        subject=build_subject(report.week_label, config, practice_mode),
        html_body=build_html_body(report, config),
        text_body=build_text_body(report, config),
        practice_mode=practice_mode,
    )
