from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ConfigError(RuntimeError):
    pass


def app_root() -> Path:
    return Path(__file__).resolve().parent


def load_json(path: Path) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError as exc:
        raise ConfigError(f"설정 파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigError(f"설정 JSON 형식이 올바르지 않습니다: {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"설정 루트는 object여야 합니다: {path}")
    return data


def load_config() -> dict[str, Any]:
    return load_json(app_root() / "config.json")


def load_site_profile() -> dict[str, Any]:
    return load_json(app_root() / "site_profile.json")


def save_practice_recipient(address: str) -> None:
    path = app_root() / "config.json"
    data = load_json(path)
    data.setdefault("mail", {})["practice_recipient"] = address.strip()
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)
