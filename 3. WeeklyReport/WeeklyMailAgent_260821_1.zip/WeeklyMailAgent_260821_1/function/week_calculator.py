from __future__ import annotations

import re
from datetime import date, timedelta


_WEEK_LABEL_RE = re.compile(r"^\s*(\d{1,2})월\s*(\d+)주차\s*$")


def thursday_of_week(day: date) -> date:
    """Return the Thursday belonging to the same Monday-Sunday week as *day*."""
    return day + timedelta(days=3 - day.weekday())


def week_label_for_date(day: date) -> str:
    """Build '<month>월 <n>주차' using the Thursday that represents that week.

    The month is the month of that Thursday and n is the ordinal number of the
    Thursday in that month. This naturally supports a 5th week only when that
    month actually has a fifth Thursday.
    """
    thursday = thursday_of_week(day)
    week_no = ((thursday.day - 1) // 7) + 1
    return f"{thursday.month}월 {week_no}주차"


def nth_thursday(year: int, month: int, ordinal: int) -> date | None:
    """Return the ordinal Thursday in *year/month*, or None if it does not exist."""
    if not 1 <= month <= 12 or ordinal < 1:
        return None
    first = date(year, month, 1)
    first_thursday = first + timedelta(days=(3 - first.weekday()) % 7)
    candidate = first_thursday + timedelta(days=(ordinal - 1) * 7)
    if candidate.month != month:
        return None
    return candidate


def next_week_label(current_label: str, reference_date: date | None = None) -> str:
    """Return the week label represented by the next Thursday.

    The visible current label is respected when possible. For example in 2026,
    ``8월 3주차`` -> ``8월 4주차`` and ``8월 4주차`` -> ``9월 1주차`` because
    August 2026 has only four Thursdays. A real fifth Thursday is kept when it
    exists (for example 2026-10-29 -> ``10월 5주차``).
    """
    reference_date = reference_date or date.today()
    match = _WEEK_LABEL_RE.match(current_label or "")
    if not match:
        return week_label_for_date(thursday_of_week(reference_date) + timedelta(days=7))

    month = int(match.group(1))
    ordinal = int(match.group(2))
    reference_thursday = thursday_of_week(reference_date)

    # Choose the matching calendar occurrence closest to the current reference
    # Thursday. This keeps manual week-label edits usable around year boundaries.
    candidates: list[date] = []
    for year in (reference_thursday.year - 1, reference_thursday.year, reference_thursday.year + 1):
        candidate = nth_thursday(year, month, ordinal)
        if candidate is not None:
            candidates.append(candidate)
    if not candidates:
        return week_label_for_date(reference_thursday + timedelta(days=7))

    current_thursday = min(candidates, key=lambda d: abs((d - reference_thursday).days))
    return week_label_for_date(current_thursday + timedelta(days=7))
