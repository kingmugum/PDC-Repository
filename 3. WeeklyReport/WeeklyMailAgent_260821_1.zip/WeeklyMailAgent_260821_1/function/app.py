from __future__ import annotations

import queue
import threading
import traceback
from datetime import date, datetime
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from .config_loader import app_root, load_config, load_site_profile, save_practice_recipient
from .credential_store import CredentialStoreError, save_credentials
from .environment_manager import check_environment
from .gw_mail_automation import ApprovalGate, GWAutomationError, run_mail_flow
from .models import TaskItem, WeeklyReportInput, clone_tasks
from .history_store import load_previous_week_record, previous_week_label, save_week_record, tasks_from_record
from .week_calculator import week_label_for_date
from .routing import build_envelope
from .validation import ValidationError, validate_email

WEEKDAYS = ["월", "화", "수", "목", "금"]


class TaskDialog(tk.Toplevel):
    def __init__(self, parent, title: str, initial: TaskItem | None = None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.result: TaskItem | None = None
        self.transient(parent)
        self.grab_set()
        initial = initial or TaskItem("", "", "", "")
        labels = ["업무명", "일정", "장소", "키워드/내용"]
        values = [initial.name, initial.schedule, initial.place, initial.keywords]
        self.vars: list[tk.StringVar] = []
        frame = ttk.Frame(self, padding=14)
        frame.pack(fill="both", expand=True)
        for r, (label, value) in enumerate(zip(labels, values)):
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky="w", pady=5)
            var = tk.StringVar(value=value)
            self.vars.append(var)
            ttk.Entry(frame, textvariable=var, width=52).grid(row=r, column=1, sticky="ew", padx=(8, 0), pady=5)
        btns = ttk.Frame(frame)
        btns.grid(row=4, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="취소", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="확인", command=self._ok).pack(side="right", padx=(0, 8))
        self.bind("<Return>", lambda e: self._ok())
        self.wait_visibility()
        self.focus_force()

    def _ok(self):
        vals = [v.get().strip() for v in self.vars]
        if not vals[0] and not vals[3]:
            messagebox.showerror("입력 확인", "업무명 또는 키워드/내용 중 하나는 입력해야 합니다.", parent=self)
            return
        # Editing/confirming a history-loaded row makes it a current-week row, so the yellow highlight clears.
        self.result = TaskItem(*vals, from_history=False)
        self.destroy()


class TaskListFrame(ttk.LabelFrame):
    def __init__(self, parent, title: str):
        super().__init__(parent, text=title, padding=8)
        self.items: list[TaskItem] = []
        self.tree = ttk.Treeview(self, columns=("name", "schedule", "place", "keywords"), show="headings", height=5)
        headers = [("name", "업무"), ("schedule", "일정"), ("place", "장소"), ("keywords", "키워드/내용")]
        widths = {"name": 210, "schedule": 130, "place": 120, "keywords": 250}
        for key, text in headers:
            self.tree.heading(key, text=text)
            self.tree.column(key, width=widths[key], anchor="w")
        self.tree.tag_configure("history", background="#FFF2CC")
        self.tree.pack(fill="x", expand=True)
        ttk.Label(self, text="연한 노란색 = 지난 주 기록에서 불러온 항목 · 더블클릭 수정 후 확인하면 흰색으로 전환").pack(anchor="w", pady=(4, 0))
        btns = ttk.Frame(self)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="+ 업무 추가", command=self.add_item).pack(side="left")
        ttk.Button(btns, text="수정", command=self.edit_item).pack(side="left", padx=6)
        ttk.Button(btns, text="삭제", command=self.delete_item).pack(side="left")
        self.tree.bind("<Double-1>", lambda e: self.edit_item())

    def _refresh(self):
        self.tree.delete(*self.tree.get_children())
        for idx, item in enumerate(self.items):
            tags = ("history",) if item.from_history else ()
            self.tree.insert(
                "", "end", iid=str(idx),
                values=(item.name, item.schedule, item.place, item.keywords),
                tags=tags,
            )

    def replace_with_history(self, items: list[TaskItem]):
        self.items = [x.as_history() for x in items]
        self._refresh()

    def add_item(self):
        dialog = TaskDialog(self, "업무 추가")
        self.wait_window(dialog)
        if dialog.result:
            self.items.append(dialog.result)
            self._refresh()

    def edit_item(self):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        dialog = TaskDialog(self, "업무 수정", self.items[idx])
        self.wait_window(dialog)
        if dialog.result:
            self.items[idx] = dialog.result
            self._refresh()

    def delete_item(self):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        del self.items[idx]
        self._refresh()


class ScrollableContent(ttk.Frame):
    """Main application content with one always-visible right-side vertical scrollbar."""

    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.content = ttk.Frame(self.canvas, padding=12)
        self._window_id = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.content.bind("<Configure>", self._sync_scroll_region)
        self.canvas.bind("<Configure>", self._sync_content_width)

    def _sync_scroll_region(self, _event=None):
        bbox = self.canvas.bbox("all")
        if bbox:
            self.canvas.configure(scrollregion=bbox)

    def _sync_content_width(self, event):
        self.canvas.itemconfigure(self._window_id, width=event.width)



class WeeklyMailApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.config_data = load_config()
        self.site_profile = load_site_profile()
        self.title(f"WeeklyMailAgent {self.config_data.get('technical_version', 'v0.13')}")
        self.geometry("1180x900")
        self.minsize(1040, 800)
        self._events: queue.Queue = queue.Queue()
        self._worker_running = False
        self.approval_gate = ApprovalGate(threading.Event())
        self._build_ui()
        self.after(100, self._poll_events)
        self.after(250, self.check_environment_async)

    def _build_ui(self):
        # The whole form is intentionally taller than the initial window.
        # Users can inspect every section with the far-right main scrollbar
        # without shrinking the preview/log areas.
        self.main_scroller = ScrollableContent(self)
        self.main_scroller.pack(fill="both", expand=True)
        root = self.main_scroller.content

        top = ttk.Frame(root)
        top.pack(fill="x")
        ttk.Label(top, text="WeeklyMailAgent", font=("Segoe UI", 20, "bold")).pack(side="left")
        self.env_var = tk.StringVar(value="환경 확인 중...")
        ttk.Label(top, textvariable=self.env_var).pack(side="right")

        tools = ttk.Frame(root)
        tools.pack(fill="x", pady=(6, 10))
        ttk.Button(tools, text="환경 확인", command=self.check_environment_async).pack(side="left")
        ttk.Button(tools, text="GW 자격증명 저장", command=self.save_credentials_dialog).pack(side="left", padx=6)
        ttk.Label(tools, text="※ ID/PW는 OS keyring에만 저장하며 config/로그/메일 본문에 기록하지 않습니다.").pack(side="left", padx=10)

        mode = ttk.LabelFrame(root, text="발송 모드", padding=8)
        mode.pack(fill="x")
        self.practice_var = tk.BooleanVar(value=bool(self.config_data["mail"].get("practice_mode_default", True)))
        self.practice_check = ttk.Checkbutton(mode, text="연습 모드", variable=self.practice_var, command=self._mode_changed)
        self.practice_check.grid(row=0, column=0, sticky="w")
        ttk.Label(mode, text="연습 수신자").grid(row=0, column=1, padx=(16, 4))
        self.practice_recipient_var = tk.StringVar(value=self.config_data["mail"].get("practice_recipient", ""))
        ttk.Entry(mode, textvariable=self.practice_recipient_var, width=36).grid(row=0, column=2, sticky="w")
        ttk.Button(mode, text="연습 주소 저장", command=self.save_practice_address).grid(row=0, column=3, padx=6)
        self.mode_info_var = tk.StringVar()
        ttk.Label(mode, textvariable=self.mode_info_var).grid(row=1, column=0, columnspan=4, sticky="w", pady=(5, 0))
        self._mode_changed()

        report = ttk.LabelFrame(root, text="주간보고 정보", padding=8)
        report.pack(fill="x", pady=(10, 0))
        ttk.Label(report, text="대상 주차").grid(row=0, column=0, sticky="w")
        self.week_var = tk.StringVar(value=week_label_for_date(date.today()))
        ttk.Entry(report, textvariable=self.week_var, width=24).grid(row=0, column=1, sticky="w", padx=(6, 8))
        ttk.Button(report, text="오늘 기준 다시 계산", command=self.reset_week_label).grid(row=0, column=2, sticky="w")
        ttk.Button(report, text="지난 주 기록 불러오기", command=self.load_previous_history).grid(row=0, column=3, sticky="w", padx=(8, 0))
        ttk.Button(report, text="현재 내용 기록 저장", command=self.save_current_history).grid(row=0, column=4, sticky="w", padx=(8, 0))
        ttk.Label(report, text="현재 PC 날짜의 '해당 주 목요일' 기준 자동 계산 · 기록은 function/history에 로컬 저장").grid(row=1, column=0, columnspan=5, sticky="w", pady=(5, 0))

        self.current_tasks = TaskListFrame(root, "금주 진행 업무")
        self.current_tasks.pack(fill="x", pady=(10, 0))
        copy_bar = ttk.Frame(root)
        copy_bar.pack(fill="x", pady=(4, 0))
        ttk.Button(copy_bar, text="금주 업무 → 차주에 복사", command=self.copy_current_to_next).pack(side="left")
        ttk.Label(copy_bar, text="복사 후 차주 업무의 일정/내용을 수정하면 됩니다.").pack(side="left", padx=8)
        self.next_tasks = TaskListFrame(root, "차주 진행 예정 업무")
        self.next_tasks.pack(fill="x", pady=(6, 0))

        sched = ttk.LabelFrame(root, text="차주 일정", padding=8)
        sched.pack(fill="x", pady=(10, 0))
        people = list(self.config_data["mail"].get("schedule_people", []))
        default_value = self.config_data["mail"].get("default_schedule_value", "현대차(남양)")
        ttk.Label(sched, text="구분").grid(row=0, column=0, padx=3, pady=3)
        for c, day in enumerate(WEEKDAYS, 1):
            ttk.Label(sched, text=day).grid(row=0, column=c, padx=3, pady=3)
        ttk.Label(sched, text="☑ = 해당 셀 빨간색 굵게").grid(row=0, column=6, padx=(10, 3), pady=3, sticky="w")
        self.schedule_vars: dict[str, dict[str, tk.StringVar]] = {}
        self.schedule_highlight_vars: dict[str, dict[str, tk.BooleanVar]] = {}
        for r, person in enumerate(people, 1):
            ttk.Label(sched, text=person).grid(row=r, column=0, padx=3, pady=3, sticky="w")
            self.schedule_vars[person] = {}
            self.schedule_highlight_vars[person] = {}
            for c, day in enumerate(WEEKDAYS, 1):
                cell = ttk.Frame(sched)
                cell.grid(row=r, column=c, padx=3, pady=3, sticky="w")
                var = tk.StringVar(value=default_value)
                red_var = tk.BooleanVar(value=False)
                self.schedule_vars[person][day] = var
                self.schedule_highlight_vars[person][day] = red_var
                ttk.Entry(cell, textvariable=var, width=15).pack(side="left")
                ttk.Checkbutton(cell, variable=red_var, takefocus=False).pack(side="left", padx=(2, 0))

        actions = ttk.Frame(root)
        actions.pack(fill="x", pady=(10, 0))
        ttk.Button(actions, text="메일 미리보기 생성", command=self.generate_preview).pack(side="left")
        self.run_btn = ttk.Button(actions, text="GW 초안 작성 → 승인 대기", command=self.start_gw_flow)
        self.run_btn.pack(side="left", padx=8)
        self.approve_btn = ttk.Button(actions, text="승인 / 보내기", command=self.approve_send, state="disabled")
        self.approve_btn.pack(side="left")
        self.reject_btn = ttk.Button(actions, text="거절", command=self.reject_send, state="disabled")
        self.reject_btn.pack(side="left", padx=8)

        body = ttk.Panedwindow(root, orient="horizontal")
        body.pack(fill="x", pady=(10, 0))
        prev = ttk.LabelFrame(body, text="미리보기", padding=6)
        logf = ttk.LabelFrame(body, text="실행 로그", padding=6)
        body.add(prev, weight=3)
        body.add(logf, weight=2)

        # Keep roughly twenty text lines visible by default.  The main form can
        # be scrolled vertically, so these panes do not have to be compressed.
        preview_holder = ttk.Frame(prev)
        preview_holder.pack(fill="both", expand=True)
        self.preview = tk.Text(preview_holder, wrap="word", height=20)
        preview_scroll = ttk.Scrollbar(preview_holder, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=preview_scroll.set)
        preview_scroll.pack(side="right", fill="y")
        self.preview.pack(side="left", fill="both", expand=True)

        log_holder = ttk.Frame(logf)
        log_holder.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_holder, wrap="word", height=20, state="disabled")
        log_scroll = ttk.Scrollbar(log_holder, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        log_scroll.pack(side="right", fill="y")
        self.log_text.pack(side="left", fill="both", expand=True)

        self.status_var = tk.StringVar(value="대기")
        ttk.Label(root, textvariable=self.status_var).pack(anchor="w", pady=(6, 0))

    def _mode_changed(self):
        if self.practice_var.get():
            self.mode_info_var.set("연습 모드: 받는사람=연습 주소 1명, 참조=없음, 제목에 [연습] 접두사. 기본값입니다.")
        else:
            enabled = bool(self.config_data["mail"].get("production_send_enabled", False))
            if not enabled:
                self.mode_info_var.set("현재 설정에서는 정식 발송이 비활성화되어 있습니다. config를 확인하세요.")
                return
            recipient = self.config_data["mail"].get("production_recipient", "")
            cc = ", ".join(self.config_data["mail"].get("production_cc", [])) or "없음"
            self.mode_info_var.set(f"정식 발송 모드: 받는사람={recipient} / 참조={cc}. 최종 승인 전에는 보내기 버튼을 누르지 않습니다.")

    def reset_week_label(self):
        self.week_var.set(week_label_for_date(date.today()))
        self.status_var.set(f"대상 주차 자동 계산: {self.week_var.get()}")

    def save_current_history(self):
        try:
            report = self._report_input()
            record = save_week_record(report, reference_date=date.today())
            self.status_var.set(f"{record.get('week_label', report.week_label)} 기록 저장 완료")
            messagebox.showinfo(
                "기록 저장",
                f"현재 금주/차주 업무와 차주 일정을 로컬 기록으로 저장했습니다.\n"
                f"기준 목요일: {record.get('reference_thursday', '')}\n"
                "저장 위치: function/history/weekly_records.json",
            )
        except Exception as exc:
            messagebox.showerror("기록 저장 실패", str(exc))

    def load_previous_history(self):
        prev_label = previous_week_label(date.today())
        record = load_previous_week_record(reference_date=date.today())
        if not record:
            messagebox.showinfo(
                "지난 주 기록",
                f"{prev_label} 저장 기록이 없습니다.\n지난 주에 '현재 내용 기록 저장'을 먼저 사용해 주세요.",
            )
            return
        if (self.current_tasks.items or self.next_tasks.items) and not messagebox.askyesno(
            "지난 주 기록 불러오기",
            f"현재 금주/차주 업무 목록을 {record.get('week_label', prev_label)} 기록으로 교체합니다.\n"
            "불러온 행은 연한 노란색으로 표시되고, 더블클릭하여 수정 후 확인하면 흰색으로 바뀝니다.\n\n계속하시겠습니까?",
        ):
            return
        current = tasks_from_record(record, "current_tasks", mark_history=True)
        next_items = tasks_from_record(record, "next_tasks", mark_history=True)
        self.current_tasks.replace_with_history(current)
        self.next_tasks.replace_with_history(next_items)
        self.status_var.set(
            f"지난 주 기록 불러오기 완료: {record.get('week_label', prev_label)} · 노란색 행은 이전 주 원본"
        )

    def copy_current_to_next(self):
        if not self.current_tasks.items:
            messagebox.showinfo("업무 복사", "금주 진행 업무가 없습니다.")
            return
        copied = clone_tasks(self.current_tasks.items)
        if self.next_tasks.items:
            decision = messagebox.askyesnocancel(
                "금주 업무 → 차주 복사",
                "차주 업무가 이미 있습니다.\n\n예: 기존 차주 업무 뒤에 추가\n아니오: 기존 차주 업무를 지우고 교체\n취소: 복사하지 않음",
            )
            if decision is None:
                return
            if decision:
                self.next_tasks.items.extend(copied)
            else:
                self.next_tasks.items = copied
        else:
            self.next_tasks.items = copied
        self.next_tasks._refresh()
        self.status_var.set("금주 업무를 차주에 복사했습니다. 차주 일정/내용을 필요한 만큼 수정하세요.")

    def log(self, message: str):
        stamp = datetime.now().strftime("%H:%M:%S")
        self._events.put(("log", f"[{stamp}] {message}"))

    def _poll_events(self):
        try:
            while True:
                kind, payload = self._events.get_nowait()
                if kind == "log":
                    self.log_text.configure(state="normal")
                    self.log_text.insert("end", payload + "\n")
                    self.log_text.see("end")
                    self.log_text.configure(state="disabled")
                elif kind == "env":
                    self.env_var.set(payload)
                elif kind == "draft_ready":
                    self.status_var.set("GW 초안 입력 완료 - 실제 브라우저 확인 후 승인/거절")
                    self.approve_btn.configure(state="normal")
                    self.reject_btn.configure(state="normal")
                    self.run_btn.configure(state="disabled")
                elif kind == "done":
                    self._worker_running = False
                    self.run_btn.configure(state="normal")
                    self.approve_btn.configure(state="disabled")
                    self.reject_btn.configure(state="disabled")
                    self.status_var.set(payload)
        except queue.Empty:
            pass
        self.after(100, self._poll_events)

    def check_environment_async(self):
        env = check_environment(self.config_data)
        selected = env.get("selected_browser") or "없음"
        text = (
            f"Python {env['python']} | keyring {'OK' if env['keyring_ok'] else 'NO'} | "
            f"Playwright {'OK' if env['playwright_ok'] else 'NO'} | "
            f"Chromium {'OK' if env.get('chromium_ok') else 'NO'} | Edge {'OK' if env.get('edge_ok') else 'NO'} | "
            f"선택: {selected}"
        )
        self._events.put(("env", text))
        self.log(text)

    def save_credentials_dialog(self):
        username = simpledialog.askstring("GW ID", "그룹웨어 ID를 입력하세요.", parent=self)
        if username is None:
            return
        password = simpledialog.askstring("GW PW", "그룹웨어 비밀번호를 입력하세요.", parent=self, show="*")
        if password is None:
            return
        try:
            save_credentials(username, password)
            messagebox.showinfo("저장 완료", "GW ID/PW를 OS 자격증명 저장소(keyring)에 저장했습니다.\n평문 config/TXT에는 저장하지 않습니다.")
        except CredentialStoreError as exc:
            messagebox.showerror("저장 실패", str(exc))

    def save_practice_address(self):
        try:
            address = validate_email(self.practice_recipient_var.get())
            save_practice_recipient(address)
            self.config_data = load_config()
            messagebox.showinfo("저장 완료", f"연습 수신자를 저장했습니다.\n{address}")
        except Exception as exc:
            messagebox.showerror("주소 확인", str(exc))

    def _report_input(self) -> WeeklyReportInput:
        schedule = {
            person: {day: var.get().strip() for day, var in by_day.items()}
            for person, by_day in self.schedule_vars.items()
        }
        highlights = {
            person: {day: bool(var.get()) for day, var in by_day.items()}
            for person, by_day in self.schedule_highlight_vars.items()
        }
        return WeeklyReportInput(
            week_label=self.week_var.get().strip(),
            current_tasks=list(self.current_tasks.items),
            next_tasks=list(self.next_tasks.items),
            next_week_schedule=schedule,
            next_week_schedule_highlight=highlights,
        )

    def _envelope(self):
        return build_envelope(
            self._report_input(),
            self.config_data,
            practice_mode=self.practice_var.get(),
            practice_recipient=self.practice_recipient_var.get().strip(),
        )

    def generate_preview(self):
        try:
            envelope = self._envelope()
        except (ValidationError, Exception) as exc:
            messagebox.showerror("미리보기 생성 실패", str(exc))
            return
        header = f"받는사람: {', '.join(envelope.to)}\n참조: {', '.join(envelope.cc) if envelope.cc else '(없음)'}\n제목: {envelope.subject}\n\n"
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", header + envelope.text_body)
        self.status_var.set("미리보기 생성 완료")

    def start_gw_flow(self):
        if self._worker_running:
            messagebox.showinfo("WeeklyMailAgent", "이미 GW 작업이 진행 중입니다.")
            return
        try:
            envelope = self._envelope()
        except Exception as exc:
            messagebox.showerror("입력 확인", str(exc))
            return
        self.generate_preview()
        if envelope.practice_mode:
            confirm_title = "GW 연습 초안 작성"
            confirm_text = (
                f"연습 모드로 GW 초안을 작성합니다.\n\n"
                f"받는사람: {', '.join(envelope.to)}\n"
                f"참조: (없음)\n\n"
                "아직 보내기 버튼은 누르지 않습니다. 계속하시겠습니까?"
            )
        else:
            confirm_title = "정식 발송 모드 확인"
            confirm_text = (
                "연습 모드가 해제되어 있습니다. 아래 정식 대상에게 GW 초안을 작성합니다.\n\n"
                f"받는사람: {', '.join(envelope.to)}\n"
                f"참조: {', '.join(envelope.cc) if envelope.cc else '(없음)'}\n\n"
                "이 단계에서는 아직 보내지 않으며, 실제 GW 초안 확인 후 별도의 '승인 / 보내기'가 필요합니다.\n"
                "계속하시겠습니까?"
            )
        if not messagebox.askokcancel(confirm_title, confirm_text):
            return
        self._worker_running = True
        self.run_btn.configure(state="disabled")
        self.status_var.set("GW 접속/초안 작성 중...")
        thread = threading.Thread(target=self._worker, args=(envelope,), daemon=True)
        thread.start()

    def _worker(self, envelope):
        try:
            result = run_mail_flow(
                envelope=envelope,
                config=self.config_data,
                site=self.site_profile,
                profile_root=app_root() / self.config_data["gw"].get("profile_dir", "browser_profile"),
                approval_gate=self.approval_gate,
                log=self.log,
                on_draft_ready=lambda: self._events.put(("draft_ready", None)),
            )
            mapping = {
                "REJECTED": "발송 거절 완료",
                "SENT_CONFIRMED": "발송 완료(화면 확인됨)",
                "SENT_UNCONFIRMED": "보내기 1회 클릭됨 - 발송 여부 직접 확인 필요(자동 재시도 안 함)",
            }
            self._events.put(("done", mapping.get(result, result)))
        except Exception as exc:
            self.log(f"실패: {exc}")
            self.log(traceback.format_exc())
            self._events.put(("done", "실패"))

    def approve_send(self):
        if not self._worker_running:
            return
        if not messagebox.askyesno(
            "최종 발송 승인",
            "현재 GW 브라우저의 받는사람/참조/제목/본문을 확인하셨습니까?\n\n승인하면 프로그램이 '보내기' 버튼을 정확히 1회 클릭합니다.",
        ):
            return
        self.approve_btn.configure(state="disabled")
        self.reject_btn.configure(state="disabled")
        self.status_var.set("사용자 승인 - 발송 직전 재검증 중...")
        self.approval_gate.approve()

    def reject_send(self):
        if not self._worker_running:
            return
        self.approve_btn.configure(state="disabled")
        self.reject_btn.configure(state="disabled")
        self.status_var.set("사용자 거절 처리 중...")
        self.approval_gate.reject()


def main():
    app = WeeklyMailApp()
    app.mainloop()
