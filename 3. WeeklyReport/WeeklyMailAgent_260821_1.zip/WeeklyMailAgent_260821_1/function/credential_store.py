from __future__ import annotations

# BoardRepo uses this Windows keyring service.  WeeklyMailAgent v0.4 shares it
# so a credential already saved by BoardRepo can be reused without re-entry.
BOARDREPO_SERVICE = "BoardRepo_Groupware"
LEGACY_WMA_SERVICE = "WeeklyMailAgent.GW"
LEGACY_USERNAME_KEY = "username"
LEGACY_PASSWORD_KEY = "password"


class CredentialStoreError(RuntimeError):
    pass


def _keyring():
    try:
        import keyring
        return keyring
    except Exception as exc:
        raise CredentialStoreError("keyring 모듈을 사용할 수 없습니다. 환경 확인을 먼저 수행하세요.") from exc


def save_credentials(username: str, password: str) -> None:
    username = username.strip()
    if not username or not password:
        raise CredentialStoreError("ID와 PW를 모두 입력해야 합니다.")
    kr = _keyring()
    try:
        # Same layout as BoardRepo credential_store.py.
        kr.set_password(BOARDREPO_SERVICE, "__username__", username)
        kr.set_password(BOARDREPO_SERVICE, username, password)
    except Exception as exc:
        raise CredentialStoreError(f"OS 자격증명 저장소 저장 실패: {exc}") from exc


def _load_boardrepo_credentials(kr):
    username = kr.get_password(BOARDREPO_SERVICE, "__username__")
    if not username:
        return None
    password = kr.get_password(BOARDREPO_SERVICE, username)
    if not password:
        return None
    return username, password


def _load_legacy_wma_credentials(kr):
    username = kr.get_password(LEGACY_WMA_SERVICE, LEGACY_USERNAME_KEY)
    password = kr.get_password(LEGACY_WMA_SERVICE, LEGACY_PASSWORD_KEY)
    if username and password:
        return username, password
    return None


def load_credentials() -> tuple[str, str] | None:
    kr = _keyring()
    try:
        creds = _load_boardrepo_credentials(kr)
        if creds:
            return creds
        # Compatibility with v0.1~v0.3 users.  Migrate silently to the shared
        # BoardRepo store after a successful read.
        legacy = _load_legacy_wma_credentials(kr)
        if legacy:
            username, password = legacy
            kr.set_password(BOARDREPO_SERVICE, "__username__", username)
            kr.set_password(BOARDREPO_SERVICE, username, password)
            return legacy
    except Exception as exc:
        raise CredentialStoreError(f"OS 자격증명 저장소 읽기 실패: {exc}") from exc
    return None


def clear_credentials() -> None:
    kr = _keyring()
    try:
        username = kr.get_password(BOARDREPO_SERVICE, "__username__")
        if username:
            try:
                kr.delete_password(BOARDREPO_SERVICE, username)
            except Exception:
                pass
        try:
            kr.delete_password(BOARDREPO_SERVICE, "__username__")
        except Exception:
            pass
    except Exception:
        pass
