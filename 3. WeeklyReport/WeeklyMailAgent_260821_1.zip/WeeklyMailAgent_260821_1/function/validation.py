from __future__ import annotations

import re
from html.parser import HTMLParser

EMAIL_RE = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


class ValidationError(ValueError):
    pass


class _ImageCounter(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.img_count = 0

    def handle_starttag(self, tag: str, attrs):
        if tag.lower() == "img":
            self.img_count += 1


def validate_email(address: str) -> str:
    address = address.strip()
    if not address or not EMAIL_RE.fullmatch(address):
        raise ValidationError(f"올바른 이메일 주소가 아닙니다: {address or '(빈 값)'}")
    return address


def assert_no_images(html_body: str) -> None:
    parser = _ImageCounter()
    parser.feed(html_body)
    if parser.img_count:
        raise ValidationError(f"메일 본문에 이미지 태그가 {parser.img_count}개 포함되어 있습니다.")


def assert_nonempty(value: str, field_name: str) -> str:
    value = value.strip()
    if not value:
        raise ValidationError(f"필수 항목이 비어 있습니다: {field_name}")
    return value
