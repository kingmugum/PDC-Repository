from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class TaskItem:
    name: str
    schedule: str
    place: str
    keywords: str = ""
    from_history: bool = False

    def as_current(self) -> "TaskItem":
        """Return the same task as a current editable item (history highlight cleared)."""
        return TaskItem(self.name, self.schedule, self.place, self.keywords, False)

    def as_history(self) -> "TaskItem":
        """Return the same task marked as loaded from a previous-week record."""
        return TaskItem(self.name, self.schedule, self.place, self.keywords, True)


def clone_tasks(tasks: list[TaskItem]) -> list[TaskItem]:
    """Create independent TaskItem objects while preserving history-origin state."""
    return [TaskItem(x.name, x.schedule, x.place, x.keywords, x.from_history) for x in tasks]


@dataclass
class WeeklyReportInput:
    week_label: str
    current_tasks: list[TaskItem] = field(default_factory=list)
    next_tasks: list[TaskItem] = field(default_factory=list)
    next_week_schedule: dict[str, dict[str, str]] = field(default_factory=dict)
    next_week_schedule_highlight: dict[str, dict[str, bool]] = field(default_factory=dict)


@dataclass(frozen=True)
class MailEnvelope:
    to: list[str]
    cc: list[str]
    subject: str
    html_body: str
    text_body: str
    practice_mode: bool
