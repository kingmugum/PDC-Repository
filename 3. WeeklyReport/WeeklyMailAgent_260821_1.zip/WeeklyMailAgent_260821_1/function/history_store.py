from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from .config_loader import app_root
from .models import TaskItem, WeeklyReportInput
from .week_calculator import thursday_of_week, week_label_for_date


HISTORY_DIRNAME = "history"
HISTORY_FILENAME = "weekly_records.json"


def history_path(path: Path | None = None) -> Path:
    if path is not None:
        return Path(path)
    folder = app_root() / HISTORY_DIRNAME
    folder.mkdir(parents=True, exist_ok=True)
    return folder / HISTORY_FILENAME


def _read_db(path: Path | None = None) -> dict[str, Any]:
    target = history_path(path)
    if not target.exists():
        return {"schema_version": 1, "records": {}}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except Exception:
        return {"schema_version": 1, "records": {}}
    if not isinstance(data, dict):
        return {"schema_version": 1, "records": {}}
    data.setdefault("schema_version", 1)
    data.setdefault("records", {})
    if not isinstance(data["records"], dict):
        data["records"] = {}
    return data


def _write_db(data: dict[str, Any], path: Path | None = None) -> Path:
    target = history_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(target)
    return target


def _task_to_dict(item: TaskItem) -> dict[str, str]:
    return {
        "name": item.name,
        "schedule": item.schedule,
        "place": item.place,
        "keywords": item.keywords,
    }


def _task_from_dict(raw: dict[str, Any], *, mark_history: bool) -> TaskItem:
    return TaskItem(
        str(raw.get("name", "")),
        str(raw.get("schedule", "")),
        str(raw.get("place", "")),
        str(raw.get("keywords", "")),
        mark_history,
    )


def save_week_record(
    report: WeeklyReportInput,
    *,
    reference_date: date | None = None,
    path: Path | None = None,
) -> dict[str, Any]:
    """Save a local weekly snapshot. Credentials are never stored here."""
    ref = reference_date or date.today()
    thu = thursday_of_week(ref)
    record_id = thu.isoformat()
    record = {
        "record_id": record_id,
        "reference_thursday": record_id,
        "week_label": report.week_label,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "current_tasks": [_task_to_dict(x) for x in report.current_tasks],
        "next_tasks": [_task_to_dict(x) for x in report.next_tasks],
        "next_week_schedule": report.next_week_schedule,
        "next_week_schedule_highlight": report.next_week_schedule_highlight,
    }
    db = _read_db(path)
    db["records"][record_id] = record
    _write_db(db, path)
    return record


def previous_week_reference(reference_date: date | None = None) -> date:
    ref = reference_date or date.today()
    return thursday_of_week(ref) - timedelta(days=7)


def previous_week_label(reference_date: date | None = None) -> str:
    return week_label_for_date(previous_week_reference(reference_date))


def load_previous_week_record(
    *,
    reference_date: date | None = None,
    path: Path | None = None,
) -> dict[str, Any] | None:
    prev_thu = previous_week_reference(reference_date)
    db = _read_db(path)
    record = db.get("records", {}).get(prev_thu.isoformat())
    return record if isinstance(record, dict) else None


def tasks_from_record(record: dict[str, Any], section: str, *, mark_history: bool = True) -> list[TaskItem]:
    rows = record.get(section, []) if isinstance(record, dict) else []
    if not isinstance(rows, list):
        return []
    return [_task_from_dict(x, mark_history=mark_history) for x in rows if isinstance(x, dict)]
