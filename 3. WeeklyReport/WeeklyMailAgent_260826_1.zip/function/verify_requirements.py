from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent  # function/
PACKAGE_ROOT = ROOT.parent
REPORT_JSON = ROOT / "verification_report.json"
REPORT_TXT = ROOT / "verification_report.txt"


def static_checks():
    checks = []

    def add(cid, ok, evidence):
        checks.append({"check_id": cid, "result": "PASS" if ok else "FAIL", "evidence": evidence})

    config_text = (ROOT / "config.json").read_text(encoding="utf-8")
    config = json.loads(config_text)
    site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
    gw_src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
    cred_src = (ROOT / "credential_store.py").read_text(encoding="utf-8")
    routing_src = (ROOT / "routing.py").read_text(encoding="utf-8")
    app_src = (ROOT / "app.py").read_text(encoding="utf-8")
    models_src = (ROOT / "models.py").read_text(encoding="utf-8")
    builder_src = (ROOT / "mail_builder.py").read_text(encoding="utf-8")
    week_src = (ROOT / "week_calculator.py").read_text(encoding="utf-8")
    config_loader_src = (ROOT / "config_loader.py").read_text(encoding="utf-8")
    browser_src = (ROOT / "browser_runtime.py").read_text(encoding="utf-8")
    env_src = (ROOT / "environment_manager.py").read_text(encoding="utf-8")
    history_src = (ROOT / "history_store.py").read_text(encoding="utf-8")

    add("ST-001", '"password"' not in config_text.lower(), "function/config.json에 password 키 없음")
    add("ST-002", "keyring" in cred_src and "set_password" in cred_src, "OS keyring 저장 구현")
    add("ST-003", config["mail"]["practice_mode_default"] is False, "연습 모드 기본 OFF / 정식 모드 기본")
    add("ST-004", config["mail"]["production_send_enabled"] is True, "v0.16 정식 발송 활성화")
    add("ST-005", "cc: list[str] = []" in routing_src, "연습 모드 CC 제거")
    add("ST-006", "approval_gate.event.wait()" in gw_src, "GW 초안 후 승인 대기")
    add("ST-007", 'approval_gate.decision != "approve"' in gw_src, "승인 없으면 send 미진입")
    add("ST-008", "정확한 '보내기' 버튼을 1회 클릭" in gw_src, "1회 send 정책 로그")
    add("ST-009", "자동 재시도하지 않습니다" in gw_src, "불확정 시 no retry")
    add("ST-010", "img" in gw_src and "발송을 차단" in gw_src, "이미지 잔존 차단")
    add("ST-011", "body_iframe_selectors" in site["mail"], "웹에디터 selector 외부화")
    add("ST-012", config["gw"]["allow_online_pip"] is False, "온라인 pip 기본 OFF")
    add("ST-013", config["gw"]["allow_playwright_browser_download"] is False, "브라우저 자동 다운로드 OFF")
    add("ST-014", (ROOT / "00_PACKAGE_NAMING_RULE.txt").exists(), "function 내부 패키지 명명 규칙 포함")
    add("ST-015", "production_addresses" in gw_src and "leaked = (actual_to | actual_cc) & production_addresses" in gw_src, "연습 모드 실제 To/CC 필드에 정식 주소 혼입 차단")
    add("ST-016", "to_committed" in gw_src and "cc_committed" in gw_src and "actual_cc" in gw_src, "연습/정식 routing이 visible email exact 검증 + 자동완성 committed-token 검증을 함께 수행")

    manifest_path = ROOT / "package_manifest.json"
    manifest_ok = False
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest_ok = manifest.get("package_name") == "WeeklyMailAgent_260826_1.zip" and manifest.get("technical_version") == "v0.16"
        except Exception:
            manifest_ok = False
    add("ST-017", manifest_ok, "function/package_manifest.json 기준선/패키지명 확인")

    add("ST-018", config["mail"].get("practice_recipient") == "dcpark@suresofttech.com", "연습 수신자 기본값 사전 설정")
    add("ST-019", "thursday_of_week" in week_src and "week_label_for_date(date.today())" in app_src, "현재 날짜 + 목요일 기준 주차 자동 계산")
    add("ST-020", "schedule_highlight_vars" in app_src and "ttk.Checkbutton(cell" in app_src, "인원×요일 강조 체크박스 GUI")
    add("ST-021", "color:#d00000;font-weight:700;" in builder_src, "체크된 일정 셀 red+bold HTML 스타일")
    add("ST-022", "clone_tasks" in models_src and "금주 업무 → 차주에 복사" in app_src, "금주→차주 업무 복사 및 독립 복제")
    add("ST-023", (ROOT / "WeeklyMailAgent_Requirements_v0_16.xlsx").exists(), "v0.16 요구사항 Excel function 내부 포함")
    add("ST-024", "class ScrollableContent" in app_src and 'orient="vertical"' in app_src and 'side="right", fill="y"' in app_src, "프로그램 전체 우측 세로 스크롤바")
    add("ST-025", app_src.count('height=20') >= 2 and "preview_scroll" in app_src and "log_scroll" in app_src, "미리보기/실행로그 20줄 + 개별 세로 스크롤")

    root_entries = {p.name for p in PACKAGE_ROOT.iterdir() if p.name != "__pycache__"}
    add("ST-026", root_entries == {"WeeklyMailAgent.pyw", "function"}, "압축 해제 최상위는 실행파일 + function 폴더만 유지")
    support_required = [
        "config.json", "site_profile.json", "README.md", "MANUAL.txt", "00_PACKAGE_NAMING_RULE.txt",
        "WeeklyMailAgent_Requirements_v0_16.xlsx", "verify_requirements.py", "requirements_catalog.json",
        "tests", "browser_profile", "logs", "history",
    ]
    support_ok = all((ROOT / name).exists() for name in support_required)
    app_root_ok = 'return Path(__file__).resolve().parent' in config_loader_src and 'parent.parent' not in config_loader_src
    add("ST-027", support_ok and app_root_ok, "지원 파일/설정/요구사항/테스트를 function 내부로 집약하고 runtime data root도 function으로 변경")
    add("ST-028", config.get("browser", {}).get("auto_order") == ["playwright_chromium", "msedge"] and "_existing_playwright_chromium" in browser_src, "BoardRepo와 동일한 Playwright Chromium → Edge 브라우저 우선순위")
    add("ST-029", 'BOARDREPO_SERVICE = "BoardRepo_Groupware"' in cred_src and '"__username__"' in cred_src and "LEGACY_WMA_SERVICE" in cred_src, "BoardRepo keyring 자격증명 공유 + 기존 WMA 호환 읽기")
    add("ST-030", "def _looks_like_login_page" in gw_src and "password_selectors" in gw_src and "page.goto(mail_url" in gw_src and "로그인 대기시간" in gw_src, "password 입력란 기반 로그인 판정 + /app/mail 접근 확인 + 수동 인증 대기")
    add("ST-031", 'args=["--start-maximized"]' not in browser_src and '"--no-sandbox"' not in browser_src, "WeeklyMailAgent 소스에서 별도 --start-maximized/--no-sandbox 플래그 미사용")
    add("ST-032", '"selected_browser"' in env_src and '"chromium_ok"' in env_src and '"edge_ok"' in env_src and "선택:" in app_src, "환경 진단에 Chromium/Edge/선택 브라우저 표시")
    add("ST-033", (ROOT / "WeeklyMailAgent_Requirements_v0_16.xlsx").exists(), "v0.16 요구사항 Excel function 내부 포함")
    write_selectors = site["mail"].get("write_button_selectors", [])
    add("ST-034", "input[type='button'][value='메일쓰기']" in write_selectors and "xpath=//*[normalize-space(@value)='메일쓰기']" in write_selectors, "메일쓰기 input[value] 선택자 외부화")
    add("ST-035", "get_by_text(name, exact=True)" in gw_src and "page.frames" in gw_src and "mouse.click" not in gw_src, "메일쓰기 exact-text + child frame 탐색, 좌표 클릭 미사용")
    add("ST-036", "_describe_exact_control_candidates" in gw_src and "후보 DOM 진단" in gw_src and "aria-label" in gw_src and "title" in gw_src, "메일쓰기 탐색 실패 시 비민감 DOM 후보 진단 로그")
    add("ST-037", "def _first_visible_in_contexts" in gw_src and "def _find_compose_field" in gw_src and "_search_contexts(page)" in gw_src, "받는사람/참조/제목 입력란 main page + child frame 탐색")
    add("ST-038", "def _discover_labeled_editable" in gw_src and "get_by_text(label_text, exact=True)" in gw_src and "same horizontal row" in gw_src and "mouse.click" not in gw_src, "selector 실패 시 exact 라벨 같은 행 editable fallback, 좌표 입력 금지")
    compose_part = gw_src[gw_src.index("def _fill_compose("):gw_src.index("def _pre_send_revalidate(")]
    body_first_ok = compose_part.index("_clear_editor_only") < compose_part.index("_fill_editor_html") < compose_part.index("_fill_address_field") < compose_part.index("_set_subject_exact")
    add("ST-039", body_first_ok and "메일쓰기 진입 직후 기본 서명/사진/본문을 먼저 삭제" in gw_src, "작성화면 진입 후 기본 본문 우선 삭제/생성 → 주소 자동완성 → 제목 최종 확정 순서")
    add("ST-040", "def _describe_editable_candidates" in gw_src and "never include current input values" in gw_src and "입력란 후보 DOM 진단" in gw_src, "작성 필드 실패 시 비민감 DOM 메타데이터 진단")
    add("ST-041", len(site["mail"].get("to_selectors", [])) >= 6 and len(site["mail"].get("cc_selectors", [])) >= 6 and len(site["mail"].get("subject_selectors", [])) >= 6, "받는사람/참조/제목 site_profile selector 후보 보강")
    add("ST-042", "def _verify_routing_fields" in gw_src and "def _safe_field_text" in gw_src and "for _, ctx in _search_contexts(page)" in gw_src and '"제목", timeout_ms, log' in gw_src, "본문 Editor/실제 To·CC routing/발송 전 제목 검증 frame-aware 통일")
    add("ST-043", "self.practice_var.set(True)" not in app_src[app_src.index("def _mode_changed"):app_src.index("def reset_week_label")], "연습 모드 체크 해제 시 정식 모드로 유지 가능")
    routing_verify_part = gw_src[gw_src.index("def _validate_actual_routing_texts"):gw_src.index("def _fill_compose") ]
    add("ST-044", "_all_context_text" not in routing_verify_part and "actual_to" in routing_verify_part and "actual_cc" in routing_verify_part, "routing 안전검증은 작성화면 전체가 아니라 실제 받는사람/참조 필드만 검사")
    add("ST-045", "if actual_to and actual_to != expected_to" in routing_verify_part and "if actual_cc and actual_cc != expected_cc" in routing_verify_part and config["mail"].get("production_send_enabled") is True, "정식 모드 visible email exact-set 재검증 + 정식 모드 활성화")
    add("ST-046", "def _safe_field_state" in gw_src and "display-name chip" in gw_src and "autocomplete-token" in gw_src, "GW 이메일→표시명 자동완성 수신자 칩 호환")
    add("ST-047", "baseline" in gw_src and "fingerprint" in gw_src and "초안 작성 시점과 달라졌습니다" in gw_src, "자동완성 수신자 칩 초안 baseline/승인 직전 fingerprint 안정성 검증")
    add("ST-048", "def save_week_record" in history_src and "weekly_records.json" in history_src and '"password"' not in history_src.lower(), "주간 기록 로컬 JSON 저장 + 자격증명 비포함 구조")
    add("ST-049", "지난 주 기록 불러오기" in app_src and "load_previous_week_record" in app_src and "tasks_from_record" in app_src, "지난 주 기록을 금주/차주 업무 목록으로 불러오기")
    add("ST-050", 'tag_configure("history", background="#FFF2CC")' in app_src and "from_history=False" in app_src, "지난 주 행 연한 노란색 표시 + 수정 확인 시 일반행 전환")
    add("ST-051", "def _commit_address_by_tab" in gw_src and 'loc.press_sequentially(address, delay=25)' in gw_src and 'page.wait_for_timeout(650)' in gw_src and 'loc.press("Tab")' in gw_src and "_find_exact_autocomplete_candidate" not in gw_src and 'loc.press("ArrowDown")' not in gw_src, "받는사람/참조는 실제 키 입력 이벤트 + 대기 + Tab으로 GW 자체 확정")
    add("ST-052", "to_input_proof" in gw_src and "cc_input_proof" in gw_src and "tab-commit-proof" in gw_src, "Tab 확정 후 DOM input/chip 판독 불가 시 exact 입력+Tab 증거 허용")
    add("ST-053", "def _clean_routing_residue" in gw_src and '"중요!"' in gw_src and '"+"' in gw_src, "참조 우측 + 및 제목 중요 체크박스를 routing 판정에서 무시")
    add("ST-054", "the small '+' beside 참조" in gw_src and "제목 '중요!' checkbox" in gw_src and "mouse.click" not in gw_src, "참조 + / 제목 중요 컨트롤을 별도 조작하지 않음")
    recipient_part = gw_src[gw_src.index("def _recipient_row_text"):gw_src.index("def _commit_address_by_tab")]
    add("ST-055", "same horizontal recipient band" in recipient_part and "getComputedStyle" in recipient_part and "overlapsInputBand" in recipient_part and "r.height <= 86" in recipient_part, "받는사람/참조 검증을 visible 동일 행 geometry로 한정")
    add("ST-056", ".innerText" not in recipient_part and "createTreeWalker" in recipient_part, "광범위 ancestor innerText 대신 visible text-node만 수집")
    add("ST-057", "실제 주소행 표시 확인" in gw_src and "to_state.get('emails'" in gw_src and "cc_state.get('emails'" in gw_src, "실제 주소행에서 검출한 e-mail만 진단 로그에 기록")
    clear_part = gw_src[gw_src.index("def _clear_editor_only"):gw_src.index("def _fill_editor_html")]
    add("ST-058", "body.click()" not in clear_part and "Direct DOM mutation" in clear_part, "기본 본문 삭제 시 하단 Editor 클릭/자동스크롤 방지")
    add("ST-059", "def _restore_compose_top" in gw_src and "window.scrollTo(0, 0)" in gw_src and "_restore_compose_top(page, log)" in gw_src, "초안 완료 후 메일쓰기 page/frame 상단 복원")
    add("ST-060", "def _confirm_recipient_exact_after_fill" not in gw_src and "_repair_missing_recipient_after_body" not in gw_src and compose_part.index("_fill_editor_html") < compose_part.index("_fill_address_field") and "e-mail text -> Tab" in compose_part, "본문 완료 후 To/CC를 exact 이메일+Tab 방식으로 최종 입력하고 칩 DOM 강제검증/재입력 제거")
    add("ST-061", "def next_week_label" in week_src and "nth_thursday" in week_src and "next_week = next_week_label(week)" in builder_src and "{next_week} 진행 예정 업무" in builder_src, "차주 진행 예정 업무를 다음 목요일 기준 주차로 생성")
    add("ST-062", config["mail"].get("sender_intro") == "안녕하십니까 팀장님, 모빌리티솔루션1팀 박동천 선임입니다.", "본문 첫 인사말을 팀장님으로 고정")
    add("ST-063", "def _set_subject_exact" in gw_src and "제목 실제 입력란에 입력 및 유지 확인" in gw_src and 'subject.press("Tab")' in gw_src and compose_part.index("_fill_editor_html") < compose_part.index("_set_subject_exact"), "본문 렌더링 완료 후 제목 exact 재확정/유지 검증")
    add("ST-064", config["mail"].get("subject_template") == "[주간보고] {week_label}_SW Integration 실차 검증 및 TC 강건화 용역", "주간보고 제목 템플릿 exact 유지")
    add("ST-065", "def _candidate_is_compose_text_entry" in gw_src and "_candidate_is_compose_text_entry(loc)" in gw_src, "받는사람/참조/제목 selector 결과에서 checkbox/radio/file 등 비텍스트 컨트롤 거부")
    selector_heads = " ".join(site["mail"].get("to_selectors", [])[:2] + site["mail"].get("subject_selectors", [])[:2]).lower()
    add("ST-066", "checkbox" in selector_heads and "not(" in selector_heads, "받는사람의 나에게 checkbox와 제목의 중요 checkbox를 XPath 단계에서 제외")
    commit_part = gw_src[gw_src.index("def _commit_address_by_tab"):gw_src.index("def _fill_address_field")]
    add("ST-067", "press_sequentially" in commit_part and "fill(address)" not in commit_part and "wait_for_timeout(650)" in commit_part, "GW 주소 확정 전에 실제 keyboard event와 pre-Tab 대기 사용")
    fill_addr_part = gw_src[gw_src.index("def _fill_address_field"):gw_src.index("def _safe_field_state")]
    add("ST-068", fill_addr_part.count("items.append(proof)") == 1, "주소 1개당 Tab commit proof를 정확히 1회 기록")
    subject_part = gw_src[gw_src.index("def _discover_subject_text_field"):gw_src.index("def _find_compose_field")]
    add("ST-069", "동일 행 전용 탐색" in subject_part and 'box["width"] < 220' in subject_part and "dy > 22" in subject_part and 'if label_text == "제목"' in gw_src, "제목은 exact 제목 라벨의 동일 수평행 geometry 전용 finder를 최우선 사용")
    add("ST-070", all("following::" not in x.lower() for x in site["mail"].get("subject_selectors", [])), "subject site profile에서 broad following:: selector 제거")
    editor_part = gw_src[gw_src.index("def _find_editor"):gw_src.index("def _clear_editor_only")]
    add("ST-071", "deadline = time.time()" in editor_part and "while time.time() < deadline" in editor_part and "time.sleep(0.2)" in editor_part, "본문 Editor 탐색을 selector timeout 동안 0.2초 polling으로 bounded retry")
    start_flow_part = app_src[app_src.index("def start_gw_flow"):app_src.index("def _worker")]
    add("ST-072", "self._save_history_snapshot(notify=False)" in start_flow_part and start_flow_part.index("self._save_history_snapshot(notify=False)") < start_flow_part.index("threading.Thread"), "GW 초안 작성→승인 대기 시작 시 현재 주차 기록 자동 저장")
    task_dialog_part = app_src[app_src.index("class TaskDialog"):app_src.index("class TaskListFrame")]
    add("ST-073", "self.keywords_text = tk.Text" in task_dialog_part and "height=6" in task_dialog_part and "<Control-Return>" in task_dialog_part, "키워드/내용 다중행 Text 입력 UI")
    add("ST-074", "def _task_detail_lines" in builder_src and "detail_lines[1:]" in builder_src and "<br>" in builder_src, "다중행 키워드/내용을 text/html 메일에서 줄바꿈 유지")
    return checks


def run_unit_tests():
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-v"],
        cwd=PACKAGE_ROOT,
        capture_output=True,
        text=True,
    )
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output


def main():
    static = static_checks()
    unit_ok, unit_output = run_unit_tests()
    compile_proc = subprocess.run(
        [sys.executable, "-m", "compileall", "-q", str(ROOT), str(PACKAGE_ROOT / "WeeklyMailAgent.pyw")],
        cwd=PACKAGE_ROOT,
        capture_output=True,
        text=True,
    )
    compile_ok = compile_proc.returncode == 0

    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "technical_version": "v0.16",
        "package": "WeeklyMailAgent_260826_1.zip",
        "offline_verification": {
            "static_checks": static,
            "unit_tests": {"result": "PASS" if unit_ok else "FAIL", "output": unit_output},
            "compile": {"result": "PASS" if compile_ok else "FAIL", "output": (compile_proc.stdout or "") + (compile_proc.stderr or "")},
        },
        "live_gw_verification": {
            "result": "PARTIAL",
            "reason": "사용자 제공 2026-08-21 17:36 로그의 실행 경로는 WeeklyMailAgent_260821_2로, v0.15(_3)가 아니라 v0.14를 실행한 로그입니다. 따라서 제목 following::input 문제는 v0.15에서 이미 수정했지만 해당 수정본은 아직 현장 검증되지 않았습니다. v0.16은 v0.15의 제목 exact-label same-row finder와 Editor bounded retry를 그대로 유지하면서, 기본 연습모드 OFF, GW 초안 작성→승인 대기 시 현재 주차 자동 기록 저장, 키워드/내용 다중행 입력/본문 줄바꿈을 추가했습니다. 실제 제목 입력, 자동 기록 저장, 다중행 GUI, 승인/발송/수신은 재검증 필요",
            "confirmed_live_evidence": [
                "Playwright Chromium persistent profile 실행 PASS",
                "BoardRepo 호환 keyring ID/PW 자동 로그인 PASS",
                "/app/mail 접근 PASS",
                "context=frame[1]의 정확한 메일쓰기 컨트롤 클릭 및 작성 화면 진입 PASS",
            ],
            "required_next_tests": [
                "프로그램 전체 우측 스크롤바로 최하단까지 이동 가능 여부",
                "미리보기/실행 로그 약 20줄 기본 높이 및 개별 스크롤 확인",
                "압축 해제 최상위에 WeeklyMailAgent.pyw와 function 폴더만 존재하는지 확인",
                "최상위 WeeklyMailAgent.pyw 더블클릭 실행 후 function 내부 설정/브라우저 프로파일 정상 접근",
                "현재 날짜 기준 대상 주차 자동값 확인(2026-08-19이면 8월 3주차)",
                "환경 확인에서 Playwright Chromium 우선 선택 또는 Edge fallback 상태 확인",
                "BoardRepo에 저장된 GW keyring 자격증명 재사용 확인",
                "GW 로그인 및 세션 재사용",
                "v0.5 현장 로그에서 메일쓰기 컨트롤 frame[1] 실제 진입 PASS",
                "v0.6 현장 로그에서 메일쓰기 진입 직후 기본 서명/사진/본문 우선 삭제 및 이미지 0개 확인 PASS",
                "v0.6 현장 로그에서 받는사람/참조/제목을 frame[1]에서 실제 입력 PASS",
                "v0.7 현장 로그에서 정식 To/CC 입력 후 GW 자동완성으로 표시명 수신자 칩 전환 및 input email 공백(actual=[]) 현상 확인",
                "v0.16에서 To/CC typed+Tab 입력 유지 및 실제 수신자 표시 확인",
                "기본 실행 시 연습 모드 체크 해제 상태 확인",
                "GW 초안 작성→승인 대기 확인 직후 function/history에 현재 주차 자동 저장 확인",
                "키워드/내용 여러 줄 입력 및 메일 본문 줄바꿈 유지 확인",
                "제목 전용 동일행 탐색 로그가 출력되고 실제 제목란에 [주간보고] 제목이 표시되는지 확인",
                "메일쓰기 직후 Editor 로딩이 지연되어도 timeout 내 반복 탐색으로 진행되는지 연속 실행 확인",
                "현재 내용 기록 저장 → 다음 주 지난 주 기록 불러오기 → 노란색 행 표시 → 더블클릭 수정 후 흰색 전환 확인",
                "기본 서명/사진 완전 삭제 및 이미지 0개",
                "연습 수신자 dcpark@suresofttech.com만 입력되고 CC가 비어 있음",
                "금주 업무 → 차주 복사 후 차주 항목만 수정되는지 확인",
                "차주 일정 강조 체크 셀이 실제 메일에서 빨간색 굵게 표시되는지 확인",
                "실제 GW 초안 입력 후 승인 대기",
                "승인 시 보내기 1회 클릭",
                "연습 수신 메일 실제 도착 확인",
            ],
        },
    }
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "WeeklyMailAgent v0.16 Verification Report",
        "=" * 44,
        f"Generated: {report['generated_at']}",
        f"Compile: {report['offline_verification']['compile']['result']}",
        f"Unit tests: {report['offline_verification']['unit_tests']['result']}",
        "",
        "[Static checks]",
    ]
    for row in static:
        lines.append(f"{row['check_id']} {row['result']} - {row['evidence']}")
    lines += ["", "[Live GW]", "PARTIAL - 사용자가 제공한 17:36 로그는 WeeklyMailAgent_260821_2(v0.14) 실행 로그이므로 v0.15 제목 same-row 수정은 아직 현장 검증되지 않았습니다. v0.16은 그 수정과 Editor bounded retry를 유지하며 연습모드 기본 OFF, 승인대기 시작 시 자동 기록, 키워드/내용 다중행을 추가했습니다. 제목/기록/다중행/승인/발송/수신 재검증 필요", "", "[Unit test output]", unit_output]
    REPORT_TXT.write_text("\n".join(lines), encoding="utf-8")

    failed = [x for x in static if x["result"] != "PASS"]
    if failed or not unit_ok or not compile_ok:
        print(REPORT_TXT.read_text(encoding="utf-8"))
        return 1
    print(REPORT_TXT.read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
