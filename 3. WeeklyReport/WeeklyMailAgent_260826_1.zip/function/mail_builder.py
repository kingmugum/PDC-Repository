from __future__ import annotations

from html import escape
from typing import Any

from .models import TaskItem, WeeklyReportInput
from .validation import assert_nonempty, assert_no_images
from .week_calculator import next_week_label

WEEKDAYS = ["월", "화", "수", "목", "금"]


def normalize_terms(text: str, aliases: dict[str, str]) -> str:
    result = text
    for source, target in aliases.items():
        result = result.replace(source, target)
    return result.strip()


def _task_name(task: TaskItem, aliases: dict[str, str]) -> str:
    name = normalize_terms(task.name, aliases)
    keywords = normalize_terms(task.keywords, aliases)
    if not name and keywords:
        name = keywords
    return assert_nonempty(name, "업무명")


def _task_detail(task: TaskItem, aliases: dict[str, str]) -> str:
    keywords = normalize_terms(task.keywords, aliases)
    if keywords:
        return keywords
    return _task_name(task, aliases)


def _task_detail_lines(task: TaskItem, aliases: dict[str, str]) -> list[str]:
    detail = _task_detail(task, aliases)
    lines = detail.splitlines() or [detail]
    # Preserve intentional line structure while trimming surrounding spaces on each line.
    return [line.strip() for line in lines]


def build_subject(week_label: str, config: dict[str, Any], practice_mode: bool) -> str:
    week_label = assert_nonempty(week_label, "대상 주차")
    template = config["mail"]["subject_template"]
    subject = template.format(week_label=week_label)
    if practice_mode:
        subject = config["mail"].get("practice_subject_prefix", "[연습] ") + subject
    return subject


def _section_text(title: str, tasks: list[TaskItem], aliases: dict[str, str]) -> list[str]:
    lines = [f"[{title}]"]
    if not tasks:
        lines.append("- 해당 없음")
        return lines
    for idx, task in enumerate(tasks, 1):
        lines.append(f"{idx}. {_task_name(task, aliases)}")
        lines.append(f"   - 일정 : {task.schedule.strip() or '-'}")
        lines.append(f"   - 장소 : {task.place.strip() or '-'}")
        detail_lines = _task_detail_lines(task, aliases)
        lines.append(f"   - 내용 : {detail_lines[0] if detail_lines else '-'}")
        for extra in detail_lines[1:]:
            lines.append(f"            {extra}")
        lines.append("")
    return lines


def _schedule_text(schedule: dict[str, dict[str, str]], people: list[str]) -> list[str]:
    lines = ["[차주 일정]"]
    header = " / ".join(WEEKDAYS)
    lines.append(f"구분 / {header}")
    for person in people:
        row = schedule.get(person, {})
        values = [row.get(day, "-").strip() or "-" for day in WEEKDAYS]
        lines.append(f"{person} / " + " / ".join(values))
    return lines


def build_text_body(report: WeeklyReportInput, config: dict[str, Any]) -> str:
    mail_cfg = config["mail"]
    aliases = config.get("term_aliases", {})
    week = assert_nonempty(report.week_label, "대상 주차")
    next_week = next_week_label(week)
    intro = mail_cfg["sender_intro"].strip()
    project_line = mail_cfg["project_line"].strip()
    people = list(mail_cfg.get("schedule_people", []))

    lines: list[str] = [intro, "", f"{week} {project_line}", ""]
    lines.extend(_section_text(f"{week} 진행 업무", report.current_tasks, aliases))
    lines.append("")
    lines.extend(_section_text(f"{next_week} 진행 예정 업무", report.next_tasks, aliases))
    lines.append("")
    lines.extend(_schedule_text(report.next_week_schedule, people))
    lines.extend(["", "이상입니다.", "", "감사합니다."])
    return "\n".join(lines).strip()


def _tasks_html(title: str, tasks: list[TaskItem], aliases: dict[str, str]) -> str:
    parts = [f"<p><strong>[{escape(title)}]</strong></p>"]
    if not tasks:
        parts.append("<p>- 해당 없음</p>")
        return "".join(parts)
    for idx, task in enumerate(tasks, 1):
        name = escape(_task_name(task, aliases))
        schedule = escape(task.schedule.strip() or "-")
        place = escape(task.place.strip() or "-")
        detail_lines = _task_detail_lines(task, aliases)
        detail_html = "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".join(
            escape(line) for line in detail_lines
        )
        parts.append(
            f"<p style='margin:0 0 8px 0;'>{idx}. {name}<br>"
            f"&nbsp;&nbsp;- 일정 : {schedule}<br>"
            f"&nbsp;&nbsp;- 장소 : {place}<br>"
            f"&nbsp;&nbsp;- 내용 : {detail_html}</p>"
        )
    return "".join(parts)


def _schedule_html(
    schedule: dict[str, dict[str, str]],
    people: list[str],
    highlights: dict[str, dict[str, bool]] | None = None,
) -> str:
    highlights = highlights or {}
    header_cells = "".join(
        f"<th style='border:1px solid #777;padding:4px 8px;'>{escape(day)}</th>" for day in WEEKDAYS
    )
    rows = []
    for person in people:
        cells = []
        row = schedule.get(person, {})
        highlight_row = highlights.get(person, {})
        for day in WEEKDAYS:
            value = escape((row.get(day, "-") or "-").strip())
            emphasis = "color:#d00000;font-weight:700;" if bool(highlight_row.get(day, False)) else ""
            cells.append(
                f"<td style='border:1px solid #777;padding:4px 8px;text-align:center;{emphasis}'>{value}</td>"
            )
        rows.append(
            f"<tr><th style='border:1px solid #777;padding:4px 8px;'>{escape(person)}</th>{''.join(cells)}</tr>"
        )
    return (
        "<p><strong>[차주 일정]</strong></p>"
        "<table style='border-collapse:collapse;font-family:Arial,Malgun Gothic,sans-serif;font-size:10pt;'>"
        f"<tr><th style='border:1px solid #777;padding:4px 8px;'>구분</th>{header_cells}</tr>"
        f"{''.join(rows)}</table>"
    )


def build_html_body(report: WeeklyReportInput, config: dict[str, Any]) -> str:
    mail_cfg = config["mail"]
    aliases = config.get("term_aliases", {})
    week = assert_nonempty(report.week_label, "대상 주차")
    next_week = next_week_label(week)
    intro = escape(mail_cfg["sender_intro"].strip())
    project_line = escape(mail_cfg["project_line"].strip())
    people = list(mail_cfg.get("schedule_people", []))
    html = (
        "<div style='font-family:Arial,Malgun Gothic,sans-serif;font-size:10pt;line-height:1.55;'>"
        f"<p>{intro}</p>"
        f"<p>{escape(week)} {project_line}</p>"
        f"{_tasks_html(f'{week} 진행 업무', report.current_tasks, aliases)}"
        f"{_tasks_html(f'{next_week} 진행 예정 업무', report.next_tasks, aliases)}"
        f"{_schedule_html(report.next_week_schedule, people, report.next_week_schedule_highlight)}"
        "<p>이상입니다.</p><p>감사합니다.</p>"
        "</div>"
    )
    assert_no_images(html)
    return html
