from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path
from threading import Event
from typing import Callable, Any

from .browser_runtime import launch_persistent_context_auto
from .credential_store import CredentialStoreError, load_credentials
from .models import MailEnvelope
from .validation import ValidationError, assert_no_images


class GWAutomationError(RuntimeError):
    pass


@dataclass
class ApprovalGate:
    event: Event
    decision: str | None = None

    def reset(self) -> None:
        self.decision = None
        self.event.clear()

    def approve(self) -> None:
        self.decision = "approve"
        self.event.set()

    def reject(self) -> None:
        self.decision = "reject"
        self.event.set()


def _first_visible(page_or_frame, selectors: list[str], timeout_ms: int = 8000):
    last_error = None
    for selector in selectors:
        try:
            loc = page_or_frame.locator(selector).first
            loc.wait_for(state="visible", timeout=timeout_ms)
            return loc
        except Exception as exc:
            last_error = exc
    raise GWAutomationError(f"필수 요소를 찾지 못했습니다. selector 후보={selectors}. 마지막 오류={last_error}")


def _search_contexts(page):
    """Return the main page plus child frames so GW micro-frontend/iframe UIs are searchable."""
    contexts = [("page", page)]
    try:
        main = page.main_frame
        for idx, frame in enumerate(page.frames):
            if frame == main:
                continue
            contexts.append((f"frame[{idx}]", frame))
    except Exception:
        pass
    return contexts



def _first_visible_in_contexts(
    page,
    selectors: list[str],
    timeout_ms: int = 8000,
    *,
    field_label: str | None = None,
    log: Callable[[str], None] | None = None,
):
    """Search a field across the main document and every child frame within one bounded timeout."""
    deadline = time.time() + max(timeout_ms, 1000) / 1000.0
    last_error = None
    while time.time() < deadline:
        for context_label, ctx in _search_contexts(page):
            for selector in selectors:
                try:
                    loc = ctx.locator(selector).first
                    if _candidate_is_visible(loc):
                        # Compose labels such as "받는사람" and "제목" have adjacent
                        # utility checkboxes ("나에게", "중요!").  Broad following::input
                        # selectors used by older releases could therefore select the
                        # checkbox instead of the real text field.  Reject non-text
                        # controls before accepting a configured selector.
                        if field_label and not _candidate_is_compose_text_entry(loc):
                            continue
                        if log and field_label:
                            log(f"{field_label} 입력란을 선택자로 찾았습니다. context={context_label}, selector={selector}")
                        return context_label, ctx, loc
                except Exception as exc:
                    last_error = exc
        time.sleep(0.15)
    raise GWAutomationError(
        f"필수 요소를 프레임 포함 탐색에서도 찾지 못했습니다. selector 후보={selectors}. 마지막 오류={last_error}"
    )


def _discover_labeled_editable(
    page,
    label_text: str,
    timeout_ms: int = 8000,
    log: Callable[[str], None] | None = None,
):
    """
    Last-resort compose-field discovery.

    Find an exact visible label (받는사람/참조/제목) and choose the nearest visible editable
    control on the same horizontal row, in the same document/frame. This avoids hard-coded
    screen coordinates and still works when GW changes input ids/classes.
    """
    editable_selector = (
        "input:not([type='hidden']):not([type='checkbox']):not([type='radio']):"
        "not([type='button']):not([type='submit']):not([type='file']), textarea, "
        "[contenteditable='true'], [contenteditable='']"
    )
    deadline = time.time() + max(timeout_ms, 1000) / 1000.0
    last_error = None
    while time.time() < deadline:
        for context_label, ctx in _search_contexts(page):
            try:
                labels = ctx.get_by_text(label_text, exact=True)
                editables = ctx.locator(editable_selector)
                label_count = min(labels.count(), 12)
                editable_count = min(editables.count(), 80)
                for li in range(label_count):
                    label = labels.nth(li)
                    if not _candidate_is_visible(label):
                        continue
                    lb = label.bounding_box()
                    if not lb:
                        continue
                    ly = lb["y"] + lb["height"] / 2.0
                    lright = lb["x"] + lb["width"]
                    best = None
                    best_score = None
                    for ei in range(editable_count):
                        loc = editables.nth(ei)
                        if not _candidate_is_visible(loc):
                            continue
                        box = loc.bounding_box()
                        if not box or box["width"] < 40 or box["height"] < 10:
                            continue
                        # A compose address/subject row is a compact horizontal control, not the large body editor.
                        if box["height"] > 120:
                            continue
                        ey = box["y"] + box["height"] / 2.0
                        dy = abs(ey - ly)
                        if dy > 45:
                            continue
                        dx = box["x"] - lright
                        # Prefer controls to the right of the label and on the same row.
                        score = dy * 8.0 + max(dx, 0.0) * 0.03 + (400.0 if dx < -25 else 0.0)
                        # Wider compose fields are more plausible than tiny utility controls.
                        if box["width"] < 120:
                            score += 120.0
                        if best_score is None or score < best_score:
                            best_score = score
                            best = loc
                    if best is not None:
                        if log:
                            try:
                                tag = best.evaluate("el => el.tagName.toLowerCase()")
                            except Exception:
                                tag = "unknown"
                            log(
                                f"{label_text} 입력란을 라벨 인접 탐색으로 찾았습니다. "
                                f"context={context_label}, tag={tag}"
                            )
                        return context_label, ctx, best
            except Exception as exc:
                last_error = exc
        time.sleep(0.15)
    raise GWAutomationError(f"'{label_text}' 라벨과 같은 행의 입력 가능 요소를 찾지 못했습니다. 마지막 오류={last_error}")


def _describe_editable_candidates(page, label_text: str) -> list[str]:
    """Log non-sensitive field metadata only; never include current input values."""
    result: list[str] = []
    selector = (
        "input:not([type='hidden']):not([type='checkbox']):not([type='radio']), textarea, "
        "[contenteditable='true'], [contenteditable='']"
    )
    for context_label, ctx in _search_contexts(page):
        try:
            labels = ctx.get_by_text(label_text, exact=True)
            label_boxes = []
            for i in range(min(labels.count(), 8)):
                loc = labels.nth(i)
                if _candidate_is_visible(loc):
                    box = loc.bounding_box()
                    if box:
                        label_boxes.append(box)
            edits = ctx.locator(selector)
            for i in range(min(edits.count(), 40)):
                loc = edits.nth(i)
                if not _candidate_is_visible(loc):
                    continue
                box = loc.bounding_box()
                if not box:
                    continue
                near = False
                for lb in label_boxes:
                    ly = lb["y"] + lb["height"] / 2.0
                    ey = box["y"] + box["height"] / 2.0
                    if abs(ey - ly) <= 60:
                        near = True
                        break
                if label_boxes and not near:
                    continue
                meta = loc.evaluate(
                    "el => ({tag:el.tagName.toLowerCase(), id:el.id||'', name:el.getAttribute('name')||'', "
                    "type:el.getAttribute('type')||'', placeholder:el.getAttribute('placeholder')||'', "
                    "aria:el.getAttribute('aria-label')||'', title:el.getAttribute('title')||''})"
                )
                result.append(
                    f"{context_label}: tag={meta.get('tag')} id={meta.get('id')!r} name={meta.get('name')!r} "
                    f"type={meta.get('type')!r} placeholder={meta.get('placeholder')!r} "
                    f"aria={meta.get('aria')!r} title={meta.get('title')!r} "
                    f"box=({round(box['x'])},{round(box['y'])},{round(box['width'])},{round(box['height'])})"
                )
        except Exception:
            continue
    return result


def _discover_subject_text_field(
    page,
    timeout_ms: int = 8000,
    log: Callable[[str], None] | None = None,
):
    """Find only the large editable on the exact '제목' row.

    GW's compose form has other text-like inputs above/below the subject row.  A
    document-order XPath such as ``제목/following::input[1]`` can therefore select an
    address or another control when the DOM is rearranged.  Use the visible label and
    geometry instead: same row, to the right, compact height, and wide enough to be the
    subject field.
    """
    editable_selector = (
        "input:not([type='hidden']):not([type='checkbox']):not([type='radio']):"
        "not([type='button']):not([type='submit']):not([type='reset']):not([type='file']):not([type='image']), "
        "textarea, [contenteditable='true'], [contenteditable='']"
    )
    deadline = time.time() + max(timeout_ms, 1000) / 1000.0
    last_error = None
    while time.time() < deadline:
        for context_label, ctx in _search_contexts(page):
            try:
                labels = ctx.get_by_text("제목", exact=True)
                editables = ctx.locator(editable_selector)
                for li in range(min(labels.count(), 8)):
                    label = labels.nth(li)
                    if not _candidate_is_visible(label):
                        continue
                    lb = label.bounding_box()
                    if not lb:
                        continue
                    ly = lb["y"] + lb["height"] / 2.0
                    lright = lb["x"] + lb["width"]
                    best = None
                    best_score = None
                    for ei in range(min(editables.count(), 100)):
                        loc = editables.nth(ei)
                        if not _candidate_is_visible(loc) or not _candidate_is_compose_text_entry(loc):
                            continue
                        box = loc.bounding_box()
                        if not box:
                            continue
                        if box["width"] < 220 or box["height"] < 12 or box["height"] > 64:
                            continue
                        if box["x"] < lright + 4:
                            continue
                        ey = box["y"] + box["height"] / 2.0
                        dy = abs(ey - ly)
                        # Subject field must be on the title row, not To/CC or attachment rows.
                        if dy > 22:
                            continue
                        score = dy * 100.0 + max(box["x"] - lright, 0.0) * 0.02 - min(box["width"], 1200.0) * 0.001
                        if best_score is None or score < best_score:
                            best_score = score
                            best = loc
                    if best is not None:
                        if log:
                            try:
                                meta = best.evaluate(
                                    "el => ({tag:(el.tagName||'').toLowerCase(), id:el.id||'', "
                                    "name:el.getAttribute('name')||'', type:el.getAttribute('type')||''})"
                                )
                                box = best.bounding_box() or {}
                                log(
                                    "제목 입력란을 동일 행 전용 탐색으로 찾았습니다. "
                                    f"context={context_label}, tag={meta.get('tag')}, id={meta.get('id')!r}, "
                                    f"name={meta.get('name')!r}, type={meta.get('type')!r}, "
                                    f"box=({round(box.get('x',0))},{round(box.get('y',0))},"
                                    f"{round(box.get('width',0))},{round(box.get('height',0))})"
                                )
                            except Exception:
                                log(f"제목 입력란을 동일 행 전용 탐색으로 찾았습니다. context={context_label}")
                        return context_label, ctx, best
            except Exception as exc:
                last_error = exc
        time.sleep(0.15)
    raise GWAutomationError(f"'제목' 동일 행의 실제 제목 입력란을 찾지 못했습니다. 마지막 오류={last_error}")


def _find_compose_field(
    page,
    selectors: list[str],
    label_text: str,
    timeout_ms: int,
    log: Callable[[str], None] | None = None,
):
    """Find compose fields across frames. Subject uses a strict same-row finder first."""
    subject_error = None
    if label_text == "제목":
        try:
            return _discover_subject_text_field(page, timeout_ms, log)
        except Exception as exc:
            subject_error = exc

    try:
        return _first_visible_in_contexts(
            page, selectors, timeout_ms, field_label=label_text, log=log
        )
    except Exception as first_exc:
        try:
            return _discover_labeled_editable(page, label_text, timeout_ms, log)
        except Exception as second_exc:
            diagnostics = _describe_editable_candidates(page, label_text)
            if log:
                if diagnostics:
                    log(f"{label_text} 입력란 후보 DOM 진단: " + " | ".join(diagnostics[:16]))
                else:
                    log(f"{label_text} 주변의 visible editable 후보를 찾지 못했습니다.")
            subject_note = f"; 제목 동일행 탐색={subject_error}" if subject_error else ""
            raise GWAutomationError(
                f"{label_text} 입력란 탐색 실패. selector 탐색={first_exc}; "
                f"라벨 인접 탐색={second_exc}{subject_note}"
            ) from second_exc

def _all_context_text(page, timeout_ms: int = 3000) -> str:
    parts: list[str] = []
    for _, ctx in _search_contexts(page):
        try:
            parts.append(ctx.locator("body").inner_text(timeout=timeout_ms) or "")
        except Exception:
            continue
    return "\n".join(parts)


def _candidate_is_visible(locator) -> bool:
    try:
        return bool(locator.count()) and locator.is_visible()
    except Exception:
        return False


def _candidate_is_compose_text_entry(locator) -> bool:
    """Return True only for controls that can actually hold To/CC/Subject text.

    GW places utility checkboxes immediately beside the labels:
    - 받는사람 -> "나에게" checkbox
    - 제목 -> "중요!" checkbox
    Older broad XPath selectors could match these first and report value="on" or
    silently toggle a checkbox instead of entering the recipient.
    """
    try:
        meta = locator.evaluate(
            "el => ({tag:(el.tagName||'').toLowerCase(), "
            "type:(el.getAttribute('type')||'').toLowerCase(), "
            "hasContenteditable:el.hasAttribute('contenteditable'), "
            "contenteditable:(el.getAttribute('contenteditable')||'').toLowerCase()})"
        )
        tag = str(meta.get("tag", "")).lower()
        input_type = str(meta.get("type", "")).lower()
        if tag == "input":
            return input_type not in {"hidden", "checkbox", "radio", "button", "submit", "reset", "file", "image"}
        if tag == "textarea":
            return True
        return bool(meta.get("hasContenteditable")) and str(meta.get("contenteditable", "")).lower() in {"", "true"}
    except Exception:
        return False


def _try_click_locator(locator) -> bool:
    """Normal click first; DOM click is a safe fallback only after an exact visible match."""
    try:
        locator.click(timeout=1500)
        return True
    except Exception:
        pass
    try:
        locator.evaluate("el => el.click()")
        return True
    except Exception:
        return False


def _describe_exact_control_candidates(page, name: str) -> list[str]:
    """Diagnostic metadata only. Never dumps arbitrary page text or user-entered field values."""
    result: list[str] = []
    script = r"""(els, exactText) => {
        const norm = s => (s || '').replace(/\\s+/g, ' ').trim();
        return els
            .filter(el => {
                const text = norm(el.innerText || el.textContent);
                const value = norm(el.getAttribute('value'));
                const aria = norm(el.getAttribute('aria-label'));
                const title = norm(el.getAttribute('title'));
                return text === exactText || value === exactText || aria === exactText || title === exactText;
            })
            .slice(0, 12)
            .map(el => {
                const r = el.getBoundingClientRect();
                return {
                    tag: el.tagName.toLowerCase(), id: el.id || '',
                    cls: typeof el.className === 'string' ? el.className : '',
                    role: el.getAttribute('role') || '', value: el.getAttribute('value') || '',
                    href: el.getAttribute('href') || '', onclick: !!el.onclick || el.hasAttribute('onclick'),
                    visible: !!(r.width && r.height), x: Math.round(r.x), y: Math.round(r.y),
                    w: Math.round(r.width), h: Math.round(r.height)
                };
            });
    }"""
    for label, ctx in _search_contexts(page):
        try:
            rows = ctx.locator("*").evaluate_all(script, name)
        except Exception:
            continue
        for row in rows:
            result.append(
                f"{label}: tag={row.get('tag')} id={row.get('id')!r} class={row.get('cls')!r} "
                f"role={row.get('role')!r} value={row.get('value')!r} href={row.get('href')!r} "
                f"onclick={row.get('onclick')} visible={row.get('visible')} "
                f"box=({row.get('x')},{row.get('y')},{row.get('w')},{row.get('h')})"
            )
    return result


def _click_exact_control(
    page,
    name: str,
    timeout_ms: int = 8000,
    selectors: list[str] | None = None,
    log: Callable[[str], None] | None = None,
):
    """
    BoardRepo-style robust exact-text control discovery.

    GW can render controls as button/a/input/div/span or inside a child iframe.
    Search is bounded and only clicks a visible element whose accessible/text/value label
    exactly matches the requested control name.
    """
    configured = list(selectors or [])
    generic = [
        f"xpath=//button[normalize-space(.)='{name}']",
        f"xpath=//a[normalize-space(.)='{name}']",
        f"xpath=//*[@role='button' and normalize-space(.)='{name}']",
        f"xpath=//input[@value='{name}']",
        f"xpath=//*[@aria-label='{name}']",
        f"xpath=//*[@title='{name}']",
    ]
    all_selectors = configured + [x for x in generic if x not in configured]
    deadline = time.time() + max(timeout_ms, 1000) / 1000.0
    last_error = None

    while time.time() < deadline:
        for context_label, ctx in _search_contexts(page):
            # 1) Explicit/site-profile selectors and common native control forms.
            for selector in all_selectors:
                try:
                    loc = ctx.locator(selector).first
                    if _candidate_is_visible(loc) and _try_click_locator(loc):
                        if log:
                            log(f"'{name}' 컨트롤을 선택자로 클릭했습니다. context={context_label}, selector={selector}")
                        return
                except Exception as exc:
                    last_error = exc

            # 2) Accessible role lookup.
            try:
                loc = ctx.get_by_role("button", name=name, exact=True).first
                if _candidate_is_visible(loc) and _try_click_locator(loc):
                    if log:
                        log(f"'{name}' 컨트롤을 접근성 이름으로 클릭했습니다. context={context_label}")
                    return
            except Exception as exc:
                last_error = exc

            # 3) BoardRepo-style exact rendered text, regardless of tag name.
            try:
                matches = ctx.get_by_text(name, exact=True)
                for idx in range(matches.count()):
                    loc = matches.nth(idx)
                    if not _candidate_is_visible(loc):
                        continue
                    if _try_click_locator(loc):
                        if log:
                            try:
                                tag = loc.evaluate("el => el.tagName.toLowerCase()")
                            except Exception:
                                tag = "unknown"
                            log(f"'{name}' 컨트롤을 정확한 표시 텍스트로 클릭했습니다. context={context_label}, tag={tag}")
                        return
            except Exception as exc:
                last_error = exc
        time.sleep(0.2)

    diagnostics = _describe_exact_control_candidates(page, name)
    if log:
        if diagnostics:
            log(f"'{name}' 후보 DOM 진단: " + " | ".join(diagnostics[:12]))
        else:
            log(f"'{name}'와 정확히 일치하는 visible/text/value DOM 후보를 찾지 못했습니다.")
    raise GWAutomationError(
        f"정확한 '{name}' 컨트롤을 찾지 못했습니다. selector 후보={all_selectors}. "
        f"프레임 포함 exact-text/value 탐색도 실패했습니다. 마지막 오류={last_error}"
    )


def _click_exact_button(page, name: str, timeout_ms: int = 8000):
    """Backward-compatible wrapper used by login/send paths."""
    _click_exact_control(page, name, timeout_ms)


def _looks_like_login_page(page, site: dict[str, Any]) -> bool:
    """BoardRepo-style login detection: visible password field is primary."""
    try:
        for selector in site["login"].get("password_selectors", []):
            try:
                loc = page.locator(selector).first
                if loc.count() and loc.is_visible():
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return "/login" in page.url.lower()


def _try_fill_and_submit_login(page, site: dict[str, Any], log: Callable[[str], None]) -> bool:
    """Same best-effort credential/login flow used by BoardRepo."""
    try:
        creds = load_credentials()
    except CredentialStoreError as exc:
        log(f"자격증명 읽기 생략: {exc}")
        return False
    if not creds:
        log("저장된 자격증명이 없습니다. 필요한 경우 브라우저에서 직접 로그인하세요.")
        return False

    username, password = creds
    try:
        user_input = _first_visible(page, site["login"]["username_selectors"], 4000)
        pw_input = _first_visible(page, site["login"]["password_selectors"], 4000)
    except Exception:
        return False

    user_input.fill(username)
    pw_input.fill(password)
    log("BoardRepo 호환 keyring의 ID/PW를 로그인 화면에 자동 입력했습니다.")

    # Use selector candidates first, then exact button fallback.
    for selector in site["login"].get("submit_selectors", []):
        try:
            loc = page.locator(selector).first
            if loc.count() and loc.is_visible():
                loc.click()
                log("로그인 버튼을 자동 클릭했습니다.")
                return True
        except Exception:
            continue
    try:
        _click_exact_button(page, site["login"].get("login_button_text", "로그인"), 4000)
        log("로그인 버튼을 자동 클릭했습니다.")
        return True
    except Exception:
        log("로그인 버튼을 자동 탐지하지 못했습니다.")
        return False


def _login_if_needed(page, config: dict[str, Any], site: dict[str, Any], log: Callable[[str], None]):
    mail_url = site["urls"]["mail"]
    page.goto(mail_url, wait_until="domcontentloaded")
    if not _looks_like_login_page(page, site):
        log("기존 GW 로그인 세션을 재사용합니다.")
        return

    log("GW 로그인이 필요한 상태를 확인했습니다.")
    deadline = time.time() + float(config["gw"].get("login_wait_sec", 180))
    auto_attempted = False

    while time.time() < deadline:
        if _looks_like_login_page(page, site):
            if not auto_attempted:
                auto_attempted = True
                _try_fill_and_submit_login(page, site, log)
                page.wait_for_timeout(800)

            if _looks_like_login_page(page, site):
                if auto_attempted:
                    log("로그인 화면이 계속 표시됩니다. 추가 인증/CAPTCHA가 있다면 브라우저에서 완료해주세요.")
                time.sleep(1)
                continue

        # BoardRepo처럼 로그인 후 목표 페이지 접근까지 확인한다.
        try:
            page.goto(mail_url, wait_until="domcontentloaded")
            if not _looks_like_login_page(page, site):
                log("로그인 완료 상태와 GW 메일 접근을 확인했습니다.")
                return
        except Exception:
            pass
        time.sleep(1)

    raise GWAutomationError(
        f"로그인 대기시간({int(config['gw'].get('login_wait_sec', 180))}초)을 초과했습니다. "
        "추가 인증/CAPTCHA 또는 계정정보를 확인해주세요. 자동 우회하지 않습니다."
    )


def _open_compose(page, config: dict[str, Any], site: dict[str, Any], log: Callable[[str], None]):
    timeout_ms = int(config["gw"].get("selector_timeout_ms", 8000))
    page.goto(site["urls"]["mail"], wait_until="domcontentloaded")
    log("GW 메일 화면에 진입했습니다.")
    _click_exact_control(
        page,
        site["mail"].get("write_button_text", "메일쓰기"),
        timeout_ms,
        selectors=site["mail"].get("write_button_selectors", []),
        log=log,
    )
    log("정확한 '메일쓰기' 컨트롤을 클릭했습니다.")
    page.wait_for_timeout(800)


def _find_editor(page, site: dict[str, Any], timeout_ms: int):
    """Find the GW body editor with a bounded readiness wait.

    The compose shell can appear before DEXT/editor frames finish mounting.  Older
    releases scanned only once and could fail intermittently immediately after
    clicking 메일쓰기.  Re-scan main page + child frames until the normal selector
    timeout expires; never guess by screen coordinates.
    """
    deadline = time.time() + max(timeout_ms, 1200) / 1000.0
    while time.time() < deadline:
        # 1) Configured editor iframe selectors across main page and child frames.
        for _, ctx in _search_contexts(page):
            for selector in site["mail"].get("body_iframe_selectors", []):
                try:
                    iframe = ctx.locator(selector).first
                    if not iframe.count():
                        continue
                    frame = iframe.content_frame()
                    if frame:
                        body = frame.locator("body").first
                        if body.count():
                            return frame, body
                except Exception:
                    continue
        # 2) Any frame whose body itself is contenteditable.
        for _, frame in _search_contexts(page):
            try:
                body = frame.locator("body[contenteditable='true'], body[contenteditable='']").first
                if body.count() and body.is_visible():
                    return frame, body
            except Exception:
                continue
        # 3) Any visible editor-sized contenteditable element in any frame.
        for _, ctx in _search_contexts(page):
            for selector in site["mail"].get("body_contenteditable_selectors", ["[contenteditable='true']"]):
                try:
                    loc = ctx.locator(selector).first
                    if loc.count() and loc.is_visible():
                        box = loc.bounding_box()
                        if box and box["width"] >= 250 and box["height"] >= 80:
                            return ctx, loc
                except Exception:
                    continue
        time.sleep(0.2)
    raise GWAutomationError(
        f"메일 본문 웹에디터를 {int(max(timeout_ms, 1200))}ms 동안 프레임 포함 대기했지만 찾지 못했습니다. "
        "site_profile.json 또는 GW 로딩 상태를 확인하세요."
    )

def _clear_editor_only(page, site: dict[str, Any], log: Callable[[str], None], timeout_ms: int):
    owner, body = _find_editor(page, site, timeout_ms)
    # Do not click/focus the lower body editor here. Playwright locator.click() can
    # auto-scroll the compose pane downward, which makes the recipient rows leave
    # the stable top viewport and on this GW can also race with recipient autocomplete.
    # Direct DOM mutation is sufficient for clearing the default signature/photo.
    try:
        body.evaluate(
            "el => { el.innerHTML = ''; "
            "el.dispatchEvent(new InputEvent('input', {bubbles:true,inputType:'deleteContent'})); "
            "el.dispatchEvent(new Event('change',{bubbles:true})); }"
        )
    except Exception as exc:
        raise GWAutomationError(f"기본 서명/사진 삭제 실패: {exc}") from exc
    img_count = int(body.locator("img").count())
    html_after = ""
    try:
        html_after = body.inner_html().strip()
    except Exception:
        pass
    if img_count != 0:
        raise GWAutomationError(f"기본 본문 삭제 후 이미지가 {img_count}개 남아 있어 발송을 차단합니다.")
    # Empty editor implementations can leave harmless <br>/<p><br></p>; image absence is the hard security gate.
    log("메일쓰기 진입 직후 기본 서명/사진/본문을 먼저 삭제하고 이미지 0개를 확인했습니다.")
    return owner, body


def _fill_editor_html(body, html_body: str, log: Callable[[str], None]):
    assert_no_images(html_body)
    body.evaluate(
        "(el, html) => { el.innerHTML = html; el.dispatchEvent(new Event('input', {bubbles:true})); "
        "el.dispatchEvent(new Event('change',{bubbles:true})); }",
        html_body,
    )
    log("주간보고 HTML 본문을 입력했습니다.")
    if int(body.locator("img").count()) != 0:
        raise GWAutomationError("생성 본문 입력 후 이미지 태그가 발견되어 발송을 차단합니다.")
    return body


def _clear_and_fill_editor(page, site: dict[str, Any], html_body: str, log: Callable[[str], None], timeout_ms: int):
    """Backward-compatible wrapper for tests/callers; compose flow uses clear-first sequencing."""
    _, body = _clear_editor_only(page, site, log, timeout_ms)
    return _fill_editor_html(body, html_body, log)


def _clean_routing_residue(text: str, label: str) -> str:
    """Remove GW compose utility labels that are not recipient tokens.

    In particular, the small '+' beside 참조 and the '중요!' checkbox beside 제목 are
    unrelated compose controls and must never be interpreted as recipient evidence.
    """
    ignored_tokens = {
        label,
        "최근 주소",
        "주소록",
        "나에게",
        "받는사람 일괄등록",
        "파일선택",
        "중요!",
        "중요",
        "대용량",
        "모두 삭제",
        "+",
        "-",
    }
    residue = text or ""
    for token in sorted(ignored_tokens, key=len, reverse=True):
        residue = residue.replace(token, " ")
    return re.sub(r"\s+", " ", residue).strip()


def _recipient_row_text(loc, label: str) -> str:
    """Return only *visible text in the same horizontal recipient band* as the input.

    The small '+' beside 참조 and 제목 '중요!' checkbox remain ignored compose controls.
    GW keeps a large recent-address / autocomplete data structure in the surrounding DOM.
    Reading ``innerText`` from a broad ancestor can therefore collect dozens of unrelated
    e-mail addresses even though only one recipient chip is visibly committed.  v0.10
    deliberately scopes routing evidence to visible text nodes whose rendered rectangle
    overlaps the address input row.  Hidden recent-address data and the autocomplete popup
    below the field are excluded by visibility + geometry.
    """
    try:
        return str(
            loc.evaluate(
                """(el, label) => {
                    const ebox = el.getBoundingClientRect();
                    const isVisible = (node) => {
                        if (!node || !node.ownerDocument) return false;
                        const style = node.ownerDocument.defaultView.getComputedStyle(node);
                        if (!style || style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) === 0) return false;
                        const r = node.getBoundingClientRect();
                        return r.width > 0 && r.height > 0;
                    };
                    const overlapsInputBand = (node) => {
                        const r = node.getBoundingClientRect();
                        return !(r.bottom < ebox.top - 7 || r.top > ebox.bottom + 7);
                    };
                    const textFromVisibleBand = (root) => {
                        const out = [];
                        const seen = new Set();
                        const walker = root.ownerDocument.createTreeWalker(root, root.ownerDocument.defaultView.NodeFilter.SHOW_TEXT);
                        let n;
                        while ((n = walker.nextNode())) {
                            const parent = n.parentElement;
                            const text = (n.nodeValue || '').replace(/\\s+/g, ' ').trim();
                            if (!text || !parent || !isVisible(parent) || !overlapsInputBand(parent)) continue;
                            if (parent.matches('script,style,option')) continue;
                            if (!seen.has(text)) { seen.add(text); out.push(text); }
                        }
                        return out.join(' ').replace(/\\s+/g, ' ').trim();
                    };

                    let p = el.parentElement;
                    let fallback = '';
                    for (let i = 0; i < 8 && p; i++, p = p.parentElement) {
                        const r = p.getBoundingClientRect();
                        // Recipient rows in this GW are shallow horizontal bands.  Never
                        // inspect tall containers that can own hidden address-book data.
                        if (r.width >= Math.max(240, ebox.width) && r.height >= ebox.height && r.height <= 86) {
                            const t = textFromVisibleBand(p);
                            if (t && !fallback) fallback = t;
                            if (/@/.test(t)) return t;
                        }
                    }
                    return fallback;
                }""",
                label,
            )
            or ""
        )
    except Exception:
        return ""


def _commit_address_by_tab(
    page,
    loc,
    address: str,
    label: str,
    log: Callable[[str], None],
) -> dict[str, Any]:
    """Commit one recipient by reproducing the GW manual keyboard workflow.

    The confirmed human workflow is: physically type the exact e-mail address, wait
    briefly for GW's own key-event/autocomplete handler, then press Tab.  Use real
    keyboard events instead of Playwright ``fill`` so the site receives the same
    keydown/keyup stream as manual input.  Do not inspect or click autocomplete
    candidates and do not use ArrowDown/Enter.
    """
    try:
        loc.click()
        try:
            loc.press("Control+A")
            loc.press("Backspace")
        except Exception:
            pass
        # press_sequentially generates the keyboard events GW uses to arm its own
        # recipient conversion.  A short pre-Tab wait mirrors the manual pause after
        # typing and prevents blur before the address handler is ready.
        loc.press_sequentially(address, delay=25)
    except Exception as exc:
        raise GWAutomationError(f"{label} 이메일 키 입력에 실패했습니다: {exc}") from exc

    log(f"{label} 이메일 키 입력: {address}")
    try:
        page.wait_for_timeout(650)
    except Exception:
        time.sleep(0.65)

    try:
        loc.press("Tab")
    except Exception as exc:
        raise GWAutomationError(f"{label} 이메일 입력 후 Tab 확정에 실패했습니다: {exc}") from exc

    try:
        page.wait_for_timeout(900)
    except Exception:
        time.sleep(0.9)
    log(f"{label} 이메일 입력 후 Tab을 눌러 GW 자체 수신자 확정 동작을 실행했습니다.")
    return {
        "accepted": True,
        "method": "typed_tab_commit",
        "address": address.lower(),
        "candidate_text": "",
    }


def _fill_address_field(page, selectors: list[str], addresses: list[str], timeout_ms: int, label: str, log: Callable[[str], None]):
    context_label, ctx, loc = _find_compose_field(page, selectors, label, timeout_ms, log)
    try:
        loc.fill("")
    except Exception:
        try:
            loc.click()
            loc.press("Control+A")
            loc.press("Backspace")
        except Exception:
            pass
    if not addresses:
        log(f"{label}: 비움 (context={context_label})")
        return {"accepted": True, "expected": [], "items": [], "context": context_label}

    items = []
    for idx, address in enumerate(addresses):
        address = str(address).strip()
        if not address:
            continue
        if idx > 0:
            context_label, ctx, loc = _find_compose_field(page, selectors, label, timeout_ms, log)
        proof = _commit_address_by_tab(page, loc, address, label, log)
        items.append(proof)

    log(
        f"{label} 입력 완료: {', '.join(addresses)} "
        f"(context={context_label}, 확정 방식={','.join(x['method'] for x in items)})"
    )
    return {
        "accepted": bool(items) and all(bool(x.get("accepted")) for x in items),
        "expected": [str(x).strip().lower() for x in addresses if str(x).strip()],
        "items": items,
        "context": context_label,
    }


def _safe_field_state(page, selectors: list[str], timeout_ms: int, label: str) -> dict[str, Any]:
    """Read the actual address row without treating adjacent utility controls as recipients."""
    try:
        context_label, _, loc = _find_compose_field(page, selectors, label, timeout_ms, None)
    except Exception:
        return {
            "context": "",
            "text": "",
            "emails": set(),
            "committed": False,
            "fingerprint": "",
        }

    parts: list[str] = []
    input_value = ""
    try:
        input_value = loc.input_value(timeout=1500) or ""
        if input_value:
            parts.append(input_value)
    except Exception:
        pass
    try:
        value_attr = loc.get_attribute("value") or ""
        if value_attr and value_attr not in parts:
            parts.append(value_attr)
    except Exception:
        pass

    row_text = _recipient_row_text(loc, label)
    if row_text and row_text not in parts:
        parts.append(row_text)

    joined = " ".join(parts).strip()
    emails = _extract_routing_emails(joined)
    residue = _clean_routing_residue(joined, label)

    # A committed chip normally leaves meaningful row text. However v0.10 also carries
    # explicit Tab commit proof from the input action because some GW builds
    # do not expose the chip text back through the editable DOM.
    committed = bool(emails or input_value.strip() or residue)
    fingerprint = re.sub(r"\s+", " ", residue).strip().lower()
    return {
        "context": context_label,
        "text": joined,
        "emails": emails,
        "committed": committed,
        "fingerprint": fingerprint,
    }

def _safe_field_text(page, selectors: list[str], timeout_ms: int, label: str) -> str:
    """Compatibility helper returning the field/recipient-chip text only."""
    return str(_safe_field_state(page, selectors, timeout_ms, label).get("text", ""))


_ROUTING_EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE)


def _extract_routing_emails(text: str) -> set[str]:
    return {m.group(0).strip().lower() for m in _ROUTING_EMAIL_RE.finditer(text or "")}


def _validate_actual_routing_texts(
    envelope: MailEnvelope,
    config: dict[str, Any],
    to_text: str,
    cc_text: str,
    *,
    to_committed: bool = False,
    cc_committed: bool = False,
    to_input_proof: bool = False,
    cc_input_proof: bool = False,
):
    """Validate routing while supporting GW employee autocomplete conversion.

    Strongest evidence is still an explicit visible e-mail exact match.  If GW replaces
    the e-mail with a display-name chip, a readable committed token is accepted.  Some GW
    builds do not expose that chip back through the input DOM at all; in that case v0.10
    may rely on the fact that the program itself typed the exact configured address and
    typed the exact configured address and pressed Tab.  Final sending still remains behind the
    human approval gate.
    """
    actual_to = _extract_routing_emails(to_text)
    actual_cc = _extract_routing_emails(cc_text)
    expected_to = {x.strip().lower() for x in envelope.to if x.strip()}
    expected_cc = {x.strip().lower() for x in envelope.cc if x.strip()}

    if expected_to:
        if actual_to and actual_to != expected_to:
            raise GWAutomationError(
                f"받는사람 실제 입력값이 기대값과 다릅니다. 기대={sorted(expected_to)}, 실제={sorted(actual_to)}"
            )
        if not actual_to and not to_committed and not to_input_proof:
            raise GWAutomationError(
                "받는사람을 확인하지 못했습니다. 이메일/수신자 토큰/자동완성 선택 증거가 모두 없습니다."
            )
    elif actual_to or to_committed or to_input_proof:
        raise GWAutomationError("받는사람은 비어 있어야 하지만 실제 수신자 값/토큰/입력 증거가 존재합니다.")

    if expected_cc:
        if actual_cc and actual_cc != expected_cc:
            raise GWAutomationError(
                f"참조 실제 입력값이 기대값과 다릅니다. 기대={sorted(expected_cc)}, 실제={sorted(actual_cc)}"
            )
        if not actual_cc and not cc_committed and not cc_input_proof:
            raise GWAutomationError(
                "참조를 확인하지 못했습니다. 이메일/참조자 토큰/자동완성 선택 증거가 모두 없습니다."
            )
    elif actual_cc or cc_committed or cc_input_proof:
        raise GWAutomationError("참조는 비어 있어야 하지만 실제 참조자 값/토큰/입력 증거가 존재합니다.")

    # If e-mail strings are visible, retain the strongest safety checks against practice /
    # production leakage.  Display-name-only or DOM-hidden chips are backed by exact input
    # + Tab commit proof and the final human approval gate.
    if envelope.practice_mode:
        production_addresses = {
            str(config["mail"].get("production_recipient", "")).strip().lower(),
            *[str(x).strip().lower() for x in config["mail"].get("production_cc", [])],
        }
        production_addresses.discard("")
        leaked = (actual_to | actual_cc) & production_addresses
        if leaked:
            raise GWAutomationError(
                f"연습 모드 실제 수신자/참조 입력란에 정식 주소가 포함되어 발송을 차단합니다: {sorted(leaked)}"
            )
    else:
        practice_recipient = str(config["mail"].get("practice_recipient", "")).strip().lower()
        if practice_recipient and practice_recipient not in expected_to and practice_recipient in (actual_to | actual_cc):
            raise GWAutomationError(
                f"정식 발송 모드 실제 수신자/참조 입력란에 연습 주소 '{practice_recipient}'가 포함되어 발송을 차단합니다."
            )

def _verify_routing_fields(
    page,
    envelope: MailEnvelope,
    config: dict[str, Any],
    site: dict[str, Any],
    timeout_ms: int,
    *,
    baseline: dict[str, dict[str, Any]] | None = None,
    entry_proof: dict[str, dict[str, Any]] | None = None,
    log: Callable[[str], None] | None = None,
) -> dict[str, dict[str, Any]]:
    # On pre-send, reuse the original exact-input/Tab commit proof.
    if entry_proof is None and baseline:
        entry_proof = baseline.get("_entry_proof", {})  # type: ignore[assignment]
    entry_proof = entry_proof or {}

    to_state = _safe_field_state(page, site["mail"]["to_selectors"], timeout_ms, "받는사람")
    cc_state = _safe_field_state(page, site["mail"]["cc_selectors"], timeout_ms, "참조")
    to_proof_ok = bool(entry_proof.get("to", {}).get("accepted")) if envelope.to else False
    cc_proof_ok = bool(entry_proof.get("cc", {}).get("accepted")) if envelope.cc else False

    _validate_actual_routing_texts(
        envelope,
        config,
        str(to_state.get("text", "")),
        str(cc_state.get("text", "")),
        to_committed=bool(to_state.get("committed")),
        cc_committed=bool(cc_state.get("committed")),
        to_input_proof=to_proof_ok,
        cc_input_proof=cc_proof_ok,
    )

    if log:
        log(
            "실제 주소행 표시 확인: "
            f"받는사람={sorted(to_state.get('emails', set())) or '[DOM-hidden/selection-proof]'}, "
            f"참조={sorted(cc_state.get('emails', set())) if envelope.cc else '[]'}"
        )

    states: dict[str, Any] = {"to": to_state, "cc": cc_state, "_entry_proof": entry_proof}
    if baseline:
        for key, label, expected in (("to", "받는사람", bool(envelope.to)), ("cc", "참조", bool(envelope.cc))):
            if not expected:
                continue
            old = str(baseline.get(key, {}).get("fingerprint", "")).strip()
            new = str(states.get(key, {}).get("fingerprint", "")).strip()
            old_emails = set(baseline.get(key, {}).get("emails", set()))
            new_emails = set(states.get(key, {}).get("emails", set()))
            proof_ok = bool(entry_proof.get(key, {}).get("accepted"))

            if old_emails and new_emails and old_emails != new_emails:
                raise GWAutomationError(f"발송 직전 {label} 이메일 값이 초안 작성 시점과 달라졌습니다.")
            if not new_emails and old and new and old != new:
                raise GWAutomationError(
                    f"발송 직전 {label} 자동완성 수신자 표시가 초안 작성 시점과 달라졌습니다. 직접 확인 후 다시 작성하세요."
                )
            if not new_emails and old and not new and not proof_ok:
                raise GWAutomationError(f"발송 직전 {label} 자동완성 수신자 토큰이 사라졌습니다.")

    if log:
        def mode(state, proof):
            if state.get("emails"):
                return "email-visible"
            if state.get("committed"):
                return "autocomplete-token"
            if proof:
                return "tab-commit-proof"
            return "empty"
        to_mode = mode(to_state, to_proof_ok)
        cc_mode = mode(cc_state, cc_proof_ok) if envelope.cc else "empty"
        log(f"수신자 자동완성 호환 검증 PASS: 받는사람={to_mode}, 참조={cc_mode}")
        if to_mode == "tab-commit-proof" or cc_mode == "tab-commit-proof":
            log(
                "GW가 수신자 칩을 DOM에서 읽을 수 없는 상태입니다. 정확한 이메일 입력+Tab 확정 증거로 통과하며, "
                "최종 승인 전에 브라우저의 받는사람/참조 표시를 직접 확인하세요."
            )
    return states

def _subject_value(loc) -> str:
    try:
        return (loc.input_value(timeout=1500) or "").strip()
    except Exception:
        try:
            return (loc.inner_text(timeout=1500) or "").strip()
        except Exception:
            return ""


def _set_subject_exact(
    page,
    selectors: list[str],
    expected_subject: str,
    timeout_ms: int,
    log: Callable[[str], None],
) -> None:
    """Set and verify the exact subject after the body editor has finished updating.

    Live GW evidence showed that writing the body after the subject can re-render the
    compose form and leave the visible subject blank.  v0.15 writes the body first, then locates the subject by its exact visible row
    geometry and asserts the subject only afterwards.  One bounded retry is allowed before
    the draft is rejected.
    """
    last_actual = ""
    for attempt in range(2):
        context_label, _, subject = _find_compose_field(
            page, selectors, "제목", timeout_ms, log if attempt == 0 else None
        )
        try:
            subject.fill(expected_subject)
        except Exception:
            subject.click()
            subject.press("Control+A")
            subject.press_sequentially(expected_subject, delay=10)
        try:
            subject.press("Tab")
        except Exception:
            pass
        try:
            page.wait_for_timeout(180)
        except Exception:
            time.sleep(0.18)
        last_actual = _subject_value(subject)
        if last_actual == expected_subject:
            log(f"제목 실제 입력란에 입력 및 유지 확인: {expected_subject} (context={context_label})")
            return
        log(
            f"제목 실제값이 기대값과 달라 1회 재입력합니다. "
            f"기대={expected_subject!r}, 실제={last_actual!r}"
        )
    raise GWAutomationError(
        f"제목 입력을 유지하지 못했습니다. 기대={expected_subject!r}, 실제={last_actual!r}"
    )


def _restore_compose_top(page, log: Callable[[str], None] | None = None) -> None:
    """Return the visible compose panes to the top without clicking any form control."""
    restored = 0
    for _, ctx in _search_contexts(page):
        try:
            ctx.evaluate(
                """() => {
                    try { window.scrollTo(0, 0); } catch (e) {}
                    for (const el of document.querySelectorAll('*')) {
                        const st = window.getComputedStyle(el);
                        if (!st) continue;
                        const oy = st.overflowY;
                        if ((oy === 'auto' || oy === 'scroll') && el.scrollTop > 0 && el.clientHeight > 120) {
                            el.scrollTop = 0;
                        }
                    }
                }"""
            )
            restored += 1
        except Exception:
            continue
    if log:
        log(f"초안 작성 후 메일쓰기 화면을 상단으로 복원했습니다. context={restored}")


def _fill_compose(page, envelope: MailEnvelope, config: dict[str, Any], site: dict[str, Any], log: Callable[[str], None]):
    timeout_ms = int(config["gw"].get("selector_timeout_ms", 8000))

    # Security/order requirement: remove the default signature/photo first, then finish
    # generated body content.  Recipient/CC and subject are entered only afterwards so
    # the editor cannot re-render and wipe them.
    _, body = _clear_editor_only(page, site, log, timeout_ms)
    _fill_editor_html(body, envelope.html_body, log)

    # Mirror the confirmed manual GW workflow exactly: e-mail text -> Tab.
    # GW itself owns employee lookup / token conversion.  We deliberately do not inspect
    # autocomplete candidates or require a particular chip DOM structure.
    to_proof = _fill_address_field(
        page, site["mail"]["to_selectors"], envelope.to, timeout_ms, "받는사람", log
    )
    cc_proof = _fill_address_field(
        page, site["mail"]["cc_selectors"], envelope.cc, timeout_ms, "참조", log
    )

    _set_subject_exact(
        page, site["mail"]["subject_selectors"], envelope.subject, timeout_ms, log
    )

    routing_baseline = _verify_routing_fields(
        page,
        envelope,
        config,
        site,
        timeout_ms,
        entry_proof={"to": to_proof, "cc": cc_proof},
        log=log,
    )
    _restore_compose_top(page, log)
    return routing_baseline

def _pre_send_revalidate(
    page, envelope: MailEnvelope, config: dict[str, Any], site: dict[str, Any],
    log: Callable[[str], None], routing_baseline: dict[str, dict[str, Any]] | None = None
):
    timeout_ms = int(config["gw"].get("selector_timeout_ms", 8000))
    _, _, subject_loc = _find_compose_field(page, site["mail"]["subject_selectors"], "제목", timeout_ms, log)
    try:
        subject = subject_loc.input_value().strip()
    except Exception:
        subject = (subject_loc.inner_text() or "").strip()
    if not subject:
        raise GWAutomationError("발송 직전 제목이 비어 있습니다.")
    if envelope.practice_mode and not subject.startswith(config["mail"].get("practice_subject_prefix", "[연습] ")):
        raise GWAutomationError("연습 모드 제목 접두사가 사라져 발송을 차단합니다.")
    _verify_routing_fields(
        page, envelope, config, site, timeout_ms, baseline=routing_baseline, log=log
    )
    _, body = _find_editor(page, site, timeout_ms)
    if int(body.locator("img").count()) != 0:
        raise GWAutomationError("발송 직전 본문 이미지가 발견되어 발송을 차단합니다.")
    if not body.inner_text().strip():
        raise GWAutomationError("발송 직전 본문이 비어 있어 발송을 차단합니다.")
    log("발송 직전 수신자/제목/본문/이미지 안전검증 PASS")


def run_mail_flow(
    envelope: MailEnvelope,
    config: dict[str, Any],
    site: dict[str, Any],
    profile_root: Path,
    approval_gate: ApprovalGate,
    log: Callable[[str], None],
    on_draft_ready: Callable[[], None],
) -> str:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        raise GWAutomationError("playwright 모듈을 사용할 수 없습니다. 환경 확인을 먼저 수행하세요.") from exc

    approval_gate.reset()
    with sync_playwright() as p:
        context, browser_choice = launch_persistent_context_auto(
            p,
            profile_root,
            config,
            log,
            purpose="mail",
        )
        try:
            pages = context.pages
            page = pages[0] if pages else context.new_page()
            _login_if_needed(page, config, site, log)
            _open_compose(page, config, site, log)
            routing_baseline = _fill_compose(page, envelope, config, site, log)
            log("GW 실제 메일쓰기 화면에 초안 입력을 완료했습니다. 브라우저 내용을 확인한 뒤 GUI에서 승인/거절하세요.")
            on_draft_ready()
            approval_gate.event.wait()
            if approval_gate.decision != "approve":
                log("사용자가 발송을 거절했습니다. 보내기 버튼은 클릭하지 않습니다.")
                return "REJECTED"

            _pre_send_revalidate(page, envelope, config, site, log, routing_baseline)

            send_clicked = False
            dialog_messages: list[str] = []

            def handle_dialog(dialog):
                msg = dialog.message or ""
                dialog_messages.append(msg)
                if "보내" in msg or "발송" in msg:
                    dialog.accept()
                else:
                    dialog.dismiss()

            page.on("dialog", handle_dialog)
            _click_exact_button(page, site["mail"].get("send_button_text", "보내기"), int(config["gw"].get("selector_timeout_ms", 8000)))
            send_clicked = True
            log("사용자 승인 후 정확한 '보내기' 버튼을 1회 클릭했습니다.")
            page.wait_for_timeout(int(config["gw"].get("post_send_wait_ms", 2500)))

            if not send_clicked:
                raise GWAutomationError("보내기 클릭이 수행되지 않았습니다.")
            current_url = page.url.lower()
            body_text = ""
            try:
                body_text = page.locator("body").inner_text(timeout=3000)
            except Exception:
                pass
            success_markers = site["mail"].get("send_success_text_candidates", ["보낸메일함", "발송"])
            confirmed = ("/write" not in current_url and "/compose" not in current_url) or any(x in body_text for x in success_markers)
            if confirmed:
                log("발송 후 화면 전환/성공 표식을 확인했습니다.")
                return "SENT_CONFIRMED"
            log("보내기 버튼은 1회 클릭되었으나 성공 화면을 확정하지 못했습니다. 중복 발송 방지를 위해 자동 재시도하지 않습니다.")
            return "SENT_UNCONFIRMED"
        finally:
            try:
                context.close()
            except Exception:
                pass
