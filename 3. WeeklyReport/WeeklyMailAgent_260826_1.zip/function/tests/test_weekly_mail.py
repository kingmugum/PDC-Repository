from __future__ import annotations

import copy
import json
import re
import sys
import threading
import tempfile
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # function/ data root
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from function.config_loader import load_config
from function.gw_mail_automation import ApprovalGate, _validate_actual_routing_texts, _clean_routing_residue, _candidate_is_compose_text_entry, GWAutomationError
from function.mail_builder import build_html_body, build_subject, build_text_body, normalize_terms
from function.models import TaskItem, WeeklyReportInput, clone_tasks
from function.history_store import load_previous_week_record, previous_week_label, save_week_record, tasks_from_record
from function.routing import build_envelope
from function.validation import ValidationError, assert_no_images, validate_email
from function.week_calculator import thursday_of_week, week_label_for_date, next_week_label, nth_thursday


DAYS = ["월", "화", "수", "목", "금"]


def sample_report() -> WeeklyReportInput:
    return WeeklyReportInput(
        week_label="8월 3주차",
        current_tasks=[TaskItem("SX3K 업데이트", "8월 17일(월)", "PDI 2동", "정치평가, 업데이트")],
        next_tasks=[TaskItem("TC 강건화 로그 측정", "8월 20일(목)", "전자연구동 2층", "JX PE 디지털키 로그 측정")],
        next_week_schedule={
            "박동천": {d: "현대차(남양)" for d in DAYS},
            "이종민": {d: "현대차(남양)" for d in DAYS},
        },
        next_week_schedule_highlight={
            "박동천": {d: False for d in DAYS},
            "이종민": {d: False for d in DAYS},
        },
    )


class WeeklyMailOfflineTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.report = sample_report()

    def test_001_practice_routes_to_only_practice_address(self):
        env = build_envelope(self.report, self.config, True, "tester@suresofttech.com")
        self.assertEqual(env.to, ["tester@suresofttech.com"])
        self.assertEqual(env.cc, [])

    def test_002_practice_subject_has_prefix(self):
        env = build_envelope(self.report, self.config, True, "tester@suresofttech.com")
        self.assertTrue(env.subject.startswith("[연습] [주간보고]"))

    def test_003_production_is_enabled_in_v0_14(self):
        self.assertTrue(self.config["mail"]["production_send_enabled"])
        env = build_envelope(self.report, self.config, False)
        self.assertEqual(env.to, ["dslee1@suresofttech.com"])
        self.assertEqual(env.cc, ["jmlee3@suresofttech.com"])

    def test_004_production_uses_fixed_recipient_when_enabled(self):
        cfg = copy.deepcopy(self.config)
        cfg["mail"]["production_send_enabled"] = True
        env = build_envelope(self.report, cfg, False)
        self.assertEqual(env.to, ["dslee1@suresofttech.com"])
        self.assertEqual(env.cc, ["jmlee3@suresofttech.com"])
        self.assertFalse(env.subject.startswith("[연습]"))

    def test_005_alias_normalizes_term(self):
        self.assertEqual(normalize_terms("정치평가 진행", self.config["term_aliases"]), "정차평가 진행")

    def test_006_body_contains_required_sections(self):
        text = build_text_body(self.report, self.config)
        self.assertIn("[8월 3주차 진행 업무]", text)
        self.assertIn("[8월 4주차 진행 예정 업무]", text)
        self.assertIn("[차주 일정]", text)
        self.assertIn("이상입니다.", text)
        self.assertIn("감사합니다.", text)

    def test_007_body_has_minimal_task_fields(self):
        text = build_text_body(self.report, self.config)
        for token in ["- 일정 :", "- 장소 :", "- 내용 :"]:
            self.assertIn(token, text)

    def test_008_html_has_no_images(self):
        html = build_html_body(self.report, self.config)
        assert_no_images(html)
        self.assertNotIn("<img", html.lower())

    def test_009_html_escapes_user_input(self):
        report = sample_report()
        report.current_tasks = [TaskItem("<script>alert(1)</script>", "1", "2", "<b>x</b>")]
        html = build_html_body(report, self.config)
        self.assertNotIn("<script>", html.lower())
        self.assertIn("&lt;script&gt;", html)

    def test_010_schedule_contains_config_people(self):
        html = build_html_body(self.report, self.config)
        for person in self.config["mail"]["schedule_people"]:
            self.assertIn(person, html)

    def test_011_email_validation(self):
        self.assertEqual(validate_email("tester@suresofttech.com"), "tester@suresofttech.com")
        with self.assertRaises(ValidationError):
            validate_email("not-an-email")

    def test_012_config_contains_no_plaintext_password_field(self):
        raw = (ROOT / "config.json").read_text(encoding="utf-8").lower()
        self.assertNotRegex(raw, r'"(pw|password|passwd)"\s*:')

    def test_013_site_selectors_are_externalized(self):
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        self.assertIn("to_selectors", site["mail"])
        self.assertIn("subject_selectors", site["mail"])
        self.assertIn("body_iframe_selectors", site["mail"])

    def test_014_approval_gate_defaults_to_no_decision(self):
        gate = ApprovalGate(threading.Event())
        gate.reset()
        self.assertIsNone(gate.decision)
        self.assertFalse(gate.event.is_set())

    def test_015_approval_gate_approve(self):
        gate = ApprovalGate(threading.Event())
        gate.approve()
        self.assertEqual(gate.decision, "approve")
        self.assertTrue(gate.event.is_set())

    def test_016_approval_gate_reject(self):
        gate = ApprovalGate(threading.Event())
        gate.reject()
        self.assertEqual(gate.decision, "reject")
        self.assertTrue(gate.event.is_set())

    def test_017_package_naming_rule(self):
        text = (ROOT / "00_PACKAGE_NAMING_RULE.txt").read_text(encoding="utf-8")
        self.assertIn("WeeklyMailAgent_YYMMDD_N.zip", text)
        self.assertIn("WeeklyMailAgent_260826_1.zip", text)

    def test_018_no_online_browser_download_default(self):
        self.assertFalse(self.config["gw"]["allow_online_pip"])
        self.assertFalse(self.config["gw"]["allow_playwright_browser_download"])

    def test_019_subject_exact_template(self):
        subject = build_subject("8월 3주차", self.config, False)
        self.assertEqual(subject, "[주간보고] 8월 3주차_SW Integration 실차 검증 및 TC 강건화 용역")

    def test_020_practice_invalid_explicit_recipient_is_rejected(self):
        with self.assertRaises(ValidationError):
            build_envelope(self.report, self.config, True, "not-an-email")

    def test_021_practice_envelope_excludes_production_addresses(self):
        env = build_envelope(self.report, self.config, True, "tester@suresofttech.com")
        all_addresses = [x.lower() for x in env.to + env.cc]
        self.assertNotIn(self.config["mail"]["production_recipient"].lower(), all_addresses)
        for address in self.config["mail"].get("production_cc", []):
            self.assertNotIn(address.lower(), all_addresses)

    def test_022_default_practice_recipient_is_user_address(self):
        self.assertEqual(self.config["mail"]["practice_recipient"], "dcpark@suresofttech.com")
        env = build_envelope(self.report, self.config, True, "")
        self.assertEqual(env.to, ["dcpark@suresofttech.com"])

    def test_023_week_label_2026_08_19_is_august_week_3(self):
        self.assertEqual(week_label_for_date(date(2026, 8, 19)), "8월 3주차")
        self.assertEqual(thursday_of_week(date(2026, 8, 19)), date(2026, 8, 20))

    def test_024_week_labels_follow_thursday_ordinal(self):
        cases = {
            date(2026, 8, 5): "8월 1주차",
            date(2026, 8, 12): "8월 2주차",
            date(2026, 8, 26): "8월 4주차",
        }
        for day, expected in cases.items():
            with self.subTest(day=day):
                self.assertEqual(week_label_for_date(day), expected)

    def test_025_week_label_month_boundary_uses_thursday_month(self):
        self.assertEqual(week_label_for_date(date(2026, 8, 31)), "9월 1주차")

    def test_026_week_label_supports_fifth_thursday(self):
        self.assertEqual(week_label_for_date(date(2026, 10, 29)), "10월 5주차")

    def test_027_clone_tasks_creates_independent_task_objects(self):
        original = [TaskItem("TC 강건화", "18일 ~ 19일", "C5-8", "JG1 차량 대상 강건화 작업 진행")]
        copied = clone_tasks(original)
        self.assertEqual(copied, original)
        self.assertIsNot(copied, original)
        self.assertIsNot(copied[0], original[0])

    def test_028_checked_schedule_cell_is_red_and_bold_in_html(self):
        report = sample_report()
        report.next_week_schedule["이종민"]["월"] = "건강검진(오전) · 오후반차"
        report.next_week_schedule_highlight["이종민"]["월"] = True
        html = build_html_body(report, self.config)
        self.assertRegex(
            html,
            r"color:#d00000;font-weight:700;'[^>]*>건강검진\(오전\) · 오후반차</td>",
        )

    def test_029_unchecked_schedule_cell_does_not_get_red_bold_style(self):
        report = sample_report()
        report.next_week_schedule["박동천"]["화"] = "UNIQUE_NORMAL_CELL"
        report.next_week_schedule_highlight["박동천"]["화"] = False
        html = build_html_body(report, self.config)
        match = re.search(r"<td style='([^']*)'>UNIQUE_NORMAL_CELL</td>", html)
        self.assertIsNotNone(match)
        self.assertNotIn("color:#d00000", match.group(1))
        self.assertNotIn("font-weight:700", match.group(1))

    def test_030_package_root_has_only_launcher_and_function(self):
        visible = {p.name for p in PACKAGE_ROOT.iterdir() if p.name != "__pycache__"}
        self.assertEqual(visible, {"WeeklyMailAgent.pyw", "function"})

    def test_031_runtime_data_root_is_function_folder(self):
        from function.config_loader import app_root

        self.assertEqual(app_root(), ROOT)
        self.assertTrue((ROOT / "config.json").exists())
        self.assertTrue((ROOT / "site_profile.json").exists())

    def test_032_browser_config_prefers_boardrepo_order(self):
        self.assertEqual(
            self.config["browser"]["auto_order"],
            ["playwright_chromium", "msedge"],
        )
        self.assertEqual(self.config["browser"]["mode"], "auto")

    def test_033_credential_store_uses_boardrepo_keyring_service(self):
        src = (ROOT / "credential_store.py").read_text(encoding="utf-8")
        self.assertIn('BOARDREPO_SERVICE = "BoardRepo_Groupware"', src)
        self.assertIn('"__username__"', src)
        self.assertIn("LEGACY_WMA_SERVICE", src)

    def test_034_browser_runtime_has_no_custom_unsafe_or_maximize_flags(self):
        src = (ROOT / "browser_runtime.py").read_text(encoding="utf-8")
        self.assertNotIn('args=["--start-maximized"]', src)
        self.assertNotIn('"--no-sandbox"', src)
        self.assertIn('display_name="Playwright Chromium"', src)

    def test_035_environment_manager_exposes_selected_browser(self):
        src = (ROOT / "environment_manager.py").read_text(encoding="utf-8")
        self.assertIn('"selected_browser"', src)
        self.assertIn('"chromium_ok"', src)
        self.assertIn('"edge_ok"', src)

    def test_036_release_baseline_is_v0_16(self):
        self.assertEqual(self.config["technical_version"], "v0.16")
        self.assertEqual(self.config["package_release"], "260826_1")

    def test_037_mail_write_selector_supports_input_value(self):
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        selectors = site["mail"].get("write_button_selectors", [])
        self.assertIn("input[type='button'][value='메일쓰기']", selectors)
        self.assertIn("xpath=//*[normalize-space(@value)='메일쓰기']", selectors)

    def test_038_mail_write_discovery_uses_exact_text_and_child_frames(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("get_by_text(name, exact=True)", src)
        self.assertIn("page.frames", src)
        self.assertIn("_search_contexts", src)
        self.assertNotIn("mouse.click", src)

    def test_039_mail_write_failure_logs_dom_candidate_metadata(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("_describe_exact_control_candidates", src)
        self.assertIn("후보 DOM 진단", src)
        self.assertIn("tag=", src)


    def test_040_compose_fields_search_all_frames(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("def _first_visible_in_contexts", src)
        self.assertIn("def _find_compose_field", src)
        self.assertIn("for context_label, ctx in _search_contexts(page)", src)
        self.assertIn("_find_compose_field(page, selectors, label", src)

    def test_041_compose_field_has_exact_label_nearest_editable_fallback(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("def _discover_labeled_editable", src)
        self.assertIn("get_by_text(label_text, exact=True)", src)
        self.assertIn("same horizontal row", src)
        self.assertNotIn("mouse.click", src)

    def test_042_compose_finishes_body_before_recipient_and_subject(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _fill_compose("):src.index("def _pre_send_revalidate(")]
        clear_pos = part.index("_clear_editor_only")
        fill_body_pos = part.index("_fill_editor_html")
        to_pos = part.index("_fill_address_field")
        subject_pos = part.index("_set_subject_exact")
        self.assertLess(clear_pos, fill_body_pos)
        self.assertLess(fill_body_pos, to_pos)
        self.assertLess(to_pos, subject_pos)
        self.assertIn("이미지 0개", src)

    def test_043_editor_and_routing_validation_are_frame_aware(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("def _find_editor", src)
        self.assertIn("def _safe_field_text", src)
        self.assertIn("def _verify_routing_fields", src)
        self.assertIn("for _, ctx in _search_contexts(page)", src)
        self.assertIn('"제목", timeout_ms, log', src)

    def test_045_practice_routing_ignores_page_wide_unrelated_addresses(self):
        env = build_envelope(self.report, self.config, True, "dcpark@suresofttech.com")
        _validate_actual_routing_texts(
            env, self.config,
            "박동천 <dcpark@suresofttech.com>",
            "",
        )

    def test_046_practice_routing_rejects_production_address_in_actual_fields(self):
        env = build_envelope(self.report, self.config, True, "dcpark@suresofttech.com")
        with self.assertRaises(GWAutomationError):
            _validate_actual_routing_texts(
                env, self.config,
                "dcpark@suresofttech.com dslee1@suresofttech.com",
                "",
            )

    def test_047_production_routing_requires_exact_fixed_to_and_cc(self):
        env = build_envelope(self.report, self.config, False)
        _validate_actual_routing_texts(
            env, self.config,
            "dslee1@suresofttech.com",
            "jmlee3@suresofttech.com",
        )
        with self.assertRaises(GWAutomationError):
            _validate_actual_routing_texts(
                env, self.config,
                "dcpark@suresofttech.com",
                "jmlee3@suresofttech.com",
            )

    def test_044_compose_field_selectors_are_expanded(self):
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(site["mail"]["to_selectors"]), 6)
        self.assertGreaterEqual(len(site["mail"]["cc_selectors"]), 6)
        self.assertGreaterEqual(len(site["mail"]["subject_selectors"]), 6)
        self.assertTrue(any("contenteditable" in x for x in site["mail"]["to_selectors"]))



    def test_048_production_autocomplete_display_tokens_are_accepted(self):
        env = build_envelope(self.report, self.config, False)
        _validate_actual_routing_texts(
            env, self.config, "이동섭/수석연구원/모빌리티솔루션1팀", "이종민/전임연구원/모빌리티솔루션1팀",
            to_committed=True, cc_committed=True,
        )

    def test_049_unexpected_committed_cc_is_blocked_when_cc_should_be_empty(self):
        env = build_envelope(self.report, self.config, True, "dcpark@suresofttech.com")
        with self.assertRaises(GWAutomationError):
            _validate_actual_routing_texts(
                env, self.config, "박동천/선임연구원", "임의 참조자",
                to_committed=True, cc_committed=True,
            )

    def test_050_visible_wrong_email_is_still_blocked_even_with_autocomplete_support(self):
        env = build_envelope(self.report, self.config, False)
        with self.assertRaises(GWAutomationError):
            _validate_actual_routing_texts(
                env, self.config, "wrong@suresofttech.com", "jmlee3@suresofttech.com",
                to_committed=True, cc_committed=True,
            )

    def test_051_history_roundtrip_and_previous_week_lookup(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "weekly_records.json"
            report = sample_report()
            report.week_label = "8월 2주차"
            save_week_record(report, reference_date=date(2026, 8, 12), path=path)
            record = load_previous_week_record(reference_date=date(2026, 8, 19), path=path)
            self.assertIsNotNone(record)
            self.assertEqual(record["week_label"], "8월 2주차")
            self.assertEqual(record["reference_thursday"], "2026-08-13")
            current = tasks_from_record(record, "current_tasks", mark_history=True)
            self.assertTrue(current[0].from_history)
            self.assertFalse(current[0].as_current().from_history)

    def test_052_previous_week_label_uses_previous_thursday(self):
        self.assertEqual(previous_week_label(date(2026, 8, 19)), "8월 2주차")

    def test_053_history_json_never_contains_credential_fields(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "weekly_records.json"
            save_week_record(self.report, reference_date=date(2026, 8, 19), path=path)
            raw = path.read_text(encoding="utf-8").lower()
            self.assertNotIn('"password"', raw)
            self.assertNotIn('"pw"', raw)
            self.assertNotIn('"username"', raw)

    def test_054_history_loaded_rows_use_yellow_tag_and_edit_clears_flag(self):
        src = (ROOT / "app.py").read_text(encoding="utf-8")
        self.assertIn('tag_configure("history", background="#FFF2CC")', src)
        self.assertIn('TaskItem(*vals, from_history=False)', src)
        self.assertIn('tags = ("history",) if item.from_history else ()', src)


    def test_055_routing_residue_ignores_cc_plus_and_subject_important_controls(self):
        self.assertEqual(_clean_routing_residue("참조 +", "참조"), "")
        self.assertEqual(_clean_routing_residue("제목 중요!", "제목"), "")
        self.assertEqual(_clean_routing_residue("참조 + 이동섭/수석연구원", "참조"), "이동섭/수석연구원")

    def test_056_dom_hidden_autocomplete_is_allowed_with_exact_input_selection_proof(self):
        env = build_envelope(self.report, self.config, False)
        _validate_actual_routing_texts(
            env, self.config, "", "",
            to_committed=False, cc_committed=False,
            to_input_proof=True, cc_input_proof=True,
        )

    def test_057_dom_hidden_autocomplete_without_input_proof_is_blocked(self):
        env = build_envelope(self.report, self.config, False)
        with self.assertRaises(GWAutomationError):
            _validate_actual_routing_texts(
                env, self.config, "", "",
                to_committed=False, cc_committed=False,
                to_input_proof=False, cc_input_proof=False,
            )

    def test_058_recipient_commit_uses_real_keyboard_typing_then_tab_only(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _commit_address_by_tab"):src.index("def _fill_address_field")]
        self.assertIn('loc.press_sequentially(address, delay=25)', part)
        self.assertIn('page.wait_for_timeout(650)', part)
        self.assertIn('loc.press("Tab")', part)
        self.assertIn('"method": "typed_tab_commit"', part)
        self.assertNotIn('loc.fill(address)', part)
        self.assertNotIn('loc.press("ArrowDown")', part)
        self.assertNotIn('loc.press("Enter")', part)
        self.assertNotIn("_find_exact_autocomplete_candidate", src)

    def test_059_cc_plus_and_subject_important_are_never_clicked_or_toggled(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("the small '+' beside 참조", src)
        self.assertIn("제목 '중요!' checkbox", src)
        self.assertNotIn("중요_check", src)
        self.assertNotIn("cc_plus", src)

    def test_060_recipient_row_validation_uses_visible_same_band_text_only(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _recipient_row_text"):src.index("def _commit_address_by_tab")]
        self.assertIn("same horizontal recipient band", part)
        self.assertIn("getComputedStyle", part)
        self.assertIn("overlapsInputBand", part)
        self.assertIn("r.height <= 86", part)

    def test_061_recipient_row_reader_does_not_use_broad_innertext(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _recipient_row_text"):src.index("def _commit_address_by_tab")]
        self.assertNotIn(".innerText", part)
        self.assertIn("createTreeWalker", part)

    def test_062_routing_log_reports_only_actual_address_row_evidence(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("실제 주소행 표시 확인", src)
        self.assertIn("to_state.get('emails'", src)
        self.assertIn("cc_state.get('emails'", src)

    def test_063_next_week_label_august_3_to_august_4(self):
        self.assertEqual(next_week_label("8월 3주차", date(2026, 8, 19)), "8월 4주차")

    def test_064_next_week_label_rolls_to_september_when_no_august_fifth_thursday(self):
        self.assertIsNone(nth_thursday(2026, 8, 5))
        self.assertEqual(next_week_label("8월 4주차", date(2026, 8, 26)), "9월 1주차")

    def test_065_next_week_label_keeps_real_fifth_thursday(self):
        self.assertEqual(nth_thursday(2026, 10, 5), date(2026, 10, 29))
        self.assertEqual(next_week_label("10월 4주차", date(2026, 10, 21)), "10월 5주차")

    def test_066_html_and_text_use_next_week_for_planned_section(self):
        report = sample_report()
        text = build_text_body(report, self.config)
        html = build_html_body(report, self.config)
        self.assertIn("[8월 4주차 진행 예정 업무]", text)
        self.assertIn("[8월 4주차 진행 예정 업무]", html)
        self.assertNotIn("[8월 3주차 진행 예정 업무]", text)

    def test_067_editor_clear_does_not_click_body_and_draft_restores_top(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        clear_part = src[src.index("def _clear_editor_only"):src.index("def _fill_editor_html")]
        self.assertNotIn("body.click()", clear_part)
        self.assertIn("def _restore_compose_top", src)
        self.assertIn("window.scrollTo(0, 0)", src)
        self.assertIn("_restore_compose_top(page, log)", src)

    def test_068_body_is_written_before_final_recipient_tab_commit(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        compose = src[src.index("def _fill_compose"):src.index("def _pre_send_revalidate")]
        self.assertLess(compose.index("_fill_editor_html"), compose.index("_fill_address_field"))
        self.assertIn("e-mail text -> Tab", compose)
        self.assertNotIn("_confirm_recipient_exact_after_fill", compose)
        self.assertNotIn("_repair_missing_recipient_after_body(", compose)

    def test_069_sender_intro_addresses_team_leader(self):
        self.assertEqual(
            self.config["mail"]["sender_intro"],
            "안녕하십니까 팀장님, 모빌리티솔루션1팀 박동천 선임입니다.",
        )
        self.assertTrue(build_text_body(self.report, self.config).startswith("안녕하십니까 팀장님,"))
        self.assertIn("안녕하십니까 팀장님,", build_html_body(self.report, self.config))

    def test_070_subject_exact_is_reasserted_after_body(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("def _set_subject_exact", src)
        compose = src[src.index("def _fill_compose"):src.index("def _pre_send_revalidate")]
        self.assertLess(compose.index("_fill_editor_html"), compose.index("_set_subject_exact"))
        self.assertIn("제목 실제 입력란에 입력 및 유지 확인", src)

    def test_071_final_recipient_does_not_require_chip_dom_or_reenter(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertNotIn("def _confirm_recipient_exact_after_fill", src)
        self.assertNotIn("최종 이메일 칩이 보이지 않아", src)
        self.assertNotIn("_repair_missing_recipient_after_body", src)
        self.assertIn("tab-commit-proof", src)
        self.assertIn("최종 승인 전에 브라우저의 받는사람/참조 표시를 직접 확인하세요", src)

    def test_072_subject_template_remains_weekly_report_format(self):
        subject = build_subject("8월 3주차", self.config, False)
        self.assertEqual(subject, "[주간보고] 8월 3주차_SW Integration 실차 검증 및 TC 강건화 용역")

    def test_073_compose_field_selectors_exclude_utility_checkboxes(self):
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        to_head = " ".join(site["mail"]["to_selectors"][:2]).lower()
        self.assertIn("checkbox", to_head)
        self.assertIn("not(", to_head)
        self.assertTrue(all("following::" not in x.lower() for x in site["mail"]["subject_selectors"]))

    def test_074_compose_candidate_filter_rejects_checkbox_and_accepts_text(self):
        class FakeLocator:
            def __init__(self, tag, typ="", contenteditable=""):
                self.meta = {"tag": tag, "type": typ, "hasContenteditable": bool(contenteditable), "contenteditable": contenteditable}
            def evaluate(self, _script):
                return self.meta

        self.assertFalse(_candidate_is_compose_text_entry(FakeLocator("input", "checkbox")))
        self.assertFalse(_candidate_is_compose_text_entry(FakeLocator("input", "radio")))
        self.assertTrue(_candidate_is_compose_text_entry(FakeLocator("input", "text")))
        self.assertTrue(_candidate_is_compose_text_entry(FakeLocator("textarea")))

    def test_075_recipient_proof_is_appended_once_per_address(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _fill_address_field"):src.index("def _safe_field_state")]
        self.assertEqual(part.count("items.append(proof)"), 1)

    def test_076_subject_field_filter_blocks_importance_checkbox_value_on(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        first_visible = src[src.index("def _first_visible_in_contexts"):src.index("def _discover_labeled_editable")]
        self.assertIn("_candidate_is_compose_text_entry(loc)", first_visible)
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        self.assertTrue(all("following::" not in x.lower() for x in site["mail"]["subject_selectors"][:2]))


    def test_077_subject_uses_dedicated_same_row_geometry_finder(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        self.assertIn("def _discover_subject_text_field", src)
        self.assertIn('if label_text == "제목"', src)
        part = src[src.index("def _discover_subject_text_field"):src.index("def _find_compose_field")]
        self.assertIn('box["width"] < 220', part)
        self.assertIn("dy > 22", part)
        self.assertIn("동일 행 전용 탐색", part)

    def test_078_subject_profile_avoids_broad_following_xpath(self):
        site = json.loads((ROOT / "site_profile.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(site["mail"]["subject_selectors"]), 6)
        self.assertTrue(all("following::" not in x.lower() for x in site["mail"]["subject_selectors"]))

    def test_079_editor_lookup_retries_until_selector_timeout(self):
        src = (ROOT / "gw_mail_automation.py").read_text(encoding="utf-8")
        part = src[src.index("def _find_editor"):src.index("def _clear_editor_only")]
        self.assertIn("deadline = time.time()", part)
        self.assertIn("while time.time() < deadline", part)
        self.assertIn("time.sleep(0.2)", part)

    def test_080_default_practice_mode_is_off(self):
        self.assertFalse(self.config["mail"]["practice_mode_default"])

    def test_081_multiline_keywords_preserved_in_text_body(self):
        report = sample_report()
        report.current_tasks = [TaskItem("TC 강건화", "8/24 ~ 8/25", "C5-8", "환경차 TC\nCCS TC\n로그 재측정")]
        text = build_text_body(report, self.config)
        self.assertIn("- 내용 : 환경차 TC", text)
        self.assertIn("            CCS TC", text)
        self.assertIn("            로그 재측정", text)

    def test_082_multiline_keywords_preserved_in_html_body(self):
        report = sample_report()
        report.current_tasks = [TaskItem("TC 강건화", "8/24 ~ 8/25", "C5-8", "환경차 TC\nCCS TC")]
        html = build_html_body(report, self.config)
        self.assertIn("환경차 TC<br>", html)
        self.assertIn("CCS TC", html)

    def test_083_draft_wait_button_auto_saves_current_week_history(self):
        src = (ROOT / "app.py").read_text(encoding="utf-8")
        part = src[src.index("def start_gw_flow"):src.index("def _worker")]
        self.assertIn("self._save_history_snapshot(notify=False)", part)
        self.assertLess(part.index("self._save_history_snapshot(notify=False)"), part.index("threading.Thread"))

    def test_084_task_dialog_uses_multiline_text_widget_for_keywords(self):
        src = (ROOT / "app.py").read_text(encoding="utf-8")
        part = src[src.index("class TaskDialog"):src.index("class TaskListFrame")]
        self.assertIn("self.keywords_text = tk.Text", part)
        self.assertIn('height=6', part)
        self.assertIn('<Control-Return>', part)
        self.assertNotIn('self.bind("<Return>"', part)

if __name__ == "__main__":
    unittest.main(verbosity=2)
