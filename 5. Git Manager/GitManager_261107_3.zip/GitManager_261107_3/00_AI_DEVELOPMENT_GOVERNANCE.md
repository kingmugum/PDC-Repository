# 00_AI_DEVELOPMENT_GOVERNANCE.md

> **Document Version:** v0.14  
> **Status:** Draft / Living Document  
> **Effective Date:** 2026-10-04  
> **Purpose:** 모든 AI 보조 개발 프로젝트에 적용할 공통 개발헌법과 Project ID별 고유 운영 규칙을 하나의 문서에서 관리한다.  
> **Registered Projects:** `PF` PassFail, `SE` Signal Export V2, `AM` Automation Manager, `GM` Git Manager, `BR` BoardRepo, `ALM` Requirement Studio Manual, `ALR` Requirement Studio Runtime / Tools, `LRN` 학습 / Knowledge Notes  
> **Supersedes:** `00_AI_DEVELOPMENT_CONSTITUTION.md` + 프로젝트별 `01_PROJECT_RULES.md`

---

# 0. 이 문서를 사용하는 방법

AI는 개발·수정·분석 작업을 시작할 때 다음 순서를 따른다.

```text
사용자의 현재 지시 확인
        ↓
현재 작업의 Project ID 식별
        ↓
Part A 공통 개발헌법 적용
        ↓
Part B 프로젝트 선택·운영 규칙 적용
        ↓
Part C의 해당 Project ID 규칙만 적용
        ↓
최신 승인 Requirements / Architecture / Code / Test 확인
        ↓
작업 수행 및 검증
```

핵심 적용 원칙:

1. `Part A`는 등록된 모든 프로젝트에 공통 적용한다.
2. `Part C`에서는 현재 확정된 Project ID의 규칙만 적용한다.
3. 다른 Project ID의 규칙을 현재 프로젝트에 혼합하거나 유추 적용하지 않는다.
4. Project ID가 없거나 둘 이상으로 판단되면 임의로 선택하지 않는다.
5. 신규 프로젝트는 `DRAFT` 상태로 등록하고 사용자 승인 후 `ACTIVE`로 전환한다.
6. 본 문서가 존재하는 신규 패키지에서는 과거의 분리 문서인 `00_AI_DEVELOPMENT_CONSTITUTION.md`와 `01_PROJECT_RULES.md`를 중복 운영하지 않는다.

---

# Part A. 모든 프로젝트 공통 개발헌법

## A1. 목적과 문서 역할

본 Part는 AI가 소프트웨어를 구현·수정할 때 따라야 하는 공통 개발 원칙을 정의한다. 개별 기능 요구사항이나 프로젝트 고유 파일명을 복제하지 않는다.

| 문서·정보원 | 담당 질문 | 최종 기준이 되는 영역 |
|---|---|---|
| 승인된 Requirements | 무엇을 해야 하는가? | 기능, 사용자 동작, 입력·출력, 예외, 판정 기준 |
| 본 문서 Part A | 어떤 원칙으로 개발해야 하는가? | 개발 절차, AI 행동 통제, 변경·검증 원칙 |
| 본 문서 Part C | 이 프로젝트만의 규칙은 무엇인가? | 파일명, 환경, 패키지, 프로젝트 고유 경계 |
| `ARCHITECTURE.md` | 어디가 책임지고 어떻게 연결되는가? | 모듈 책임, Interface, Dependency, 실행 구조 |
| `CODING_STANDARD.md` | 코드를 어떤 방식으로 작성·검사하는가? | Coding Style, 정적분석, Metric, Runtime 규칙 |
| Manifest / Release 기록 | 현재 배포 기준은 무엇인가? | 실제 파일 목록, Hash, Revision, Package Sequence |

`ARCHITECTURE.md` 또는 `CODING_STANDARD.md`가 없는 프로젝트에서는 존재하지 않는 내용을 추정하지 않는다. 필요성이 확인되면 신규 문서 초안을 제안한다.

## A2. 문서 충돌 처리

문서 간 충돌은 하나의 고정된 서열만으로 처리하지 않고, 충돌한 내용의 권한 영역을 먼저 판단한다.

1. 사용자의 현재 명시적 지시
2. 해당 내용의 권한을 가진 최신 승인 정보원
3. 검증된 기존 동작과 시험 결과
4. 기존 코드, 주석, 과거 패키지와 기타 참고자료

영역별 기준:

- 기능, 입력·출력, 판정, 예외: 최신 승인 Requirements
- 공통 개발 절차와 AI 행동 통제: Part A
- 파일명, 실행 환경, 배포 구성과 프로젝트 고유 규칙: 활성 Project ID의 Part C
- 모듈 책임과 Interface: Requirements의 기능 의도를 확인한 후 Architecture
- 실제 구현 상태: Code와 Test 근거로 확인하되, 코드가 존재한다는 이유만으로 Requirement를 추정하지 않음

사용자의 일회성 지시는 그 작업에 우선 적용할 수 있지만, 영구 규칙 변경으로 자동 해석하지 않는다. 지속 적용이 필요한 변경은 Requirements 또는 본 문서에 기록한다.

## A3. 승인된 Requirements 준수

### A3.1 Single Source of Truth

각 프로젝트의 활성 프로필에서 지정한 최신 승인 Requirements를 기능 요구사항의 Single Source of Truth로 사용한다.

### A3.2 요구사항에 없는 기능 금지

AI는 요구사항에 없는 사용자 동작, 기능, 제약 완화 또는 안전 우회를 임의로 추가하지 않는다.

불명확한 내용은 추정하여 확정하지 않고 다음 중 하나로 표시한다.

- `TBD`
- `OPEN ISSUE`
- `ASSUMPTION`

### A3.3 Assumption 관리

- 가정을 암묵적으로 코드에 반영하지 않는다.
- 가정의 내용과 영향 범위를 기록한다.
- 사용자 또는 승인된 Requirement로 확정되기 전까지 임시 상태로 관리한다.
- 안전, 데이터 손실, 외부 전송, 비용 발생과 관련된 가정은 사용자 승인 없이 구현하지 않는다.

### A3.4 현행 동작과 Requirement의 차이

```text
승인 Requirement 확인
        ↓
현행 동작 확인
        ↓
차이점과 영향 식별
        ↓
의도된 변경인지 판단
        ↓
필요 시 사용자 확인 또는 문서 갱신
```

## A4. 기존 기능 보존과 최소 변경

변경 요구사항과 직접 관련 없는 기존 기능은 유지한다.

> 요청받은 변경보다 수정 범위를 불필요하게 넓히지 않는다.

- 리팩터링이 기존 동작에 영향을 줄 가능성이 있으면 별도 변경사항으로 취급한다.
- 중복 제거, 구조 정리, 가독성 개선도 요청 범위 안에서만 수행한다.
- 외부 동작 불변을 관련 회귀 시험으로 확인할 수 없는 리팩터링은 자동 수행하지 않는다.
- 기존 Interface, 데이터 Format, 외부 참조 식별자를 임의로 변경하지 않는다.

## A5. 변경 전 영향 분석

코드를 수정하기 전에 최소한 다음을 확인한다.

- 변경되는 Requirement와 상위 시나리오
- 영향받는 Module과 Responsibility
- 영향받는 Interface와 Dependency
- 입력·출력 및 데이터 Format
- 파일·설정·외부 시스템 영향
- 기존 기능에 대한 회귀 위험
- 추가·수정할 Test와 판정 기준
- 변경금지조건 또는 안전 Gate

## A6. Architecture 경계 보호

새 기능을 기존 Module에 추가하기 전에 다음을 확인한다.

1. 해당 기능이 그 Module의 책임 범위인지 확인한다.
2. 다른 책임이라면 별도 Module 또는 명시적 Interface 분리를 검토한다.
3. 다른 Module의 내부 구현에 직접 의존하지 않는다.
4. 공개 Interface와 데이터 계약을 우선 사용한다.
5. Architecture가 현행 코드와 다르면 차이를 기록하고 어느 쪽을 갱신할지 결정한다.

## A7. AI의 자율 판단 범위

AI가 비교적 자율적으로 판단할 수 있는 범위:

- 승인된 Requirement 안에서의 내부 구현 방식
- 요청 범위 내의 국소적 중복 제거
- 외부 동작과 Interface에 영향을 주지 않는 가독성 개선
- 검증 방법이 명확한 작은 구조 정리

AI가 임의로 결정할 수 없는 범위:

- Requirement 또는 사용자 동작 변경
- 파일·데이터 Format 변경
- Interface 변경
- 기존 기능 삭제 또는 비활성화
- 외부 Dependency·네트워크·서비스 추가
- 비가역적 데이터 변경
- 인증정보 처리 방식 변경
- 안전 Gate 완화
- 배포 방식과 호환 범위 변경

## A8. 외부 Dependency

새 Library, Framework, Package 또는 외부 서비스를 추가하기 전에 다음을 확인한다.

1. 해당 언어·플랫폼의 표준 기능 또는 기존 Dependency로 해결 가능한가?
2. 신규 Dependency가 반드시 필요한가?
3. 현재 배포 환경과 지원 버전에서 사용할 수 있는가?
4. License, 보안 취약점, 버전 고정, 장기 유지보수 부담은 적절한가?
5. 오프라인·사내망·고객 환경에서도 요구된 기능을 수행할 수 있는가?

외부 Dependency 추가는 사용자의 명시적 승인 또는 승인된 Requirement가 필요하다.

## A9. 파일·데이터·보안 보호

- 입력 원본 파일을 불필요하게 직접 수정하지 않는다.
- 삭제, 덮어쓰기, 비가역적 변경은 명시적으로 승인된 Requirement가 있을 때만 수행한다.
- 기존 파일 대체가 요구되지 않으면 별도 결과 파일 생성을 우선 검토한다.
- 데이터 변경 대상과 결과를 추적할 수 있어야 한다.
- API Key, 비밀번호, Token, 인증서와 개인정보를 코드·로그·보고서에 평문으로 기록하지 않는다.
- 사용자 승인 없이 프로젝트 데이터를 외부 시스템으로 전송하지 않는다.
- 민감정보, 고객 원본, 개인 PC 설정을 배포 패키지에 포함하지 않는다.
- 보호·암호화 파일의 보안을 임의로 우회하지 않는다.

## A10. 실패·예외·로그

예외를 무조건 무시하거나 성공처럼 숨기지 않는다.

실패 발생 시 가능한 범위에서 다음을 확인할 수 있어야 한다.

- 무엇이 실패했는가?
- 어떤 입력과 조건에서 실패했는가?
- 실패 원인은 무엇인가?
- 영향받은 결과는 무엇인가?
- 사용자가 어떤 조치를 취할 수 있는가?

기본 로그 수준:

| Level | 의미 |
|---|---|
| `INFO` | 정상 진행과 주요 상태 |
| `WARNING` | 예상과 다르지만 제한적으로 진행 가능 |
| `ERROR` | 기능 수행 실패 또는 결과 신뢰 불가 |
| `DEBUG` | 개발 및 원인 분석용 상세 정보 |

로그 위치, 보존기간, Format과 마스킹 규칙은 활성 프로젝트 프로필 또는 Requirement에서 정의한다.

## A11. Test와 Regression

변경 후 최소한 다음을 수행한다.

1. 변경 기능 Test
2. 관련 기존 기능 Regression Test
3. 실패·경고 원인 확인
4. 기존 동작의 의도치 않은 변경 여부 확인
5. 수행하지 못한 시험과 사유 기록

> 프로그램 실행 성공, Compile 성공, 정적 검증 성공과 Requirement 충족은 서로 다른 상태다.

검증 상태는 최소한 다음과 같이 구분한다.

- 문서 반영
- 코드 구현
- Compile / Import / Build 통과
- 정적·함수·합성 확인
- 자동·모의 회귀 확인
- 실제 입력자료·장비·외부 서비스 확인
- 실제 사용자·현장 확인
- 미수행 / 부분수행 / 수행불가

수행하지 않은 단계를 전체 PASS로 표현하지 않는다.

## A12. Date, Revision, Version과 Package

다음은 기본적으로 서로 다른 개념이다.

- 작업·생성 Date
- Governance / Requirements / Code Version 또는 Revision
- 배포 Package Sequence

각 프로젝트가 일부 Revision을 하나의 Baseline으로 묶을 수는 있지만, Package Sequence와 동일한 값으로 해석하지 않는다. 구체적인 명명·증가 규칙은 활성 프로젝트 프로필을 따른다.

기존 파일을 동일 이름으로 조용히 덮어쓰지 않는다.

## A13. Traceability

가능한 경우 다음 연결을 추적할 수 있어야 한다.

```text
사용자 시나리오
    ↓
상세 Requirement
    ↓
Architecture / Module / Interface
    ↓
Code 근거
    ↓
Test Case / Regression 결과
```

- 기존 Requirement ID는 재번호하지 않는다.
- 삭제·대체된 ID를 다른 요구사항에 재사용하지 않는다.
- 변경 이유, 대체 ID와 영향 범위를 기록한다.
- 요구사항에서 시나리오를 복원했다는 이유만으로 기존 Requirement를 자동 변경하지 않는다.

## A14. 문서 중복 방지

동일한 구체 요구사항을 여러 문서에 복제하지 않는다.

- Part A: 공통 원칙
- Part C: 프로젝트 고유 운영 규칙
- Requirements: 구체적인 기능과 판정 조건
- Architecture: 모듈 책임과 연결 구조
- Code / Test: 구현 및 검증 근거

다른 문서의 내용을 반복해야 할 때는 요약과 참조 위치를 기록하고, 원본 권한 영역을 명시한다.

## A15. 공통 Definition of Done

AI가 완료를 선언하기 전에 각 항목의 결과를 `완료`, `부분완료`, `미수행`, `해당 없음` 중 하나로 구분한다.

- [ ] 활성 Project ID 확정
- [ ] 공통 헌법과 활성 프로젝트 규칙 확인
- [ ] 최신 승인 Requirements 확인
- [ ] 상위 시나리오와 상세 Requirement 영향 확인
- [ ] Architecture / Interface / Data 영향 확인
- [ ] 요구사항 충돌·중복·누락 확인
- [ ] 코드 최소 변경
- [ ] 변경 기능 Test
- [ ] 관련 Regression Test
- [ ] 미수행·부분수행·수행불가 항목 기록
- [ ] 관련 Requirements / Architecture / Code 근거 갱신
- [ ] Date / Revision / Package 규칙 확인
- [ ] 배포 파일과 민감정보 포함 여부 확인
- [ ] 패키지 무결성 확인

실제 장비·차량·외부 API·고객 환경이 없어 수행할 수 없는 검증은 임의로 PASS 처리하지 않는다.

## A16. Living Governance

본 문서는 실제 프로젝트 적용 결과에 따라 점진적으로 개선한다.

- 공통 원칙 변경: `Document Version` 증가
- 특정 프로젝트 규칙 변경: 해당 `Profile Version` 증가
- 기존 규칙 삭제: 삭제보다 `DEPRECATED` 또는 대체 규칙 기록을 우선
- 변경 이유와 적용 프로젝트를 Change History에 기록

---

## A17. Governance Carry-Forward와 패키지 기준선

`00_AI_DEVELOPMENT_GOVERNANCE.md`는 AI 보조 개발의 공통 기준 문서이며, 등록 프로젝트의 내부 개발 패키지에서는 다음 규칙을 따른다.

1. Automation Manager 통합 배포본 Root에는 본 파일을 반드시 포함한다.
2. Git Manager 및 BoardRepo 독립 Release에도 본 파일을 포함한다.
3. 이후 패키지를 이전 승인 패키지에서 파생할 때 본 파일을 자동 승계 대상으로 취급한다. 사용자가 동일 Governance 파일을 매번 별도 첨부할 필요는 없다.
4. 패키지 Manifest에는 Governance 파일명, Document Version, SHA-256을 기록한다.
5. Governance 파일이 누락된 패키지는 코드 실행 자체와 별개로 개발 기준선 불완전 상태로 표시하며, 다음 수정·Release 전에 복구한다.
6. 여러 Governance 사본이 발견되면 임의 병합하지 않는다. 통합 패키지 Root의 최신 승인 사본을 기준으로 차이를 검토한다.
7. Governance 변경은 Living Document 규칙에 따라 Document Version 또는 해당 Project Profile Version을 증가시키고 Change History에 기록한다.
8. 기능·입력·출력·판정·예외의 최종 기준은 계속 최신 승인 Requirements이며, Governance는 공통 개발 절차·AI 행동 통제·프로젝트 고유 운영 규칙의 기준이다.

따라서 사용자가 단순히 “기능 추가/수정”을 요청하더라도 AI는 패키지에 동봉된 Governance → 활성 Project Profile → 최신 Requirements → Architecture/Code/Test 순으로 영향과 충돌을 확인한 뒤 작업한다.


## A18. 배포 패키지 명명·생성·청결성 규칙

배포 패키지는 재현 가능하고 다른 PC에서 안전하게 사용할 수 있는 **소스·설정·승인 산출물 중심의 Clean Distribution**이어야 한다.

### A18.1 Package Naming

1. 실제 생성일을 `YYMMDD`로 사용한다. 임의의 과거 날짜를 새 패키지명에 재사용하지 않는다.
2. 같은 프로젝트·같은 날짜의 패키지는 `_1`, `_2`, `_3` 순으로 증가시키고 날짜가 바뀌면 다시 `_1`부터 시작한다.
3. Package Sequence는 Code/Requirements/Governance의 Technical Version 또는 Revision과 독립적으로 관리한다.
4. 동일 이름의 기존 ZIP을 조용히 덮어쓰지 않는다.
5. 정확한 Prefix와 파일명 Pattern은 활성 Project Profile의 `Package Pattern`을 따른다.
6. 외부 ZIP 파일명과 ZIP 내부 최상위 Root 폴더명은 특별한 Requirement가 없는 한 확장자를 제외하고 동일하게 유지한다.
7. 한글 등 비ASCII 경로는 ZIP UTF-8 filename metadata로 보존하고, 압축 해제 후 canonical 폴더명이 원본과 동일한지 확인한다.

예:

```text
Automation_Manager_260912_5.zip
└─ Automation_Manager_260912_5/

BoardRepo_260912_5.zip
└─ BoardRepo_260912_5/
```

### A18.2 Package에 포함하지 않는 생성·Cache 파일

다음 항목은 Runtime이 필요 시 다시 만들 수 있는 생성물 또는 개발 Cache이므로 **배포 ZIP과 Git 추적 대상에서 재귀적으로 제외**한다.

- `__pycache__/`
- `*.pyc`
- `*.pyo`
- `.pytest_cache/`
- `.mypy_cache/`
- `.ruff_cache/`
- Python/도구가 생성한 기타 명백한 일회성 Cache
- `.DS_Store`, `Thumbs.db` 등 OS 임시 메타데이터

비밀번호, Token, 실제 로그인 Profile, 개인 PC 경로를 포함한 민감정보는 A9에 따라 별도로 배제한다.

### A18.3 Build/Test 후 Final Clean 단계

Compile, Import, Self-Test 과정에서 `__pycache__` 또는 `*.pyc`가 생성될 수 있으므로 최종 배포는 다음 순서를 따른다.

```text
구현/수정
  ↓
Compile / Test / Regression
  ↓
배포 Staging 구성
  ↓
Cache·임시파일 재귀 제거
  ↓
Requirements / Governance / Manifest 최종 반영
  ↓
금지 항목 0건 검사
  ↓
ZIP 생성
  ↓
ZIP 내부 금지 항목 0건 + Unicode 경로 + 필수 파일 검증
```

최종 ZIP을 만든 뒤 검증을 위해 프로그램을 다시 실행하여 Cache가 생성되었다면, 그 Staging을 그대로 재압축하지 않고 다시 Clean 단계를 거친다.

### A18.4 Git Ignore 기본선

Automation Manager 계열 Git Repository는 최소한 다음 패턴을 `.gitignore`에 유지한다.

```gitignore
__pycache__/
*.py[cod]
.pytest_cache/
.mypy_cache/
.ruff_cache/
.DS_Store
Thumbs.db
```

프로젝트 고유 산출물을 추가 제외할 때는 승인 Requirements 또는 활성 Project Profile의 배포 규칙과 충돌하지 않는지 확인한다.

승인된 관리 Target의 필수 Release artifact가 사용자 PC의 global Git ignore 또는 repository-local ignore에 의해 숨겨지는 경우, 해당 Target의 승인된 파일명/확장자/버전 규칙을 만족하는 파일에 한해서만 명시적으로 추적할 수 있다. 이 예외는 Target별 opt-in이어야 하며 `__pycache__`, `*.pyc` 같은 Cache 또는 임의 하위 파일을 광범위하게 `git add -f`하는 근거로 사용하지 않는다.

### A18.5 Manifest와 Requirements 동기화

- Package Manifest는 실제 최종 ZIP에 들어가는 Clean Staging을 기준으로 생성한다.
- Manifest에 금지 Cache 파일이 기록되어 있으면 패키지를 승인하지 않는다.
- Governance 변경 시 Document Version과 SHA-256을 Manifest에 갱신한다.
- Requirements가 변경된 프로젝트는 최신 승인 Requirements를 함께 동봉한다.
- 패키지 생성/명명/청결성 정책 변경은 Requirements의 Packaging/Distribution 항목과 본 Governance에 함께 추적한다.

# Part B. Project ID 선택과 통합 문서 운영 규칙

## B1. Project ID 원칙

- Project ID는 영문 대문자 중심의 짧고 의미 있는 고유 식별자를 사용한다.
- 한번 활성화한 Project ID는 프로젝트명이 바뀌어도 재사용하거나 임의 변경하지 않는다.
- 단순 순번보다 `PF`, `SE`, `WMA`, `BR`, `RTC`와 같이 의미를 식별할 수 있는 약어를 권장한다.
- Scenario, Requirement, Architecture, Test ID에 Project ID를 사용할지는 프로젝트 프로필에서 정한다.

## B2. 활성 프로젝트 식별 순서

AI는 다음 순서로 현재 Project ID를 식별한다.

1. 사용자가 현재 요청에서 명시한 Project ID 또는 프로젝트명
2. `package_manifest.json` 등 Manifest의 `project_id`
3. 승인 Requirements의 프로젝트 식별 정보
4. 패키지명과 프로젝트별 고유 파일 Signature
5. 위 근거가 하나로 일치하지 않으면 사용자 확인

폴더명 하나만으로 Project ID를 확정하지 않는다.

## B3. 적용 격리

- 활성 Project ID의 프로필만 적용한다.
- 비활성 프로젝트 프로필은 현재 작업의 근거로 사용하지 않는다.
- 공통 헌법과 활성 프로필이 충돌하면 권한 영역을 판단하고, 해결되지 않으면 사용자에게 확인한다.
- 두 프로젝트의 파일이 한 작업공간에 섞여 있으면 각각의 변경 대상을 분리하고 교차 수정하지 않는다.

## B4. 신규 프로젝트 등록

등록되지 않은 신규 프로젝트를 작업하는 경우 AI는 다음 절차를 따른다.

```text
신규 프로젝트 확인
        ↓
의미 있는 Project ID 제안
        ↓
Part D 양식으로 DRAFT 프로필 생성
        ↓
파일명·요구사항·환경·배포·검증 규칙 작성
        ↓
사용자 검토
        ↓
승인 후 ACTIVE 전환
```

- 사용자가 신규 프로젝트 등록을 명시했거나 신규 프로젝트임이 명백할 때만 프로필을 생성한다.
- 단순히 알 수 없는 폴더나 파일을 발견했다는 이유로 자동 등록하지 않는다.
- DRAFT 상태에서 확정되지 않은 값은 `TBD`로 남긴다.
- DRAFT 규칙을 근거로 비가역적 변경이나 외부 배포를 수행하지 않는다.

## B5. 프로젝트 프로필 상태

| 상태 | 의미 |
|---|---|
| `DRAFT` | 생성·복원 중이며 사용자 승인이 필요함 |
| `ACTIVE` | 현재 작업에 적용 가능한 승인 프로필 |
| `INACTIVE` | 일시 중단되었으나 재개 가능함 |
| `ARCHIVED` | 종료·폐기되었으며 신규 개발에 적용하지 않음 |

## B6. 통합 문서 갱신 범위

- 공통 원칙을 변경하면 모든 프로젝트 영향도를 확인한다.
- 프로젝트 고유 변경은 해당 프로필만 수정한다.
- 한 프로젝트의 변경 때문에 다른 프로젝트의 현재 기준을 임의로 갱신하지 않는다.
- 프로젝트의 최신 Revision과 다음 Requirement ID 같은 가변 정보는 Requirements 또는 Manifest를 우선한다.
- 프로필의 현재 기준 정보가 실제 패키지와 다르면 실제 파일을 확인한 뒤 프로필을 갱신한다.

## B7. 내부 원본과 외부 배포

본 통합 문서에는 여러 프로젝트의 내부 규칙이 포함될 수 있다.

- 개인·사내 작업용 원본에는 등록된 프로젝트 프로필 전체를 유지할 수 있다.
- 고객·외부 전달 패키지에는 다른 프로젝트명, 내부 경로, 보안 규칙과 기준정보가 노출되지 않도록 한다.
- 외부 배포가 필요한 경우 `Part A + 활성 프로젝트 프로필`만 포함한 Project-resolved 사본 생성을 우선한다.
- 외부 배포용 사본도 원본의 Document Version과 Project ID를 표시한다.

## B8. 요구사항 이중 계층 표준

프로젝트 프로필에서 `DUAL_LAYER_XLSX_V1`을 사용하는 경우 다음 구조를 적용한다.

### 1층 — 사람용 사용자 시나리오

기본 시트명: `사용자 시나리오`

기본 열:

1. 시나리오 ID
2. 시나리오명
3. 사용자 목적·상황
4. 사용자 시나리오
5. 기대 결과
6. 관련 FR ID
7. 현황

기본 현황 값:

- `일치`
- `검토중`
- `불일치`
- `미확인`
- `폐기`

### 2층 — AI용 상세 계층

- `AI_01_문서목적·운영규칙`
- `AI_02_요구사항목록`
- `AI_03_판정기준`
- `AI_04_실패상황`
- `AI_05_변경금지조건`
- `AI_06_디버깅체크`
- `AI_07_회귀테스트`
- `AI_08_코드근거`
- `AI_09_AI작업규칙`
- `AI_10_요구사항충돌검토`

### 공통 추적성 규칙

- 하나의 시나리오는 여러 상세 Requirement와 연결할 수 있다.
- 모든 유효 Requirement는 승인된 상위 시나리오에 연결한다.
- 사용자 시나리오의 관련 ID와 상세 요구사항의 상위 시나리오 ID는 서로 일치해야 한다.
- AI는 상위 시나리오와 연결된 상세 Requirement를 함께 읽는다.
- 역복원한 시나리오는 사람의 승인 전까지 `검토중`으로 유지한다.
- 시나리오를 복원·수정했다는 이유만으로 기존 상세 Requirement를 자동 변경하지 않는다.

---

# Part C. Project Registry

## C1. `[PF]` PassFail / Oracle Checker

### C1.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `PF` |
| Project Name | PassFail / Oracle Checker |
| Status | `ACTIVE` |
| Profile Version | v1.2 |
| Requirements Mode | `DUAL_LAYER_XLSX_V1` |
| Requirements Pattern | `PassFail_Requirements_Management_revXX.xlsx` |
| Package Pattern | `PassFail_YYMMDD_N.zip` |
| Primary Environment | Python/PYW, Windows, CANoe/CANalyzer COM, CAPL, DBC |

### C1.2 식별 Signature

다음 근거가 서로 일치할 때 `PF`로 식별한다.

- 패키지명 `PassFail_*.zip`
- 요구사항 파일 `PassFail_Requirements_Management_rev*.xlsx`
- Oracle Checker GUI/Core 모듈 또는 PassFail 고유 실행 파일
- Requirements 또는 Manifest의 Project ID `PF`

### C1.3 기능 변경 자동 절차

```text
통합 Governance 확인
        ↓
Project ID PF 확정
        ↓
최신 Requirements 확인
        ↓
관련 사용자 시나리오·FR·판정·실패상황 확인
        ↓
LOCK·안전 Gate·영향 Module 확인
        ↓
충돌·중복·회귀 영향 검토
        ↓
Requirements 갱신
        ↓
코드 최소 변경
        ↓
변경 기능 Test + 관련 Regression
        ↓
코드근거·회귀테스트·충돌검토 갱신
        ↓
패키지 생성 및 무결성 확인
```

코드만 수정하거나 Excel만 수정한 상태를 완료로 처리하지 않는다.

### C1.4 Package Naming

`PassFail_YYMMDD_N.zip`

1. `YYMMDD`는 Asia/Seoul 기준 실제 패키지 생성일이다.
2. `N`은 같은 날짜에 생성한 PassFail 전체 패키지 순번이다.
3. 기존 같은 날짜의 가장 큰 N 다음 번호를 사용한다.
4. 날짜가 바뀌면 `_1`부터 시작한다.
5. 기존 동일 이름 패키지를 조용히 덮어쓰지 않는다.

### C1.5 Baseline Revision

PassFail은 S/W Revision과 Requirements Document Revision을 하나의 Baseline Revision으로 통일한다.

```text
Baseline Revision = S/W rev = Requirements rev
Package Sequence  = PassFail_YYMMDD_N의 N
```

- 기능 또는 승인 Requirements 변경 시 Baseline Revision을 증가시킨다.
- Governance 문서만 변경한 경우 코드 기능을 바꾸지 않고 Revision rollover로 동일 Baseline을 유지할 수 있다.
- Rollover 시 모듈 파일명, Import, 로그, Template과 안내의 현재 Baseline 표기를 동기화한다.
- 과거 Revision과 요구사항 근거 번호는 역사 정보이므로 재작성하지 않는다.
- ZIP 순번은 Baseline Revision과 독립적이다.

### C1.6 배포 구성

필수:

- `00_AI_DEVELOPMENT_GOVERNANCE.md`
- 최신 `PassFail_Requirements_Management_revXX.xlsx`
- 해당 Baseline의 Python/PYW 모듈
- 필요한 CAPL Template
- 해당 Revision 안내문 또는 Manifest

기본 제외:

- 회사·고객 원본 DBC
- 실제 Runtime 로그와 현장 사용자 데이터
- `PF_Stimulus_Runtime` 사용자 데이터
- Python cache와 임시 파일
- 인증정보와 개인 PC 고유 설정
- 외부 전달 시 다른 Project ID의 내부 프로필

### C1.7 안정 기능과 실험 기능의 경계

`테스트용 P/F 차량 테스트 (1안)`은 실험 트랙이다.

- `oracle_checker_gui_replacement_revXX.py`
- `oracle_checker_replacement_revXX.py`

두 모듈을 제거해도 기본 PassFail이 ImportError로 종료되지 않아야 한다.

```text
1안 모듈 삭제 → 1안 탭만 제거 → 기존 기본 탭·기능 정상
```

Replacement 모듈을 기본 기능의 필수 Dependency로 만들지 않는다.

### C1.8 차량 Stimulus 안전 규칙

- Safety-critical TC 자동 Stimulus BLOCK 유지
- Body-comfort TC 경고·승인 정책 유지
- CRC, Alive, E2E 알고리즘을 근거 없이 추측하여 자동 계산하지 않음
- 반복 송신을 Source Replacement로 과장하지 않음
- DBC-Bridge Identity Mismatch Hard BLOCK 유지
- 사전 Runtime Bridge 생성은 실제 CAN 출력 없이 수행
- 사용자가 요청하지 않은 안전 Gate 완화 금지

상세 판정·시간·대상 목록은 최신 Requirements를 따른다.

### C1.9 검증 상태

다음을 별도 상태로 구분한다.

- Python Compile / Import
- 자동·모의 회귀
- CANoe/CANalyzer 환경 확인
- 실제 차량 현장 확인

`AI_07_회귀테스트`에 미수행 또는 부분확인이 있으면 전체 현장 검증 PASS로 표현하지 않는다.

### C1.10 현재 참고 기준

> 아래 값은 프로필 식별을 위한 참고이며, 실제 최신 값은 패키지의 Requirements와 Manifest를 우선한다.

- 기준일: 2026-09-06
- Baseline: `rev87`
- 기준 배포: `PassFail_260906_2.zip`
- 요구사항 구조: 사용자 시나리오 + AI_01~AI_10
- 다음 신규 FR 참고값: `FR-160`

## C2. `[SE]` Signal Export V2

### C2.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `SE` |
| Project Name | Signal Export V2 |
| Status | `ACTIVE` |
| Profile Version | v1.2 |
| Requirements Mode | `DUAL_LAYER_XLSX_V1` |
| Requirements Pattern | `SignalAuto_Requirements_Management_revXX_V2.xlsx` |
| Package Pattern | `Signal_Export_V2_YYMMDD_N.zip` |
| Primary Environment | Python/PYW, Windows, BLF/ASC, DBC, Excel, 선택적 외부 AI API |

### C2.2 식별 Signature

다음 근거가 서로 일치할 때 `SE`로 식별한다.

- 패키지명 `Signal_Export_V2_*.zip`
- 요구사항 파일 `SignalAuto_Requirements_Management_rev*_V2.xlsx`
- `Signal_Export_V2_Main`, GUI, Step1~7 모듈
- Requirements 또는 Manifest의 Project ID `SE`

### C2.3 기능 변경 자동 절차

```text
통합 Governance 확인
        ↓
Project ID SE 확정
        ↓
최신 Requirements 확인
        ↓
관련 사용자 시나리오·FR·판정·실패상황 확인
        ↓
LOCK·영향 Step·Interface·Data 확인
        ↓
충돌·중복·회귀 영향 검토
        ↓
Requirements 갱신
        ↓
코드 최소 변경
        ↓
변경 기능 Test + 관련 Regression
        ↓
코드근거·회귀테스트·충돌검토 갱신
        ↓
패키지 생성 및 무결성 확인
```

코드만 수정하거나 Excel만 수정한 상태를 완료로 처리하지 않는다.

### C2.4 Package Naming

`Signal_Export_V2_YYMMDD_N.zip`

1. `YYMMDD`는 Asia/Seoul 기준 실제 패키지 생성일이다.
2. `N`은 같은 날짜에 생성한 Signal Export V2 전체 ZIP의 순번이다.
3. 같은 날짜에는 기존 가장 큰 N 다음 번호를 사용한다.
4. 날짜가 바뀌면 `_1`부터 시작한다.
5. 기존 동일 이름 패키지를 조용히 덮어쓰지 않는다.

### C2.5 Revision 정책

다음은 서로 다른 축으로 관리한다.

- Requirements Document Revision
- Python/PYW Module별 Revision
- ZIP Package Sequence

- Requirements가 변경되면 문서 Revision을 증가시킨다.
- 코드가 변경된 Module만 Module Revision을 증가시킨다.
- 문서·Governance만 변경한 경우 Python/PYW Revision을 올리지 않는다.
- ZIP 순번은 문서·코드 Revision과 독립적이다.

### C2.6 배포 구성

필수:

- `00_AI_DEVELOPMENT_GOVERNANCE.md`
- `00_PACKAGE_NAMING_RULE.txt`
- `package_manifest.json`
- 최신 `SignalAuto_Requirements_Management_revXX_V2.xlsx`
- 현재 GUI, Main, Report, Excel Compat, Step1~7, GLOBAL Step3 모듈
- 해당 Revision 안내문

기본 제외:

- 회사·고객 원본 DBC
- 실제 BLF, ASC, TestCase와 사용자 결과 데이터
- API Key, 인증정보와 개인 PC 설정
- Python cache와 임시 파일
- 외부 전달 시 다른 Project ID의 내부 프로필

### C2.7 Pipeline 경계

| Module | Responsibility |
|---|---|
| GUI | 사용자 설정, 상태, 로그, 실행 제어 |
| Main | `PipelineConfig` 최종 소유, 최신 Module 선택, 단계 실행 |
| Step1 | BLF→ASC 변환과 파일명 정리 |
| Step2 | DBC 기반 Message Group 생성과 선택적 AI 보강 |
| Step3 | ASC 디코딩과 Message·Signal 변화 추출 |
| Step4 | TestCase 매핑과 AI 문의 생성 |
| Step5 | AI 호출·재시도·응답 정규화 |
| Step6 | 선정 신호의 상세 변화 복원 |
| Step7 | Input·Output·Excluded 분류 |
| GLOBAL Step3 | 전체 ASC 디코딩과 변경 요약 |
| Report | 산출물과 오류 보고서 생성 |
| Excel Compat | XLS/XLSX와 보호 문서 입력 처리 |

각 Step의 `run(config)` 진입점과 Main의 `PipelineConfig` 중심 전달 구조를 유지한다.

### C2.8 Category 규칙

- 일반 Category는 12개를 유지한다.
- CONNECT 정식 Prefix는 `12. Connect UX 사양서 기반 TC 검토 초안`이다.
- CONNECT Keyword는 `커넥트`, `UX`, `Connect`, `connect`를 사용한다.
- `connect`는 CONNECT, `connected`는 BLUELINK_CCS로 구분한다.
- GUI, Main, Step1, TestCase 시트 선택의 Category 정의를 서로 다르게 하드코딩하지 않는다.
- 기존 Sender Include 56개, Message-name Include 36개와 TP/DEV Exclude 규칙을 근거 없이 축소·완화하지 않는다.

### C2.9 CAN·DBC 매핑

- 활성 CAN1~CAN4 각각 정확히 하나의 DBC를 사용한다.
- 논리 CAN과 DBC 관계를 관리하며 VN1640A 물리 Channel 번호를 자동 추정하지 않는다.
- 자동 감지는 파일명 근거만 사용한다.
- 모든 활성 CAN 매핑이 하나로 확정될 때만 전체를 일괄 적용한다.
- 누락·중복·모호함이 있으면 일부만 적용하지 않고 기존 설정 전체를 유지한다.
- DBC 내용 유사도, Message 포함 여부 또는 물리 CH→CAN 추측으로 매핑하지 않는다.

### C2.10 Step2 AI 보강

- 기본값은 OFF이다.
- 선택 상태를 다음 실행에 자동 저장하지 않는다.
- AI 후보는 규칙 기반 결과에 추가만 한다.
- Hard Exclude와 기존 제외 정책은 AI보다 우선한다.
- API 실패·응답 오류·정규화 실패 시 규칙 기반 결과로 Fallback한다.
- AI가 기존 Rule 후보를 삭제하거나 제외 규칙을 우회하지 못하게 한다.

### C2.11 파일·데이터·비밀정보

- 원본 BLF, ASC, DBC, TestCase를 직접 수정하지 않는다.
- 산출물은 정의된 결과 폴더에 별도 생성한다.
- 미해결 Error·Warning을 성공처럼 숨기거나 임의 삭제하지 않는다.
- 성공한 동일 Case의 Stale Error만 승인 Requirement에 따라 정리한다.
- API Key를 로그, 설정 미리보기, Error, Report에 평문으로 출력하지 않는다.
- 보호·암호화 Excel을 우회 해제하거나 손상시키지 않는다.

### C2.12 검증 상태

다음을 별도 상태로 구분한다.

- Python Compile
- 정적·합성·함수 확인
- 실제 DBC·BLF·ASC·TestCase 회귀
- 외부 AI API 호출 확인
- 실제 사용자 환경 확인

Compile 또는 정적 감사 PASS를 전체 기능 검증 PASS로 표현하지 않는다.

### C2.13 현재 참고 기준

> 아래 값은 프로필 식별을 위한 참고이며, 실제 최신 값은 패키지의 Requirements와 Manifest를 우선한다.

- 기준일: 2026-09-07
- Requirements: `SignalAuto_Requirements_Management_rev59_V2.xlsx`
- 기준 배포: `Signal_Export_V2_260907_1.zip`
- 코드 기준: rev57 패키지의 Python/PYW 12개 파일과 동일
- 요구사항 구조: 사용자 시나리오 + AI_01~AI_10
- 사용자 시나리오: 24개, `검토중`
- 활성 FR: 142개
- 다음 신규 FR 참고값: `FR-152`
- 기능 논리 충돌: 0건

---

## C3. `[AM]` Automation Manager

### C3.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `AM` |
| Project Name | Automation Manager |
| Status | `ACTIVE` |
| Profile Version | v1.8 |
| Requirements Mode | `CUSTOM` |
| Requirements Pattern | `Automation_Manager_Requirements_YYMMDD_N.xlsx` |
| Package Pattern | `Automation_Manager_YYMMDD_N.zip` |
| Primary Environment | Python/PYW, Windows, Git, BoardRepo |

### C3.2 핵심 운영 규칙

- Automation Manager는 Git Manager와 BoardRepo를 한 GUI에서 제공하는 통합 Launcher/Core이다.
- 자체를 별도 관리 Target으로 중복 등록하지 않는다.
- 공통 Target 정의는 `program_catalog.json`을 기준으로 한다.
- Git Manager와 BoardRepo 엔진의 책임 경계를 유지하고 상호 재귀 호출을 만들지 않는다.
- 통합 Release에는 본 Governance와 최신 Automation/Git/BoardRepo Requirements를 포함한다.

### C3.3 현재 관리 Target 기준

1. PassFail
2. SignalExport
3. WeeklyReport
4. Ext
5. Git Manager
6. BoardRepo
7. Requirement Studio Manual
8. Requirement Studio Runtime / Tools
9. 학습

7·8의 그룹웨어 Board URL은 사용자 확인으로 확정되었다.

- Target 7 Requirement Studio Manual: `https://gw.suresofttech.com/app/community/130/board/394`
- Target 8 Requirement Studio Runtime / Tools: `https://gw.suresofttech.com/app/community/130/board/395`
- Target 9 학습: `AI 스냅샷_학습` / `https://gw.suresofttech.com/app/community/130/board/400`으로 사용자 확인 완료되어 ACTIVE 라우팅으로 사용한다.

### C3.4 통합 GUI 상태 표시 및 시작 동작

- Automation Manager 시작 시 Git Manager/BoardRepo의 자동 초기 점검 때문에 `작업 중` 또는 오류 Modal을 즉시 표시하지 않는다. 자동 초기 점검의 Busy/오류 상태는 로그와 상단 상태 표시로 전달한다.
- Git Manager Header의 Compact Status는 공용 Operation Lock 상태를 반영한다.
  - 주황색 `작업 중`: Git Manager 또는 BoardRepo의 공용 작업이 실행 중
  - 초록색 `사용 가능`: 공용 작업이 없고 선택된 Git Repository가 정상 사용 가능
  - 회색 `사용 불가`: Repository 미연결/비정상 등으로 Git Manager 작업을 시작할 수 없음
- 상태 표시는 요약 문구만 제공하며 별도 설명 영역을 추가하지 않는다. 상세 원인은 기존 로그와 Repository 정보에서 확인한다.
- 사용자가 직접 실행한 작업에서 필요한 확인/경고/오류 Modal은 기존 안전 정책을 유지한다. 본 규칙은 프로그램 시작 시 자동 점검에 의한 불필요한 Modal 억제에 한정한다.

### C3.5 BoardRepo 작업 결과 Modal

- Automation Manager에 통합된 BoardRepo의 업로드/다운로드 완료 결과는 긴 일반 `messagebox` 문자열 대신 한눈에 판독 가능한 전용 결과 Modal을 사용한다.
- 결과 Modal 상단에는 다음 4개 요약 카드만 고정 배치한다.
  - `미선택`: 현재 작업에서 체크되지 않은 Target 수
  - `확인 필요`: 자동 처리가 완료되지 않아 사용자 확인이 필요한 파일/항목 수
  - `실행 완료`: 실제 업로드/다운로드 또는 정상 최신 판정 등 완료 건수
  - `오류`: 작업 실패 건수
- Target 요약 목록은 `program_catalog.json`의 현재 관리 순서를 그대로 사용하며 현재 기준 1~9 Target을 표시한다.
- 확인 필요/오류가 존재하면 파일명과 사유를 표 형태의 상세 영역에 표시한다. 긴 사유는 줄바꿈 가능한 형태로 표시하고 상세 로그 자체는 기존 BoardRepo 로그에 계속 남긴다.
- 기존 원격 중복검사·SHA 판정·다운로드 상태 코드의 의미를 UI 편의를 위해 변경하지 않는다. 결과 Modal은 기존 판정 결과를 표현하는 Presentation 계층이다.
- 정상 완료, 중복 Skip, 확인 필요, 실패 등 모든 일반 배치 종료 시 동일한 Result Modal 계열을 사용한다. 공통 세션 실패도 가능한 범위에서 동일 Modal로 요약한다.
- 작업 완료 후 공용 Operation Lock을 먼저 해제한 다음 결과 Modal을 표시하여 Modal을 보고 있는 동안 다른 엔진의 사용 가능 상태가 불필요하게 `작업 중`으로 남지 않게 한다.
- 사용자가 직접 실행한 작업의 사전 안전 확인/설정/환경 오류 Modal은 본 Result Modal 정책의 적용 대상이 아니며 기존 안전 정책을 유지한다.

### C3.6 BoardRepo 그룹웨어 로그인 정보 갱신

- BoardRepo가 저장된 그룹웨어 자격증명으로 자동 로그인을 시도한 뒤 명시적인 계정정보 오류가 표시되거나 일정 시간 로그인 화면이 유지되면 `비밀번호 변경`으로 단정하지 않고 `로그인 정보 확인 필요` 상태로 전환한다.
- 저장된 ID가 존재하면 갱신 UI에는 ID를 읽기 전용으로 표시하고 사용자는 새 비밀번호만 입력할 수 있어야 한다.
- 새 비밀번호는 Windows 운영체제 자격 증명 저장소(keyring)에만 덮어써 저장하며 source/config/Requirements/Governance/log/ZIP에 평문 비밀번호를 기록하지 않는다.
- 자격증명 갱신에 성공하면 중단되었던 업로드 사전 중복검사 또는 다운로드 동기화를 자동 재시도한다. 재시도 횟수에는 상한을 두어 잘못된 비밀번호 반복 입력으로 무한 루프하지 않게 한다.
- CAPTCHA/MFA/보안문자 징후가 있으면 자격증명 오류로 오판하지 않고 기존 수동 인증 대기 정책을 유지한다.
- 사용자가 취소하거나 재시도 한도를 초과하면 원래 작업을 안전하게 중지하고 원인을 로그/상태에 남긴다.

### C3.7 Git 복구 가시성 및 Git 미설치 대응

- `현재 폴더 Git 연결/복구`를 실행하면 실제 Git 복구 작업을 시작하기 전에 Git 실행 파일 존재 여부와 `git --version` 응답을 먼저 확인한다.
- Git이 설치되어 있지 않거나 PATH에서 찾을 수 없으면 Git Repository 초기화/원격 연결을 시도하지 않고 즉시 `Git 미설치` 상태로 종료한다.
- Git 미설치/실행 실패는 `작업 중` 상태를 남겨두지 않으며 사용자에게 `Git for Windows 설치 후 git --version 확인` 안내를 제공한다.
- Git 복구 진행 단계는 다음 5단계 기준으로 로그와 상단 상태에 표시한다.
  1. Git 설치 확인
  2. 로컬 Repository 초기화
  3. 원격 Git 연결 / 인증 확인
  4. 기존 Git 이력 연결
  5. 관리 파일 복구 / 상태 확인
- Git Manager Header 상태 표시는 기존 색상 의미를 유지하되 가로·세로 크기를 확대하고 2줄 표시를 사용하여 `작업 중`뿐 아니라 현재 단계/원인을 함께 보여준다.
- Worker Thread는 Tk API를 직접 호출하지 않고 Thread-safe UI Queue로 진행/완료/오류 이벤트를 Main Thread에 전달하여 `busy`와 공용 Operation Lock이 반드시 해제되도록 한다.

### C3.8 Git for Windows 자동 설치 및 복구 연계

- Git 미설치 상태에서는 `Git 자동 설치` 버튼을 제공하고, 사용자가 승인하면 WinGet을 이용해 `Git.Git` 패키지를 설치할 수 있다.
- 자동 설치 명령의 기준은 `winget install --id Git.Git -e --source winget`이며 자동화 시 package/source agreement 동의 옵션을 사용할 수 있다.
- 자동 설치는 Windows UAC, 회사 보안 정책, 관리자 권한 제한을 우회하지 않는다. 필요한 시스템 확인창은 사용자가 직접 승인한다.
- WinGet이 없거나 실행할 수 없으면 임의의 다른 패키지 관리자/다운로드 우회 경로를 사용하지 않고 Git 공식 Windows 설치 페이지로 수동 설치를 안내한다.
- 설치 진행은 `WinGet 확인 → Git 설치 → 설치 결과 확인 → git --version 검증`의 4단계로 Header와 로그에 표시한다.
- WinGet 설치 후 현재 프로세스 PATH가 갱신되지 않을 수 있으므로 `Program Files\Git\cmd`, `LOCALAPPDATA\Programs\Git\cmd` 등 승인된 Git for Windows 설치 위치에서 `git.exe`를 다시 탐색해 현재 프로세스에서 즉시 사용할 수 있게 한다.
- Git 설치 검증 성공 후 사용자가 처음 요청했던 `현재 폴더 Git 연결/복구`를 자동 재개한다. 이 자동 재개는 최초 `Git 자동 설치` 확인창에서 설치와 복구를 함께 승인한 경우에 한해 두 번째 복구 확인창을 생략할 수 있다.
- Git 설치 실패, WinGet 미존재, UAC 거부, 회사 정책 차단 등에서는 Repository 초기화나 원격 fetch를 시작하지 않고 안전 종료한다.

### C3.9 새 PC Git 사용자 정보 설정 안내

- Windows 포맷/신규 PC처럼 Git 전역 설정이 초기화된 환경에서는 Repository 복구 성공과 `user.name` / `user.email` 설정 유무를 별도 상태로 취급한다.
- Git Repository가 정상이어도 Git 사용자 정보가 없으면 Header는 `설정 필요 / Git 사용자 정보`를 표시하여 Commit + Push 전에 필요한 조치를 명확히 보여준다.
- `Git 사용자 설정/갱신`은 기존 설정값이 있으면 초기값으로 보여주고 사용자가 명시적으로 입력·확정한 값을 `--global` 설정으로 저장한다. 사용자 이름/이메일을 AI가 임의 추정해 자동 저장하지 않는다.
- Commit + Push를 실행했는데 Git 사용자 정보가 없으면 단순 경고 후 종료하지 않고 사용자가 원할 경우 즉시 설정 UI로 연결하고, 설정 성공 후 원래 Push 흐름을 계속 진행할 수 있다.
- Pull, 상태 확인, 복구 등 작성자 정보가 필요하지 않은 작업까지 Git 사용자 정보 미설정을 이유로 차단하지 않는다.


## C4. `[GM]` Git Manager

### C4.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `GM` |
| Project Name | Git Manager |
| Status | `ACTIVE` |
| Profile Version | v1.4 |
| Requirements Mode | `CUSTOM` |
| Requirements Pattern | `GitManager_Requirements_YYMMDD_N.xlsx` |
| Package Pattern | `GitManager_YYMMDD_N.zip` |
| Primary Environment | Python/PYW, Windows, Git |

### C4.2 변경금지·안전 경계

- 기본 Branch는 승인된 Repository 설정의 `main`을 사용한다.
- Force Push, 자동 Conflict 해결, 파괴적 `reset --hard`/`clean`을 자동 수행하지 않는다.
- 현재 폴더 Git 연결/복구는 로컬 Working Tree를 우선 보존한다.
- 최신 Automation Manager ZIP만으로 self-bootstrap 복구가 가능해야 하며 Clone을 필수 단계로 되돌리지 않는다.
- Target 추가/순서 변경 시 숫자만으로 의미를 추정하지 않고 catalog key/alias를 사용한다.

### C4.3 복구 단계 표시 및 실패 종료 보장

- Git Manager의 Self-Bootstrap 복구는 Git 설치 확인을 선행하고 Git 실행 불가 상태에서는 `.git` 생성이나 원격 fetch를 시작하지 않는다.
- 복구 중에는 단계별 진행 상황을 Header의 확대 상태 박스와 Git Manager 로그에 동시에 표시한다.
- 복구 실패 시 기존 로컬 파일 보존/신규 `.git` rollback 정책을 유지하며, Worker → Main Thread UI Queue를 통해 GUI의 `작업 중` 상태와 Operation Lock도 반드시 해제한다.
- Git 설치 여부 확인은 OS PATH의 Git 실행 파일과 `git --version` 응답을 기준으로 하며 GitHub 인증 여부와 혼동하지 않는다.

### C4.4 Git 자동 설치 안전 규칙

- Git 자동 설치는 Windows + WinGet 사용 가능 환경에서만 수행한다.
- 설치 대상은 exact package ID `Git.Git`으로 제한하며 다른 Git 유사 패키지를 자동 선택하지 않는다.
- 설치 완료 판정은 WinGet 종료코드만으로 확정하지 않고 실제 `git.exe` 재탐색과 `git --version` 성공을 함께 확인한다.
- 설치 중 UAC/보안 정책을 우회하거나 관리자 권한을 강제로 획득하지 않는다.
- 설치 후 기존 Self-Bootstrap 복구의 비파괴 정책, 원격 최신본 보호, 자동 Push 금지 정책을 그대로 적용한다.

### C4.5 Git 사용자 정보 초기화 대응

- `git config user.name` / `user.email`이 비어 있는 상태는 Repository 고장이나 GitHub 인증 실패와 구분한다.
- Git 사용자 정보가 없으면 Commit/Push만 제한하고 상태 확인·Pull·Self-Bootstrap 복구는 계속 허용한다.
- Push 직전에 사용자 정보가 없으면 `Git 사용자 설정/갱신`으로 연결할 수 있으며 저장 성공 시 사용자가 다시 Push 버튼을 누르지 않아도 원래 Push 절차를 이어갈 수 있다.
- 사용자 정보는 사용자가 직접 확인·입력한 값을 사용하며 원격 Commit 작성자나 계정명을 근거로 자동 추정·저장하지 않는다.


## C5. `[BR]` BoardRepo

### C5.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `BR` |
| Project Name | BoardRepo |
| Status | `ACTIVE` |
| Profile Version | v1.5 |
| Requirements Mode | `CUSTOM` |
| Requirements Pattern | `BoardRepo_Requirements_v*.xlsx` |
| Package Pattern | `BoardRepo_YYMMDD_N.zip` |
| Primary Environment | Python/PYW, Playwright, Windows, 그룹웨어 게시판 |

### C5.2 핵심 운영 규칙

- Target/Board/폴더/Release 규칙은 `program_catalog.json`을 단일 기준선으로 사용한다.
- 기존 Chromium 경로를 1순위로 보존하고 필요한 경우 설치된 Microsoft Edge를 fallback으로 사용한다.
- 외부 Browser 다운로드와 Online pip fallback은 승인 없이 자동 활성화하지 않는다.
- 게시판 상세 URL 진입과 본문·첨부 Ready를 구분하여 Polling한다.
- Ext는 파일명+SHA-256 정책을 유지한다.
- 하위 `01. old` 등은 versioned target의 최신 Release 탐색 대상에 포함하지 않는다.
- BoardRepo는 Git 복구 엔진을 직접 실행하지 않는다.
- Target 9 `학습`은 Ext와 동일한 `file_hash` 계열 일반파일 Inbox로 취급한다. BoardRepo는 `9. 학습` 바로 아래의 현재 자료만 자동 게시 후보로 보고 `01. old` 등 하위 폴더는 재귀 업로드하지 않는다.
- Target 9의 실제 그룹웨어 Board URL이 확정되기 전에는 해당 Target만 `게시판 URL 설정 필요`로 안전하게 처리하고 다른 Target의 동작을 방해하지 않는다.

### C5.3 Governance Carry-Forward

- BoardRepo 및 Automation Manager Release에는 `00_AI_DEVELOPMENT_GOVERNANCE.md`를 포함한다.
- 다음 수정은 동봉된 Governance와 최신 승인 BoardRepo Requirements를 먼저 읽고 영향·충돌·회귀를 검토한다.
- Governance가 패키지에 있으므로 사용자가 동일 MD를 매 Release마다 별도로 다시 첨부하도록 요구하지 않는다.

### C5.4 결과 표시 규칙

- 업로드/다운로드 배치 결과는 공통 `result_dialog.py` Presentation 계층을 통해 표시한다.
- 기존 `boardrepo.py`와 통합 `boardrepo_tab.py`가 동일한 결과 모델/Modal을 사용하여 standalone과 Automation Manager 간 결과 표현이 달라지지 않게 한다.
- 결과 Modal은 판정 로직을 재계산하지 않고 이미 생성된 success/duplicate/conflict/error/download 상태를 집계하여 보여준다.
- 상세 파일이 많아도 화면 높이를 무한히 늘리지 않고 Scroll 가능한 상세 영역을 사용한다.
- Raw 문자열 요약의 literal `\n`을 사용자 결과 UI에 직접 노출하지 않는다.

### C5.5 그룹웨어 자격증명 변경 대응

- BoardRepo는 `CredentialRefreshRequired`와 같은 명시적 인증 갱신 신호를 Presentation 계층으로 전달할 수 있어야 하며 일반 Browser/Network 오류와 구분한다.
- 저장된 ID/PW 제출 후 `credential_failure_text_candidates`가 확인되거나, CAPTCHA/MFA 징후 없이 로그인 화면이 설정 시간 이상 유지될 때 자격증명 갱신 후보로 판단한다. 이 판정은 `비밀번호가 바뀌었다`는 확정 판정이 아니다.
- 갱신 UI는 저장된 ID를 유지하고 비밀번호만 교체할 수 있게 하며 저장 위치는 OS keyring으로 한정한다. 비밀번호를 로그나 예외 문자열에 포함하지 않는다.
- 업로드는 원격 중복검사 단계, 다운로드는 원격 동기화 세션 단계에서 로그인 갱신 후 같은 작업 인자를 사용해 재시도한다.
- 추가 인증 텍스트가 보이는 경우 자동 갱신창을 우선 띄우지 않고 사용자의 수동 인증을 기다린다.
### C5.6 오프라인 Python 의존성 및 Python 3.15 준비 규칙

- BoardRepo 회사/오프라인 dependency baseline은 현재 `playwright==1.62.0`, `keyring==25.7.0`, `greenlet==3.5.6`으로 고정한다.
- Playwright 1.62.0의 greenlet 요구조건과 충돌하는 greenlet 4.x를 오프라인 Wheelhouse 기준선에 사용하지 않는다.
- Windows x64 오프라인 준비 대상 Python은 3.10, 3.11, 3.12, 3.13, 3.14, 3.15를 포함한다. Python 3.15 환경에서는 해당 CPython tag의 `greenlet 3.5.6` wheel 존재를 확인한다.
- `회사용 오프라인 준비`는 기존 Wheelhouse에 신규 파일을 누적하는 방식 대신 임시 staging 영역에서 전체 dependency set과 현재 Python용 Portable Vendor 생성이 모두 성공한 뒤 기존 생성물을 교체한다. 실패 시 기존 정상 Wheelhouse/Vendor를 유지한다.
- 설치/복구 시 현재 Python에 맞는 pinned greenlet wheel이 없으면 일반 pip resolver 오류만 노출하지 않고 `회사용 오프라인 준비` 재실행이 필요하다는 원인을 로그에 남긴다.
- 브라우저 자동화 핵심 로직(`browser_automation.py`)은 본 dependency 패키징 수정만을 이유로 변경하지 않는다.


## C6. `[ALM]` Requirement Studio Manual

### C6.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `ALM` |
| Project Name | Requirement Studio Manual |
| Status | `DRAFT` |
| Profile Version | v0.4 |
| Requirements Mode | `TBD` |
| Requirements Pattern | `TBD` |
| Package Pattern | 고정 패키지 없음 — 일반 파일 Inbox (`file_hash`) |
| Primary Environment | DOCX/PDF/XLSX/PPTX/MD 등 문서·매뉴얼 및 일반 파일, Windows |

### C6.2 현재 승인 범위

- Requirement Studio의 사용·운영 매뉴얼을 지속 작성·개정하는 독립 관리 대상이다.
- Automation Manager/BoardRepo Target 7로 배치한다.
- 그룹웨어 게시판 명칭은 `AI 스냅샷_Requirement Studio_매뉴얼`이다.
- 실제 Board URL은 `https://gw.suresofttech.com/app/community/130/board/394`로 확정한다.
- BoardRepo Target 7은 `file_hash` 일반 파일 Inbox로 운영한다.
- 압축파일만 요구하지 않으며 DOCX/PDF/XLSX/PPTX/MD/TXT/이미지/ZIP 등 일반 파일을 직접 보관할 수 있다.
- 각 파일은 파일명 + SHA-256으로 중복을 판정한다.
- 같은 파일명에 다른 SHA-256이면 자동 덮어쓰지 않고 확인 필요로 처리한다.
- 폴더 바로 아래의 일반 파일만 대상으로 하며 하위 폴더는 자동 재귀 업로드하지 않는다.
- 신규 사용자 표시명과 BoardRepo 제목 식별자는 `Requirement Studio`를 사용한다.
- BoardRepo 신규 게시글 제목은 `[BoardRepo][Requirement_Studio_Manual] <filename>`을 사용한다.
- 과거 `[BoardRepo][ALIRA_Manual] ...` 게시글과 `7. ALIRA 매뉴얼` 폴더명은 Legacy Alias로 계속 인식하여 기존 자료를 손실하지 않는다.
- 내부 Project ID `ALM`과 catalog key `ALIRAManual`은 호환성을 위해 유지하며 사용자 표시명과 분리한다.

## C7. `[ALR]` Requirement Studio Runtime / Tools

### C7.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `ALR` |
| Project Name | Requirement Studio Runtime / Tools |
| Status | `DRAFT` |
| Profile Version | v0.4 |
| Requirements Mode | `TBD` |
| Requirements Pattern | `TBD` |
| Package Pattern | `Requirement_Studio_V<major>.<minor>[.<patch>].zip` (Legacy: `ALIRA_V...zip`) |
| Primary Environment | Python 및 Requirement Studio 구동·보조 프로그램, Windows |

### C7.2 현재 승인 범위

- Requirement Studio 실제 사용에 필요한 Python 프로그램, 구동 도구와 보조 산출물을 지속 개발·관리하는 독립 대상이다.
- Automation Manager/BoardRepo Target 8로 배치한다.
- 그룹웨어 게시판 명칭은 `AI 스냅샷_Requirement Studio_구동`이다.
- 실제 Board URL은 `https://gw.suresofttech.com/app/community/130/board/395`로 확정한다.
- 신규 권장 배포 ZIP은 `Requirement_Studio_V0.15.zip`, `Requirement_Studio_V0.16.zip`, `Requirement_Studio_V1.0.zip`과 같이 `Vmajor.minor[.patch]` 형식을 사용한다. 과거 `ALIRA_V...zip`은 Legacy Alias로 계속 인식한다.
- 최신판은 날짜가 아니라 Semantic Version의 숫자 비교로 판정한다. 예: `V0.15 < V0.16 < V1.0`.
- 신규 BoardRepo 게시글 제목의 안정 식별자는 `[BoardRepo] Requirement_Studio_Runtime_Vx.y` 형식을 사용하고 첨부파일의 Semantic Version과 교차검증한다. 과거 `[BoardRepo] ALIRA_Runtime_Vx.y` 제목도 읽기/중복/다운로드 호환 대상으로 유지한다.
- Git 상태는 새 `Requirement_Studio_Vx.y.zip` 또는 Legacy `ALIRA_Vx.y.zip`이 아직 Commit되지 않았거나 PC의 Git ignore에 의해 숨겨져 있어도 관리대상 변경으로 식별해야 한다.
- Requirement Studio Runtime Target에 한해 승인된 Semantic Version 압축파일이 Git ignore에 걸린 경우 해당 파일만 제한적으로 force-add할 수 있다. Cache/임의 파일에는 이 예외를 확대하지 않는다.


### C7.3 Rename / Legacy Compatibility

- 2026-09-19부터 사용자 표시명은 `ALIRA`에서 `Requirement Studio`로 변경한다.
- Project ID `ALM`/`ALR`과 catalog key `ALIRAManual`/`ALIRARuntime`은 기존 Git/Requirements/원격 게시글 호환을 위해 변경하지 않는다.
- 폴더, GUI, 그룹웨어 Board Name, 신규 BoardRepo 제목과 신규 권장 Package Prefix는 `Requirement Studio`를 사용한다.
- Legacy `ALIRA` 폴더명·게시글 제목·Package Prefix는 읽기/복구/중복검사 호환 목적으로만 유지하며 신규 생성의 기본값으로 사용하지 않는다.

## C8. `[LRN]` 학습 / Knowledge Notes

### C8.1 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `LRN` |
| Project Name | 학습 / Knowledge Notes |
| Status | `ACTIVE` |
| Profile Version | v0.2 |
| Requirements Mode | `NOTE_GOVERNANCE` |
| Requirements Pattern | 고정 Requirements 없음 — `노트_정리_헌법_v*.md` 기준 |
| Package Pattern | 고정 패키지 없음 — 일반 파일 Inbox (`file_hash`) |
| Primary Environment | Markdown/DOCX/PDF/XLSX/PPTX 등 학습 문서, Git, BoardRepo |

### C8.2 현재 승인 범위

- Automation Manager Target 9의 사용자 표시명과 canonical 폴더명은 `9. 학습`이다.
- Target 9의 목적은 AI / LLM, SW Engineering, ISTQB, SDV, 책·영상 등 학습 자산을 하나의 상위 Target에서 관리하는 것이다. 자료가 늘어나더라도 분야마다 Automation Manager Target/그룹웨어 게시판을 즉시 추가하지 않는다.
- Git은 `9. 학습` 전체를 이력 관리하며 하위 폴더를 포함할 수 있다.
- BoardRepo는 `9. 학습` 바로 아래의 현재 자료만 일반파일 + SHA-256 방식으로 관리한다. `01. old` 및 기타 하위 폴더는 자동 게시 대상에서 제외한다.
- 현재 학습 자료 목록과 기준 버전은 `00_KNOWLEDGE_INDEX.md`에서 확인한다.
- 현재 학습 노트의 작성·검증·편입 방법은 `노트_정리_헌법_v*.md`의 최신 승인본을 우선 적용한다. 본 AI Development Governance는 해당 노트의 내용·표현을 임의로 수정하는 권한을 갖지 않는다.
- 신규 일반파일 게시글 제목은 `[BoardRepo][학습] <filename>`을 사용하고 파일명 + SHA-256으로 중복 여부를 판정한다.
- 그룹웨어 게시판은 `AI 스냅샷_학습`이며 실제 URL은 `https://gw.suresofttech.com/app/community/130/board/400`으로 사용자 확인 완료되었다. BoardRepo 원격 업로드·다운로드·중복검사는 이 exact URL을 사용하고 다른 번호로 추정·대체하지 않는다.

### C8.3 자료 배치 원칙

```text
9. 학습
├─ 00_KNOWLEDGE_INDEX.md
├─ 노트_정리_헌법_vX.Y.md
├─ 현재 학습 문서들
└─ 01. old/
   └─ 과거 버전 및 보관 자료
```

- BoardRepo에 자동 게시할 현재본은 Root에 둔다.
- 과거 버전은 필요 시 `01. old`로 이동한다.
- Git 내 세부 분류가 필요해 하위 폴더를 추가하더라도 BoardRepo 자동 게시가 필요한 현재본은 Root에 유지한다.
- 특정 학습 분야가 독립 프로젝트 수준으로 커지고 별도 Board/Release/Requirements가 필요해질 때에만 신규 Target 분리를 검토한다.

# Part D. 신규 프로젝트 프로필 양식

신규 프로젝트는 아래 양식을 복사하여 Project Registry에 추가한다.

```markdown
## CX. `[PROJECT_ID]` Project Name

### 프로필 정보

| 항목 | 값 |
|---|---|
| Project ID | `<PROJECT_ID>` |
| Project Name | `<PROJECT_NAME>` |
| Status | `DRAFT` |
| Profile Version | v0.1 |
| Requirements Mode | `DUAL_LAYER_XLSX_V1` / `CUSTOM` / `TBD` |
| Requirements Pattern | `<REQUIREMENTS_FILENAME_OR_PATTERN>` |
| Package Pattern | `<PACKAGE_PATTERN>` |
| Primary Environment | `<LANGUAGE_TOOL_OS_EXTERNAL_SYSTEM>` |

### 식별 Signature

- Package Pattern
- Requirements Filename
- Main Code / Module Signature
- Manifest Project ID

### 기능 변경 자동 절차

- Requirements 확인
- 영향 분석
- 문서 갱신
- 코드 최소 변경
- Test / Regression
- 패키지 생성과 무결성 확인

### Revision과 Package 규칙

- `<REVISION_POLICY>`
- `<PACKAGE_SEQUENCE_POLICY>`

### 배포 필수·제외 구성

- 필수: `<REQUIRED_FILES>`
- 제외: `<EXCLUDED_AND_SENSITIVE_FILES>`

### Architecture와 변경금지 경계

- `<MODULE_RESPONSIBILITIES>`
- `<LOCKS_AND_SAFETY_GATES>`

### 검증 상태와 완료 조건

- `<STATIC_TEST_INTEGRATION_FIELD_LEVELS>`

### 현재 참고 기준

- 기준일: `<YYYY-MM-DD>`
- Requirements: `<CURRENT_REQUIREMENTS>`
- 기준 배포: `<CURRENT_PACKAGE>`
- 다음 Requirement ID: `<NEXT_ID>`
```

---

# Part E. Change History

| Governance Version | Date | Change | Affected Scope |
|---|---|---|---|
| v0.1 | 2026-09-06 | 공통 개발헌법 초안 작성 | 모든 프로젝트 |
| v0.2 | 2026-09-11 | 공통 헌법과 Project Rules를 단일 Governance로 통합, Project ID 선택·격리·신규 등록 규칙 추가, PF·SE 프로필 등록 | 모든 프로젝트, PF, SE |
| v0.3 | 2026-09-12 | Governance Carry-Forward/Manifest 기준 추가, AM·GM·BR 프로필 ACTIVE 등록, ALIRA Manual(ALM)·Runtime(ALR) DRAFT 등록, Automation Manager Target 7·8 확장 기준 추가 | 모든 프로젝트, AM, GM, BR, ALM, ALR |
| v0.3 (Profile Update) | 2026-09-12 | ALM·ALR Profile v0.2: 실제 그룹웨어 Board URL board/394·395 확정 | ALM, ALR |
| v0.3 (Profile Update) | 2026-09-12 | ALM Profile v0.3: Target 7을 압축 Release 방식에서 일반 파일 Inbox(file_hash, 파일명+SHA-256) 방식으로 변경 | ALM |
| v0.4 | 2026-09-12 | 공통 Package Naming, Clean Distribution, Cache/임시파일 제외, Build/Test 후 Final Clean, `.gitignore`, Manifest 동기화 규칙 추가 | 모든 프로젝트 |
| v0.5 | 2026-09-13 | ALR Profile v0.3: `ALIRA_Vmajor.minor[.patch].zip` Semantic Version 관리, BoardRepo 제목/첨부 교차검증, Git ignore에 숨은 승인 ALIRA Release의 제한적 추적 예외 규칙 추가 | 모든 프로젝트 Git Hygiene, ALR |
| v0.6 | 2026-09-19 | Target 7·8 사용자 표시명을 ALIRA에서 Requirement Studio로 변경. board/394·395 URL은 유지하고 게시판 명칭, 폴더/GUI, 신규 게시글 제목/권장 Package Prefix를 Requirement Studio로 전환. ALM/ALR Project ID와 ALIRA Legacy Alias는 호환을 위해 유지 | AM, GM, BR, ALM, ALR |
| v0.7 | 2026-09-27 | Automation Manager 시작 시 자동 초기 점검의 Busy/Error Modal을 억제하고 Git Manager Header에 공용 Operation 상태를 Compact Status로 표시하는 규칙 추가. AM Profile v1.1 | AM, GM, BR |
| v0.8 | 2026-09-28 | BoardRepo 업로드/다운로드 결과를 요약 카드 + 1~8 Target 상태 + Scroll 가능한 파일/사유 상세표의 전용 Result Modal로 표준화. 기존 판정/로그는 유지하고 Presentation 계층만 개선. AM Profile v1.2, BR Profile v1.1 | AM, BR |
| v0.9 | 2026-10-04 | Automation Manager Target 9 `학습` 추가. `9. 학습`을 Git recursive + BoardRepo file_hash direct-only 지식/학습 자료 Target으로 정의하고 `00_KNOWLEDGE_INDEX.md`, 최신 노트 정리 헌법, AI/LLM 학습 노트 기준을 등록. 권장 Board 이름은 `AI 스냅샷_학습`, 실제 URL은 미확정/TBD로 유지. AM Profile v1.3, GM v1.1, BR v1.2, 신규 LRN Profile v0.1 | AM, GM, BR, LRN |

| v0.10 | 2026-10-04 | Target 9 `학습`의 실제 그룹웨어 게시판 `AI 스냅샷_학습` / board/400 확정. BoardRepo 원격 업로드·다운로드·중복검사를 활성화하고 LRN Profile v0.2, AM Profile v1.4, BR Profile v1.3으로 갱신. Git은 Board URL 비의존 유지 | AM, GM, BR, LRN |
| v0.11 | 2026-10-25 | 저장된 그룹웨어 로그인 정보로 인증하지 못한 경우 ID는 유지하고 새 비밀번호만 OS keyring에 갱신한 뒤 중단 작업을 재시도하는 흐름 추가. 비밀번호 변경을 단정하지 않고 CAPTCHA/MFA/네트워크 가능성을 구분하며 재시도 상한 적용. AM Profile v1.5, BR Profile v1.4 | AM, BR |
| v0.12 | 2026-11-07 | Git 복구 시작 전 Git 설치/실행 여부를 즉시 확인하고 미설치 시 안전 종료하도록 개선. 복구 로그를 5단계로 표시하고 Git Manager Header 상태 박스를 확대하여 현재 단계/원인을 2줄로 표시. Worker Thread가 Tk API를 직접 호출하지 않도록 UI Queue 구조로 변경하여 오류 시 `작업 중`/OperationLock이 해제되지 않을 수 있는 문제를 수정. AM Profile v1.6, GM Profile v1.2 | AM, GM |
| v0.13 | 2026-11-07 | Git 미설치 상태에서 `Git 자동 설치` 버튼을 제공하고 WinGet `Git.Git` 설치 → git.exe 재탐색 → `git --version` 검증 → 기존 Self-Bootstrap 복구 자동 재개 흐름을 추가. WinGet 미존재/UAC/회사 정책 차단 시 안전 종료 및 공식 수동 설치 안내. AM Profile v1.7, GM Profile v1.3 | AM, GM |
| v0.14 | 2026-11-07 | 신규 Windows에서 Git Repository 복구 후 `user.name/user.email` 미설정 상태를 `설정 필요`로 명확히 표시하고 Push 시 설정 UI로 연결 후 계속 진행하도록 개선. BoardRepo 오프라인 baseline을 Playwright 1.62.0 / keyring 25.7.0 / greenlet 3.5.6으로 고정하고 Python 3.15 wheel 준비 및 staging 교체 방식 추가. AM Profile v1.8, GM Profile v1.4, BR Profile v1.5 | AM, GM, BR |

---

# 최종 실행 원칙

> 공통 헌법은 모든 프로젝트에 적용한다.  
> 프로젝트 고유 규칙은 활성 Project ID의 프로필만 적용한다.  
> 기능의 최종 기준은 최신 승인 Requirements이다.  
> AI는 모르는 내용을 추정하여 구현하지 않는다.  
> 변경은 최소화하고 영향과 Regression을 확인한다.  
> 정적 확인과 실제 환경 검증을 구분한다.  
> 신규 프로젝트는 DRAFT로 등록하고 사용자 승인 후 ACTIVE로 전환한다.  
> 외부 배포 시 다른 프로젝트의 내부 프로필을 노출하지 않는다.
