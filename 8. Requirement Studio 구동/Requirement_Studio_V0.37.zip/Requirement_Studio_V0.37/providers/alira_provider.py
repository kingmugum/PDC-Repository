from __future__ import annotations

import base64
import mimetypes
import os
from pathlib import Path

from core.alira_client import AliraClient
from providers.base import AIProvider, ProviderMetadata, ProgressCallback

try:
    import requests
except Exception:
    requests = None


class AliraProvider(AIProvider):
    provider_id = "alira"
    display_name = "ALIRA / Qwen"

    def __init__(self, project_root: Path, config: dict):
        self.project_root = Path(project_root).resolve()
        self.config = config
        self.client = AliraClient(
            project_root=self.project_root,
            model=str(config.get("model") or "hosted_vllm/Qwen/Qwen3.6-27B"),
            api_base=str(config.get("api_base") or "http://10.10.10.200:19640/v1"),
            timeout_seconds=int(config.get("timeout_seconds") or 600),
        )

    def metadata(self) -> ProviderMetadata:
        exists = self.client.exe_exists()
        credential = "ALIRA 실행파일/라이선스 확인" if exists else "ALIRA 실행파일 없음"
        return ProviderMetadata(
            provider_id=self.provider_id,
            display_name=self.display_name,
            model=self.client.model,
            api_base=self.client.api_base,
            credential_status=credential,
            supports_text=True,
            supports_images=bool(self.config.get("supports_images", False)),
            supports_files=False,
        )

    def test_connection(self, progress_callback: ProgressCallback = None) -> str:
        return self.client.test_connection(progress_callback=progress_callback)

    def generate(
        self,
        user_prompt: str,
        *,
        system_message: str = "",
        timeout_seconds: int | None = None,
        progress_callback: ProgressCallback = None,
    ) -> str:
        prompt = user_prompt
        if system_message:
            prompt = f"[SYSTEM INSTRUCTION]\n{system_message}\n\n[USER REQUEST]\n{user_prompt}"
        return self.client.run_prompt(
            prompt,
            agent_type="general_agent",
            timeout_seconds=timeout_seconds,
            progress_callback=progress_callback,
        )

    def generate_with_images(
        self,
        user_prompt: str,
        image_paths,
        *,
        system_message: str = "",
        timeout_seconds: int | None = None,
    ) -> str:
        """Dormant native-Vision path for an OpenAI-compatible ALIRA/Qwen API.

        It is used only when config `alira.supports_images=true`.  The default
        remains false until the detachable ALIRA Vision Probe confirms that the
        configured model/API accepts image_url payloads.
        """
        if not bool(self.config.get("supports_images", False)):
            raise RuntimeError(
                "ALIRA Native Vision은 아직 비활성화되어 있습니다. "
                "diagnostics/ALIRA_Vision_Probe에서 먼저 Direct API 시험을 수행해주세요."
            )
        if requests is None:
            raise ImportError("requests 패키지가 설치되지 않았습니다.")

        base = str(self.client.api_base or "").rstrip("/")
        if not base:
            raise RuntimeError("ALIRA api_base가 비어 있습니다.")
        url = base if base.endswith("/chat/completions") else base + "/chat/completions"

        content: list[dict] = [{"type": "text", "text": user_prompt}]
        for item in image_paths or []:
            path = Path(item)
            if not path.is_file():
                continue
            mime = mimetypes.guess_type(path.name)[0] or "image/png"
            data_url = f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")
            content.append({"type": "image_url", "image_url": {"url": data_url}})

        if len(content) <= 1:
            raise RuntimeError("ALIRA Native Vision에 전달할 유효 이미지 파일이 없습니다.")

        messages: list[dict] = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": content})

        headers = {"Content-Type": "application/json"}
        # Optional corporate/internal API auth. Secret is environment-only.
        key_env = str(self.config.get("vision_api_key_env") or "ALIRA_API_KEY")
        api_key = os.environ.get(key_env, "").strip()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        payload = {"model": self.client.model, "messages": messages}
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=int(timeout_seconds or self.client.timeout_seconds),
        )
        response.raise_for_status()
        body = response.json()
        try:
            text = body["choices"][0]["message"]["content"]
        except Exception as exc:
            raise RuntimeError("ALIRA Vision API 응답에서 message.content를 찾을 수 없습니다.") from exc
        if isinstance(text, list):
            chunks = []
            for part in text:
                if isinstance(part, dict) and part.get("text"):
                    chunks.append(str(part["text"]))
            text = "\n".join(chunks)
        result = str(text or "").strip()
        if not result:
            raise RuntimeError("ALIRA Vision API 응답이 비어 있습니다.")
        return result
