# Requirement Studio V0.37

V0.37은 V0.35의 SWE.1/SWE.6 산출물 구조를 유지하면서, **Provider별 Model 선택 공통화**, **H-Chat Claude Skeleton**, **기타 API 확장**, **분리 가능한 ALIRA Vision 진단 도구**, **간결한 3-dot 현재 단계 상태 UI**를 추가한 버전입니다.


## V0.37 H-Chat Credential / ALIRA Vision Probe 보완

- `README_API_KEY_사용법.txt` 같은 설명 파일은 H-Chat Credential 후보에서 자동 제외합니다.
- 자동 탐색 및 H-Chat 수동 입력 Key는 공백 없는 printable ASCII token인지 사전 검증합니다.
- 설명문이 HTTP Header에 들어가 발생하던 `ascii codec can't encode...` 유형 오류를 API 호출 전에 차단합니다.
- `diagnostics/ALIRA_Vision_Probe/RUN_ALIRA_VISION_PROBE.cmd`를 실행하면 환경 검사 + deterministic fixture 생성 + ALIRA/Qwen Direct API image test를 한 번에 수행합니다.
- 본체 `AliraProvider`에는 같은 OpenAI-compatible `image_url` Native Vision Adapter가 기본 비활성(`supports_images=false`) 상태로 준비되어 있어 Probe PASS 후 Flag만 true로 전환할 수 있습니다.
- 이 Probe는 Main Pipeline의 H-Chat Vision fallback과 독립적이며, 폴더를 통째로 삭제해도 본체에 영향이 없습니다.

## 핵심 원칙

- 입력문서가 factual Source of Truth입니다.
- Canonical Requirement가 내부 Single Source of Truth입니다.
- SWE.1 Word / SWE.1 Excel / SWE.6 Excel은 동일 Canonical에서 파생합니다.
- Provider와 Model은 출력 형식과 분리합니다.
- Source에 없는 신호/수치/상태/시험방법을 임의 생성하지 않습니다.
- Gap/TBD/Conflict 등 품질정보는 내부 Canonical/Review 정보로 유지할 수 있으나 최종 산출물은 일반 엔지니어 관점으로 단순화합니다.
- 자체 제작 EXE는 포함하지 않으며 공식 실행 진입점은 `Requirement Studio.pyw`입니다.

## AI Engine / Model

Dashboard AI Engine:

- GPT (H-Chat)
- Gemini (H-Chat)
- Claude (H-Chat Skeleton)
- ALIRA / Qwen
- 기타(Custom API)

모든 Provider는 **현재 Model + 선택 가능한 Model 목록**을 Config에서 관리할 수 있습니다. AI Engine을 바꾸면 Model Dropdown도 해당 Provider의 목록으로 바뀝니다.

주요 Config:

- GPT: `hchat.gpt_model`, `hchat.gpt_model_options`
- Gemini: `hchat.gemini_model`, `hchat.gemini_model_options`
- Claude: `hchat.claude_model`, `hchat.claude_model_options`
- ALIRA: `alira.model`, `alira.model_options`
- 기타: `custom.model`, `custom.model_options`

Gemini/Claude의 실제 사내 최신 Model ID는 임의 추정하지 않습니다. 회사에서 확인한 ID를 Config에 추가/교체하는 구조입니다.

## H-Chat Claude Skeleton

V0.37은 `hchat_claude` Provider Skeleton을 제공합니다.

현재 회사 H-Chat Claude의 실제 Protocol/Base URL/Endpoint/Model 규격이 미확정이므로 기본값은 TBD입니다. TBD 상태에서 연결 테스트를 실행하면 설정이 필요하다는 오류를 반환하며 정상 연결로 표시하지 않습니다.

확인 후 교체할 항목:

- `claude_protocol`
- `claude_base_url`
- `claude_endpoint`
- `claude_model`
- `claude_model_options`
- `claude_api_version`
- `claude_supports_images`

## 기타(Custom API)

지원 Profile:

- OpenAI-compatible Chat Completions
- OpenAI Responses
- Anthropic Messages
- Gemini generateContent

설정 항목:

- API Base / Endpoint
- Model / Model 목록
- API Key 사용 여부
- Auth Mode: Auto / Bearer / x-api-key / Query Key / None
- API Key Header/Query 이름
- 선택적 API Version Header
- 이미지 입력 여부

`profile_flags`로 Profile을 개별 활성/비활성할 수 있어 신규 확장 Profile을 롤백해도 기존 Profile을 유지할 수 있습니다. 실제 API Key 값은 config/log에 평문 저장하지 않습니다.

완전히 독자적인 요청/응답 규격은 별도 Provider Adapter가 필요합니다.

## ALIRA Vision Probe

ALIRA Native Vision 검증은 본체와 분리된 다음 폴더에서 수행합니다.

`diagnostics/ALIRA_Vision_Probe/`

본체는 이 모듈을 import하지 않으므로 폴더 전체를 삭제해도 Requirement Studio의 정상 기능에 영향이 없어야 합니다.

Probe 목적:

1. 환경/ALIRA CLI 도움말 확인
2. Direct API Image 입력 시험
3. 실제 확인된 CLI Image Argument 시험
4. Text-only와 Image 입력 A/B 비교
5. 검증 후 `alira.supports_images=true/false`를 명시적으로 전환

Probe의 실제 사내 ALIRA/API 실행은 사용자 환경에서 확인합니다. V0.37 기본값은 `supports_images=false`입니다.

## 진행 상태 UI

- `전체 진행률`: Local Pipeline STEP 기반 실제 Overall % 표시
- `현재 단계 상태`: 짧은 업무 상태 문구 표시
- 실행 중: 3개의 점이 순차 강조되는 Activity Indicator
- 완료/오류/대기: Activity Indicator 정지
- 현재 단계에 별도의 모델 내부 % 또는 Busy Progress Bar를 표시하지 않습니다.
- AI 연결 테스트의 ALIRA elapsed heartbeat는 연결 진단용으로 유지합니다.
- 실제 분석 실행은 요청 전송 → 응답 대기 → 응답 수신 → 결과 정리 → 단계 완료 Event 중심입니다.
- Progress 표시만을 위한 별도 서버 Polling은 추가하지 않습니다.

## SWE.1

### Word

`SWE.1 요구사항 정리_<원본문서>_<YYMMDD>_<V버전>.docx`

최종 표시 11개 필드:

- SRS ID
- 상위 기능
- 분류
- 요구사항 내역
- 동작 조건 / Trigger
- 작동 명세 정의
- 사전 조건
- 예상 결과
- 검증 기준
- 출처 / Traceability
- 기타

Word 표는 항목 약 24% / 내용 약 76% 폭을 사용합니다.

### Excel

`SWE.1 요구사항 명세_<원본문서>_<YYMMDD>_<V버전>.xlsx`

기본 Sheet:

- `00_Overview`
- `01_SWE1`
- `02_Traceability`

Traceability는 Input Source → SWE.1 SRS → SWE.6 TC 연결을 우선합니다.

## SWE.6

`SWE.6 적격성 평가_<원본문서>_<YYMMDD>_<V버전>.xlsx`

SWE.6는 선택 AI가 Excel을 직접 쓰는 방식이 아니라 Canonical 이후 Local Exporter가 공통 규칙으로 생성합니다.

기본 Sheet:

- `표지`
- `0_변경이력`
- `1_테스트요약`
- `2_테스트 케이스`

Test Case Sheet는 6개 Group Header + 21개 상세열을 사용합니다. `Tolerance lower`, `Tolerance upper`, `Capture Environment`는 생성하지 않습니다.

## 실행

1. ZIP 압축을 해제합니다.
2. `Requirement Studio.pyw`를 더블클릭합니다.
3. `.pyw` 연결이 없는 환경에서는 `pythonw "Requirement Studio.pyw"` 또는 `pyw "Requirement Studio.pyw"`를 사용합니다.
4. 실제 H-Chat 사용 시 `api_keys/` 또는 프로젝트 Root의 기존 H-Chat API Key TXT 형식을 사용할 수 있습니다.

## 기준 문서

- Package: `Requirement_Studio_V0.37.zip`
- Requirements: `Requirement_Studio_Requirements_Management_rev39.xlsx`
- User Manual: `docs/Requirement_Studio_사용자_매뉴얼_v0.23_V0.37.docx`
- SWE.1 Guide: `reference/OUTPUT_AUTHORING_GUIDE.md`
- SWE.6 Guide: `reference/SWE6_AUTHORING_GUIDE.md`
- Next FR: `FR-291`

## 검증 경계

제작 환경에서 정적/합성 검증 가능한 항목은 Package Manifest에 기록합니다.

사용자 환경 확인이 필요한 항목:

- Windows PySide6 실제 Dashboard / 3-dot Animation 렌더
- 실제 H-Chat Claude 연결
- 실제 사내 ALIRA Native Vision Probe
- 최신 사내 Gemini Model ID
- 실제 고객사/외부 Custom API End-to-End

미확인 Runtime은 PASS로 기록하지 않습니다.
