Requirement Studio - H-Chat API Key 배치 안내

1. 이 폴더에 파일명에 API_Key가 포함된 TXT 파일을 넣습니다.
   예) 260919_API_Key_1차.txt

2. 파일 내용은 다음 둘 중 하나면 됩니다.
   - Key 값만 한 줄
   - API_KEY=<Key 값>

3. 여러 파일이 있으면 가장 최근 수정된 유효 파일을 우선 사용합니다.

4. API Key는 화면/로그/산출물에 평문으로 표시하지 않습니다.

5. 파일을 두기 어려운 경우 Requirement Studio의 [API Key 수동 입력]을 사용할 수 있습니다.
   수동 입력 값은 현재 실행 메모리에만 보관하며 config 파일에 저장하지 않습니다.
