# Requirement Studio sample_inputs

V0.33 샘플 입력 문서 모음입니다.

## 기본 샘플
- `sample_vcu_lite_implicit_behavior.docx`
- `sample_vcu_lite_implicit_behavior.pdf`
- `sample_vcu_lite_implicit_behavior.pptx`
- `sample_vcu_lite_implicit_behavior.xlsx`

## 그림/도식 포함 샘플
- `sample_vcu_lite_visual_diagram.docx`
- `sample_vcu_lite_visual_diagram.pdf`
- `sample_vcu_lite_visual_diagram.pptx`

그림/도식 포함 샘플은 Text/Table/Visual Evidence 통합 분석 확인용입니다.
VCU 저전력 제어 도식 안의 Trigger, Expected Result, Not Confirmed 정보를 Vision 분석 대상으로 사용할 수 있습니다.

## 사용 방법
1. 원하는 샘플 파일을 `input` 폴더로 복사합니다.
2. Requirement Studio에서 [새로고침]을 누릅니다.
3. 문서가 인식되면 입력 영역이 연한 초록색 상태로 표시됩니다.
4. [분석 및 요구사항 추출 시작]을 실행합니다.

README를 포함하여 sample_inputs 폴더에는 총 8개 파일이 포함됩니다.
