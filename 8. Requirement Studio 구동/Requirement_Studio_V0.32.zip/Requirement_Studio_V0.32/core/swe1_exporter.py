from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Pt, RGBColor
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


NOT_CONFIRMED = "입력문서에서 확인되지 않음"
NO_DETAIL = "입력문서에서 추가 작동 명세를 확인할 수 없음"


def _safe_stem(name: str) -> str:
    stem = Path(name).stem or "document"
    stem = re.sub(r'[<>:"/\\|?*]+', "_", stem)
    stem = re.sub(r"\s+", "_", stem).strip("._ ")
    return stem[:80] or "document"


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        result = []
        for item in value:
            if isinstance(item, dict):
                text = "; ".join(f"{k}={v}" for k, v in item.items() if v not in (None, "", [], {}))
            else:
                text = str(item).strip()
            if text:
                result.append(text)
        return result
    if isinstance(value, dict):
        text = "; ".join(f"{k}={v}" for k, v in value.items() if v not in (None, "", [], {}))
        return [text] if text else []
    text = str(value).strip()
    return [text] if text else []


def _text(value: Any, *, empty: str = "") -> str:
    items = _as_list(value)
    return "\n".join(items) if items else empty


def _normalize_classification(value: Any) -> str:
    raw = _text(value).strip()
    low = raw.lower()
    if "비기능" in raw or "non-functional" in low or "nonfunctional" in low:
        return "비기능"
    if raw == "기능" or "functional" in low or ("기능" in raw and "비기능" not in raw):
        return "기능"
    return raw or "검토 필요"


def _format_evidence(items: Any) -> str:
    lines = []
    for idx, item in enumerate(items if isinstance(items, list) else [], start=1):
        if not isinstance(item, dict):
            text = str(item).strip()
            if text:
                lines.append(f"[{idx}] {text}")
            continue
        document = str(item.get("document") or "").strip()
        location = str(item.get("location") or "").strip()
        evidence = str(item.get("text") or "").strip()
        prefix = " / ".join(x for x in (document, location) if x)
        if evidence:
            lines.append(f"[{idx}] {prefix}: {evidence}" if prefix else f"[{idx}] {evidence}")
        elif prefix:
            lines.append(f"[{idx}] {prefix}")
    return "\n".join(lines) if lines else NOT_CONFIRMED


def _behavior_text(req: dict[str, Any]) -> str:
    flows = _as_list(req.get("behavior_flows"))
    if flows:
        rendered = []
        for idx, item in enumerate(flows, start=1):
            clean = re.sub(r"^BF\s*\d+(?:[-.]\d+)?[.:\-]?\s*", "", item, flags=re.IGNORECASE).strip()
            rendered.append(f"BF1-{idx}. {clean or item}")
        return "\n".join(rendered)
    processing = _text(req.get("processing_action")).strip()
    if processing:
        return processing
    return NO_DETAIL


def build_swe1_records(requirement_data: dict[str, Any]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    requirements = requirement_data.get("requirements") or []
    for idx, req in enumerate(requirements, start=1):
        if not isinstance(req, dict):
            continue
        clarifications = _text(req.get("clarification_needed"), empty="").strip() or "-"
        records.append({
            "SRS ID": _text(req.get("srs_id"), empty=f"SRS_{idx:03d}") or f"SRS_{idx:03d}",
            "상위 기능": _text(req.get("function_name"), empty="미분류") or "미분류",
            "분류": _normalize_classification(req.get("category")),
            "분류 근거": _text(req.get("classification_basis"), empty="검토 필요") or "검토 필요",
            "요구사항 내역": _text(req.get("requirement"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "동작 조건 / Trigger": _text(req.get("activation_trigger"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "작동 명세 정의": _behavior_text(req),
            "사전 조건": _text(req.get("preconditions"), empty="") or _text(req.get("system_input_preconditions"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "예상 결과": _text(req.get("output"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "검증 기준": _text(req.get("acceptance_criteria"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "평가 방안": _text(req.get("evaluation_method"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "예외 조건": _text(req.get("exception_conditions"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "출처 / Traceability": _format_evidence(req.get("source_evidence")),
            "관련 자료": _text(req.get("related_artifacts"), empty=NOT_CONFIRMED) or NOT_CONFIRMED,
            "Gap / TBD": clarifications,
            "도출 유형": _text(req.get("derivation_type"), empty="-") or "-",
            "도출 근거": _text(req.get("derivation_reason"), empty="-") or "-",
            "Candidate ID": _text(req.get("candidate_id"), empty="-") or "-",
        })
    return records


class SWE1Exporter:
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _filename(self, prefix: str, source_document: Path, suffix: str) -> Path:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return self.output_dir / f"{prefix}_{_safe_stem(Path(source_document).name)}_{stamp}.{suffix}"

    def export_word(self, source_document: Path, requirement_data: dict[str, Any]) -> Path:
        records = build_swe1_records(requirement_data)
        if not records:
            raise ValueError("SWE.1 Word로 내보낼 Requirement가 없습니다.")
        out_path = self._filename("SWE.1 요구사항 정리", source_document, "docx")
        doc = Document()
        doc.styles["Normal"].font.name = "Malgun Gothic"
        doc.styles["Normal"].font.size = Pt(9)
        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run("SWE.1 소프트웨어 요구사항 정리")
        run.bold = True
        run.font.size = Pt(18)
        meta = doc.add_table(rows=4, cols=2)
        meta.style = "Table Grid"
        for row, (key, value) in enumerate([
            ("원본 문서", Path(source_document).name),
            ("생성 일시", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            ("SRS 개수", str(len(records))),
            ("작성 기준", "Requirement Studio 산출물 작성 기준 V0.1 — SWE.1"),
        ]):
            meta.cell(row, 0).text = key
            meta.cell(row, 1).text = value
        note = doc.add_paragraph()
        note_run = note.add_run(
            "※ 입력문서를 factual Source of Truth로 사용하며, 확인되지 않은 정보는 임의로 창작하지 않습니다. "
            "평가 방안/예외 조건 등이 Source에 없으면 ‘입력문서에서 확인되지 않음’으로 표시합니다."
        )
        note_run.font.size = Pt(8.5)
        note_run.font.color.rgb = RGBColor(90, 98, 110)
        current_feature = None
        fields = [
            "SRS ID", "상위 기능", "분류", "분류 근거", "요구사항 내역", "동작 조건 / Trigger",
            "작동 명세 정의", "사전 조건", "예상 결과", "검증 기준", "평가 방안", "예외 조건",
            "출처 / Traceability", "관련 자료", "Gap / TBD",
        ]
        for record in records:
            feature = record["상위 기능"]
            if feature != current_feature:
                doc.add_heading(feature, level=1)
                current_feature = feature
            table = doc.add_table(rows=len(fields), cols=2)
            table.style = "Table Grid"
            for row_idx, field in enumerate(fields):
                left, right = table.cell(row_idx, 0), table.cell(row_idx, 1)
                left.text, right.text = field, record[field]
                left.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                right.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for paragraph in left.paragraphs:
                    for r in paragraph.runs:
                        r.bold = True
                        r.font.size = Pt(8.5)
                for paragraph in right.paragraphs:
                    for r in paragraph.runs:
                        r.font.size = Pt(8.5)
            doc.add_paragraph()
        gaps = requirement_data.get("gaps") or []
        if gaps:
            doc.add_heading("문서 전체 Gap / TBD", level=1)
            for gap in gaps:
                doc.add_paragraph(_text(gap, empty=str(gap)), style="List Bullet")
        doc.save(out_path)
        return out_path

    def export_excel(self, source_document: Path, requirement_data: dict[str, Any]) -> Path:
        records = build_swe1_records(requirement_data)
        if not records:
            raise ValueError("SWE.1 Excel로 내보낼 Requirement가 없습니다.")
        out_path = self._filename("SWE.1 요구사항 명세", source_document, "xlsx")
        wb = Workbook()
        ws0 = wb.active
        ws0.title = "00_Overview"
        ws1 = wb.create_sheet("01_SWE1")
        ws2 = wb.create_sheet("02_Behavior_Flow")
        ws3 = wb.create_sheet("03_Traceability")
        ws4 = wb.create_sheet("04_Gap_TBD")
        blue, light, border_color = "2F75B5", "D9EAF7", "D0D7DE"
        thin = Side(style="thin", color=border_color)
        header_fill = PatternFill("solid", fgColor=blue)
        sub_fill = PatternFill("solid", fgColor=light)
        white_font, bold = Font(color="FFFFFF", bold=True), Font(bold=True)
        wrap = Alignment(vertical="top", wrap_text=True)
        center = Alignment(horizontal="center", vertical="center", wrap_text=True)
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        for row in [
            ["항목", "내용"],
            ["문서", "SWE.1 소프트웨어 요구사항 명세"],
            ["원본 문서", Path(source_document).name],
            ["생성 일시", datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
            ["SRS 개수", len(records)],
            ["작성 기준", "Requirement Studio 산출물 작성 기준 V0.1 — SWE.1"],
            ["핵심 원칙", "Feature는 묶음, SRS는 독립 검증 가능한 Requirement, BF는 SRS 내부 상세 동작"],
            ["Source 원칙", "입력문서에 없는 사실은 만들지 않으며 Gap/TBD/Conflict로 남김"],
        ]:
            ws0.append(row)
        for cell in ws0[1]:
            cell.fill, cell.font, cell.alignment = header_fill, white_font, center
        for row in ws0.iter_rows(min_row=2):
            row[0].font = bold
            for cell in row:
                cell.alignment, cell.border = wrap, border
        ws0.column_dimensions["A"].width, ws0.column_dimensions["B"].width = 18, 90
        ws0.freeze_panes = "A2"
        headers = [
            "SRS ID", "상위 기능", "분류", "분류 근거", "요구사항 내역", "동작 조건 / Trigger",
            "작동 명세 정의", "사전 조건", "예상 결과", "검증 기준", "평가 방안", "예외 조건",
            "출처 / Traceability", "관련 자료", "Gap / TBD", "도출 유형", "도출 근거", "Candidate ID",
        ]
        ws1.append(headers)
        for record in records:
            ws1.append([record[h] for h in headers])
        for cell in ws1[1]:
            cell.fill, cell.font, cell.alignment, cell.border = header_fill, white_font, center, border
        for row in ws1.iter_rows(min_row=2):
            for cell in row:
                cell.alignment, cell.border = wrap, border
        ws1.freeze_panes, ws1.auto_filter.ref = "A2", ws1.dimensions
        widths = [12, 20, 11, 18, 46, 32, 42, 30, 32, 32, 28, 28, 50, 34, 30, 12, 28, 18]
        for idx, width in enumerate(widths, start=1):
            ws1.column_dimensions[get_column_letter(idx)].width = width
        ws2.append(["SRS ID", "상위 기능", "BF ID", "Behavior Flow"])
        for record in records:
            behavior = record["작동 명세 정의"]
            lines = [x.strip() for x in behavior.splitlines() if x.strip()]
            bf_lines = [x for x in lines if re.match(r"^BF\d+-\d+\.", x)]
            if bf_lines:
                for line in bf_lines:
                    bf_id, text = line.split(".", 1)
                    ws2.append([record["SRS ID"], record["상위 기능"], bf_id, text.strip()])
            else:
                ws2.append([record["SRS ID"], record["상위 기능"], "-", behavior])
        ws3.append(["SRS ID", "상위 기능", "Source / Evidence"])
        for record in records:
            ws3.append([record["SRS ID"], record["상위 기능"], record["출처 / Traceability"]])
        ws4.append(["구분", "SRS ID", "내용"])
        for record in records:
            if record["Gap / TBD"] not in ("", "-"):
                ws4.append(["Requirement", record["SRS ID"], record["Gap / TBD"]])
        for gap in requirement_data.get("gaps") or []:
            ws4.append(["Document", "-", _text(gap, empty=str(gap))])
        if ws4.max_row == 1:
            ws4.append(["-", "-", "등록된 Gap/TBD 없음"])
        for ws, widths_local in [(ws2, [12, 22, 12, 80]), (ws3, [12, 24, 100]), (ws4, [16, 12, 100])]:
            for cell in ws[1]:
                cell.fill, cell.font, cell.alignment = header_fill, white_font, center
            for row in ws.iter_rows(min_row=1):
                for cell in row:
                    cell.border, cell.alignment = border, wrap
            ws.freeze_panes = "A2"
            for idx, width in enumerate(widths_local, start=1):
                ws.column_dimensions[get_column_letter(idx)].width = width
        for ws in (ws0, ws1, ws2, ws3, ws4):
            ws.sheet_view.showGridLines = False
        for row in ws1.iter_rows(min_row=2):
            row[0].fill, row[0].font = sub_fill, bold
        wb.save(out_path)
        return out_path
