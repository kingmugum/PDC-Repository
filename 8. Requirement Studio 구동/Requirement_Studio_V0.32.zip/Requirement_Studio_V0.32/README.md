# Requirement Studio V0.32

V0.32는 V0.31의 **SWE.1 Word/Excel Export / Provider Native Vision / 기타 API / ALIRA 진단 / No-EXE** 기준을 유지하면서, 사용자가 확정한 `SWE.6 Template V0.1`을 Provider와 분리된 Local Exporter로 실제 생성하는 MVP를 추가한 버전입니다.

## 핵심 변경

- Canonical Requirement를 기준으로 SWE.1 Word/Excel을 동일 Source에서 파생합니다.
- Canonical merge 완료 후 `SRS_001`, `SRS_002` ... 형식의 SRS ID를 로컬에서 결정론적으로 부여하고 JSON/Word/Excel이 공유합니다.
- SWE.1 Authoring Rule은 `Feature > SRS > BF` 계층을 사용합니다.
  - Feature: 관련 SRS 묶음
  - SRS: 독립적으로 이해·변경·검증 가능한 Software Requirement
  - BF: 한 SRS 내부의 상세 동작/순서
- Trigger와 Pre-condition, Verification Criteria와 Evaluation Method를 구분합니다.
- Source에 없는 평가 방안·예외 조건·수치·상태는 AI가 창작하지 않습니다.
- 관련 자료는 Source-backed reference로 우선 기록하고, V0.32에서도 원문에 없는 그래프/도식을 새로 만들어 사실을 추가하지 않습니다.
- Gap/TBD/Conflict를 숨기지 않습니다.

## 실행 Card

V0.32 기본 상태:

- `SWE.1 문서 (Word 파일)` — On / 실제 생성
- `SWE.1 문서 (엑셀 양식)` — On / 실제 생성
- `SWE.6 문서 (엑셀 양식)` — On / 실제 생성

SWE.1/SWE.6 선택값은 실제 Exporter에 연결됩니다. 선택을 해제한 산출물은 만들지 않으며, 기존 분석 결과 DOCX와 Canonical Requirement JSON 생성은 계속 유지합니다.

`작성 기준 보기` 버튼을 누르면 SWE.1 및 SWE.6 작성 기준과 설계 이유를 별도 **Modeless 창**으로 표시합니다. 이 창이 열린 상태에서도 메인 Dashboard를 계속 조작할 수 있습니다.

작성 기준의 Single Source는 다음 파일입니다.

- `reference/OUTPUT_AUTHORING_GUIDE.md` — SWE.1 기준
- `reference/SWE6_AUTHORING_GUIDE.md` — SWE.6 기준

GUI 설명 창은 두 기준을 함께 표시하며 Requirement Extraction Prompt는 SWE.1 기준만 사용합니다. SWE.6는 Canonical 이후 Local Exporter가 별도 기준을 사용합니다.

## SWE.1 실제 산출물

### Word

`SWE.1 요구사항 정리_<원본문서>_<timestamp>.docx`

Feature별 Section 아래 각 SRS를 표로 표시하며, 주요 필드는 다음과 같습니다.

- SRS ID / 상위 기능
- 분류 / 분류 근거
- 요구사항 내역
- 동작 조건 / Trigger
- 작동 명세 정의 / BF
- 사전 조건
- 예상 결과
- 검증 기준
- 평가 방안
- 예외 조건
- 출처 / Traceability
- 관련 자료
- Gap / TBD

### Excel

`SWE.1 요구사항 명세_<원본문서>_<timestamp>.xlsx`

기본 Sheet:

- `00_Overview`
- `01_SWE1`
- `02_Behavior_Flow`
- `03_Traceability`
- `04_Gap_TBD`

### SWE.6

`SWE.6 적격성 평가_<원본문서>_<timestamp>.xlsx`를 실제 생성합니다. SWE.6는 동일 Canonical Requirement에서 Local Rule로 파생되며 GPT/Gemini/ALIRA/기타 Provider별 별도 SWE.6 Prompt를 사용하지 않습니다.

## Vision

문서 내 이미지 추출/제한/Visual Evidence Schema는 공통이고, 이미지 전송은 선택 Provider Adapter가 담당합니다.

- H-Chat GPT / Gemini: Native image payload 지원
- ALIRA/Qwen: native image PoC 전까지 `supports_images=false`
- 기타 API: 사용자가 `이미지 입력 사용`을 명시적으로 켠 경우 Native image payload 사용
- Custom API 이미지 미지원 시 H-Chat로 자동 우회하지 않고 Text/Table 분석 계속
- `Observed / Interpreted / Not Confirmed` Visual Evidence
- Base64 이미지 본문과 API Key를 Runtime Log/Request Snapshot에 기록하지 않음

## 실행

1. 압축을 해제합니다.
2. `Requirement Studio.pyw`를 더블클릭합니다.
3. `.pyw` 연결이 없는 환경에서는 다음 중 하나를 사용합니다.
   - `pythonw "Requirement Studio.pyw"`
   - `pyw "Requirement Studio.pyw"`
4. 실제 H-Chat을 사용하려면 `api_keys/` 또는 프로젝트 Root에 기존 방식의 H-Chat API Key TXT 파일을 둡니다.

자체 제작 EXE는 포함하지 않습니다.

## 기준 문서

- Requirements: `Requirement_Studio_Requirements_Management_rev34.xlsx`
- Governance: `00_AI_DEVELOPMENT_GOVERNANCE.md` / Profile v0.32
- Architecture: `ARCHITECTURE.md` / v0.32
- User Manual: `docs/Requirement_Studio_사용자_매뉴얼_v0.17_V0.32.docx`
- Authoring Guide: `reference/OUTPUT_AUTHORING_GUIDE.md`
- 다음 신규 FR: `FR-250`

## 검증 상태

현재 제작 환경에서 확인 완료:

- Python syntax compile
- Canonical merge 후 SRS ID 결정론적 부여 합성 테스트
- SWE.1 Word/Excel Exporter 합성 테스트
- SWE.1 Word 샘플 DOCX 렌더링 및 페이지 시각 검토
- SWE.1 Excel 샘플 구조/데이터 inspect
- Requirements rev34 formula-error scan 0건
- No-EXE 최종 ZIP 검사: `.exe` 0개 / `Requirement Studio.pyw` 존재

사용자 Windows 환경에서 추가 확인 필요:

- V0.31 실제 3-Card Dashboard/Result Tab Connector 렌더와 `작성 기준 보기` Modeless 동작
- 실제 H-Chat/ALIRA 문서 분석 → Canonical → SWE.1 Word/Excel End-to-End
- 그림 포함 문서 Vision 통합 Runtime
- 실제 문서에서 SRS Atomicity / 분류 / Traceability의 Semantic 품질

미확인 Runtime을 PASS로 기록하지 않습니다.


## V0.30 주요 변경
- 입력 문서 준비 완료 시 Drop Zone을 연한 초록색으로 표시합니다.
- 상단 Dashboard의 AI 설정/실행 Card를 사용자 시안 기준으로 재배치했습니다.
- sample_inputs에 그림/도식 포함 DOCX/PPTX/PDF 샘플 3종을 추가했습니다.
- Vision 정책을 selected_provider_native 우선으로 변경했습니다. H-Chat GPT/Gemini는 native image 요청을 지원하고, ALIRA는 PoC 전까지 supports_images=false를 유지합니다.


## 기타 API Provider

AI Engine의 `기타`는 다음 3개 REST Profile을 제공합니다.

- OpenAI-compatible Chat Completions
- Anthropic Messages
- Gemini generateContent

`기타 API 설정`에서 API 형식, API Base/Endpoint, Model, API Key 사용 여부, 이미지 입력 사용 여부를 입력합니다. API Key 값 자체는 config에 저장하지 않으며 현재 실행 메모리 또는 `REQUIREMENT_STUDIO_CUSTOM_API_KEY` 환경변수에서만 사용합니다.

이 기능은 모든 독자 API를 자동 해석하는 Universal Adapter가 아닙니다. 고객사 API가 위 3개 요청/응답 형식 중 하나와 호환되면 설정만으로 연결할 수 있고, 독자 규격이면 `providers/` 아래 별도 Adapter를 추가해야 합니다.

기타 API에서 이미지 입력을 끈 경우 H-Chat로 이미지를 자동 우회 전송하지 않습니다. Text/Table 분석은 계속합니다.

## Result Tab 연결 UI

선택된 `진행 로그 / 문서 분석 결과 / 요구사항 후보` Tab의 하단 Border 구간을 흰색 Connector로 덮어 아래 Content Panel과 하나의 Card처럼 보이도록 합니다. 비선택 Tab의 Border는 유지됩니다.


## V0.31 ALIRA 응답 대기 가시성

- ALIRA 연결 테스트는 최대 60초 대기 구간을 기준으로 `경과초 / 최대초 / timeout 기준 %`를 로그에 표시합니다.
- 일반 문서 분석/요구사항 추출 ALIRA 호출도 약 4초 간격 Heartbeat를 기록하며 기본 최대 대기시간은 600초입니다.
- 표시 %는 원격 Qwen의 실제 추론 진행률이 아니라 **Timeout 구간 경과비율**입니다.
- 응답 수신 시 `사내 Qwen 응답 수신 완료`와 함께 100% 상태를 기록합니다.

## V0.31 Vision Route 진단

그림/도식이 있는 문서는 STEP 3에서 다음 정보를 진행 로그에 표시합니다.

- Main Provider / Model
- 실제 Vision Provider / Model
- Native 또는 Fallback 경로
- Vision Credential 상태

시각 자산이 존재하지만 `Visual Evidence 0개`이면 그림 내용이 후속 분석에 반영되지 않았음을 경고하고 asset별 `vision_status`와 `work/normalized` 하위 `visual_evidence.json` 확인을 안내합니다.


## V0.32 SWE.6 Qualification Test MVP

- 실행 Card의 `SWE.6 문서 (엑셀 양식)`을 실제 생성 기능으로 활성화했습니다.
- 기본값은 SWE.1 Word / SWE.1 Excel / SWE.6 Excel 모두 On입니다.
- SWE.6는 `표지 / 0_변경이력 / 1_테스트요약 / 2_테스트 케이스` 4개 Sheet로 생성합니다.
- 표지 Metadata는 입력문서에서 명시적으로 식별되는 값만 사용하며 없으면 공란입니다.
- 최초 Revision은 `V.0.0`, 문서 상태는 `Draft`이며 상태는 Dropdown으로 변경할 수 있습니다.
- Test Result 영역(Output Value / PASS-FAIL / Comment / Capture)은 실제 시험 전 공란입니다.
- Test Method는 요구사항 기반 테스트를 Base로 하며 Threshold/Range/State 특성에 따라 경계값/동등분할/상태전이를 Local Rule로 선택합니다.
- 상세 기준은 `reference/SWE6_AUTHORING_GUIDE.md`에서 확인할 수 있습니다.
