# Requirement Studio 산출물 작성 기준 V0.1 — SWE.1

이 문서는 Requirement Studio가 SWE.1 Word/Excel을 어떤 원칙으로 작성하는지 설명하는 기준 문서입니다.
사람이 보는 `작성 기준` 팝업과 AI Requirement 추출 Prompt가 이 문서를 공통 기준으로 사용합니다.

## 1. 기본 원칙

### 1.1 Source First
- 입력문서가 factual Source of Truth입니다.
- 입력문서에 없는 신호명, 수치, 시간, 상태, 평가방법, 예외조건을 새로 만들지 않습니다.
- 정보가 부족하거나 충돌하면 Gap/TBD/Conflict로 남깁니다.

### 1.2 Feature / SRS / BF 계층
- Feature: 서로 관련된 SRS를 묶는 상위 기능 단위입니다.
- SRS: 독립적으로 이해·변경·검증 가능한 Software Requirement 단위입니다.
- BF(Behavior Flow): 하나의 SRS 내부에서 수행되는 상세 동작 또는 순서를 표현합니다.
- BF는 별도의 독립 요구사항을 한 SRS 안에 묶기 위한 수단이 아닙니다.

### 1.3 SRS 분할 기준
다음 중 하나라도 명확히 성립하면 별도 SRS로 분리하는 것을 우선합니다.
- Trigger/Activation 조건이 독립적임
- Expected Result가 독립적으로 검증 가능함
- 한 항목만 변경·삭제해도 다른 항목이 그대로 성립함
- 기능/비기능 성격이 서로 다름
- Source Requirement가 독립적이고 별도 Trace를 유지할 가치가 있음

여러 문장이 하나의 연속 동작을 상세화하는 Step이라면 하나의 SRS 아래 BF로 유지할 수 있습니다.
단순히 원문 문장 수에 맞춰 SRS 개수를 정하지 않습니다.

## 2. SRS ID
- 각 문서의 Export 시 Canonical Requirement 순서에 따라 `SRS_001`, `SRS_002` ... 형식으로 부여합니다.
- SRS ID는 하나의 Atomic Requirement를 식별합니다.
- 상위 Feature 자체에 SRS ID를 부여하지 않습니다.

## 3. 분류 — 기능 / 비기능
- 입력문서가 기능/비기능을 명시하면 원문 분류를 우선합니다.
- 입력문서에 명시가 없으면 Requirement의 의무 성격을 기준으로 기능/비기능을 분류할 수 있습니다.
  - 기능: Software가 무엇을 수행해야 하는지에 대한 동작/서비스/상태전이 요구
  - 비기능: 성능, 시간, 자원, 품질속성, 제약 등 기능의 수행 특성에 대한 요구
- 추론으로 분류한 경우 `분류 근거`에 `규칙 기반 추론`임을 명시합니다.
- 한 문장에 기능과 비기능 의무가 독립적으로 섞여 있으면 Atomicity 기준에 따라 분리를 우선합니다.
- 명확히 분류하기 어려우면 `검토 필요`로 남기며 억지로 확정하지 않습니다.

## 4. 요구사항 내역
- Software가 무엇을 해야 하는지를 한 개의 명확하고 검증 가능한 의무로 기술합니다.
- 표현은 정제할 수 있으나 원문의 의미를 확장하거나 새로운 동작을 창작하지 않습니다.
- Requirement 하나에 서로 독립적인 보호기능, 진단기능, 상태전이 등을 과도하게 묶지 않습니다.

## 5. Trigger와 Pre-condition
- Trigger/Activation: Requirement의 동작을 발생시키는 사건 또는 조건입니다.
- Pre-condition: Requirement 수행 전에 이미 성립해 있어야 하는 상태입니다.
- 두 항목을 구분하여 향후 SWE.6의 Test Input과 Test Environment가 섞이지 않게 합니다.
- 입력문서에서 구분 근거가 없으면 임의로 만들어내지 않습니다.

## 6. 작동 명세 정의 / BF
- Source에 상세 동작 순서가 존재할 때만 BF로 구조화합니다.
- BF는 `BF1-1`, `BF1-2`와 같이 순서를 식별할 수 있게 작성할 수 있습니다.
- 단순 Requirement 한 문장을 내용 증가를 위해 여러 BF로 늘리지 않습니다.
- 상세 Flow가 없으면 `입력문서에서 추가 작동 명세를 확인할 수 없음`으로 표시할 수 있습니다.

## 7. 예상 결과
- Requirement 수행 후 Source에서 확인되는 Output, State Change, Status, Message 등을 기록합니다.
- Source에 없는 기대값이나 정상 동작을 상식으로 보완하지 않습니다.

## 8. 검증 기준과 평가 방안
- 검증 기준: Pass/Fail을 판단할 수 있는 수치, 상태, 조건, 허용범위 등입니다.
- 평가 방안: CANoe, Oscilloscope, 전류계, 분석 절차처럼 실제 확인 방법입니다.
- 두 항목을 분리합니다.
- 입력문서에 평가 방안이 없으면 AI가 일반적인 시험방법을 창작하지 않고 `입력문서에서 확인되지 않음`으로 표시합니다.

## 9. 예외 조건
- 이 Requirement가 적용되지 않거나 예외적으로 처리되는 조건이 Source에 있을 때만 작성합니다.
- 확인되지 않을 경우 `없음`이라고 단정하지 않고 `입력문서에서 확인되지 않음`으로 표시합니다.

## 10. 출처 / Traceability
- 각 SRS는 가능한 범위에서 Source Document, Source Location, Source Evidence를 유지합니다.
- 추적성은 향후 SRS → SWE.6 Test Case 연결의 기준점으로 사용합니다.

## 11. 관련 자료
- Requirement와 관련된 Source Table, Figure, Diagram, Signal/Parameter 정보가 확인되면 연결 정보를 기록합니다.
- 원본 자료를 우선 사용합니다.
- Source의 상태/전이/수치가 충분히 명시된 경우 이를 시각적으로 재구성할 수 있으나, `Requirement Studio 재구성 도식`임을 구분해야 합니다.
- 원문에 없는 상태, 값, 곡선, 연결관계를 새로 그리지 않습니다.
- V0.32 MVP에서는 관련 자료의 참조 정보를 우선 기록하며, 자동 도식 재생성/그래프 생성은 후속 고도화 대상으로 둡니다.

## 12. Gap / TBD / Conflict
- Requirement 작성에 필요한 정보가 부족하면 AI가 보완하여 완성하지 않습니다.
- 불명확, 미정, 상충 정보는 Gap/TBD/Conflict로 명시합니다.
- `입력문서에서 확인되지 않음`과 `존재하지 않음`은 서로 다른 의미로 취급합니다.

## 13. V0.32 산출물 범위
- `SWE.1 문서 (Word 파일)`: 실제 DOCX를 생성합니다.
- `SWE.1 문서 (엑셀 양식)`: 실제 XLSX를 생성합니다.
- `SWE.6 문서 (엑셀 양식)`: 동일 Canonical Requirement를 입력으로 Local SWE.6 Exporter에서 실제 XLSX를 생성합니다. 상세 규칙은 `SWE6_AUTHORING_GUIDE.md`를 따릅니다.
- SWE.1 Word/Excel과 SWE.6 Excel은 동일한 Canonical Requirement에서 파생되며, SWE.6는 Provider별 별도 Prompt로 직접 생성하지 않습니다.
