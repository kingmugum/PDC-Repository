@echo off
setlocal
cd /d "%~dp0\..\.."
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "tools\generate_e2e_practice_corpus_v0110.py"
) else (
  py -3 "tools\generate_e2e_practice_corpus_v0110.py"
)
if errorlevel 1 (echo [ERROR] 가상 변형 데이터 생성 실패) else (echo [OK] 200건 가상 변형 + 정적 검증 결과 생성)
pause
endlocal
