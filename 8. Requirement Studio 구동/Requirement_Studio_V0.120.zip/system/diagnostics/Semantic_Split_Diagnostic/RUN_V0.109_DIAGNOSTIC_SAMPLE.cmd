@echo off
setlocal
cd /d "%~dp0\..\.."
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "tools\run_semantic_split_diagnostic_samples.py"
) else (
  py -3 "tools\run_semantic_split_diagnostic_samples.py"
)
if errorlevel 1 (
  echo.
  echo [ERROR] 가상 재현 시험에 실패했습니다. Python 환경과 출력 내용을 확인하세요.
) else (
  echo.
  echo [OK] output 폴더에 99_의미분할_가상재현시험_*.txt 생성 완료
)
pause
endlocal
