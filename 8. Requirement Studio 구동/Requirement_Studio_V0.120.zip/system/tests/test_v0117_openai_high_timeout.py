"""V0.117 offline regression: OpenAI High and 300s without real token spending."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from providers.config_store import ProviderConfigStore
from providers.factory import create_provider


def api_config(tmp_path):
    store=ProviderConfigStore(tmp_path)
    cfg=store.load()
    cfg['commercial']['openai_api']['manual_api_key']='TEST_KEY_OFFLINE'
    return store,cfg


def test_shipped_config_is_300_high():
    root=Path(__file__).parents[1]
    cfg=json.loads((root/'config/provider_config.json').read_text(encoding='utf-8'))
    assert cfg['commercial']['openai_api']['timeout_seconds']==300
    assert cfg['commercial']['openai_api']['reasoning_effort']=='high'
    assert cfg['commercial']['gemini_api']['timeout_seconds']==300
    assert cfg['commercial']['claude_api']['timeout_seconds']==300
    assert cfg['hchat']['timeout_seconds']==120


def test_default_and_restart_persist_settings(tmp_path):
    store,cfg=api_config(tmp_path)
    openai=cfg['commercial']['openai_api']
    assert (openai['timeout_seconds'],openai['reasoning_effort'])==(300,'high')
    store.save(cfg)
    reloaded=ProviderConfigStore(tmp_path).load()
    assert (reloaded['commercial']['openai_api']['timeout_seconds'],reloaded['commercial']['openai_api']['reasoning_effort']) == (300,'high')


def test_stock_116_timeout_is_migrated_custom_timeout_is_preserved(tmp_path):
    store=ProviderConfigStore(tmp_path)
    cfg=store.load()
    old=cfg['commercial']['openai_api']
    old['timeout_seconds']=120
    old.pop('reasoning_effort',None)
    store.save(cfg)
    migrated=store.load()['commercial']['openai_api']
    assert migrated['timeout_seconds']==300 and migrated['reasoning_effort']=='high'
    cfg['commercial']['openai_api']['timeout_seconds']=220
    store.save(cfg)
    assert store.load()['commercial']['openai_api']['timeout_seconds']==220

@pytest.mark.parametrize('method', ['generate','vision'])
def test_responses_request_contains_high_and_uses_300_timeout(tmp_path,method):
    store,cfg=api_config(tmp_path)
    api=create_provider(tmp_path,'openai_api',cfg)
    calls=[]
    def post(url,key,payload,timeout):
        calls.append((url,key,payload,timeout))
        return {'output':[{'content':[{'type':'output_text','text':'OFFLINE_OK'}]}]}
    with patch.object(api,'_post',side_effect=post):
        if method=='generate':
            assert api.generate('extract facts',system_message='system')=='OFFLINE_OK'
        else:
            tiny=tmp_path/'one.png'
            tiny.write_bytes(b'png fixture bytes')
            assert api.generate_with_images('inspect image',[tiny])=='OFFLINE_OK'
    assert len(calls)==1
    url,key,payload,timeout=calls[0]
    assert url=='https://api.openai.com/v1/responses'
    assert key=='TEST_KEY_OFFLINE'
    assert timeout==300
    assert payload['model']=='gpt-6.1-sol'
    assert payload['reasoning']=={'effort':'high'}


def test_gemini_claude_custom_are_unaffected(tmp_path):
    store,cfg=api_config(tmp_path)
    for provider in ('gemini_api','claude_api'):
        cfg['commercial'][provider]['manual_api_key']='FIXTURE'
        api=create_provider(tmp_path,provider,cfg)
        assert api.timeout_seconds==300
        assert api.reasoning_effort==('high' if provider=='claude_api' else '')
    cfg['custom']['manual_api_key']='FIXTURE'
    custom=create_provider(tmp_path,'custom_api',cfg)
    assert custom.reasoning_effort==''


def test_timeout_does_not_retry_billable_request(tmp_path):
    import requests
    store,cfg=api_config(tmp_path)
    api=create_provider(tmp_path,'openai_api',cfg)
    calls=[]
    def fake_post(*args,**kwargs):
        calls.append(kwargs)
        raise requests.exceptions.ReadTimeout('OFFLINE')
    with patch('providers.custom_api_provider.requests.post',side_effect=fake_post):
        with pytest.raises(TimeoutError, match=r'300초'):
            api.generate('test')
    assert len(calls)==1
    assert calls[0]['timeout']==300
