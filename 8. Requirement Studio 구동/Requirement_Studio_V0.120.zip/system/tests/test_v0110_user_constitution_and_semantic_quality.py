"""V0.110 user-confirmed independent TC preference, display and meaning checks."""
from pathlib import Path
from core.engineering_condition_combinations import independent_scenarios
from core.basic_functional_test_design import build_basic_functional_cases
from core.semantic_objective_design import identify_conditional_path_goals
from core.e2e_exporter import E2EExporter


def _run(text):
    req={'srs_id':'SRS_DEMO','function_name':'가상 통신 제어','requirement':text,
         'processing_action':text,'acceptance_criteria':text,
         'preconditions':'CAN 통신 정상 상태',  # deliberately contradictory parent; branch must override
         'source_backed_atomic_behaviors':[{'source_fact_fragment_id':'FAKE-F1',
           'source_location':'synthetic source','behavior_text':text}]}
    base={'parent_srs_id':'SRS_DEMO','test_object_id':'DEMO_B1','test_object_type':'SYS5_CANDIDATE',
          'source_fact_fragment_ids':['FAKE-F1']}
    return req,build_basic_functional_cases({'requirements':[req]},[base])[0]


def test_conditional_parser_does_not_cut_korean_verb_sido():
    text=('CAN 통신이 정상인경우 마스터 제어기는 LIN 통신 복구를 시도하되 NM를 통해 Low Power Mode로 진입한다. '
          'CAN과 LIN 통신 오류인 경우 마스터 제어기는 Low Power Mode로 진입한다.')
    goals=identify_conditional_path_goals([{'fid':'FAKE-F1','text':text}])
    assert len(goals)==2
    assert '시도하되 NM' in goals[0].expected
    assert '복구를 시' not in goals[0].condition
    assert goals[0].condition.startswith('CAN 통신이 정상인경우')
    req,cases=_run(text)
    # The known named-intent classifier may run first; independent path parser
    # itself must nevertheless preserve the complete original expression.
    assert len(cases)>=2


def test_scenario_planner_generalizes_one_to_eight_conditions():
    assert len(independent_scenarios('AND',1))==2
    assert len(independent_scenarios('OR',2))==4
    assert len(independent_scenarios('XOR',2))==4
    assert len(independent_scenarios('NOR',2))==4
    for n in (3,4,5,6,7,8):
        for op in ('AND','OR','XOR','NOR'):
            cases=independent_scenarios(op,n)
            assert len(cases)>=n+1
            assert len({tuple(c['inputs']) for c in cases})==len(cases)
            assert all(len(c['inputs'])==n for c in cases)
    assert len(independent_scenarios('AND',8))<256
    assert [x['expected'] for x in independent_scenarios('XOR',2)]==[False,True,True,False]


def test_human_excel_cleans_meta_while_internal_keeps_provenance(tmp_path,monkeypatch):
    from core import e2e_exporter as ex
    cases=[{'parent_srs_id':'SRS_DEMO','test_object_id':'MOCK','test_object_type':'SYS5_CANDIDATE',
            'test_design_mode':'BASIC_FUNCTIONAL_SOURCE_BACKED','basic_case_kind':'BOOLEAN_CONDITION_COVERAGE',
            'evaluation_name':'A 거짓 조건', 'test_objective':'A가 거짓일 때 출력 상태 확인',
            'precondition':'A=거짓','test_execution':'A 거짓을 설정한다 (조건별 조작 가능 여부 확인 필요)',
            'expected_state':'출력 OFF (시험 설계 가설)',
            'pass_criterion':'[시험 설계 가설] 출력 OFF이면 PASS (원본 부정 동작 미명시)',
            'expectation_basis':'ENGINEERING_HYPOTHESIS','source_fact_fragment_ids':['FAKE-F1']}]
    monkeypatch.setattr(ex,'finalize_verification_single_truth',lambda *args,**kw:{
        'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
        'integrated_test_objects':cases,'basic_functional_design_audit':{}})
    req={'srs_id':'SRS_DEMO','requirement':'A 참이면 출력 ON'}
    dest=E2EExporter(tmp_path).export_evaluation_excel(Path('fictional.docx'),{'requirements':[req]})
    # Use OOXML to read display-only values for focused verification.
    import zipfile,xml.etree.ElementTree as ET
    with zipfile.ZipFile(dest) as z:
        xml=z.read('xl/worksheets/sheet4.xml')
        styles=z.read('xl/styles.xml')
    root=ET.fromstring(xml);ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    def text(ref):
        cel=root.find(f'.//m:c[@r="{ref}"]',ns)
        return ''.join(n.text or '' for n in cel.findall('.//m:t',ns)) if cel is not None else ''
    body=' | '.join(text(f'{letter}4') for letter in 'EFGHIJKLMNOP')
    assert '가설' not in body and '검토 필요' not in body and '원본 부정 동작' not in body
    assert '출력 OFF이면 PASS' in body
    assert text('Q4')==text('R4')==text('S4')==text('T4')==''
    assert '베이지 색상' in text('A1') and '보라색 색상' in text('A1')
    assert '[시험 설계 가설]' in cases[0]['pass_criterion']  # audit not mutated


def test_decision_table_one_independent_tc_per_source_row():
    text='''미러 상태 판단 표\nMirror_UnFldCtrlSta | Mirror_FldCtrlSta | 미러 상태\nAny | 0x1,0x2 | 접힘\n0x1 | Any | 접힘\n0x0,0x2,0x3 | 0x0,0x3 | 펼침'''
    from core.basic_functional_test_design import _pipe_decision_table_cases
    req={'srs_id':'SRS_DEMO','function_name':'미러 상태 판단','requirement':text,
         'processing_action':text,'acceptance_criteria':text,
         'source_backed_atomic_behaviors':[{'source_fact_fragment_id':'F-SYNTH','behavior_text':text}]}
    base={'parent_srs_id':'SRS_DEMO','test_object_id':'SYNTH','test_object_type':'SWE6_TC','source_fact_fragment_ids':['F-SYNTH']}
    cases,_=_pipe_decision_table_cases(req,base,1)
    assert len(cases)==3
    assert all(c['split_decision']=='SPLIT_EACH_DECISION_TABLE_ROW' for c in cases)
    assert all(len(c['test_vectors'])==1 for c in cases)
    assert [c['expected_state'] for c in cases]==['접힘','접힘','펼침']


def test_published_priority_policy_visible_in_prompt():
    from core.prompt_builder import PromptBuilder
    from core.semantic_split_diagnostic import prompt_guide_visibility
    root=Path(__file__).resolve().parents[1]
    diag=prompt_guide_visibility(root)
    assert diag['priority_policy_chars']>200
    assert diag['priority_policy_chars']<2200
    assert diag['editorial_truncated_chars']>=0


def test_generalized_xor_nor_from_structured_source_atoms():
    from core.basic_functional_test_design import _explicit_boolean_transition_cases
    from core.engineering_condition_combinations import expected_truth
    for logic in ('XOR','NOR'):
        names=['입력 A ON','입력 B ON']
        fids=['FAKED-A','FAKED-B']
        req={'srs_id':'SRS_LOGIC','function_name':'가상 모드','requirement':'입력 A ON 또는 입력 B ON 조건에서 모드 진입',
             'output':'모드 진입','source_backed_atomic_behaviors':[
                 {'source_fact_fragment_id':f,'behavior_text':t} for f,t in zip(fids,names)]}
        base={'parent_srs_id':'SRS_LOGIC','test_object_id':'SYNTH-LOGIC','test_object_type':'SYS5_CANDIDATE',
              'transition_family':'mode_transition','expected_target_state':'모드 진입',
              'source_fact_fragment_ids':fids,'condition_logic':logic,'condition_texts':names,
              'condition_fragment_ids':fids}
        cases,_=_explicit_boolean_transition_cases(req,base,1)
        assert len(cases)==4
        actual=[]
        for c in cases:
            states=tuple(d['expected'] for d in c['boolean_condition_states'])
            assert bool(c['expectation_basis']=='SOURCE_EXPLICIT')==expected_truth(logic,states)
            assert len(c['test_vectors'])==1
            actual.append(states)
        assert len(set(actual))==4


def test_two_condition_and_or_exhaustive_and_five_condition_bounded():
    from core.basic_functional_test_design import _explicit_boolean_transition_cases
    for logic in ('ALL_OF','ANY_OF'):
        for n in (2,5):
            names=[f'조건{c} 성립' for c in range(n)]
            fids=[f'F{c}' for c in range(n)]
            req={'srs_id':'SRS_LOGIC','requirement':' '.join(names)+' 제어 모드 진입',
                'output':'제어 모드 진입', 'source_backed_atomic_behaviors':[
                    {'source_fact_fragment_id':fid,'behavior_text':label} for fid,label in zip(fids,names)]}
            base={'parent_srs_id':'SRS_LOGIC','test_object_id':'SYNTH','test_object_type':'SYS5_CANDIDATE',
                  'transition_family':'mode_transition','expected_target_state':'제어 모드 진입',
                  'source_fact_fragment_ids':fids,'condition_logic':logic,
                  'condition_texts':names,'condition_fragment_ids':fids}
            cases,_=_explicit_boolean_transition_cases(req,base,1)
            assert len(cases)==(4 if n==2 else n+1)
            assert len({tuple(x['expected'] for x in c['boolean_condition_states']) for c in cases})==len(cases)


def test_two_hundred_synthetic_variants_registry_and_coverage():
    from tools.generate_e2e_practice_corpus_v0110 import make_corpus
    from core.engineering_condition_combinations import independent_scenarios
    data=make_corpus()
    assert len(data)==200
    assert len({x['id'] for x in data})==200
    assert len({x['practice_requirement'] for x in data})==200
    assert len({x['source_judgment_id'] for x in data})==20
    assert not any(x['source_type']!='FICTIONAL_PRACTICE' for x in data)
    for row in data:
        assert row['expected_independent_tc_count']>=0
        if row['pattern_kind'] in ('AND','OR','XOR','NOR'):
            assert row['expected_independent_tc_count']==len(independent_scenarios(
                row['pattern_kind'],row['condition_count']))
