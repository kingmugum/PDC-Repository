"""V1.00: sourced condition names, readable vectors, no invented negative verdict."""
from pathlib import Path
from core.basic_functional_test_design import _explicit_boolean_transition_cases
from core.e2e_exporter import _compact_input_value, E2EExporter
from core.e2e_decision_log import build_e2e_decision_summary
from tests.test_v082_integrated_specs_single_truth import _mode_fixture
from core.verification_single_truth import build_e2e_evaluation_cases,build_integrated_test_objects
from core.swe6_exporter import build_swe6_cases,build_sys5_candidates


def _candidates():
    data=_mode_fixture()
    objs=build_integrated_test_objects(data,build_swe6_cases(data),build_sys5_candidates(data))
    objectives=build_e2e_evaluation_cases(data,objs)
    out={}
    for req in data['requirements']:
        base=next(x for x in objectives if x.get('parent_srs_id')==req['srs_id'] and x.get('test_object_type') in {'SYS5_CANDIDATE','SWE6_TC'})
        cases,_=_explicit_boolean_transition_cases(req,base,1)
        out[req['srs_id']]=cases
    return out


def test_v100_human_or_names_not_numeric_placeholder():
    c=_candidates()['SRS_005']
    assert len(c)==5  # plus all-false proposed negative scenario
    assert c[-1]['expectation_basis']=='ENGINEERING_HYPOTHESIS'
    assert 'ON 명령 수신' in c[0]['pass_criterion']
    assert '조건 1' not in c[0]['pass_criterion']
    assert 'B-CAN WAKE UP' in c[1]['pass_criterion']
    assert 'High Power Mode' in c[1]['pass_criterion']
    assert 'OFF 명령' not in c[0]['pass_criterion']  # never mix low-power fact with high-power target
    assert '1) ON 명령 수신' in c[0]['test_execution']
    assert '[\'' not in _compact_input_value(c[0])
    assert '1) ON 명령 수신' in _compact_input_value(c[0])
    assert c[0]['boolean_condition_states'][0]['source_fact_fragment_id'] == 'F-HIGH-1'


def test_v100_human_and_negative_has_no_made_up_pass():
    c=_candidates()['SRS_004']
    assert len(c)==5
    assert all('조건 1' not in x['test_objective'] for x in c)
    assert '무드램프 OFF' in c[2]['test_objective']
    assert all('시험 설계 가설' in x['pass_criterion'] and '시험 설계 가설' in x['expected_state'] for x in c[1:])
    assert all(x['human_review_required'] for x in c[1:])
    assert all(x['expectation_basis']=='ENGINEERING_HYPOTHESIS' for x in c[1:])
    assert '최종' in c[1]['required_resolution']


def test_v100_summary_contains_named_conditions_not_generic_numbers():
    cases=_candidates()['SRS_005']
    txt=build_e2e_decision_summary(source_document=Path('MLM.docx'),cases=cases,human_ids=[f'SRS_TC_{i:03}' for i in range(1,len(cases)+1)],reqs={'SRS_005':{}})
    assert '실제 조건:' in txt
    assert 'ON 명령 수신 시=참' in txt
    assert '조건 1 단독 충족' not in txt
    assert 'B-CAN WAKE UP' in txt


def test_v100_export_does_not_fill_negative_pass_from_parent(tmp_path):
    import core.e2e_exporter as exp
    import zipfile,xml.etree.ElementTree as ET
    cases=_candidates()['SRS_004']
    req=_mode_fixture()['requirements'][0]
    # internal single-truth already finalized - feed a controlled scoped fixture to exporter
    def patched(*args,**kwargs):
        return {'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
                'integrated_test_objects':cases,'basic_functional_design_audit':{},
                'single_truth_audit':{},'semantic_verification_quality_audit':{}}
    old=exp.finalize_verification_single_truth
    exp.finalize_verification_single_truth=patched
    try:
        out=E2EExporter(tmp_path).export_evaluation_excel(Path('MLM.docx'),{'requirements':[req]})
    finally:
        exp.finalize_verification_single_truth=old
    NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(out) as z:
        root=ET.fromstring(z.read('xl/worksheets/sheet4.xml'))
    def value(ref):
        node=root.find(f'.//m:sheetData/m:row/m:c[@r="{ref}"]',NS)
        return ''.join(t.text or '' for t in node.findall('.//m:t',NS)) if node is not None else ''
    assert 'OFF 명령' in value('P4')
    assert '[시험 설계 가설]' not in value('P5')  # hypothesized, not positive parent acceptance criterion
    assert 'OFF 명령 수신' in value('K4')
    assert '[\'' not in value('K4')
    assert '최종 검토 대상' not in value('R5')  # reviewer status moved to review sheet
