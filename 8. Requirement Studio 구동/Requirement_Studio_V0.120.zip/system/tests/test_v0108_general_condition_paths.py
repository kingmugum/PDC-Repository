"""V0.108: general, provenance-linked split beyond named subsystem patterns."""
from pathlib import Path
from openpyxl import load_workbook
from core.semantic_objective_design import identify_conditional_path_goals
from core.basic_functional_test_design import build_basic_functional_cases
from core.e2e_exporter import E2EExporter


def _req(text, sid='SRS_DEMO'):
    return {'srs_id':sid,'function_name':'가상 자동 장치 동작',
            'requirement':text,'acceptance_criteria':text,'processing_action':text,
            'source_backed_atomic_behaviors':[{'source_fact_fragment_id':'FAKE-SRC-01',
                'source_location':'fictional demonstration','behavior_text':text}]}


def _make(text):
    base={'parent_srs_id':'SRS_DEMO','test_object_id':'FAKE_OBJ_01','test_object_type':'SYS5_CANDIDATE',
          'source_fact_fragment_ids':['FAKE-SRC-01']}
    return build_basic_functional_cases({'requirements':[_req(text)]},[base])[0]


def test_general_source_literal_paths_not_preprogrammed():
    text='센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.'
    cases=_make(text)
    assert len(cases)==2
    assert {c.get('semantic_goal_kind') for c in cases}=={
        'GENERAL_CONDITIONAL_PATH_01','GENERAL_CONDITIONAL_PATH_02'}
    assert all(c['source_fact_fragment_ids']==['FAKE-SRC-01'] for c in cases)
    assert {c.get('execution_basis') for c in cases}=={'ENGINEERING_PROPOSED_STEP'}
    assert '청색 램프를 점등한다' in cases[0]['pass_criterion']
    assert '컨베이어를 정지한다' in cases[1]['pass_criterion']
    assert all(c['engineering_decision_record']['rule']=='EXPLICIT_CONDITIONAL_PATH_PROPOSAL' for c in cases)
    assert all('0x' not in str(c) for c in cases)


def test_no_unrelated_single_condition_expansion():
    cases=_make('센서 A 감지 시 장비는 청색 램프를 점등한다.')
    assert len(cases)==1
    assert cases[0].get('semantic_goal_kind') is None


def test_untraced_or_unspecified_facts_not_promoted():
    text='센서 A 감지 시 청색 램프를 점등한다. 센서 B 감지 시 컨베이어를 정지한다.'
    assert identify_conditional_path_goals([{'fid':'','text':text}])==[]
    assert identify_conditional_path_goals([{'fid':'F1','text':'센서 A 감지 시 장비를 작동한다.'}])==[]


def test_sheet_renaming_and_log_explains_proposal(tmp_path,monkeypatch):
    from core import e2e_exporter as mod
    text='센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.'
    cases=_make(text)
    monkeypatch.setattr(mod,'finalize_verification_single_truth',lambda *a,**kw:{
        'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,'integrated_test_objects':cases,
        'basic_functional_design_audit':{},'single_truth_audit':{},'semantic_verification_quality_audit':{}})
    out=E2EExporter(tmp_path).export_evaluation_excel(Path('invented.docx'),{'requirements':[_req(text)]})
    wb=load_workbook(out)
    try:
        assert wb.sheetnames==['표지','0_변경이력','1_평가요약','2_E2E_평가케이스','3_요구사항-평가추적성']
        assert wb['2_E2E_평가케이스'].max_column==20
        assert wb['3_요구사항-평가추적성'].max_column==8
        assert wb['2_E2E_평가케이스']['L4'].fill.fgColor.rgb.endswith('FAF1E5')
    finally:
        wb.close()
    log=next(tmp_path.glob('00_E2E_판단근거_요약_*.txt')).read_text(encoding='utf-8-sig')
    assert 'EXPLICIT_CONDITIONAL_PATH_PROPOSAL' in log
    assert '입력 조작 방법은 미확정' in log
