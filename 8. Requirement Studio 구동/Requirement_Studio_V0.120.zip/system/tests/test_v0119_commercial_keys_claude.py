"""V0.119 offline: source code + files + commercial request payload, no live paid API."""
from pathlib import Path
import tempfile
import shutil
import json
from unittest.mock import patch
import pytest

from providers.commercial_credentials import credential_folder, list_credential_files, read_credential_file, selected_credential
from providers.config_store import ProviderConfigStore, CLAUDE_COMMERCIAL_MODELS
from providers.factory import create_provider

ROOT = Path(__file__).resolve().parents[1]
MODELS = ('claude-sonnet-5-5','claude-opus-5-5','claude-fable-5-1','claude-haiku-5-5')


def test_claude_catalog_and_protocol_default():
    cfg = json.loads((ROOT/'config/provider_config.json').read_text('utf-8'))
    c = cfg['commercial']['claude_api']
    assert CLAUDE_COMMERCIAL_MODELS == MODELS
    assert c['model_options'] == list(MODELS)
    assert (c['model'],c['timeout_seconds'],c['reasoning_effort'],c['thinking_mode']) == (MODELS[0], 300,'high','adaptive')
    assert (c['auth_mode'], c['api_key_name'], c['version_header_value']) == ('x-api-key','x-api-key','2023-06-01')


@pytest.mark.parametrize('provider,folder', [('openai_api','openai'),('gemini_api','gemini'),('claude_api','claude'),('custom_api','custom')])
def test_provider_key_folder_isolated_and_selection(tmp_path,provider,folder):
    home=credential_folder(tmp_path,provider)
    assert home == tmp_path/'api_keys'/'commercial'/folder
    home.mkdir(parents=True)
    (home/'B.txt').write_text('second-SECRET',encoding='utf-8')
    (home/'A.txt').write_text('first-SECRET\n',encoding='utf-8')
    assert [p.name for p in list_credential_files(tmp_path,provider)]==['A.txt','B.txt']
    assert selected_credential(tmp_path,provider)==('first-SECRET','A.txt')
    assert selected_credential(tmp_path,provider,'B.txt')==('second-SECRET','B.txt')
    assert selected_credential(tmp_path,provider,'deleted.txt')==('','')
    for other in set(['openai_api','gemini_api','claude_api','custom_api'])-{provider}:
        assert selected_credential(tmp_path,other)==('','')


def test_reject_invalid_secret_and_symlink(tmp_path):
    home=credential_folder(tmp_path,'claude_api');home.mkdir(parents=True)
    for bad in ['','line1\nline2','with spaces\n','\n']:
        (home/'key.txt').write_text(bad,encoding='utf-8')
        with pytest.raises(ValueError): read_credential_file(home/'key.txt',home)
    (home/'key.txt').write_text('X'*4097,encoding='utf-8')
    with pytest.raises(ValueError): read_credential_file(home/'key.txt',home)
    (home/'key.txt').unlink()
    target=tmp_path/'outside.txt';target.write_text('SECRET',encoding='utf-8')
    (home/'key.txt').symlink_to(target)
    assert list_credential_files(tmp_path,'claude_api')==[]
    with pytest.raises(ValueError): read_credential_file(home/'key.txt',home)


def test_key_files_not_saved_to_config(tmp_path):
    store = ProviderConfigStore(tmp_path)
    cfg=store.load()
    assert 'manual_api_key' not in cfg['commercial']['claude_api']
    assert 'api_keys' not in store.path.read_text('utf-8')


@pytest.mark.parametrize('model',MODELS)
def test_claude_text_and_image_requests(model,tmp_path):
    cfg=ProviderConfigStore(tmp_path).load()
    settings=cfg['commercial']['claude_api']
    settings['model']=model
    settings['manual_api_key']='FIXTURE-DO-NOT-SHARE'
    settings['credential_source']='TXT 키 파일'
    api=create_provider(tmp_path,'claude_api',cfg)
    calls=[]
    def fake_post(url,key,body,timeout):
        calls.append((url,key,body,timeout))
        return {'content':[{'type':'text','text':'{"ok":true}'}], 'stop_reason':'end_turn'}
    api._post=fake_post
    assert api.generate('도어핸들 분석',system_message='json only')=='{"ok":true}'
    from PIL import Image
    image=tmp_path/'sample.png';Image.new('RGB',(6,6),'white').save(image)
    assert api.generate_with_images('그림 분석',[image])=='{"ok":true}'
    assert len(calls)==2
    for url,key,body,timeout in calls:
        assert url=='https://api.anthropic.com/v1/messages'
        assert key=='FIXTURE-DO-NOT-SHARE'
        assert (body['model'],timeout)==(model,300)
        assert body['thinking']=={'type':'adaptive'}
        assert body['output_config']=={'effort':'high'}
        assert body['max_tokens']==32768
    assert calls[1][2]['messages'][0]['content'][0]['type']=='image'
    headers,_=api._request_auth('FIXTURE')
    assert headers['x-api-key']=='FIXTURE' and headers['anthropic-version']=='2023-06-01'
    assert api.metadata().credential_status=='TXT 키 파일'


def test_claude_truncated_response_fails_without_retry(tmp_path):
    cfg=ProviderConfigStore(tmp_path).load()
    cfg['commercial']['claude_api']['manual_api_key']='FIXTURE'
    api=create_provider(tmp_path,'claude_api',cfg)
    calls=[]
    def fake(url,key,body,timeout):
        calls.append(1)
        return {'content':[{'type':'text','text':'partial'}], 'stop_reason':'max_tokens'}
    api._post=fake
    with pytest.raises(RuntimeError,match='토큰 한도'):
        api.generate('long text')
    assert len(calls)==1


def test_old_config_upgrade_preserves_custom_choices(tmp_path):
    store=ProviderConfigStore(tmp_path)
    old=store.load()
    old['commercial']['claude_api'].update(model='claude-sonnet-4-5',model_options=['claude-sonnet-4-5'],timeout_seconds=120,max_tokens=4096)
    old['commercial']['claude_api'].pop('reasoning_effort',None)
    old['commercial']['claude_api'].pop('thinking_mode',None)
    store.save(old)
    newer=store.load()['commercial']['claude_api']
    assert newer['model']==MODELS[0] and newer['timeout_seconds']==300 and newer['max_tokens']==32768
    old['commercial']['claude_api'].update(model='special-private-model',model_options=['special-private-model'],timeout_seconds=600,max_tokens=10000)
    store.save(old)
    chosen=store.load()['commercial']['claude_api']
    assert chosen['model']=='special-private-model' and chosen['timeout_seconds']==600 and chosen['max_tokens']==10000


def test_gui_manual_key_precedence_and_no_secrets_in_status():
    src=(ROOT/'main.py').read_text('utf-8')
    assert 'APP_VERSION = "v0.120"' in src
    assert 'key = explicit or file_key' in src
    assert '수동 입력되었습니다' in src
    assert 'status = file_name' in src
    assert 'def _clear_commercial_manual_key' in src
    assert 'def _on_key_status_clicked' in src
    assert 'api_keys' in src
