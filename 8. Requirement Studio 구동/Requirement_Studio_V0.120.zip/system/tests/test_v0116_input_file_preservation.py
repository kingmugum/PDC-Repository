"""V0.116 regression: imported documents are never disposed of as app cache."""

from __future__ import annotations

from pathlib import Path
import re

import pytest

from core.document_manager import DocumentManager


def _put(folder: Path, name: str, content: bytes) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / name
    p.write_bytes(content)
    return p


def test_select_input_pdf_keeps_real_file_and_registers_it(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    src = _put(manager.input_dir, 'test.pdf', b'%PDF-1.4 local')
    assert manager.import_documents([src]) == [src]
    assert src.read_bytes() == b'%PDF-1.4 local'
    assert manager.get_documents() == [src]


def test_select_external_copies_and_preserves_original_and_unselected_files(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    stale = _put(manager.input_dir, 'previous.pdf', b'USER ORIGINAL')
    source = _put(tmp_path / 'external', 'new.pdf', b'NEW PDF')
    selected = manager.import_documents([source])
    assert selected == [manager.input_dir / 'new.pdf']
    assert selected[0].read_bytes() == source.read_bytes()
    assert stale.read_bytes() == b'USER ORIGINAL'
    assert manager.get_documents() == selected
    assert len(manager.list_documents()) == 2


def test_manual_paste_into_input_then_refresh_keeps_document(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    target = _put(manager.input_dir, 'pasted.pdf', b'KEEP PASTED')
    assert manager.select_all_from_input() == [target]
    assert target.exists()


def test_duplicate_selection_is_idempotent_without_deleting_source(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    source = _put(tmp_path / 'external', 'abc.pdf', b'ABC')
    first = manager.import_documents([source]); second = manager.import_documents([source])
    assert first == second
    assert len(manager.list_documents()) == 1
    assert source.read_bytes() == b'ABC'


def test_collision_different_bytes_uses_new_name_without_overwriting(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    existing = _put(manager.input_dir, 'abc.pdf', b'FIRST')
    incoming = _put(tmp_path / 'external', 'abc.pdf', b'SECOND')
    selected = manager.import_documents([incoming])
    assert existing.read_bytes() == b'FIRST'
    assert selected == [manager.input_dir / 'abc_2.pdf']
    assert selected[0].read_bytes() == b'SECOND'
    assert incoming.read_bytes() == b'SECOND'


def test_batch_two_same_names_different_bytes_is_safe(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    a = _put(tmp_path / 'a', 'abc.pdf', b'1')
    b = _put(tmp_path / 'b', 'abc.pdf', b'2')
    selected = manager.import_documents([a, b])
    assert [p.name for p in selected] == ['abc.pdf', 'abc_2.pdf']
    assert [p.read_bytes() for p in selected] == [b'1', b'2']


def test_cancellation_or_failed_selection_preserves_previous_active_and_files(tmp_path, monkeypatch):
    manager = DocumentManager(tmp_path / 'input')
    old = _put(manager.input_dir, 'old.pdf', b'old original')
    manager.import_documents([old])
    with pytest.raises(ValueError):
        manager.import_documents([tmp_path / 'not_found.pdf'])
    assert manager.get_documents() == [old]
    assert old.read_bytes() == b'old original'
    # File dialog Cancel emits no selection; the manager never changes state.
    assert manager.get_documents() == [old]


def test_copy_failure_removes_only_own_temporary_file(tmp_path, monkeypatch):
    import core.document_manager as mod
    manager = DocumentManager(tmp_path / 'input')
    existing = _put(manager.input_dir, 'old.pdf', b'user data')
    manager.import_documents([existing])
    external = _put(tmp_path / 'external', 'new.pdf', b'new')
    def fail_copy(*args, **kwargs):
        raise PermissionError('simulated copy error')
    monkeypatch.setattr(mod.shutil, 'copy2', fail_copy)
    with pytest.raises(PermissionError):
        manager.import_documents([external])
    assert existing.read_bytes() == b'user data'
    assert manager.get_documents() == [existing]
    assert not list(manager.input_dir.glob('._rs_import_*'))
    assert not (manager.input_dir / 'new.pdf').exists()
    assert external.read_bytes() == b'new'


def test_after_restart_input_persists_and_is_selectable(tmp_path):
    old_manager = DocumentManager(tmp_path / 'input')
    source = _put(old_manager.input_dir, 'stays.pdf', b'forever')
    old_manager.import_documents([source])
    new_manager = DocumentManager(tmp_path / 'input')
    assert new_manager.get_documents() == [source]
    assert source.read_bytes() == b'forever'


def test_multiple_selection_then_refresh_can_include_newly_pasted_input(tmp_path):
    manager = DocumentManager(tmp_path / 'input')
    a = _put(manager.input_dir, 'a.pdf', b'a')
    b = _put(manager.input_dir, 'b.docx', b'b')
    assert manager.import_documents([a]) == [a]
    assert manager.get_documents() == [a]
    assert manager.select_all_from_input() == [a, b]


def test_main_import_path_does_not_delete_user_input():
    src = (Path(__file__).resolve().parents[1] / 'main.py').read_text(encoding='utf-8')
    method = src.split('    def import_input_files(self, path_list):', 1)[1].split('    def open_input_folder(self):', 1)[0]
    assert 'self.documents.import_documents(path_list)' in method
    assert 'existing.unlink' not in method
    assert '.rmtree(' not in method
    assert 'self.documents.select_all_from_input()' in method
    assert 'self.documents.get_documents()' in src


def test_regression_workflow_without_external_api(tmp_path):
    # Pipeline receives the selected file list; the actual E2E pipeline is
    # tested separately by the pre-existing regression suite.
    manager = DocumentManager(tmp_path / 'input')
    source = _put(tmp_path / 'external', 'one.pdf', b'%PDF-1.4 fake')
    docs = manager.import_documents([source])
    assert manager.get_documents() == docs
    assert all(p.is_file() for p in docs)


def test_commercial_api_read_timeout_is_not_retried_and_explains_next_step(tmp_path, monkeypatch):
    import requests
    from providers.custom_api_provider import CustomApiProvider
    import providers.custom_api_provider as mod
    calls = []
    def fake_post(*args, **kwargs):
        calls.append((args, kwargs))
        raise requests.exceptions.ReadTimeout('read timeout=120')
    monkeypatch.setattr(mod.requests, 'post', fake_post)
    provider = CustomApiProvider(tmp_path, {
        'profile': 'openai_responses',
        'base_url': 'https://api.openai.com/v1',
        'model': 'gpt-6.1-sol',
        'manual_api_key': 'TEST_ONLY_LOCAL',
        'timeout_seconds': 120,
    })
    with pytest.raises(TimeoutError, match='120초') as exc:
        provider.generate('short prompt')
    assert '자동 재요청하지 않았습니다' in str(exc.value)
    assert len(calls) == 1
    assert calls[0][1]['timeout'] == 120


def test_new_file_arriving_during_copy_is_never_overwritten(tmp_path, monkeypatch):
    import core.document_manager as mod
    manager=DocumentManager(tmp_path/'input')
    existing=_put(manager.input_dir,'old.pdf',b'OLD')
    manager.import_documents([existing])
    external=_put(tmp_path/'external','raced.pdf',b'NEW')
    orig_link=mod.os.link
    def simulate_race(staged, target):
        Path(target).write_bytes(b'USER COPY AT SAME TIME')
        return orig_link(staged,target)
    monkeypatch.setattr(mod.os,'link',simulate_race)
    with pytest.raises(FileExistsError):
        manager.import_documents([external])
    assert (manager.input_dir/'raced.pdf').read_bytes()==b'USER COPY AT SAME TIME'
    assert manager.get_documents()==[existing]
    assert not list(manager.input_dir.glob('._rs_import_*'))
