"""V0.103: presentation-only hypothesis styling, readable conditions, safe cross-domain de-dup."""
from pathlib import Path
from copy import deepcopy
from openpyxl import load_workbook

from core.basic_functional_test_design import (
    _deduplicate_cross_domain, _readable_boolean_condition,
)
from core.e2e_exporter import E2EExporter
from core.e2e_decision_log import build_e2e_decision_summary
from tests.test_v100_human_boolean_labels import _candidates


def _swe_sys_pair():
    a=dict(parent_srs_id='SRS_006',basic_case_kind='SOURCE_BACKED_FALLBACK',
           test_object_type='SYS5_CANDIDATE',test_object_id='TC_SYS',
           source_fact_fragment_ids=['FRAG_SYS'],source_semantic_unit_ids=['SEM_SYS'],
           precondition='제어기 동작 중 SW 오류 발생',input_variable='',input_compare='',
           input_value='',output_variable='',output_compare='',output_value='',
           expected_state='초기 B+ 상태',pass_criterion='MCU Reset 이후 초기 B+ 상태로 복귀',
           test_execution='MCU Reset을 발생시키고 상태를 확인한다.',
           human_review_required=True)
    b=deepcopy(a)
    b.update(test_object_type='SWE6_TC',test_object_id='TC_SWE',
             source_fact_fragment_ids=['FRAG_SWE'],source_semantic_unit_ids=['SEM_SWE'],
             test_execution='SW 오류 발생 시 MCU Reset을 통해 정상 상태로 복귀해야 한다.')
    return a,b


def test_exact_cross_domain_duplicate_is_one_case_with_both_provenances():
    a,b=_swe_sys_pair()
    result,merged=_deduplicate_cross_domain([a,b])
    assert len(result)==1 and len(merged)==1
    assert set(result[0]['merged_test_object_types'])=={'SWE6_TC','SYS5_CANDIDATE'}
    assert set(result[0]['source_fact_fragment_ids'])=={'FRAG_SYS','FRAG_SWE'}
    assert set(result[0]['merged_source_object_ids'])=={'TC_SYS','TC_SWE'}
    log=build_e2e_decision_summary(source_document=Path('fictional.docx'),cases=result,
          human_ids=['SRS_TC_001'],reqs={},design_audit={'cross_domain_duplicate_merges':merged})
    assert 'TC_SYS + TC_SWE' in log and 'FRAG_SWE' in log


def test_different_pass_or_controlled_input_is_not_merged():
    a,b=_swe_sys_pair()
    b['pass_criterion']='내부 상태만 확인'
    assert len(_deduplicate_cross_domain([a,b])[0])==2
    b['pass_criterion']=a['pass_criterion']
    b['input_variable']='InternalResetFlag'
    assert len(_deduplicate_cross_domain([a,b])[0])==2


def test_natural_condition_false_does_not_hallucinate_sleep():
    assert _readable_boolean_condition('OFF 명령 수신 시',True)=='OFF 명령 수신'
    assert _readable_boolean_condition('OFF 명령 수신 시',False)=='OFF 명령 수신 안됨'
    assert _readable_boolean_condition('무드램프 OFF 상태',False)=='무드램프 ON 상태'
    assert _readable_boolean_condition('B-CAN WAKE UP 상태',False)=='B-CAN WAKE UP 상태가 아님'
    assert _readable_boolean_condition('최초B+ 인가 시',False)=='최초 B+ 인가 상황이 아님'
    assert _readable_boolean_condition('TRANSCEIVER ERR PIN HIGH에서 LOW 전환 시',False).endswith('발생하지 않음')


def test_e2e_sheet_contract_22_cols_legend_beige_and_unrun_blank(tmp_path,monkeypatch):
    import core.e2e_exporter as export_module
    cases=_candidates()['SRS_004']
    monkeypatch.setattr(export_module,'finalize_verification_single_truth',lambda *args,**kwargs:{
       'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
       'integrated_test_objects':cases,'basic_functional_design_audit':{},
       'single_truth_audit':{},'semantic_verification_quality_audit':{},
    })
    path=E2EExporter(tmp_path).export_evaluation_excel(Path('fictional.docx'),{'requirements':[]})
    wb=load_workbook(path)
    try:
        ws=wb['2_E2E_평가케이스']
        assert ws.max_column==20
        assert ws['Q3'].value=='실제 출력값'
        assert ws['T3'].value=='결과 화면 캡처'
        assert '베이지 색상으로 된 셀' in ws['A1'].value and '보라색 색상으로 된 셀' in ws['A1'].value
        assert ws['A1'].font.sz==10
        assert '검토 사유 / 필요 조치' not in [ws.cell(3,c).value for c in range(1,21)]
        assert ws['A4'].fill.fgColor.rgb != ws['A5'].fill.fgColor.rgb
        assert ws['P5'].fill.fgColor.rgb.endswith('FAF1E5')
        assert '시험 설계 가설' not in str(ws['P5'].value)
        assert '시험 설계 가설' not in str(ws['O5'].value)
        assert 'OFF 명령 수신 안됨' in str(ws['K5'].value)
        assert ws['K5'].alignment.horizontal=='left'
        for row in range(4,ws.max_row+1):
            for col in range(17,21):
                assert ws.cell(row,col).value is None
        assert '3_검토필요' not in wb.sheetnames
    finally:
        wb.close()
    log=next(tmp_path.glob('00_E2E_판단근거_요약_*.txt')).read_text('utf-8-sig')
    assert '판정 가설(원본 미명시)' in log
    assert '사람용 조건:' in log
