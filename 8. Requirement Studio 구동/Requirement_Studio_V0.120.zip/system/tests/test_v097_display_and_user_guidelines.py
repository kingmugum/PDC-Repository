"""V0.97: bounded GUI label width, Source-preserving human presentation and guide."""
from pathlib import Path
from core.e2e_exporter import _format_tc_preconditions, _format_tc_execution
from core.prompt_builder import PromptBuilder

ROOT = Path(__file__).resolve().parents[1]


def test_gui_file_drop_label_not_ignored_or_clipped():
    text = (ROOT / 'main.py').read_text(encoding='utf-8')
    block = text.split('class FileDropZone', 1)[1].split('class LoadingDotsIndicator', 1)[0]
    assert 'self.title_label.setMinimumWidth(238)' in block
    assert 'QSizePolicy.Policy.Ignored' not in block
    assert 'self.title_label.setWordWrap(False)' in block
    assert '문서 {count}개가 준비되었습니다.' in block
    assert '파일을 선택하세요' in block
    assert 'APP_VERSION = "v0.120"' in text


def test_tc_preconditions_number_only_meaningful_clauses():
    source = '무드램프 OFF 상태, 슬레이브 제어기 SLEEP(OFF) 상태, B-CAN SLEEP MODE 상태 OFF 명령 수신'
    expected = ('① 무드램프 OFF 상태\n② 슬레이브 제어기 SLEEP(OFF) 상태\n'
                '③ B-CAN SLEEP MODE 상태 OFF 명령 수신')
    assert _format_tc_preconditions(source) == expected
    assert _format_tc_preconditions('단일 조건') == '단일 조건'
    # Numeric comma groups must not accidentally be treated as individual preconditions.
    assert _format_tc_preconditions('0x1, 0x2, 0x3') == '0x1, 0x2, 0x3'
    # Raw Source is unchanged.
    assert source.startswith('무드램프 OFF 상태,')


def test_tc_execution_removes_internal_prefix_without_inventing_technical_action():
    raw = 'Source-backed SWE.6 검증 intent: 무드램프 마스터 제어기는 AVN 정보를 CAN 통신으로 전달 받아'
    out = _format_tc_execution(raw)
    assert out == '무드램프 마스터 제어기는 AVN 정보를 CAN 통신으로 전달받는다.'
    assert 'Source-backed' not in out
    assert _format_tc_execution('제어기는 상태를 관찰한다.') == '제어기는 상태를 관찰한다.'


def test_guide_separates_user_rules_from_unverified_case_details():
    guide = (ROOT / 'Build AI Better Decision' / 'Decision Complete' /
             'AI_E2E_GUIDELINE_CONSTITUTION.txt').read_text(encoding='utf-8')
    assert '[USER_EDITORIAL_GUIDE_START]' in guide
    assert '[USER_EDITORIAL_GUIDE_END]' in guide
    assert '[B-TC003]' in guide and '네 조건' in guide
    assert '[C-02]' in guide and '60ms' in guide
    assert '자동 Rule 승인 아님' in guide
    # Verify prompt construction uses *only* compact authored rules, not raw unresolved TC rows.
    src = (ROOT / 'core/prompt_builder.py').read_text(encoding='utf-8')
    assert 'editorial = (e2e_guide.split(a, 1)' in src
    assert 'editorial = editorial[:3200]' in src
    assert '[AI_E2E_USER_EDITORIAL_GUIDE_NOT_SOURCE]' in src


def test_existing_registries_are_not_automatically_promoted():
    import json
    registry = json.loads((ROOT / 'policy' / 'guideline_rule_registry.json').read_text(encoding='utf-8'))
    assert registry
    txt = (ROOT / 'docs/V0.97_TC_사용자판단_학습해석.txt').read_text(encoding='utf-8')
    assert '미구현' in txt
