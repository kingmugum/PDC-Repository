from pathlib import Path
from zipfile import ZipFile
import json

import core.better_decision as better


def dummy_data():
    requirements=[]
    cases=[]
    cats=[('5초 이내 timeout 확인','미응답 시 5초 timing checkpoint','TIMEOUT'),
          ('전압 출력 확인','제어 출력 0x1','DIRECT'),
          ('차종 variant 전용 상태','HEV/EV 변형 조건','VARIANT'),
          ('전원 상태전이 확인','상태전이 순차 step','TRANSITION'),
          ('미정의 응답 검토','미정의 기대값','REVIEW')]
    for n,(name,description,mode) in enumerate(cats,1):
        sid=f'SRS_{n:03d}'
        requirements.append({'srs_id':sid,'requirement':f'{description} 시스템 요구사항',
                             'function_name':name,'source_evidence':[{'text':f'사양 {description}','location':f'Page {n}'}]})
        cases.append({'parent_srs_id':sid,'test_objective':description,'evaluation_name':name,
                     'test_execution':'요구사항 확인','test_design_mode':mode,
                     'output_variable':f'SIG_{n}', 'output_value':'0x1',
                     'pass_criterion':'SIG=0x1', 'source_fact_fragment_ids':[f'F-{n}'],
                     'source_locations':[f'Page {n}']})
    return {'requirements':requirements}, cases


def test_v095_learning_only_text_first_and_no_auto_promote(tmp_path, monkeypatch):
    data,cases=dummy_data()
    monkeypatch.setattr(better,'finalize_verification_single_truth',lambda data: {'e2e_basic_functional_cases': cases})
    original = tmp_path / 'MLM.docx'
    original.write_text('mock, no real Source',encoding='utf-8')
    info=better.create_learning_sample(tmp_path,original,data)
    assert info['candidate_count']==5
    assert info['excel'].exists() and info['feedback'].exists()
    assert len(info['candidate_categories'])>=3
    with ZipFile(info['excel']) as z:
        assert z.testzip() is None
        assert len([x for x in z.namelist() if 'worksheets/sheet' in x])==3
        assert 'SRS_TC_001' in z.read('xl/worksheets/sheet2.xml').decode()
    assert (tmp_path / better.DIR_NAME / 'Decision Complete' / better.GUIDE_NAME).exists()
    txt=info['feedback'].read_text(encoding='utf-8')
    assert txt.count('=== CASE')==5
    assert '[판단]: ' in txt
    # Unfilled feedback must never be auto-approved.
    import pytest
    with pytest.raises(ValueError,match='확정 가능한'):
        better.import_user_feedback(tmp_path,info['feedback'])
    txt=txt.replace('[판단]: ', '[판단]: 수정',1).replace('[수정 내용]: ', '[수정 내용]: PASS 조건을 원본에 맞춰 수정',1)
    info['feedback'].write_text(txt,encoding='utf-8')
    result=better.import_user_feedback(tmp_path,info['feedback'])
    assert result['approved_count']==1
    guide=result['guide'].read_text(encoding='utf-8')
    assert 'PASS 조건을 원본에 맞춰 수정' in guide
    registry=json.loads((tmp_path / better.DIR_NAME / 'Decision Registry' / 'decision_learning_index.json').read_text(encoding='utf-8'))
    assert len(registry['completed_signatures'])==1
    assert len(registry['completed_batches'])==1
    with pytest.raises(ValueError):
        better.import_user_feedback(tmp_path,info['feedback'])
    # A second run avoids the previously confirmed candidate, without deleting other candidates.
    nxt=better.create_learning_sample(tmp_path,original,data)
    assert nxt['candidate_count']==4


def test_v095_no_source_fake_and_mode_is_opt_in():
    s=Path(__file__).resolve().parents[1].joinpath('main.py').read_text(encoding='utf-8')
    assert 'self.learning_only_checkbox.setChecked(False)' in s
    assert 'if getattr(self, "current_learning_only_run", False)' in s
    assert 'persist_result=not self.current_learning_only_run' in s
    assert 'self.current_learning_only and req_data' in s
    assert 'self.output_swe1_word.isChecked()' in s
    assert 'self._start_automatic_evaluation(' in s  # existing normal mode retained
    assert 'AI E2E 학습 후보 10개 생성' in s
    assert 'self._on_learning_pipeline_success' in s
