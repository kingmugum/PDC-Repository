"""V0.98: UI-only N/A; chat manual versioning; native fact provenance. No live AI."""
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import core.better_decision as better
from core.basic_functional_test_design import _fallback_case
from core.e2e_exporter import E2EExporter

ROOT=Path(__file__).resolve().parents[1]


def _cases():
    req={'srs_id':'SRS_006','function_name':'소비 전류 및 환경 범위',
         'requirement':'전류와 두 온도범위 준수',
         'acceptance_criteria':'최대 소비전류 100mA, 사용 온도 -40~85C, 보존 온도 -40~105C'}
    fragments=[('EL-001','최대 소비 전류 100mA','ELECTRICAL_VERIFICATION_INTENT'),
               ('EN-002','사용 온도 -40~85C','ENVIRONMENTAL_VERIFICATION_INTENT'),
               ('EN-003','보존 온도 -40~105C','ENVIRONMENTAL_VERIFICATION_INTENT')]
    cases=[]
    for i,(fid,text,typ) in enumerate(fragments,1):
        base={'test_object_type':typ,'test_object_id':f'OBJECT-{i}',
              'parent_srs_id':'SRS_006','source_fact_fragment_ids':[fid],
              'source_backed_behavior':text,'deferred_reason_code':'NON_SWE6_VERIFICATION_DOMAIN',
              'human_review_required':True}
        cases.append(_fallback_case(req,base,i))
    return req,cases


def _cells(path,sheet_no):
    with ZipFile(path) as z:
        data=z.read(f'xl/worksheets/sheet{sheet_no}.xml')
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    root=ET.fromstring(data)
    cells={}
    for node in root.findall('.//m:sheetData/m:row/m:c',ns):
        text=''.join(t.text or '' for t in node.findall('.//m:t',ns))
        cells[node.attrib['r']]=(text,node.attrib.get('s'))
    return cells


def test_native_children_do_not_inherit_full_parent_acceptance():
    req,cases=_cases()
    assert len(set(c['evaluation_name'] for c in cases))==3
    assert len(set(c['expected_state'] for c in cases))==3
    assert len(set(c['pass_criterion'] for c in cases))==3
    for case, fragment in zip(cases,('EL-001','EN-002','EN-003')):
        assert case['source_fact_fragment_ids']==[fragment]
        assert case['test_execution']==''
        assert case['human_review_required'] is True
    assert not any('사용 온도' in c['pass_criterion'] and '소비 전류' in c['pass_criterion'] for c in cases)


def test_e2e_visible_fields_na_centered_but_execution_results_blank(tmp_path,monkeypatch):
    import core.e2e_exporter as exp
    req,cases=_cases()
    monkeypatch.setattr(exp,'finalize_verification_single_truth', lambda data,force=True: {
        'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
        'integrated_test_objects':cases,'basic_functional_design_audit':{},
        'single_truth_audit':{},'semantic_verification_quality_audit':{},
    })
    file=E2EExporter(tmp_path).export_evaluation_excel(Path('demo.docx'),{'requirements':[req]})
    assert file.exists()
    with ZipFile(file) as z:
        assert z.testzip() is None
        names=[n for n in z.namelist() if n.startswith('xl/worksheets/sheet')]
        # sheet order: cover, history, summary, evaluation, review, trace
        eval_xml=z.read('xl/worksheets/sheet4.xml')
        styles=z.read('xl/styles.xml')
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    ele=ET.fromstring(eval_xml)
    def val(ref):
        n=ele.find(f'.//m:sheetData/m:row/m:c[@r="{ref}"]',ns)
        return None if n is None else ''.join(x.text or '' for x in n.findall('.//m:t',ns))
    assert val('I4')=='N/A'  # no invented input signal
    assert val('P4')=='최대 소비 전류 100mA'
    assert val('P5')=='사용 온도 -40~85C'
    assert val('P6')=='보존 온도 -40~105C'
    for r in range(4,7):
        for col in 'QRST': assert val(f'{col}{r}') in ('',None)
    assert b'horizontal="center"' in styles and b'vertical="center"' in styles


def test_learning_excel_center_and_na_only_for_design(tmp_path,monkeypatch):
    req,cases=_cases()
    monkeypatch.setattr(better,'finalize_verification_single_truth',lambda d:{'e2e_basic_functional_cases':cases})
    info=better.create_learning_sample(tmp_path,Path('test.docx'),{'requirements':[req]})
    cells=_cells(info['excel'],2)
    assert cells['I4'][0]=='N/A'
    assert cells['T4'][0]=='' and cells['U4'][0]==''
    with ZipFile(info['excel']) as z:
        styles=z.read('xl/styles.xml')
    assert b'horizontal="center" vertical="center"' in styles


def test_no_gui_feedback_button_chat_feedback_is_developer_versioned():
    src=(ROOT/'main.py').read_text(encoding='utf-8')
    assert '학습 피드백 TXT 반영' not in src
    assert 'learning_feedback_button' not in src
    assert 'APP_VERSION = "v0.120"' in src
    guide=(ROOT/better.DIR_NAME/'Decision Complete'/better.GUIDE_NAME).read_text(encoding='utf-8')
    assert '[OBS-006/007/008]' in guide
    assert '자동 동기화' in guide
    assert '[A-10 중복 후보]' in guide
