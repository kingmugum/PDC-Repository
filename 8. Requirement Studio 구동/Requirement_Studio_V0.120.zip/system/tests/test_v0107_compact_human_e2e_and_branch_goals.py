"""V0.107 human-facing E2E contract and distinct source-traced intent cases."""
from datetime import date
from pathlib import Path
from openpyxl import load_workbook
from core.semantic_objective_design import identify_independent_goals
from core.basic_functional_test_design import build_basic_functional_cases
from core.e2e_exporter import E2EExporter


def make_req(sid, text):
    return {
        'srs_id':sid, 'function_name':'가상 복합 상태 제어',
        'requirement':text,'acceptance_criteria':text,'processing_action':text,
        'source_backed_atomic_behaviors':[
            {'source_fact_fragment_id':'F-'+sid,'source_location':'Fictional requirements',
             'behavior_text':text}],
    }


def make_base(sid):
    return {'parent_srs_id':sid,'test_object_id':sid+'_OBJ',
        'test_object_type':'SYS5_CANDIDATE', 'source_fact_fragment_ids':['F-'+sid]}


def build(req):
    return build_basic_functional_cases({'requirements':[req]},[make_base(req['srs_id'])])[0]


def test_distinct_lin_error_paths_without_invented_states():
    req=make_req('SRS_LIN',
        'CAN 통신 정상 시 LIN 통신 오류가 발생하면 LIN 통신 복구를 시도하며 NM를 통해 Low Power Mode 진입할 수 있다. '
        'CAN 및 LIN 통신 오류 시 Low Power Mode로 진입한다.')
    cases=build(req)
    kinds={c.get('semantic_goal_kind') for c in cases}
    assert kinds=={'LIN_RECOVERY_WHILE_CAN_NORMAL','CAN_LIN_COMBINED_FAILURE_SAFE_STATE'}
    assert all(c['source_fact_fragment_ids']==['F-SRS_LIN'] for c in cases)
    assert all(c['basic_case_kind']=='SEMANTIC_INDEPENDENT_OBJECTIVE' for c in cases)
    assert all('0x' not in c.get('pass_criterion','') for c in cases)


def test_data_integrity_safe_action_vs_user_setting_fallback():
    req=make_req('SRS_MEM',
        '데이터 정합성 이상 시 모든 슬레이브 무드등 출력이 OFF 되고 슬레이브가 Low Power Mode로 진입한다. '
        '사용자 설정값 복구가 불가능하면 초기값으로 정상 동작한다.')
    cases=build(req)
    assert {c.get('semantic_goal_kind') for c in cases}=={
        'DATA_FAULT_SAFE_REACTION','USER_SETTING_DEFAULT_RECOVERY'}
    assert len(cases)==2


def test_can_fault_then_restoration_split_with_proposed_step_only_beige():
    req=make_req('SRS_CAN',
        'CAN 통신 유지 불가 시 모든 작동을 중지하고 Low Power Mode로 진입한다. '
        'CAN 통신 복구 시 정상 동작한다.')
    cases=build(req)
    assert {c.get('semantic_goal_kind') for c in cases}=={
        'COMMUNICATION_FAILURE_RESPONSE','COMMUNICATION_RESTORATION'}
    recovery=next(c for c in cases if c['semantic_goal_kind']=='COMMUNICATION_RESTORATION')
    assert recovery['execution_basis']=='ENGINEERING_PROPOSED_STEP'
    assert recovery.get('expectation_basis')!='ENGINEERING_HYPOTHESIS'


def test_fresh_e2e_document_contract_and_slim_trace(tmp_path,monkeypatch):
    from core import e2e_exporter as exmod
    req=make_req('SRS_CAN',
        'CAN 통신 유지 불가 시 모든 작동을 중지하고 Low Power Mode로 진입한다. '
        'CAN 통신 복구 시 정상 동작한다.')
    cases=build(req)
    monkeypatch.setattr(exmod, 'finalize_verification_single_truth', lambda *a, **kw: {
        'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
        'integrated_test_objects':cases,'basic_functional_design_audit':{},
        'single_truth_audit':{},'semantic_verification_quality_audit':{}})
    out=E2EExporter(tmp_path).export_evaluation_excel(Path('fictional.docx'), {'requirements':[req]})
    wb=load_workbook(out)
    try:
        assert wb.sheetnames == ['표지','0_변경이력','1_평가요약','2_E2E_평가케이스','3_요구사항-평가추적성']
        assert 'Source Fidelity' not in [wb['표지'].cell(r,2).value for r in range(1,16)]
        h=wb['0_변경이력']
        assert [h.cell(3,c).value for c in range(1,6)]==['No.','Version','Date','Change','작성자']
        assert [h.cell(4,c).value for c in range(1,6)][:2]==[1,'V1.00']
        assert h['D4'].value=='초안 작성' and h['E4'].value is None
        assert date.fromisoformat(h['C4'].value)
        assert h.max_row==4
        summary=wb['1_평가요약']
        totals={summary.cell(r,1).value:summary.cell(r,2).value for r in range(4,8)}
        assert totals=={'전체 TC':2,'기능 TC':2,'비기능 TC':0,'입력 요구사항 (고유 BF ID)':2}
        t=wb['3_요구사항-평가추적성']
        assert t.max_column==8
        assert 'Split Decision' not in [t.cell(3,c).value for c in range(1,9)]
        main=wb['2_E2E_평가케이스']
        assert main.max_column==20
        assert len([r for r in range(4,main.max_row+1) if main.cell(r,1).value])==2
        assert main['L5'].fill.fgColor.rgb.endswith('FAF1E5')
        assert all(main.cell(r,c).value is None for r in range(4,6) for c in range(17,21))
    finally:
        wb.close()
    log=next(tmp_path.glob('00_E2E_판단근거_요약_*.txt')).read_text(encoding='utf-8-sig')
    assert 'COMMUNICATION_RESTORATION' in log or '복구' in log
