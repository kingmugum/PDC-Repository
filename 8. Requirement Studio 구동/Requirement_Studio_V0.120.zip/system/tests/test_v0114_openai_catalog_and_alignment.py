"""V0.114: official OpenAI dropdown + shared dashboard grid (offline checks)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from providers.config_store import ProviderConfigStore, OPENAI_COMMERCIAL_MODELS
from providers.factory import create_provider

EXPECTED = ('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-astra', 'gpt-6-luna')


def test_four_verified_models_are_present_in_default_openai_catalog(tmp_path):
    store = ProviderConfigStore(tmp_path)
    cfg = store.load()
    assert OPENAI_COMMERCIAL_MODELS == EXPECTED
    assert cfg['commercial']['openai_api']['model'] == 'gpt-6.1-sol'
    assert cfg['commercial']['openai_api']['model_options'] == list(EXPECTED)
    assert cfg['commercial']['openai_api']['base_url'] == 'https://api.openai.com/v1'
    assert cfg['commercial']['openai_api']['profile'] == 'openai_responses'


def test_migrate_existing_v0113_single_gpt5mini_catalog(tmp_path):
    store = ProviderConfigStore(tmp_path)
    data = store.load()
    data['commercial']['openai_api']['model'] = 'gpt-5-mini'
    data['commercial']['openai_api']['model_options'] = ['gpt-5-mini']
    store.save(data)
    after = store.load()
    assert after['commercial']['openai_api']['model'] == 'gpt-6.1-sol'
    assert after['commercial']['openai_api']['model_options'] == list(EXPECTED)
    assert after['hchat'] == data['hchat']
    assert after['alira'] == data['alira']
    assert after['commercial']['gemini_api'] == data['commercial']['gemini_api']


def test_preserve_user_entered_model_without_removing_four_verified_models(tmp_path):
    store = ProviderConfigStore(tmp_path)
    data = store.load()
    data['commercial']['openai_api']['model'] = 'my-approved-snapshot'
    data['commercial']['openai_api']['model_options'] = ['my-approved-snapshot', 'gpt-5-mini']
    store.save(data)
    after = store.load()['commercial']['openai_api']
    assert after['model'] == 'my-approved-snapshot'
    assert after['model_options'] == list(EXPECTED) + ['my-approved-snapshot']


@pytest.mark.parametrize('model', EXPECTED)
def test_each_selected_model_is_forwarded_to_openai_responses_without_live_api(tmp_path, model, monkeypatch):
    store = ProviderConfigStore(tmp_path)
    data = store.update_selection('openai_api', model=model)
    data['commercial']['openai_api']['manual_api_key'] = 'offline-dummy-key'
    api = create_provider(tmp_path, 'openai_api', data)
    calls = []
    def fake_post(url, key, payload, timeout):
        calls.append((url, key, payload, timeout))
        return {'output': [{'content': [{'type': 'output_text','text': 'connection fixture ok'}]}]}
    monkeypatch.setattr(api, '_post', fake_post)
    assert api.generate('test') == 'connection fixture ok'
    assert calls[0][0] == 'https://api.openai.com/v1/responses'
    assert calls[0][2]['model'] == model
    assert calls[0][2]['input'] == 'test'


def test_grid_links_top_and_middle_card_edges():
    main = (Path(__file__).parents[1] / 'main.py').read_text(encoding='utf8')
    assert 'dashboard_grid = QGridLayout()' in main
    for line in (
        'dashboard_grid.addWidget(self._build_file_card(), 0, 0)',
        'dashboard_grid.addWidget(self._build_ai_card(), 0, 1)',
        'dashboard_grid.addWidget(self._build_execution_card(), 0, 2)',
        'dashboard_grid.addWidget(self._build_pipeline_card(), 1, 0, 1, 2)',
        'dashboard_grid.addWidget(self._build_checklist_card(), 1, 2)',
    ):
        assert line in main
    assert 'card.setMinimumHeight(284)' in main
    assert 'action_col.setContentsMargins(0, 0, 0, 5)' in main
    assert 'btn.setFixedSize(124, 42)' in main


def test_openai_official_catalog_only_does_not_modify_hchat_default(tmp_path):
    data = ProviderConfigStore(tmp_path).load()
    assert data['hchat']['gpt_model_options'] == ['gpt-5.6-terra']
    assert data['hchat']['gemini_model_options'] == ['gemini-3.7-flash']
    assert data['hchat']['claude_model_options'] == ['claude-sonnet-5']
    for model in EXPECTED:
        data = ProviderConfigStore(tmp_path).update_selection('openai_api',model=model)
        assert data['commercial']['openai_api']['model'] == model
        assert data['hchat']['gpt_model_options'] == ['gpt-5.6-terra']
