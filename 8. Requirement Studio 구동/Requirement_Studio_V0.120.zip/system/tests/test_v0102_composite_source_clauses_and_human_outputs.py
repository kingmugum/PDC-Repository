"""V0.102: compound-traced condition clauses, human-only document rendering."""
from pathlib import Path
from copy import deepcopy
import zipfile
from xml.etree import ElementTree as ET

from tests.test_v082_integrated_specs_single_truth import _mode_fixture
from core.verification_single_truth import _state_transition_model
from core.basic_functional_test_design import _explicit_boolean_transition_cases, build_basic_functional_cases
from core.e2e_exporter import _format_behavior_definition, _human_reference_note, E2EExporter
from core.e2e_decision_log import build_e2e_decision_summary

LOW = '무드램프 마스터 제어기는 OFF 명령 수신, 무드램프 OFF 상태, 슬레이브 제어기 SLEEP(OFF) 상태 및 B-CAN SLEEP MODE 상태의 모든 조건이 참이면 Low Power Mode(Sleep Mode)로 전환해야 한다.'
HIGH = '무드램프 마스터 제어기는 ON 명령 수신, B-CAN WAKE UP 상태, TRANSCEIVER ERR PIN의 HIGH에서 LOW 상태 변환 또는 최초 B+ 인가 조건 중 하나라도 참이면 High Power Mode로 전환해야 한다.'


def _input(text, fid='F-COMPOSITE'):
    req=deepcopy(_mode_fixture()['requirements'][0]);req.update({
        'srs_id':'SRS_003', 'function_name':'전원 모드 전환',
        'requirement': text,'processing_action':text,'acceptance_criteria':text,
        'output': 'Low Power Mode(Sleep Mode)' if 'Low Power Mode' in text else 'High Power Mode',
        'source_backed_atomic_behaviors':[{'source_fact_fragment_id':fid,'behavior_text':text,'source_location':'Paragraph 8'}],
        'fact_level_allocations':[],
    })
    state=_state_transition_model(req)
    base={'parent_srs_id':'SRS_003','test_object_id':'OBJ-003',
          'test_object_type':'SYS5_CANDIDATE','source_fact_fragment_ids':[fid],
          'source_semantic_unit_ids':['SEM-3'],'test_intent':'모드 전환 시험',**state}
    return req,base


def test_and_compound_literal_four_clauses_expand_without_independent_fact_ids():
    req,base=_input(LOW)
    assert base['condition_logic']=='ALL_OF'
    assert base['condition_source_derivation']=='COMPOSITE_SOURCE_FACT_CLAUSES'
    assert len(set(base['condition_fragment_ids']))==1
    cases,_=_explicit_boolean_transition_cases(req,base,1)
    assert len(cases)==5
    assert len(cases[0]['boolean_condition_states'])==4
    assert all(c['source_fact_fragment_ids'] for c in cases)
    assert sum(c['expectation_basis']=='ENGINEERING_HYPOTHESIS' for c in cases)==4
    assert all('시험 설계 가설' in c['pass_criterion'] for c in cases[1:])
    assert all(c['field_fact_trace']['pass_criterion']==[] for c in cases[1:])
    # Normal builder, not just the helper, must expand these cases.
    out,_,_=build_basic_functional_cases({'requirements':[req]},[base])
    assert len(out)==5
    assert all(c['basic_case_kind']=='BOOLEAN_CONDITION_COVERAGE' for c in out)


def test_or_compound_literal_four_clauses_expand_and_add_hypothesis():
    req,base=_input(HIGH,'F-HIGH-COMPOSITE')
    assert base['condition_logic']=='ANY_OF'
    cases,_=_explicit_boolean_transition_cases(req,base,1)
    assert len(cases)==5
    assert all('High Power Mode' in c['pass_criterion'] for c in cases)
    assert cases[-1]['expectation_basis']=='ENGINEERING_HYPOTHESIS'
    assert [c['boolean_condition_states'][i]['expected'] for i,c in enumerate(cases[:4])]==[True]*4


def test_requires_real_source_fact_and_explicit_connection():
    req,base=_input(LOW)
    req['source_backed_atomic_behaviors']=[]
    assert _explicit_boolean_transition_cases(req,base,1)[0]==[]
    altered=LOW.replace('무드램프 OFF 상태','타사에서 숨긴 상태')
    req,base=_input(altered)
    req['requirement']=LOW
    assert _explicit_boolean_transition_cases(req,base,1)[0]==[]
    # Do not infer from a comma list that has no explicit logical link.
    req,base=_input('무드램프 마스터 제어기는 OFF 명령 수신, 무드램프 OFF 상태로 동작해야 한다.')
    assert base['condition_logic'] not in ('ALL_OF','ANY_OF')


def test_human_fields_remove_internal_key_markers_without_erasing_semantics():
    s='1. flow_id=BF_001; description=사용자 설정 정보를 CAN 통신으로 수신한다.\n2. flow_id=BF_002; description=비휘발성 메모리에 저장한다.'
    out=_format_behavior_definition(s)
    assert 'flow_id=' not in out and 'description=' not in out
    assert '1. 사용자 설정 정보를' in out and '2. 비휘발성 메모리에' in out
    assert _human_reference_note('artifact_type=table; reference=Table 12 동작 환경 범위; source_location=SRC X')=='표 12'
    assert _human_reference_note('artifact_type=figure; reference=Figure 1. 시스템 구조; source_location=SRC X')=='그림 1'
    assert _human_reference_note('artifact_type=external_specification; reference=ES90000-01, ES90000-02; source_location=SRC X')=='참조 규격: ES90000-01, ES90000-02'


def test_export_history_latest_version_and_diagnostic(tmp_path,monkeypatch):
    import core.e2e_exporter as exporter
    req,base=_input(LOW)
    cases,_,_=build_basic_functional_cases({'requirements':[req]},[base])
    monkeypatch.setattr(exporter,'finalize_verification_single_truth',lambda *args,**kw: {
        'e2e_basic_functional_cases':cases, 'e2e_evaluation_cases':cases,
        'integrated_test_objects':cases, 'basic_functional_design_audit':{},
        'single_truth_audit':{}, 'semantic_verification_quality_audit':{},
    })
    output=E2EExporter(tmp_path).export_evaluation_excel(Path('test.docx'),{'requirements':[req]})
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(output) as z:
        hist=ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
        hist_text=' '.join(n.text or '' for n in hist.findall('.//m:t',ns))
        assert 'V1.00' in hist_text and '초안 작성' in hist_text and 'V0.102' not in hist_text
    log=build_e2e_decision_summary(source_document=Path('test.docx'),cases=cases,
          human_ids=[f'SRS_TC_{i:03d}' for i in range(1,6)],reqs={'SRS_003':req})
    assert '단일 원본 Fact' in log
    assert 'AND 출처 기반 대표 조합 생성됨' in log
