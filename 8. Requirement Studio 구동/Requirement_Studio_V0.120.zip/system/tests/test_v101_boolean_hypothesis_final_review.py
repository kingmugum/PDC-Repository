"""V1.01: final-only hypothesis proposal vs Source assertion, with XML workbook proof."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET

from tests.test_v100_human_boolean_labels import _candidates
from core.basic_functional_test_design import _trace_integrity_review
from core.e2e_decision_log import build_e2e_decision_summary
from core.e2e_exporter import E2EExporter

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


def test_and_negative_proposes_nonblocking_labeled_hypothesis():
    cases=_candidates()['SRS_004']
    assert len(cases)==5
    assert cases[0]['expectation_basis']=='SOURCE_EXPLICIT'
    for case in cases[1:]:
        assert case['expectation_basis']=='ENGINEERING_HYPOTHESIS'
        assert case['split_decision']=='PROPOSE_BOOLEAN_NEGATIVE_EXPECTATION'
        assert '전환되지 않음' in case['expected_state']
        assert '[시험 설계 가설]' in case['pass_criterion']
        assert '원본 부정 동작 미명시' in case['pass_criterion']
        assert case['execution_readiness']=='FINAL_REVIEW_PROPOSAL'
        assert '중간 승인 없이' in case['required_resolution']
        assert case['input_compare']=='조건별 참/거짓 조합'
        assert case['inference_evidence_fids']
        assert case['inferred_expected_fields']==['output_value','expected_state','pass_criterion']
        assert case['field_fact_trace']['pass_criterion']==[]  # no counterfeit Source attribution


def test_or_all_false_scenario_is_labeled_only_as_hypothesis():
    cases=_candidates()['SRS_005']
    assert len(cases)==5
    assert all(case['expectation_basis']=='SOURCE_EXPLICIT' for case in cases[:4])
    hypothesis=cases[4]
    assert hypothesis['expectation_basis']=='ENGINEERING_HYPOTHESIS'
    assert all(not x['expected'] for x in hypothesis['boolean_condition_states'])
    assert '모든 진입 조건' in hypothesis['test_objective']
    assert 'High Power Mode로 전환되지 않으면 PASS' in hypothesis['pass_criterion']
    assert '시험 설계 가설' in hypothesis['pass_criterion']


def test_inference_trace_is_distinguished_from_exact_source_trace():
    from tests.test_v082_integrated_specs_single_truth import _mode_fixture
    case=_candidates()['SRS_004'][1]
    review=_trace_integrity_review(_mode_fixture()['requirements'][0],case)
    assert review is None
    assert case['exact_field_trace_status']=='SOURCE_TRACED_WITH_INFERRED_EXPECTATION'
    assert not case['field_fact_trace'].get('pass_criterion')


def test_export_displays_proposed_result_and_final_review_without_fabricating_execution(tmp_path,monkeypatch):
    import core.e2e_exporter as exp
    from tests.test_v082_integrated_specs_single_truth import _mode_fixture
    case_list=_candidates()['SRS_004']
    req=_mode_fixture()['requirements'][0]
    monkeypatch.setattr(exp,'finalize_verification_single_truth',lambda *a,**kw: {
        'e2e_basic_functional_cases':case_list,'e2e_evaluation_cases':case_list,
        'integrated_test_objects':case_list, 'basic_functional_design_audit':{},
        'single_truth_audit':{},'semantic_verification_quality_audit':{}})
    xlsx=E2EExporter(tmp_path).export_evaluation_excel(Path('Synthetic.docx'),{'requirements':[req]})
    with ZipFile(xlsx) as z:
        root=ET.fromstring(z.read('xl/worksheets/sheet4.xml'))
    def val(cell):
        el=root.find(f'.//m:sheetData/m:row/m:c[@r="{cell}"]',NS)
        return ''.join(n.text or '' for n in el.findall('.//m:t',NS)) if el is not None else ''
    assert '시험 설계 가설' not in val('P5')
    assert '시험 설계 가설' not in val('P5')
    assert val('R5')==''  # no human review status column
    assert '실제 출력값' == val('Q3')
    assert val('J5')=='조건별 참/거짓 조합'
    for col in 'QRST':assert val(col+'5')==''
    log=next(tmp_path.glob('00_E2E_판단근거_요약_*.txt')).read_text('utf-8-sig')
    assert '시험 설계 가설' in log and '원본 미명시' in log


def test_log_says_generated_hypothesis_is_not_certain_and_no_intermediate_approval():
    cases=_candidates()['SRS_004']
    log=build_e2e_decision_summary(source_document=Path('synthetic.docx'),cases=cases,
                                   human_ids=['SRS_TC_'+str(i).zfill(3) for i in range(1,len(cases)+1)],reqs={'SRS_004':{}})
    assert '중간 승인으로 분석을 멈추지 않음' in log
    assert '판정 가설(원본 미명시)' in log
    assert '원본 사실 아님' in log
    assert 'SRC-FRAG' not in log or '출처=' in log
