"""V0.109 root-cause diagnostics, no model calls, no source paragraphs."""
from pathlib import Path
from core import basic_functional_test_design as design
from core.semantic_split_diagnostic import build_semantic_split_diagnostic, prompt_guide_visibility


def _data(text):
    fid='SYNTHETIC-GOOD-01';sid='SRS_DEMO'
    req={'srs_id':sid,'function_name':'가상 장치','requirement':text,
         'processing_action':text,'acceptance_criteria':text,
         'source_backed_atomic_behaviors':[{'source_fact_fragment_id':fid,
          'source_location':'fictional','behavior_text':text}]}
    base={'parent_srs_id':sid,'test_object_id':'SAMPLE-OBJ',
          'test_object_type':'SYS5_CANDIDATE','source_fact_fragment_ids':[fid]}
    return req,base


def _run(req,base):
    return design.build_basic_functional_cases({'requirements':[req]},[base])


def test_multiple_goals_produce_diagnostic_trace():
    req,base=_data('센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.')
    cases,_,audit=_run(req,base)
    assert len(cases)==2
    events=audit['semantic_split_diagnostic_events'];assert len(events)==1
    assert events[0]['decision_path']=='SEMANTIC_OBJECTIVES_EMITTED'
    assert len(events[0]['candidate_goal_kinds'])==2
    text=build_semantic_split_diagnostic(source_document=Path('example.docx'),cases=cases,
      human_ids=['T1','T2'],reqs={'SRS_DEMO':req},design_audit=audit)
    assert 'SEMANTIC_OBJECTIVES_EMITTED' in text
    assert 'SYNTHETIC-GOOD-01' in text
    assert '센서 A 감지 시 장비는 청색 램프를 점등한다' not in text


def test_preceding_rule_skip_provides_a_real_reason(monkeypatch):
    req,base=_data('센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.')
    # Simulate a higher-priority rule producing one case so later semantic pass is skipped.
    monkeypatch.setattr(design,'_dimension_case',
        lambda r,b,i:([design._fallback_case(r,b,i)],i+1))
    cases,_,audit=_run(req,base)
    assert len(cases)==3  # V0.112: one legacy case + two explicit uncovered paths
    event=audit['semantic_split_diagnostic_events'][0]
    assert event['semantic_evaluation']=='AUGMENTED_AFTER_PRECEDING_RULE'
    assert len(event['candidate_goal_kinds'])==2
    log=build_semantic_split_diagnostic(source_document=Path('example.docx'),cases=cases,
      human_ids=['T1','T2','T3'],reqs={'SRS_DEMO':req},design_audit=audit)
    assert '선행 규칙 후 의미 분할 추가 1건' in log


def test_single_condition_reports_no_multiple_goals():
    req,base=_data('센서 A 감지 시 장비는 청색 램프를 점등한다.')
    cases,_,audit=_run(req,base)
    assert len(cases)==1
    assert audit['semantic_split_diagnostic_events'][0]['candidate_goal_kinds']==[]


def test_guide_limit_is_reported_as_configuration_not_actual_send(tmp_path):
    folder=tmp_path/'Build AI Better Decision'/'Decision Complete';folder.mkdir(parents=True)
    (folder/'AI_E2E_GUIDELINE_CONSTITUTION.txt').write_text(
        '[USER_EDITORIAL_GUIDE_START]'+('가'*3500)+'[USER_EDITORIAL_GUIDE_END]',encoding='utf-8')
    conf=prompt_guide_visibility(tmp_path)
    assert conf['editorial_chars']==3500
    assert conf['editorial_truncated_chars']==300
    assert '정적 추정' in conf['note']


def test_end_to_end_export_writes_diagnostic_next_to_excel(tmp_path,monkeypatch):
    from core import e2e_exporter as mod
    req,base=_data('센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.')
    cases,_,audit=_run(req,base)
    monkeypatch.setattr(mod,'finalize_verification_single_truth',lambda *a,**kw:{
        'e2e_basic_functional_cases':cases,'e2e_evaluation_cases':cases,
        'integrated_test_objects':cases,'basic_functional_design_audit':audit})
    exporter=mod.E2EExporter(tmp_path)
    excel=exporter.export_evaluation_excel(Path('example.docx'),{'requirements':[req]})
    assert excel.is_file()
    diag=exporter.last_semantic_diagnostic_path
    assert diag is not None and diag.is_file()
    assert diag.parent==excel.parent
    assert 'SEMANTIC_OBJECTIVES_EMITTED' in diag.read_text(encoding='utf-8-sig')
    assert exporter.last_decision_log_path.is_file()


def test_offline_sample_runner_writes_3_fictional_checks(tmp_path):
    from tools.run_semantic_split_diagnostic_samples import run
    out, checks=run(output_dir=tmp_path)
    assert len(checks)==3
    assert all(x.startswith('PASS') for x in checks)
    assert 'DEMO_A' in out.read_text(encoding='utf-8-sig')
