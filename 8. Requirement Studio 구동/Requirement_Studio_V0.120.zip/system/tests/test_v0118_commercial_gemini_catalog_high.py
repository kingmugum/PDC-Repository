"""V0.118 offline only: official Gemini model catalog and paid API transport safety."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
import requests

from providers.config_store import ProviderConfigStore, GEMINI_COMMERCIAL_MODELS
from providers.factory import create_provider

ROOT = Path(__file__).resolve().parents[1]
MODELS = (
    'gemini-3.8-flash',
    'gemini-3.1-pro-preview',
    'gemini-3.7-flash',
    'gemini-3.5-flash-lite',
)


def test_shipped_gemini_configuration_and_independent_providers():
    cfg = json.loads((ROOT/'config/provider_config.json').read_text(encoding='utf-8'))
    assert GEMINI_COMMERCIAL_MODELS == MODELS
    gemini = cfg['commercial']['gemini_api']
    assert gemini['model'] == MODELS[0] and gemini['model_options'] == list(MODELS)
    assert (gemini['profile'],gemini['auth_mode'],gemini['api_key_name']) == ('gemini_generate_content','x-api-key','x-goog-api-key')
    assert gemini['supports_images'] and (gemini['thinking_level'], gemini['timeout_seconds']) == ('high', 300)
    assert cfg['commercial']['openai_api']['reasoning_effort'] == 'high'
    assert cfg['commercial']['openai_api']['timeout_seconds'] == 300
    assert cfg['commercial']['claude_api']['timeout_seconds'] == 300
    assert cfg['hchat']['gemini_model'] == 'gemini-3.7-flash'


def test_gemini_default_first_run_and_restart(tmp_path):
    store = ProviderConfigStore(tmp_path)
    cfg = store.load()
    gem = cfg['commercial']['gemini_api']
    assert gem['model'] == MODELS[0] and gem['model_options'] == list(MODELS)
    assert gem['timeout_seconds'] == 300 and gem['thinking_level'] == 'high'
    store.save(cfg)
    reloaded = ProviderConfigStore(tmp_path).load()['commercial']['gemini_api']
    assert reloaded['model_options'][:4] == list(MODELS)
    assert reloaded['timeout_seconds'] == 300


def test_v117_stock_migration_keeps_custom_settings(tmp_path):
    store = ProviderConfigStore(tmp_path)
    cfg = store.load()
    gem = cfg['commercial']['gemini_api']
    gem['model'] = 'gemini-2.5-flash'
    gem['model_options'] = ['gemini-2.5-flash']
    gem['timeout_seconds'] = 120
    gem.pop('thinking_level',None)
    store.save(cfg)
    updated = store.load()['commercial']['gemini_api']
    assert updated['model'] == MODELS[0]
    assert updated['model_options'][:4] == list(MODELS)
    assert updated['timeout_seconds'] == 300
    assert updated['thinking_level'] == 'high'
    original = store.load()
    original['commercial']['gemini_api'].update({
       'model':'gemini-custom',
       'model_options':['gemini-custom','gemini-2.5-flash'],
       'timeout_seconds':240,
       'thinking_level':'medium',
    })
    store.save(original)
    updated = store.load()['commercial']['gemini_api']
    assert updated['model'] == 'gemini-custom'
    assert updated['model_options'][-1] == 'gemini-custom'
    assert updated['timeout_seconds'] == 240 and updated['thinking_level'] == 'medium'


@pytest.mark.parametrize('model', MODELS)
@pytest.mark.parametrize('mode', ['text','image'])
def test_gemini_model_endpoint_key_and_high_thinking(tmp_path,model,mode):
    store = ProviderConfigStore(tmp_path)
    cfg = store.update_selection('gemini_api',model=model)
    cfg['commercial']['gemini_api']['manual_api_key'] = 'SYNTHETIC_TEST_ONLY'
    api = create_provider(tmp_path,'gemini_api',cfg)
    seen=[]
    def fake_post(*,unused=None): pass
    def post(url,key,payload,timeout):
        seen.append((url,key,payload,timeout))
        return {'candidates':[{'content':{'parts':[{'text':'MOCK_OK'}]}, 'finishReason':'STOP'}]}
    with patch.object(api,'_post',side_effect=post):
        if mode=='text':
            assert api.generate('Extract requirements',system_message='System rules')=='MOCK_OK'
        else:
            p=tmp_path/'tiny.png'
            p.write_bytes(b'test image data')
            assert api.generate_with_images('Read the picture',[p],system_message='System rules') == 'MOCK_OK'
    assert len(seen)==1
    url,key,payload,timeout=seen[0]
    assert url == f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'
    assert key == 'SYNTHETIC_TEST_ONLY'
    assert timeout == 300
    assert payload['generationConfig']['thinkingConfig'] == {'thinkingLevel':'HIGH'}
    assert payload['systemInstruction']['parts'][0]['text'] == 'System rules'
    if mode=='image':
        assert payload['contents'][0]['parts'][1]['inlineData']['mimeType'] == 'image/png'
        assert payload['contents'][0]['parts'][1]['inlineData']['data']
    else:
        assert len(payload['contents'][0]['parts'])==1
    headers,params = api._request_auth(key)
    assert headers['x-goog-api-key']==key and 'Authorization' not in headers and params is None


def test_paid_request_timeout_is_single_shot(tmp_path):
    cfg=ProviderConfigStore(tmp_path).load()
    cfg['commercial']['gemini_api']['manual_api_key']='FIXTURE'
    api=create_provider(tmp_path,'gemini_api',cfg)
    seen=[]
    def fake_post(*args,**kwargs):
        seen.append(kwargs)
        raise requests.exceptions.ReadTimeout('simulated timeout')
    with patch('providers.custom_api_provider.requests.post',side_effect=fake_post):
        with pytest.raises(TimeoutError,match=r'300초'):
            api.generate('Test')
    assert len(seen)==1 and seen[0]['timeout']==300


def test_models_menu_provider_isolation_and_no_key_persistence(tmp_path):
    store=ProviderConfigStore(tmp_path)
    before=store.load()
    hchat_before=json.loads(json.dumps(before['hchat']))
    openai_before=json.loads(json.dumps(before['commercial']['openai_api']))
    claude_before=json.loads(json.dumps(before['commercial']['claude_api']))
    for model in MODELS:
        after=store.update_selection('gemini_api',model=model)
        assert after['commercial']['gemini_api']['model']==model
        assert after['commercial']['openai_api']==openai_before
        assert after['commercial']['claude_api']==claude_before
        assert after['hchat']==hchat_before
    assert 'manual_api_key' not in json.loads(store.path.read_text())['commercial']['gemini_api']
    source=(ROOT/'main.py').read_text(encoding='utf-8')
    assert 'self.radio_commercial_gemini = QRadioButton("Gemini")' in source
    assert 'elif provider_id in ("openai_api", "gemini_api", "claude_api")' in source


def test_gemini_high_does_not_leak_to_other_custom_api(tmp_path):
    cfg=ProviderConfigStore(tmp_path).load()
    for name in ('openai_api','claude_api'):
        cfg['commercial'][name]['manual_api_key']='FIXTURE'
        p=create_provider(tmp_path,name,cfg)
        assert p.thinking_level==''
    cfg['custom']['manual_api_key']='FIXTURE'
    other=create_provider(tmp_path,'custom_api',cfg)
    assert other.thinking_level==''
