from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v088_provider_selector_remains_exclusive_after_user_authorized_gui_expansion():
    # V0.113 explicitly supersedes the two-row UI-only geometry expectation.
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    method = text.split("def _build_ai_card", 1)[1].split("def _build_execution_card", 1)[0]
    assert "self.provider_button_group.setExclusive(True)" in method
    assert 'provider_row(0, "상용 AI"' in method
    assert 'provider_row(1, "H-CHAT"' in method
    assert 'provider_row(2, "ALIRA"' in method
    for token in ("self.radio_openai", "self.radio_commercial_gemini", "self.radio_commercial_claude", "self.radio_custom",
                  "self.radio_gpt", "self.radio_gemini", "self.radio_claude", "self.radio_alira"):
        assert token in method


def test_v088_ai_fields_and_actions_remain_compact_under_v0113_gui_override():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    method = text.split("def _build_ai_card", 1)[1].split("def _build_execution_card", 1)[0]
    assert "self.provider_model_combo.setMinimumWidth(154)" in method
    assert "self.api_key_field.setMinimumWidth(154)" in method
    assert "QSizePolicy.Policy.Expanding" in method
    assert "btn.setFixedSize(124, 42)" in method
    assert "provider_grid.setColumnMinimumWidth(0, 76)" in method


def test_v088_top_dashboard_shrinks_before_horizontal_scroll():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "self.resize(1200, 900)" in text
    assert "self.dashboard_content.setMinimumSize(1280, 820)" in text
    # V0.114 user-authorized change: top/middle cards share grid columns.
    dashboard = text.split("dashboard_grid = QGridLayout()", 1)[1].split("layout.addLayout(dashboard_grid)", 1)[0]
    assert "dashboard_grid.setColumnStretch(0, 3)" in dashboard
    assert "dashboard_grid.setColumnStretch(1, 6)" in dashboard
    assert "dashboard_grid.setColumnStretch(2, 3)" in dashboard
    assert "dashboard_grid.addWidget(self._build_file_card(), 0, 0)" in dashboard
    assert "dashboard_grid.addWidget(self._build_ai_card(), 0, 1)" in dashboard
    assert "dashboard_grid.addWidget(self._build_execution_card(), 0, 2)" in dashboard
    assert "dashboard_grid.addWidget(self._build_pipeline_card(), 1, 0, 1, 2)" in dashboard
    assert "dashboard_grid.addWidget(self._build_checklist_card(), 1, 2)" in dashboard
    assert "card.setMinimumWidth(328)" in text
    assert 'QLabel("분석 진행 상황")' in text
    assert 'QLabel("필수 항목 확인")' in text


def test_v088_runtime_version_and_non_gui_semantics_are_not_reworked():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert 'APP_VERSION = "v0.120"' in text  # V0.113 GUI-only authorized override
    # E2E outputs and automatic triad remain present; V0.89 preserves the V0.88 responsive GUI while refining human-facing output.
    assert 'E2E 요구사항 명세서 (Word 파일 & 엑셀 양식)' in text
    assert 'E2E 평가 명세서 (엑셀 양식)' in text
    assert 'for index, provider in enumerate(("gpt", "gemini", "claude"), start=1)' in text
