"""V0.113 offline-only GUI/provider configuration verification (no external API request)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from providers.config_store import ProviderConfigStore
from providers.factory import create_provider

COMMERCIAL = ("openai_api", "gemini_api", "claude_api")


def test_provider_default_catalog_and_hchat_preserved(tmp_path):
    store = ProviderConfigStore(tmp_path)
    data = store.load()
    assert set(COMMERCIAL).issubset(data["commercial"])
    assert data["hchat"]["gpt_model"] == "gpt-5.6-terra"
    assert data["selected_provider"] == "hchat_gpt"
    assert data["commercial"]["openai_api"]["profile"] == "openai_responses"
    assert data["commercial"]["gemini_api"]["profile"] == "gemini_generate_content"
    assert data["commercial"]["claude_api"]["profile"] == "anthropic_messages"


@pytest.mark.parametrize("provider", COMMERCIAL)
def test_commercial_selection_uses_the_right_adapter_and_model(tmp_path, provider):
    data = ProviderConfigStore(tmp_path).load()
    data["commercial"][provider]["manual_api_key"] = "dummy-test-key"
    api = create_provider(tmp_path, provider, data)
    assert api.metadata().provider_id == provider
    assert api.model == data["commercial"][provider]["model"]
    assert api.metadata().credential_status == "수동 API Key"


def test_independent_configuration_and_selected_model(tmp_path):
    store = ProviderConfigStore(tmp_path)
    original = store.load()
    other_original = original["custom"]
    hchat_original = original["hchat"]
    alira_original = original["alira"]
    store.update_commercial(
        "openai_api", profile="openai_responses", base_url="https://api.openai.com/v1",
        model="gpt-fixture", model_options=["gpt-fixture"],
        api_key_required=True, auth_mode="bearer", api_key_name="Authorization",
        version_header_name="", version_header_value="", supports_images=True,
    )
    after = store.update_selection("gemini_api", model="gemini-fixture")
    assert after["selected_provider"] == "gemini_api"
    assert after["commercial"]["openai_api"]["model"] == "gpt-fixture"
    assert after["commercial"]["gemini_api"]["model"] == "gemini-fixture"
    assert after["hchat"] == hchat_original
    assert after["alira"] == alira_original
    assert after["custom"] == other_original


def test_commercial_keys_are_not_written_to_configuration(tmp_path):
    store = ProviderConfigStore(tmp_path)
    store.update_commercial("openai_api", model="gpt-fixture", manual_api_key="should-not-persist")
    persisted = json.loads((tmp_path / "config/provider_config.json").read_text(encoding="utf8"))
    assert "should-not-persist" not in json.dumps(persisted)
    assert "manual_api_key" not in persisted["commercial"]["openai_api"]


def test_gemini_header_auth_is_distinct_from_openai_and_claude(tmp_path):
    data = ProviderConfigStore(tmp_path).load()
    for provider, expected_name, expected_version in (
        ("openai_api", "Authorization", False),
        ("gemini_api", "x-goog-api-key", False),
        ("claude_api", "x-api-key", True),
    ):
        data["commercial"][provider]["manual_api_key"] = "local-test-key"
        api = create_provider(tmp_path, provider, data)
        headers, params = api._request_auth("local-test-key")
        assert expected_name in headers
        assert not params
        assert ("anthropic-version" in headers) == expected_version


def test_legacy_other_custom_api_still_independent(tmp_path):
    data = ProviderConfigStore(tmp_path).load()
    data["custom"]["model"] = "model-legacy"
    data["custom"]["manual_api_key"] = "legacy-secret"
    custom = create_provider(tmp_path, "custom_api", data)
    assert custom.metadata().provider_id == "custom_api"
    assert custom.metadata().display_name.startswith("기타 API /")
    assert custom.model == "model-legacy"


def test_main_gui_declares_eight_exclusive_choices_and_three_categories():
    main = Path(__file__).parents[1] / "main.py"
    text = main.read_text(encoding="utf8")
    assert 'self.provider_button_group.setExclusive(True)' in text
    for category in ('provider_row(0, "상용 AI"', 'provider_row(1, "H-CHAT"', 'provider_row(2, "ALIRA"'):
        assert category in text
    for attr in ("radio_openai", "radio_commercial_gemini", "radio_commercial_claude", "radio_custom",
                 "radio_gpt", "radio_gemini", "radio_claude", "radio_alira"):
        assert f"self.{attr} = QRadioButton" in text
    assert 'btn.setFixedSize(124, 42)' in text
    assert 'self.api_key_folder_button.setText("AI 설정")' in text


def test_selected_commercial_model_remains_runtime_only_for_credentials(tmp_path):
    store = ProviderConfigStore(tmp_path)
    data = store.update_selection("openai_api", model="gpt-6.1-sol")
    assert data["selected_provider"] == "openai_api"
    provider = create_provider(tmp_path, "openai_api", data)
    assert "미입력" in provider.metadata().credential_status


def test_preexisting_hchat_selection_remains_unmodified(tmp_path):
    store = ProviderConfigStore(tmp_path)
    for provider in ("hchat_gpt", "hchat_gemini", "hchat_claude", "alira"):
        data = store.update_selection(provider)
        meta = create_provider(tmp_path, provider, data).metadata()
        assert meta.provider_id == provider
