"""V0.120 folder/launcher contract and non-destructive path regression tests."""
from pathlib import Path
import hashlib
import json
import runpy
import zipfile
from unittest.mock import patch
import pytest

SYSTEM = Path(__file__).resolve().parents[1]
ROOT = SYSTEM.parent
EXPECTED = {
    "input", "output", "system", "sample_input", "RequirementStudio.pyw",
    "Requirement_Studio_Requirements_Management_rev103.xlsx",
}


def test_exact_six_root_entries_and_preserved_original_sources():
    assert {p.name for p in ROOT.iterdir()} == EXPECTED
    assert (ROOT/'RequirementStudio.pyw').is_file()
    for source in ('main.py','package_manifest.json','requirements.txt','START_HERE.txt','Requirement Studio.pyw'):
        assert (SYSTEM/source).is_file(), source
        assert not (ROOT/source).exists(), source
    for folder in ('core','providers','config','policy','contracts','history','tests','api_keys',
                   'Build AI Better Decision','app','assets','work','review_exchange'):
        assert (SYSTEM/folder).is_dir(), folder
    assert (ROOT/'sample_input').is_dir()
    assert not (ROOT/'sample_inputs').exists()
    assert (ROOT/'input'/'.gitkeep').is_file()


def test_user_visible_launcher_points_to_system_bootstrap_without_extra_dependencies():
    launcher=(ROOT/'RequirementStudio.pyw').read_text('utf-8')
    assert "'system' / 'app' / 'ALIRA.pyw'" in launcher
    source=(SYSTEM/'app'/'ALIRA.pyw').read_text('utf-8')
    assert 'MAIN_PY = ROOT / "main.py"' in source
    assert 'REQUIREMENTS = ROOT / "requirements.txt"' in source
    assert 'VENV_DIR = ROOT / ".venv"' in source
    meta=runpy.run_path(str(SYSTEM/'app'/'ALIRA.pyw'),run_name='__layout_test__')
    assert meta['ROOT']==SYSTEM
    assert meta['MAIN_PY']==SYSTEM/'main.py'
    assert meta['REQUIREMENTS']==SYSTEM/'requirements.txt'


def test_runtime_main_uses_separate_internal_and_external_data_roots():
    source=(SYSTEM/'main.py').read_text('utf-8')
    assert 'APP_VERSION = "v0.120"' in source
    assert 'self.documents = DocumentManager(self.user_root / "input")' in source
    assert 'self.output_dir = self.user_root / "output"' in source
    assert 'self.api_key_dir = self.project_root / "api_keys"' in source


def test_requirement_engine_outputs_to_top_level_without_changing_policy(tmp_path):
    from core.requirement_engine import RequirementEngine
    bundle=tmp_path/'Requirement_Studio_V0.120'
    system=bundle/'system';system.mkdir(parents=True)
    (bundle/'RequirementStudio.pyw').write_text('launcher',encoding='utf-8')
    engine=RequirementEngine(system)
    assert engine.output_dir==bundle/'output'
    assert engine.output_dir.is_dir()
    assert engine.policy_path == system/'policy'/'requirement_judgment_policy.json'
    # Existing standalone/unmoved test paths remain compatible.
    legacy=RequirementEngine(tmp_path/'legacy')
    assert legacy.output_dir==tmp_path/'legacy'/'output'


def test_alira_uses_safe_work_copy_not_original_file(tmp_path):
    from core.alira_client import AliraClient
    bundle=tmp_path/'Requirement_Studio_V0.120'
    system=bundle/'system'; system.mkdir(parents=True)
    src=bundle/'input'/'case.pdf';src.parent.mkdir()
    src.write_bytes(b'%PDF-1.7 stable-original')
    digest=hashlib.sha256(src.read_bytes()).hexdigest()
    client=AliraClient(system)
    relative=client._relative_input_for_cli(src)
    copied=system/relative
    assert copied.is_file()
    assert copied!=src
    assert copied.read_bytes()==src.read_bytes()
    assert hashlib.sha256(src.read_bytes()).hexdigest()==digest
    with patch.object(client,'_run',return_value='mock response') as mock:
        assert client.analyze_document(src)=='mock response'
        prompt=mock.call_args.kwargs['prompt']
        assert relative.as_posix() in prompt
        assert client.extract_requirements(src)=='mock response'
    assert src.is_file() and hashlib.sha256(src.read_bytes()).hexdigest()==digest
    other=tmp_path/'outside.pdf';other.write_bytes(b'external')
    with pytest.raises(RuntimeError):client._relative_input_for_cli(other)


def test_key_storage_remains_internal_and_user_sample_is_preserved():
    from providers.commercial_credentials import credential_folder
    assert credential_folder(SYSTEM,'openai_api')==SYSTEM/'api_keys'/'commercial'/'openai'
    assert credential_folder(SYSTEM,'gemini_api')==SYSTEM/'api_keys'/'commercial'/'gemini'
    assert credential_folder(SYSTEM,'claude_api')==SYSTEM/'api_keys'/'commercial'/'claude'
    assert any(ROOT.joinpath('sample_input').rglob('*.pdf'))
    assert (SYSTEM/'Build AI Better Decision'/'Decision Complete'/'AI_E2E_GUIDELINE_CONSTITUTION.txt').is_file()


def test_main_workflow_data_locations_remain_compatible():
    from core.document_manager import DocumentManager
    from core.document_normalizer import DocumentNormalizer
    from core.prompt_builder import PromptBuilder
    from providers.config_store import ProviderConfigStore
    docs=DocumentManager(ROOT/'input')
    docs.ensure_input_dir()
    assert docs.input_dir==ROOT/'input'
    normalizer=DocumentNormalizer(SYSTEM)
    assert normalizer.work_root==SYSTEM/'work'/'normalized'
    prompts=PromptBuilder(SYSTEM)
    assert prompts.e2e_guide_path.is_file()
    assert ProviderConfigStore(SYSTEM).path==SYSTEM/'config'/'provider_config.json'
