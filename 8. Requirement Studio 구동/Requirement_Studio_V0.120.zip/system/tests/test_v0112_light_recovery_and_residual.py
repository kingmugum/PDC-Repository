"""V0.112 local-only synthetic regression: no external H-Chat/GPT requests."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from core.json_light_recovery import restore_complete_json, UnsafeJSONRecovery
from core.ai_job_runner import AIJobRunner
from core.prompt_builder import PromptPart
from core.requirement_engine import RequirementEngine
from providers.base import ProviderMetadata


def _fixture():
    return {"schema_version":"REQ-STUDIO-CANONICAL-REQ-1.1",
        "source_document":{"name":"synthetic.docx"},
        "scenario_candidates":[],"requirements":[{"candidate_id":"CAND_001",
        "requirement":"A 조건에서 B를 출력한다.",
        "source_evidence":[{"document":"synthetic.docx","location":"F1","text":"A 조건에서 B"}]}],
        "gaps":[{"gap_id":"GAP_001","description":"정의되지 않은 외부 정보"}]}


def test_eof_suffix_recovery_no_reanalysis():
    raw=json.dumps(_fixture(),ensure_ascii=False,separators=(',',':'))
    assert raw.endswith(']}')
    data,suffix=restore_complete_json(raw[:-2])
    assert suffix==']}' and data==_fixture()


def test_unclosed_string_is_not_guessed():
    raw=json.dumps(_fixture(),ensure_ascii=False)
    with pytest.raises(UnsafeJSONRecovery,match='문자열'):
        restore_complete_json(raw[:-4]+'미완성')


def test_extra_data_is_not_silently_discarded():
    raw=json.dumps(_fixture(),ensure_ascii=False)+' '+json.dumps(_fixture(),ensure_ascii=False)
    with pytest.raises(UnsafeJSONRecovery):
        restore_complete_json(raw)


def test_empty_or_incomplete_requirement_not_accepted():
    bad=_fixture();bad['requirements']=[]
    with pytest.raises(UnsafeJSONRecovery,match='요구사항'):
        restore_complete_json(json.dumps(bad,ensure_ascii=False)[:-2])


class _Provider:
    count=0
    def metadata(self):
        return ProviderMetadata(provider_id='fake',display_name='Fake',model='fictional',api_base='local',credential_status='na')


def _runner(tmp_path, responses):
    fake=_Provider()
    r=AIJobRunner(tmp_path,fake,None,None,RequirementEngine(tmp_path))
    def request(source,kind,part,log_callback=None):
        fake.count+=1
        if fake.count>len(responses):
            raise AssertionError('불필요한 추가 API 호출')
        return responses[fake.count-1]
    r._call=request
    source=tmp_path/'synthetic.docx';source.write_text('FAKE SOURCE',encoding='utf8')
    part=PromptPart(1,1,'fake system','[SOURCE]\nA 조건에서 B 출력')
    return r,source,part,fake


def test_local_fix_uses_zero_additional_provider_calls(tmp_path):
    raw=json.dumps(_fixture(),ensure_ascii=False,separators=(',',':'))
    r,doc,part,fake=_runner(tmp_path,[raw[:-2]])
    logs=[]
    result=r._extract_requirement_with_recovery(doc,part,part_index=1,part_total=1,log_callback=logs.append)
    assert fake.count==1 and result[0]['requirements']
    assert any('추가 API 0회' in log for log in logs)
    assert list((tmp_path/'work'/'recovery_failures').glob('*'))
    # Repeat identical document/prompt/model: reuse validated local checkpoint.
    r._extract_requirement_with_recovery(doc,part,part_index=1,part_total=1)
    assert fake.count==1
    doc.write_text('SOURCE CHANGED',encoding='utf8')
    with pytest.raises(AssertionError,match='불필요한'):
        r._extract_requirement_with_recovery(doc,part,part_index=1,part_total=1)


def test_nonrepairable_input_retries_only_once_then_stops(tmp_path):
    bad='{"a":1} {"b":2}'
    r,doc,part,fake=_runner(tmp_path,[bad,bad])
    with pytest.raises(RuntimeError,match='최대 1회'):
        r._extract_requirement_with_recovery(doc,part,part_index=1,part_total=1)
    assert fake.count==2
    assert len(list((tmp_path/'work'/'recovery_failures').glob('*.txt')))==2


def test_config_can_disable_retries(tmp_path):
    r,doc,part,fake=_runner(tmp_path,['{"a":1} {"b":2}'])
    config=tmp_path/'config';config.mkdir()
    (config/'json_recovery_config.json').write_text('{"max_extra_ai_calls_per_failed_part":0}',encoding='utf8')
    with pytest.raises(RuntimeError,match='자동 재요청 0회'):
        r._extract_requirement_with_recovery(doc,part,part_index=1,part_total=1)
    assert fake.count==1


def test_artifact_format_and_resolution_are_independent_tcs():
    from core.basic_functional_test_design import build_basic_functional_cases
    req={'srs_id':'FICT_001','function_name':'저장 영상 속성',
        'requirement':'저장 Format: JPEG. 저장 Resolution: 1920x1080.',
        'source_backed_atomic_behaviors':[{'source_fact_fragment_id':'F1','behavior_text':'Format: JPEG'},
                                           {'source_fact_fragment_id':'F2','behavior_text':'Resolution: 1920x1080'}]}
    base={'parent_srs_id':'FICT_001','test_object_id':'OBJ_001','test_object_type':'SWE6_TC',
          'source_fact_fragment_ids':['F1','F2']}
    cases,_,_=build_basic_functional_cases({'requirements':[req]},[base])
    props=[c for c in cases if c.get('basic_case_kind')=='OUTPUT_ARTIFACT_PROPERTIES']
    assert len(props)==2
    assert {c['output_variable'] for c in props}=={'Format','Resolution'}
    assert all(len(c.get('test_vectors',[]))==1 for c in props)
