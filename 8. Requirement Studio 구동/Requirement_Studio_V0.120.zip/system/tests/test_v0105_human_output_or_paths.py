"""V0.105: 20-column human output, source-exact OR branch, UI dimming."""
from pathlib import Path

from core.basic_functional_test_design import _source_explicit_alternative_trigger_cases
from core.e2e_exporter import (_format_boolean_pass_for_humans,
                               _format_tc_semicolon_lines,
                               _merge_expected_value_and_state,E2EExporter)


def test_or_source_two_shared_outcome_branches_with_fact_trace():
    req={'srs_id':'SRS_T','function_name':'메모리 정합성 확인',
         'activation_trigger':'마스터 제어기 전원 공급 또는 High Power Mode 진입',
         'processing_action':'저장된 데이터의 정합성을 Check-sum으로 검사한다',
         'output':'데이터 정합성 검사 수행',
         'acceptance_criteria':'마스터 제어기 전원 공급 또는 High Power Mode 진입 시 Check-sum으로 데이터 정합성을 검사한다',
         'source_backed_atomic_behaviors':[
             {'source_fact_fragment_id':'F-T','behavior_text':'마스터 제어기 전원 공급 또는 High Power Mode 진입 시 Check-sum으로 데이터 정합성을 검사한다'}]}
    base={'parent_srs_id':'SRS_T','test_object_type':'SWE6_TC',
          'source_fact_fragment_ids':['F-T'],'test_object_id':'OBJECT-T'}
    result,_=_source_explicit_alternative_trigger_cases(req,base,1)
    assert len(result)==2
    assert [c['input_value'] for c in result]==['마스터 제어기 전원 공급','High Power Mode 진입']
    assert all(c['split_decision']=='SPLIT_SOURCE_EXPLICIT_OR_TRIGGERS' for c in result)
    assert all('F-T' in c['source_fact_fragment_ids'] for c in result)
    assert all(c['human_review_required'] for c in result) # no false guarantee of independent control


def test_or_split_requires_literal_fact_and_same_consequence():
    base={'parent_srs_id':'SRS_T','test_object_type':'SYS5_CANDIDATE','source_fact_fragment_ids':['F1']}
    req={'srs_id':'SRS_T','activation_trigger':'제어기 전원 공급 또는 High Power Mode 진입',
         'processing_action':'정합성을 검사한다','output':'정합성 검사 수행',
         'acceptance_criteria':'정합성 검사 완료'}
    assert not _source_explicit_alternative_trigger_cases(req,base,1)[0]
    req['source_backed_atomic_behaviors']=[{'source_fact_fragment_id':'F1','behavior_text':'제어기 전원 공급 또는 High Power Mode 진입 시 정합성을 검사한다'}]
    req['activation_trigger']='사용자 설정 정보 수신 또는 LED 제어 명령 수신'
    req['acceptance_criteria']='사용자 설정을 저장하고 LED를 제어한다'
    assert not _source_explicit_alternative_trigger_cases(req,base,1)[0]


def test_semicolon_output_line_breaks_and_expected_values_are_not_lost():
    assert _format_tc_semicolon_lines('LED OFF; 슬레이브 LOW POWER MODE; 마스터 LOW POWER MODE 진입')=='LED OFF\n슬레이브 LOW POWER MODE\n마스터 LOW POWER MODE 진입'
    assert '0x4' in _merge_expected_value_and_state('0x4','동작 완료')
    assert _merge_expected_value_and_state('0x4','동작 완료 0x4')=='동작 완료 0x4'


def test_boolean_pass_is_numbered_for_independent_cases():
    case={'basic_case_kind':'BOOLEAN_CONDITION_COVERAGE','condition_logic':'ALL_OF',
          'expected_target_state':'Low Power Mode',
          'boolean_condition_states':[{'name':'OFF 명령 수신 시','expected':True},
                                     {'name':'슬레이브 SLEEP','expected':False}]}
    s=_format_boolean_pass_for_humans(case,'한 줄로 이어진 원본 문장')
    assert '1) 슬레이브 SLEEP 조건 미충족' in s
    assert '2) 나머지 진입 조건 충족' in s
    assert '3) Low Power Mode로 전환되지 않으면 PASS' in s


def test_visual_quality_review_none_dims_card_and_radio_choices():
    text=(Path(__file__).resolve().parents[1]/'main.py').read_text(encoding='utf-8')
    assert 'self.review_artifact_card.setStyleSheet' in text
    assert 'self.review_artifact_title.setStyleSheet' in text
    assert 'self.review_artifact_unified.setEnabled(review_enabled)' in text
    assert 'background-color:#F1F3F6' in text


def test_20_column_latest_layout_with_unique_name_and_merge(tmp_path,monkeypatch):
    from openpyxl import load_workbook
    import core.e2e_exporter as e
    mock={'parent_srs_id':'SRS_0','evaluation_name':'전원단 전압 구간별 검증 - 7V < V < 18V',
          'test_object_type':'SYS5_CANDIDATE','input_value':'8V',
          'output_variable':'상태 신호','output_value':'0x4',
          'expected_state':'제어기 동작 확인; 통신 상태 확인',
          'pass_criterion':'동작 및 통신 확인'}
    monkeypatch.setattr(e,'finalize_verification_single_truth',lambda *_a,**_k:{
        'e2e_basic_functional_cases':[mock], 'e2e_evaluation_cases':[],
        'integrated_test_objects':[], 'basic_functional_design_audit':{},
        'single_truth_audit':{},'semantic_verification_quality_audit':{}})
    path=E2EExporter(tmp_path).export_evaluation_excel(Path('fake.docx'),{'requirements':[]})
    w=load_workbook(path);sh=w['2_E2E_평가케이스']
    assert sh.max_column==20
    assert sh['E4'].value=='전원단 전압 구간별 검증 - 7V < V < 18V'
    assert sh['O3'].value=='예상 결과'
    assert '0x4' in sh['O4'].value
    assert '\n' in sh['O4'].value
    assert sh['Q3'].value=='실제 출력값' and sh['T3'].value=='결과 화면 캡처'
    assert all(sh.cell(4,i).value is None for i in range(17,21))
    w.close()
