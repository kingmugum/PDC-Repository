"""V0.111 deterministic regression: actual feedback classes with fictional inputs only."""
from pathlib import Path

from core.basic_functional_test_design import (
    _deduplicate_exact_semantic_goals,
    _looks_like_actual_decision_table,
    _pipe_decision_table_cases,
)
from core.semantic_objective_design import (
    human_conditional_tc_title,
    identify_conditional_path_goals,
)
from core.e2e_exporter import E2EExporter


def test_signal_enumeration_catalog_is_not_an_executable_decision_table():
    headers = ['Output', 'CAN Communication', 'C_GreenRValue', '신호 설명']
    values = [
        ['Input', 'CAN Communication', 'C_BlueNValueSet', '0x0:OFF 0x1:ON 0x2~0xE:reserved'],
        ['Output', 'CAN Communication', 'C_GreenRValue', '0x0:OFF 0x1:ON 0x2~0xE:reserved'],
    ]
    assert not _looks_like_actual_decision_table(headers, values, 2)
    source='\n'.join(' | '.join(row) for row in [headers]+values)
    req = {'srs_id':'SRS_EX','requirement':source,
           'source_backed_atomic_behaviors':[{'source_fact_fragment_id':'FACT-1','behavior_text':source}]}
    base = {'parent_srs_id':'SRS_EX','test_object_id':'T1','test_object_type':'SWE6_TC',
            'source_fact_fragment_ids':['FACT-1']}
    cases,_=_pipe_decision_table_cases(req,base,1)
    assert not cases


def test_explicit_real_decision_table_still_yields_independent_tcs():
    headers=['신호 A','신호 B','제어 결과']
    rows=[['0','0','비동작'],['1','0','동작'],['1','1','동작']]
    assert _looks_like_actual_decision_table(headers,rows,2)
    source='\n'.join(' | '.join(r) for r in [headers]+rows)
    req={'srs_id':'SRS_EX','requirement':source,'source_backed_atomic_behaviors':[
        {'source_fact_fragment_id':'FACT-1','behavior_text':source}]}
    base={'parent_srs_id':'SRS_EX','test_object_id':'T1','test_object_type':'SYS5_CANDIDATE',
          'source_fact_fragment_ids':['FACT-1']}
    cases,_=_pipe_decision_table_cases(req,base,1)
    assert len(cases)==3
    assert [c['expected_state'] for c in cases]==['비동작','동작','동작']


def test_human_names_describe_behavior_not_source_identifier_or_truncation():
    source=(
        '[REQ02_12] Input_MoodLpOn 신호와 관계없이 Input_FootLpOn 신호가 Off(0x0)인 경우 '
        '풋램프 위치의 슬레이브 제어기를 Off제어한다. '
        '[REQ02_13] Input_MoodLpOn 신호와 관계없이 Input_FootLpOn 신호가 On(0x1)인 경우 '
        '풋램프 위치의 슬레이브 제어기를 밝기 설정값으로 On 한다. '
        '[REQ02_14] Input_FootLpOn 신호가 Dimout(0x2)인 경우 '
        '풋램프 위치의 슬레이브 제어기를 감광 제어한다.'
    )
    goals=identify_conditional_path_goals([{'fid':'FACT-X','text':source}])
    assert len(goals)==3
    assert all('REQ' not in x.title and '…' not in x.title and '결과 확인' not in x.title for x in goals)
    assert goals[0].title=='풋램프 OFF 제어'
    assert goals[1].title=='풋램프 ON 및 밝기 제어'
    assert goals[2].title=='풋램프 감광 제어'
    assert '[REQ02_12]' in goals[0].evidence_excerpt  # provenance remains in raw Source evidence


def test_one_input_two_outputs_splits_into_two_independent_observable_goals():
    text='사용자 동의가 미완료인 경우 동의 정보를 삭제하고 OSD를 출력한다.'
    goals=identify_conditional_path_goals([{'fid':'FACT-Q','text':text}])
    assert len(goals)==2
    assert {g.expected for g in goals}=={'동의 정보를 삭제한다','OSD를 출력한다'}
    assert all(g.source_fact_fragment_ids==('FACT-Q',) for g in goals)
    assert all('동의' in g.condition for g in goals)


def test_single_result_does_not_force_extra_semantic_case():
    assert identify_conditional_path_goals([
        {'fid':'F1','text':'전원이 정상인 경우 작동 상태를 유지한다.'}
    ])==[]


def test_same_exact_semantic_case_dedup_preserves_both_object_ids():
    common={'parent_srs_id':'SRS_001','basic_case_kind':'SEMANTIC_INDEPENDENT_OBJECTIVE',
            'semantic_goal_kind':'GENERAL_CONDITIONAL_PATH_01','semantic_condition_source':'A가 참인 경우',
            'evaluation_name':'경고 출력','expected_state':'경고 ON','pass_criterion':'경고 ON이면 PASS',
            'source_fact_fragment_ids':['FACT-1']}
    a={**common,'test_object_id':'SYS5_001'}
    b={**common,'test_object_id':'SWE6_001'}
    different={**common,'test_object_id':'SWE6_002','semantic_condition_source':'B가 참인 경우'}
    kept,merged=_deduplicate_exact_semantic_goals([a,b,different])
    assert len(kept)==2 and len(merged)==1
    assert 'SWE6_001' in kept[0]['merged_source_object_ids']


def test_excel_human_display_removes_internal_req_references_but_keeps_conditions(tmp_path):
    exp=E2EExporter(tmp_path)
    text='[REQ07_03] 고/저전압 발생 시 (시스템 사양서 참조) 출력 차단을 수행한다.'
    human=exp._human_e2e_text(text)
    assert 'REQ07_03' not in human and '시스템 사양서 참조' not in human
    assert '고/저전압 발생 시' in human and '출력 차단' in human


def test_diagnostic_logs_show_current_release_version():
    from core import e2e_decision_log,semantic_split_diagnostic
    assert 'V0.112 | E2E 시험 설계' in Path(e2e_decision_log.__file__).read_text(encoding='utf-8')
    assert 'V0.112 | E2E 의미 분할' in Path(semantic_split_diagnostic.__file__).read_text(encoding='utf-8')


def test_source_metadata_is_line_broken_for_human_reader(tmp_path):
    exp=E2EExporter(tmp_path)
    raw='Input / CAN Communication / C_GSelDisp / 주행 중 감광 기능 (TCU) 0x0:P 0x1:L'
    assert exp._human_e2e_text(raw).splitlines()[:3]==['Input','CAN Communication','C_GSelDisp']
