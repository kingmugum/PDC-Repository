"""V0.115 UI-only copy update, no live API usage."""
from pathlib import Path


def test_commercial_placeholder_guides_right_hand_key_button():
    source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
    assert 'APP_VERSION = "v0.120"' in source
    assert '"우측에 API Key 수동입력으로 키를 입력해주세요"' in source
    assert 'status = "API Key 미사용"' in source
    assert 'self.api_key_field.setReadOnly(True)' in source
    assert 'self.api_key_manual_button.clicked.connect(self._on_provider_action_secondary)' in source
    assert 'self.api_key_manual_button.setEnabled(key_required)' in source

def test_hchat_and_alira_prompt_paths_are_untouched():
    source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
    assert 'self.api_key_field.setPlaceholderText("API Key를 입력하세요.")' in source
    assert 'self.api_key_field.setPlaceholderText("ALIRA CLI / License / 원격 Qwen")' in source
