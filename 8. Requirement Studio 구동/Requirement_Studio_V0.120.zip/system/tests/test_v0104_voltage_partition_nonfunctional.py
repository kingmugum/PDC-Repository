"""V0.104: source-anchored voltage ranges and 21-column nonfunctional presentation."""
from pathlib import Path
from core.basic_functional_test_design import _voltage_boundary_value_cases
from core.e2e_exporter import E2EExporter, _is_nonfunctional_e2e_case


def _base():
    return {'parent_srs_id':'SRS_N','test_object_type':'SYS5_CANDIDATE',
            'source_fact_fragment_ids':['F_NORMAL','F_HYST','F_OUT'],
            'test_object_id':'MOCK_SYS5','human_review_required':True}


def _requirement(text):
    return {'srs_id':'SRS_N','function_name':'전원단 동작 전압',
            'requirement':text, 'acceptance_criteria':text,
            'source_backed_atomic_behaviors':[
                {'source_fact_fragment_id':'F_NORMAL','behavior_text':text},
            ]}


def test_multi_region_five_candidates_preserve_explicit_outputs_and_boundary_overlap():
    req=_requirement('제어기 전원단 전압 DC 7V~18V에서 정상동작하고, '
        '6.5V~7V 및 18V~18.5V에서 통신 송신 금지 및 제어기 정상동작, '
        'DC 6.5V 이하 또는 DC 18.5V 이상에서 통신 disable된다.')
    cases,_=_voltage_boundary_value_cases(req,_base(),1)
    assert len(cases)==5
    assert [c['boundary_region'] for c in cases]==[
        'V < 6.5V','6.5V < V < 7V','7V < V < 18V','18V < V < 18.5V','V > 18.5V']
    assert cases[1]['pass_criterion'].find('통신 송신 금지')>=0
    assert cases[0]['boundary_exact_points_review']==['6.5V','7V','18V','18.5V']
    assert all(c['expectation_basis']=='SOURCE_EXPLICIT' for c in cases)
    assert all('F_NORMAL' in c['source_fact_fragment_ids'] for c in cases)


def test_single_declared_range_yields_three_without_inventing_negative_failure():
    req=_requirement('제어기 전원단 전압 DC 9V~16V에서 정상동작한다.')
    cases,_=_voltage_boundary_value_cases(req,_base(),1)
    assert len(cases)==3
    assert cases[0]['expectation_basis']=='ENGINEERING_HYPOTHESIS'
    assert cases[1]['expectation_basis']=='SOURCE_EXPLICIT'
    assert cases[2]['expectation_basis']=='ENGINEERING_HYPOTHESIS'
    assert not any('정상동작하지 않' in c['pass_criterion'] for c in cases)
    assert cases[0]['boundary_exact_points_review']==['9V','16V']


def test_no_bva_on_unverified_voltage_number_or_wrong_objective():
    req=_requirement('DC 13.5V 정격 전압을 적용한다.')
    assert _voltage_boundary_value_cases(req,_base(),1)[0]==[]
    req=_requirement('9V~16V에서 정상동작한다.')
    base=_base();base['test_object_type']='MANUFACTURING_VERIFICATION_INTENT'
    assert _voltage_boundary_value_cases(req,base,1)[0]==[]


def test_nonfunctional_classification_uses_source_and_preserves_domain():
    assert _is_nonfunctional_e2e_case({'test_object_type':'ELECTRICAL_VERIFICATION_INTENT'})
    assert _is_nonfunctional_e2e_case({'evaluation_name':'최대 소비 전류 100mA 확인'})
    assert _is_nonfunctional_e2e_case({'evaluation_name':'-40 ~ 85도 사용 온도 범위'})
    assert not _is_nonfunctional_e2e_case({'evaluation_name':'S/W 오류 복귀 확인','test_object_type':'SWE6_TC'})


def test_e2e_21_cols_violet_beige_and_a1_legend(tmp_path,monkeypatch):
    from openpyxl import load_workbook
    import core.e2e_exporter as exp
    nonfunctional={'parent_srs_id':'SRS_X','evaluation_name':'최대 소비 전류 100mA','basic_case_kind':'SOURCE_BACKED_FALLBACK','test_object_type':'ELECTRICAL_VERIFICATION_INTENT',
      'expected_state':'100mA 이하','pass_criterion':'100mA 이하','source_fact_fragment_ids':['FF']}
    guessed=dict(nonfunctional,expectation_basis='ENGINEERING_HYPOTHESIS',evaluation_name='전압 범위 밖 결과 확인')
    monkeypatch.setattr(exp,'finalize_verification_single_truth',lambda *_args,**_kwargs:{
        'e2e_basic_functional_cases':[nonfunctional,guessed], 'e2e_evaluation_cases':[],
        'integrated_test_objects':[], 'basic_functional_design_audit':{}, 'single_truth_audit':{},
        'semantic_verification_quality_audit':{}})
    out=E2EExporter(tmp_path).export_evaluation_excel(Path('demo.docx'),{'requirements':[]})
    wb=load_workbook(out)
    ws=wb['2_E2E_평가케이스']
    assert ws.max_column==20
    assert ws['Q3'].value=='실제 출력값' and ws['T3'].value=='결과 화면 캡처'
    assert ws['C4'].value=='비기능'
    assert '보라색 색상으로 된 셀은 비기능 TC입니다' in ws['A1'].value
    assert ws['A1'].font.sz==10
    assert ws['B4'].fill.fgColor.rgb.endswith('F5F0FC')
    assert ws['P5'].fill.fgColor.rgb.endswith('FAF1E5')
    assert 'TC 검토 상태' not in [ws.cell(3,c).value for c in range(1,21)]
    for row in (4,5):
        assert all(ws.cell(row,c).value is None for c in range(17,21))
    wb.close()
