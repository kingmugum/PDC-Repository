"""V0.95.1: independently selectable outputs and top aligned drop card."""
from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/'main.py').read_text(encoding='utf-8')

def _method(name):
    mod=ast.parse(TEXT)
    cls=next(n for n in mod.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
    node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.get_source_segment(TEXT,node)

def test_all_five_choices_are_independent_and_not_disabled():
    build=_method('_build_execution_card')
    selection=_method('run_combined_pipeline')
    toggler=_method('_on_learning_mode_toggled')
    busy=_method('_sync_busy_state')
    assert len(['SWE.1 문서','SWE.6 문서','E2E 요구사항 명세서','E2E 평가 명세서','AI E2E 학습 후보 10개 생성'])==5
    for label in ['SWE.1 문서','SWE.6 문서','E2E 요구사항 명세서','E2E 평가 명세서','AI E2E 학습 후보 10개 생성']:
        assert label in build
    assert 'setEnabled(not enabled)' not in toggler
    assert 'self.output_swe1_word.isChecked() and not self.current_learning_only' not in selection
    assert 'self.output_swe1_word.isChecked()' in selection
    assert 'self.current_learning_only and not any(self.current_output_selection.values())' in selection
    assert 'if enabled and self.learning_only_checkbox.isChecked()' not in busy

def test_mixed_mode_writes_learning_and_standard_outputs():
    completion=_method('_on_pipeline_success')
    assert 'if self.current_learning_only and req_data:' in completion
    assert 'create_learning_sample(self.project_root, document, req_data)' in completion
    assert 'if req_data and self.current_output_selection.get("swe6_excel")' in completion
    assert 'if req_data and self.current_output_selection.get("e2e_evaluation_excel")' in completion

def test_learning_only_avoids_extra_ai_and_unwanted_documents():
    run=_method('run_combined_pipeline')
    complete=_method('_on_pipeline_success')
    assert 'persist_result=not self.current_learning_only_run' in run
    assert 'if getattr(self, "current_learning_only_run", False):' in complete
    assert 'review_cfg = {"enabled": False' in run
    assert 'self.review_mode_none.setChecked(True)' in _method('_reset_quality_review_defaults')

def test_file_card_aligns_top_with_ellipsis_not_wrapping():
    src=TEXT.split('class FileDropZone',1)[1].split('class LoadingDotsIndicator',1)[0]
    assert 'QLabel("파일 드래그")' in src
    assert 'self.title_label.setWordWrap(False)' in src
    card=_method('_build_file_card')
    assert 'layout.addWidget(self.drop_zone, 0)' in card
    assert 'layout.addStretch(1)' in card
