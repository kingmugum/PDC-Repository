"""V0.99: output explanation log, scoped alignment and traced Boolean coverage."""
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET

from core.basic_functional_test_design import _explicit_boolean_transition_cases
from core.e2e_decision_log import build_e2e_decision_summary
from core.e2e_exporter import E2EExporter
from tests.test_v082_integrated_specs_single_truth import _mode_fixture

NS={"m":"http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def test_traced_and_four_conditions_have_one_positive_and_four_unasserted_negative():
    req=_mode_fixture()['requirements'][0]
    from core.verification_single_truth import build_e2e_evaluation_cases,build_integrated_test_objects
    from core.swe6_exporter import build_swe6_cases,build_sys5_candidates
    data={'requirements':[req],'testability_and_decomposition_result':{'by_srs':[]}}
    objective=build_e2e_evaluation_cases(data,build_integrated_test_objects(data,build_swe6_cases(data),build_sys5_candidates(data)))
    primary=next(x for x in objective if x.get('test_object_type')=='SYS5_CANDIDATE')
    cases,_=_explicit_boolean_transition_cases(req,primary,1)
    assert len(cases)==5
    assert cases[0]['expected_state']
    assert cases[0]['pass_criterion']
    for c in cases[1:]:
        assert c['human_review_required'] is True
        assert c['pass_criterion'].startswith('[시험 설계 가설]')
        assert '시험 설계 가설' in c['expected_state']
        assert c['split_decision']=='PROPOSE_BOOLEAN_NEGATIVE_EXPECTATION'
        assert c['source_fact_fragment_ids']


def test_untraced_or_undefined_target_does_not_synthesize_boolean_cases():
    req={'srs_id':'R','requirement':'AA와 BB 참이면 상태전이', 'source_backed_atomic_behaviors':[]}
    base={'test_object_type':'SYS5_CANDIDATE','condition_logic':'ALL_OF',
          'transition_family':'power_mode_transition','expected_target_state':'Low Power Mode',
          'condition_texts':['AA','BB'],'condition_fragment_ids':['MISSING-A','MISSING-B']}
    cases,idx=_explicit_boolean_transition_cases(req,base,1)
    assert cases==[] and idx==1


def test_log_explains_generated_and_missing_coverage_without_secret():
    cases=[
        {'parent_srs_id':'SRS_1','evaluation_name':'Low Power Mode',
         'basic_case_kind':'SOURCE_BACKED_FALLBACK','condition_logic':'ALL_OF',
         'source_fact_fragment_ids':['F1'], 'pass_criterion':'조건 참','human_review_required':True},
        {'parent_srs_id':'SRS_1','evaluation_name':'Low Power Mode',
         'basic_case_kind':'SOURCE_BACKED_FALLBACK','condition_logic':'ALL_OF',
         'source_fact_fragment_ids':['F2'], 'pass_criterion':'조건 참','human_review_required':True},
    ]
    txt=build_e2e_decision_summary(source_document=Path('sample.docx'),cases=cases,human_ids=['SRS_TC_001','SRS_TC_002'],reqs={'SRS_1':{}})
    for value in ('같은 요구사항', '중복 가능성','AND','자동 생성되지 않음','SRS_TC_001','F1','input'):
        if value=='input': continue
        assert value in txt
    assert len(txt)<9000


def test_e2e_workbook_left_center_data_and_sidecar(tmp_path:Path):
    import core.e2e_exporter as exp
    from core.basic_functional_test_design import _fallback_case
    req={'srs_id':'SRS_006','function_name':'온도 범위','requirement':'사용 온도 -40C ~ +85C', 'acceptance_criteria':'사용 온도 -40C ~ +85C'}
    base={'test_object_type':'ENVIRONMENTAL_VERIFICATION_INTENT','parent_srs_id':'SRS_006',
          'source_backed_behavior':'사용 온도 범위 -40C ~ +85C','source_fact_fragment_ids':['F-TEMP'],
          'human_review_required':True}
    one=_fallback_case(req,base,1)
    def bundle(*args,**kwargs):
        return {'e2e_basic_functional_cases':[one], 'e2e_evaluation_cases':[one],
                'integrated_test_objects':[one], 'basic_functional_design_audit':{},
                'single_truth_audit':{},'semantic_verification_quality_audit':{}}
    original=exp.finalize_verification_single_truth
    exp.finalize_verification_single_truth=bundle
    try:
        out=E2EExporter(tmp_path).export_evaluation_excel(Path('Demo.docx'),{'requirements':[req]})
    finally:
        exp.finalize_verification_single_truth=original
    assert out.is_file()
    logs=list(tmp_path.glob('00_E2E_판단근거_요약_*.txt'))
    assert len(logs)==1
    assert 'SRS_TC_001' in logs[0].read_text(encoding='utf-8-sig')
    with ZipFile(out) as z:
        root=ET.fromstring(z.read('xl/worksheets/sheet4.xml'))
        styles=ET.fromstring(z.read('xl/styles.xml'))
    alignments=styles.find('m:cellXfs',NS)
    def cell(ref):
        n=root.find(f'.//m:sheetData/m:row/m:c[@r="{ref}"]',NS)
        assert n is not None,ref
        style=int(n.attrib.get('s','0'))
        a=alignments[style].find('m:alignment',NS)
        val=''.join(x.text or '' for x in n.findall('.//m:t',NS))
        return a.attrib if a is not None else {},val
    assert cell('E4')[0]['horizontal']=='left'  # title
    assert cell('P4')[0]['horizontal']=='left'  # PASS
    assert cell('Q4')[0]['vertical']=='center'
    assert cell('I4')[0]['horizontal']=='left'  # E:Q always left, including N/A
    assert cell('A4')[0]['horizontal']=='center'
    assert cell('T4')[1]=='' # no fabricated actual result
