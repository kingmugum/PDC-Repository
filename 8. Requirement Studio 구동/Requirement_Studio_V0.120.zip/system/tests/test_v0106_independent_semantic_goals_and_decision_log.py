"""V0.106 independent objectives and *applied-rule* log regression."""
from pathlib import Path

from core.basic_functional_test_design import build_basic_functional_cases
from core.e2e_decision_log import build_e2e_decision_summary
from core.semantic_objective_design import identify_independent_goals


def sample(sid, chunks):
    req={'srs_id':sid,'function_name':'복합 기능',
         'requirement':' '.join(v for _,v in chunks),
         'acceptance_criteria':' '.join(v for _,v in chunks),
         'source_backed_atomic_behaviors':[
             {'behavior_text':v,'source_fact_fragment_id':fid,
              'source_semantic_unit_id':sid+'_U','source_location':'Fictional'}
             for fid,v in chunks]}
    base={'parent_srs_id':sid,'test_object_type':'SYS5_CANDIDATE',
          'test_object_id':sid+'_OBJ',
          'source_fact_fragment_ids':[f for f,_ in chunks],
          'human_review_required':True}
    return req,base


def test_sw_recovery_and_watchdog_are_separate_verification_objectives():
    req,base=sample('SRS_A',[
       ('F-RESET','SW 오류 발생 시 MCU Reset을 통해 즉시 정상 상태로 복귀한다.'),
       ('F-WDT','Watchdog Timer는 가장 낮은 Task 이후 작동하며 인터럽트 서비스 루틴 내부에는 위치하지 않는다.')])
    cases,reviews,audit=build_basic_functional_cases({'requirements':[req]},[base])
    assert len(cases)==2
    by_kind={x['semantic_goal_kind']:x for x in cases}
    assert set(by_kind)=={'SOFTWARE_ERROR_RECOVERY','WATCHDOG_ARCHITECTURE'}
    assert by_kind['SOFTWARE_ERROR_RECOVERY']['source_fact_fragment_ids']==['F-RESET']
    assert by_kind['WATCHDOG_ARCHITECTURE']['source_fact_fragment_ids']==['F-WDT']
    assert '정적 분석' in by_kind['WATCHDOG_ARCHITECTURE']['semantic_verification_method']
    assert all(x['engineering_decision_record']['decision']=='SPLIT' for x in cases)
    assert audit['semantic_independent_objective_count']==2


def test_compound_one_fact_supports_distinct_objectives_without_fake_fact_ids():
    text=('SW 오류 발생 시 MCU Reset으로 정상 상태로 복귀한다. '
          'Watchdog Timer는 가장 낮은 Task 이후에 동작하며 인터럽트 서비스 루틴 안에 존재하지 않는다.')
    req,base=sample('SRS_B',[('ONE-FACT',text)])
    cases,_,_=build_basic_functional_cases({'requirements':[req]},[base])
    assert len(cases)==2
    assert all(x['source_fact_fragment_ids']==['ONE-FACT'] for x in cases)
    assert len({x['semantic_goal_kind'] for x in cases})==2
    log=build_e2e_decision_summary(source_document=Path('safe_demo.docx'),cases=cases,
       human_ids=['SRS_TC_001','SRS_TC_002'],reqs={'SRS_B':req})
    assert 'SPLIT' in log and 'Watchdog' in log
    assert '순서·구성:' in log and 'ONE-FACT' in log
    assert '입력 신호 미연결' in log
    assert 'AI의 비공개 내부 추론' in log


def test_memory_check_and_safe_response_and_can_recovery_rules():
    records=[{'fid':'F1','text':'전원 인가 시 EEPROM 저장 데이터의 정합성을 Check-sum으로 검사한다.'},
             {'fid':'F2','text':'데이터 정합성 이상 시 모든 슬레이브 출력을 OFF하고 LOW POWER MODE로 진입한다.'},
             {'fid':'F3','text':'CAN 통신 오류 발생 시 모든 작동을 중지하고 LOW POWER MODE 진입한다.'},
             {'fid':'F4','text':'CAN 통신 복구 시 정상 동작한다.'}]
    kinds={g.kind for g in identify_independent_goals(records)}
    assert kinds=={'DATA_INTEGRITY_CHECK','DATA_FAULT_SAFE_REACTION',
                   'COMMUNICATION_FAILURE_RESPONSE','COMMUNICATION_RESTORATION'}


def test_untraced_or_single_goal_not_arbitrarily_split():
    assert identify_independent_goals([{'fid':'F1','text':'Watchdog Timer 사용 시 가장 낮은 Task 이후에 작동한다.'}])==[]
    assert identify_independent_goals([{'fid':'','text':'SW 오류 시 MCU Reset을 통해 정상 상태로 복귀한다.'},
                                     {'fid':'','text':'Watchdog Timer는 Task 이후에 작동한다.'}])==[]


def test_led_distinct_goals_do_not_invent_brightness_values():
    records=[{'fid':'F1','text':'사용자 설정 정보를 비휘발성 메모리에 저장한다.'},
             {'fid':'F2','text':'슬레이브 LED의 On/Off, 밝기 및 색상을 제어한다.'}]
    goals=identify_independent_goals(records)
    assert len(goals)==4
    assert all('10%' not in x.execution and '0x1' not in x.expected for x in goals)
    assert all(x.source_fact_fragment_ids for x in goals)


def test_existing_ordered_sequence_logged_as_step_not_arbitrary_tc_split():
    case={'parent_srs_id':'SRS_SE','evaluation_name':'원본 순차 요청과 응답',
          'basic_case_kind':'SEQUENCE_REQUEST_RESPONSE','source_fact_fragment_ids':['SE-Q'],
          'test_vectors':[{'step':1},{'step':2}],}
    log=build_e2e_decision_summary(source_document=Path('demo.docx'),cases=[case],
      human_ids=['SRS_TC_001'],reqs={'SRS_SE':{}})
    assert 'KEEP+STEP/VECTOR' in log
    assert '원본에 명시된 전환 순서' in log


def test_log_replaces_old_boilerplate_with_compact_reason():
    req,base=sample('SRS_A',[
        ('F1','SW 오류 발생 시 MCU Reset을 통해 정상 상태로 복귀한다.'),
        ('F2','Watchdog Timer는 가장 낮은 Task 이후 작동하고 인터럽트 서비스 루틴 내에 존재하지 않는다.')])
    cases,_,audit=build_basic_functional_cases({'requirements':[req]},[base])
    log=build_e2e_decision_summary(source_document=Path('demo.docx'),cases=cases,
        human_ids=['SRS_TC_001','SRS_TC_002'],reqs={'SRS_A':req},design_audit=audit)
    assert '[TC별 Engineering 판단과 실행 순서의 이유]' in log
    assert '원본 Fact → 검증 목적 → TC/Step/Vector' in log
    assert len(log)<7500


def test_e2e_export_writes_one_decision_log_with_source_fact_and_reason(tmp_path,monkeypatch):
    """Actual Excel export path, without a network provider, generates exactly one sidecar."""
    from core import e2e_exporter as exporter
    req,base=sample('SRS_A',[
      ('F-RESET','SW 오류 발생 시 MCU Reset을 통해 정상 상태로 복귀한다.'),
      ('F-WDT','Watchdog Timer는 가장 낮은 Task 이후 작동하며 인터럽트 서비스 루틴 내에 존재하지 않는다.')])
    cases,_,audit=build_basic_functional_cases({'requirements':[req]},[base])
    monkeypatch.setattr(exporter,'finalize_verification_single_truth',lambda *args,**kwargs:{
      'e2e_basic_functional_cases':cases, 'e2e_evaluation_cases':cases,
      'integrated_test_objects':cases,'basic_functional_design_audit':audit,
      'single_truth_audit':{},'semantic_verification_quality_audit':{},
    })
    excel=exporter.E2EExporter(tmp_path).export_evaluation_excel(Path('fully_fictional_input.docx'),{'requirements':[req]})
    assert excel.exists()
    logs=list(tmp_path.glob('00_E2E_판단근거_요약_*.txt'))
    assert len(logs)==1
    assert not list(tmp_path.glob('*Decision*Log*'))
    log=logs[0].read_text(encoding='utf-8-sig')
    assert 'F-RESET' in log and 'F-WDT' in log
    assert '정적 분석' in log and 'SRS_TC_001' in log and 'SRS_TC_002' in log
    assert 'SPLIT' in log
