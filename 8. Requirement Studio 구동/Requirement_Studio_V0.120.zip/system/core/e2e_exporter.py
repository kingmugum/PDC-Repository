from __future__ import annotations

import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from core.output_naming import output_filename
from core.e2e_decision_log import write_e2e_decision_summary
from core.semantic_split_diagnostic import write_semantic_split_diagnostic
from core.swe1_exporter import build_engineering_records
from core.verification_single_truth import finalize_verification_single_truth

NOT_CONFIRMED = "입력문서에서 확인되지 않음"


def _list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, dict):
        return "\n".join(f"{k}: {_text(v)}" for k, v in value.items() if v not in (None, "", [], {}))
    if isinstance(value, (list, tuple, set)):
        return "\n".join(x for x in (_text(v).strip() for v in value) if x)
    return str(value).strip()


def _safe_stem(name: str) -> str:
    stem = Path(name).stem or "document"
    stem = re.sub(r'[<>:"/\\|?*]+', "_", stem)
    stem = re.sub(r"\s+", "_", stem).strip("._ ")
    return stem[:80] or "document"


def _source_trace(req: dict[str, Any]) -> tuple[str, str, str]:
    sems = [str(x) for x in _list(req.get("source_semantic_unit_ids")) if str(x)]
    fids: list[str] = []
    locs: list[str] = []
    for key in ("source_backed_atomic_behaviors", "fact_level_allocations", "source_fact_fragments"):
        for item in _list(req.get(key)):
            if not isinstance(item, dict):
                continue
            fid = str(item.get("source_fact_fragment_id") or "")
            if fid and fid not in fids:
                fids.append(fid)
            sem = str(item.get("source_semantic_unit_id") or item.get("parent_source_semantic_unit_id") or "")
            if sem and sem not in sems:
                sems.append(sem)
            loc = _text(item.get("source_location"))
            if loc and loc not in locs:
                locs.append(loc)
    for ev in _list(req.get("source_evidence")):
        if isinstance(ev, dict):
            loc = _text(ev.get("location"))
            if loc and loc not in locs:
                locs.append(loc)
    return ", ".join(sems), ", ".join(fids), " | ".join(locs)


def _source_evidence(req: dict[str, Any]) -> str:
    lines=[]
    for ev in _list(req.get("source_evidence")):
        if isinstance(ev, dict):
            loc=_text(ev.get("location")); txt=_text(ev.get("text")); doc=_text(ev.get("document"))
            prefix=" / ".join(x for x in (doc,loc) if x)
            val=f"{prefix}: {txt}" if prefix and txt else (prefix or txt)
        else:
            val=_text(ev)
        if val and val not in lines:
            lines.append(val)
    return "\n".join(lines) or NOT_CONFIRMED


def _scope_label(req: dict[str, Any]) -> str:
    sys1=str(req.get("sys1_eligibility") or "")
    swe1=str(req.get("swe1_eligibility") or "")
    if sys1 in {"Eligible","Review Needed"} and swe1 in {"Eligible","Review Needed"}:
        return "SYS.1 + SWE.1"
    if swe1 in {"Eligible","Review Needed"}:
        return "SWE.1"
    if sys1 in {"Eligible","Review Needed"}:
        return "SYS.1"
    return "Engineering Native / Review"


OBJECT_TYPE_KO = {
    "SYS5_CANDIDATE": "SYS.5 평가 후보",
    "SYS5_PARENT_SCOPE_REVIEW": "SYS.5 상위 범위 검토",
    "SWE6_TC": "SWE.6 테스트 케이스",
    "DEFERRED_INTENT": "보류 검증 의도",
    "ALLOCATION_PENDING_INTENT": "할당 검토 대기",
    "EXTERNAL_DEPENDENCY_INTENT": "외부 의존 검토",
    "ELECTRICAL_VERIFICATION_INTENT": "전기 검증",
    "ENVIRONMENTAL_VERIFICATION_INTENT": "환경 검증",
    "MECHANICAL_VERIFICATION_INTENT": "기구/HW 검증",
    "MANUFACTURING_VERIFICATION_INTENT": "제조 검증",
    "REVIEW_REQUIRED": "사람 검토 필요",
}

LOGIC_KO = {
    "ALL_OF": "모두 만족(AND)",
    "ANY_OF": "하나 이상 만족(OR)",
    "SEQUENCE": "순차 조건",
}

TRANSITION_KO = {
    "power_mode_transition": "전원 모드 전이",
    "capture_mode_transition": "캡처 모드 전이",
    "mirror_fold_transition": "미러 폴딩 전이",
    "ignition_transition": "시동/점화 전이",
    "sleep_wake_transition": "슬립/웨이크 전이",
    "wake_init_transition": "웨이크 초기화 전이",
    "communication_recovery": "통신 복구",
    "environmental_qualification": "환경 적격성",
}

ALLOCATION_KO = {
    "SW_BEHAVIOR_INFERRED_REVIEW_REQUIRED": "SW 동작 추론 - 사람 검토 필요",
    "SYSTEM_REQUIREMENT_PENDING_SW_ALLOCATION": "시스템 요구사항 - SW 할당 검토 대기",
    "SW_IMPLEMENTATION_REQUIREMENT": "SW 구현 요구사항",
    "ELECTRICAL_REQUIREMENT": "전기 요구사항",
    "ENVIRONMENTAL_QUALIFICATION_REQUIREMENT": "환경 적격성 요구사항",
    "MECHANICAL_CONNECTOR_REQUIREMENT": "기구/커넥터 요구사항",
    "MANUFACTURING_PROCESS_REQUIREMENT": "제조 공정 요구사항",
    "EXTERNAL_STANDARD_REFERENCE": "외부 표준 참조",
}

def _display_enum(value: Any, mapping: dict[str, str]) -> str:
    raw = str(value or "")
    return mapping.get(raw, raw)

def _display_eligibility(value: Any) -> str:
    raw = str(value or "")
    return {
        "Eligible": "대상",
        "Review Needed": "검토 필요",
        "Not Applicable": "비대상",
        "Deferred pending SW allocation": "SW 할당 검토 대기",
    }.get(raw, raw)

def _display_readiness(value: Any) -> str:
    raw = str(value or "")
    return {
        "REVIEW_REQUIRED": "검토 필요",
        "PARTIALLY_TESTABLE": "부분 평가 가능",
        "INTENT_DRAFT": "평가 의도 초안",
        "READY": "실행 가능",
    }.get(raw, raw)


REVIEW_STATUS_KO = {
    "HUMAN_DECISION_REQUIRED": "사람의 리뷰 필요",
    "REVIEW_REQUIRED": "사람의 리뷰 필요",
    "HOLD": "사람의 리뷰 필요",
    "SOURCE_BACKED": "리뷰 불필요",
    "APPROVED": "리뷰 완료",
}

REASON_KO = {
    "ALLOCATION_PENDING": "SW 할당 검토 대기",
    "SOURCE_INSUFFICIENT": "입력 문서 정보 부족",
    "EXPORTER_CAPABILITY_PENDING": "자동 구조화 검토 필요",
    "HUMAN_REVIEW_REQUIRED": "사람의 리뷰 필요",
    "STATE_TRANSITION_LOGIC_REVIEW_REQUIRED": "상태 전이 조건 논리 검토 필요",
    "STATE_TRANSITION_TARGET_REVIEW_REQUIRED": "상태 전이 목표 상태 검토 필요",
    "SW_BEHAVIOR_INFERRED_REVIEW_REQUIRED": "SW 동작 추론 결과에 대한 사람 검토 필요",
    "SYSTEM_REQUIREMENT_PENDING_SW_ALLOCATION": "시스템 요구사항의 SW 할당 검토 필요",
    "INFERRED_NEGATIVE_EXPECTATION": "원본 미정의 음성 결과 — 시험 설계 가설",
}

# V0.94 human-facing translation only. Raw English remains authoritative in Trace/JSON.
REVIEW_TEXT_KO = {
    "Approve System qualification scope, controllable conditions, observations, and acceptance criteria before execution.":
        "실행 전 시스템 적격성 평가 범위, 제어 가능한 조건, 관찰 항목 및 판정 기준을 승인해야 합니다.",
    "Confirm fact-level System/SW responsibility for both transitions and approve whether the allocation difference is intentional.":
        "두 상태 전이에 대한 Fact 단위 System/SW 책임을 확인하고 Allocation 차이가 의도된 것인지 승인해야 합니다.",
    "Approve the responsible verification owner/domain and author execution criteria only from approved Source/evidence.":
        "검증 책임자/도메인을 승인하고, 승인된 Source/Evidence만 사용하여 실행 기준을 작성해야 합니다.",
    "Generate a Source-backed SWE.6 candidate TC or record an explicit deferred/review disposition.":
        "Source 기반 SWE.6 후보 TC를 생성하거나 명시적인 Deferred/Review 처리를 기록해야 합니다.",
    "Create an auditable deferred/allocation-pending intent with reason and Source trace.":
        "사유와 Source Trace를 포함한 감사 가능한 Deferred/Allocation Pending Intent를 생성해야 합니다.",
    "Review the cited visual asset with approved Vision/human evidence or document why the visual contains no additional requirement semantics.":
        "승인된 Vision/사람 검토 근거로 해당 시각 자료를 확인하거나, 추가 요구사항 의미가 없다는 근거를 기록해야 합니다.",
    "Correct the deterministic cross-output inconsistency.":
        "결정론적으로 재현되는 산출물 간 불일치를 수정해야 합니다.",
    "Authoritative Source decision을 연결한 뒤 재생성합니다.":
        "권한 있는 Source 결정 근거를 연결한 뒤 다시 생성합니다.",
    "Open Conflict/Gap의 authoritative decision을 연결한 뒤 affected TC를 재생성합니다.":
        "Open Conflict/Gap에 대한 권한 있는 결정 근거를 연결한 뒤 영향받는 TC를 다시 생성합니다.",
}

def _humanize_review_text(value: Any) -> str:
    text=str(value or "").strip()
    if not text:
        return ""
    text=REASON_KO.get(text,text)
    text=REVIEW_TEXT_KO.get(text,text)
    for k,v in REASON_KO.items():
        text=text.replace(k,v)
    for k,v in REVIEW_TEXT_KO.items():
        text=text.replace(k,v)
    # Conservative phrase-level localization for mixed Korean/English review text.
    replacements=(
        ("Source Fact Fragment", "Source Fact Fragment"),
        ("Review status", "검토 상태"),
        ("Review Required", "검토 필요"),
        ("authoritative decision", "권한 있는 결정"),
        ("affected TC", "영향받는 TC"),
        ("System qualification", "시스템 적격성 평가"),
        ("controllable conditions", "제어 가능한 조건"),
        ("observations", "관찰 항목"),
        ("acceptance criteria", "판정 기준"),
    )
    for a,b in replacements:
        text=text.replace(a,b)
    return text


def _display_review_status(req: dict[str, Any], raw: Any = "") -> str:
    if req.get("human_decision_required"):
        return "사람의 리뷰 필요"
    value = str(raw or req.get("review_status") or "").strip()
    if value in REVIEW_STATUS_KO:
        return REVIEW_STATUS_KO[value]
    upper = value.upper()
    if any(token in upper for token in ("REVIEW", "HOLD", "PENDING", "REQUIRED")):
        return "사람의 리뷰 필요"
    return "리뷰 불필요"


def _format_human_multiline(value: Any) -> str:
    """Presentation-only line breaking. Never changes the Source facts stored in JSON/audit."""
    text = _text(value).replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        return ""
    # Display-only Korean wording; raw Source/JSON values are untouched.
    text = text.replace("Source-defined", "사양에 정의된").replace("Source-backed Atomic Behavior", "출처 기반 세부 동작")
    # Preserve existing lines while breaking common source-table/numbered patterns.
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s*•\s*", "\n- ", text)
    text = re.sub(r"(?<!\n)\s+(?=(?:\d+(?:\.\d+)*[\)\.]\s+))", "\n", text)
    text = re.sub(r"(?<!\n)\s+(?=0x[0-9A-Fa-f]+\s*[:·-])", "\n", text)
    text = re.sub(r"(?<!\n)\s+(?=[A-Za-z][A-Za-z0-9_]*\s*값\s*송신\s*조건)", "\n", text)
    text = re.sub(r"(?<=다\.)\s+(?=[가-힣A-Za-z0-9])", "\n", text)
    lines=[]
    for line in text.splitlines():
        line=re.sub(r"\s+", " ", line).strip()
        if not line:
            continue
        if line.startswith("•"):
            line="- "+line[1:].strip()
        lines.append(line)
    # Avoid orphan numbering lines such as `3)` followed by the actual item on the next line.
    merged=[]; i=0
    while i < len(lines):
        if re.fullmatch(r"\d+(?:\.\d+)*[\)\.]", lines[i]) and i+1 < len(lines):
            merged.append(lines[i]+" "+lines[i+1]); i += 2
        else:
            merged.append(lines[i]); i += 1
    return "\n".join(merged)



def _format_tc_semicolon_lines(value: Any) -> str:
    """Presentation-only semantic line breaks, keeping technical source/audit unchanged."""
    text=_format_human_multiline(value)
    if not text or not re.search(r"[;；]", text):
        return text
    chunks=[]
    for line in text.splitlines():
        chunks.extend(part.strip() for part in re.split(r"\s*[;；]\s*",line) if part.strip())
    return "\n".join(chunks)


def _format_boolean_pass_for_humans(case: dict[str, Any], fallback: str) -> str:
    """Put one independently understandable judgment on each numbered line."""
    if str(case.get("basic_case_kind") or "")!="BOOLEAN_CONDITION_COVERAGE":
        return _format_tc_semicolon_lines(fallback)
    states=[x for x in _list(case.get("boolean_condition_states")) if isinstance(x,dict)]
    logic=str(case.get("condition_logic") or "")
    target=_text(case.get("expected_target_state") or case.get("expected_state"))
    target=re.sub(r"\s*\(시험 설계 가설\)","",target).strip()
    if not states or not target: return _format_tc_semicolon_lines(fallback)
    met=[_text(x.get("name")) for x in states if x.get("expected") is True]
    missed=[_text(x.get("name")) for x in states if x.get("expected") is False]
    if logic=="ALL_OF" and len(missed)==1:
        lines=[f"1) {missed[0]} 조건 미충족", "2) 나머지 진입 조건 충족", f"3) {target}로 전환되지 않으면 PASS"]
    elif logic=="ALL_OF" and not missed:
        lines=[f"{i}) {name} 조건 충족" for i,name in enumerate(met,1)]
        lines.append(f"{len(lines)+1}) {target}로 전환되면 PASS")
    elif logic=="ANY_OF" and len(met)==1:
        lines=[f"1) {met[0]} 조건 충족", "2) 나머지 진입 조건 미충족",f"3) {target}로 전환되면 PASS"]
    elif logic=="ANY_OF" and not met:
        lines=["1) 모든 진입 조건 미충족", f"2) {target}로 전환되지 않으면 PASS"]
    else:
        return _format_tc_semicolon_lines(fallback)
    return "\n".join(lines)


def _merge_expected_value_and_state(output_value: Any, expected_state: Any) -> str:
    """On removing the redundant column, retain an independent numeric/enum output."""
    state=_format_tc_semicolon_lines(expected_state)
    val=_format_tc_semicolon_lines(output_value)
    if not val or val.upper()=='N/A':
        return state
    if not state:
        return val
    # Don't duplicate the same criterion, and preserve numeric/enum actual values.
    if val in state or re.sub(r"\s+","",val) in re.sub(r"\s+","",state):
        return state
    if re.search(r"(?:0x[0-9A-Fa-f]+|[-+]?\d+(?:\.\d+)?\s*(?:mA|A|ms|s|V|°C|℃|%))", val):
        return f"기대 신호값: {val}\n{state}"
    # Distinct natural-language output and overall state belong to separate
    # layers of the same human-readable cell, not separately repeated columns.
    if len(val)>160 or len(state)>500:
        return state
    return f"출력 관찰: {val}\n{state}"

_CIRCLED_NUMBERS = ["①","②","③","④","⑤","⑥","⑦","⑧","⑨","⑩","⑪","⑫","⑬","⑭","⑮","⑯","⑰","⑱","⑲","⑳"]


def _format_tc_preconditions(value: Any) -> str:
    """Number meaningful precondition clauses for *display only*.

    Preserve original source text in canonical data. Avoid splitting technical lists
    such as enum literals, comma-separated values, or numeric descriptions without
    recognizable state/condition boundaries.
    """
    text = _format_human_multiline(value)
    if not text:
        return ""
    if re.match(r"^(?:[①-⑳]|\d+[.)])", text):
        return text
    units = [x.strip() for x in text.splitlines() if x.strip()]
    if len(units) == 1 and ("," in text or ";" in text):
        pieces = [p.strip() for p in re.split(r"\s*[,;；]\s*", text) if p.strip()]
        condition_words = ("상태", "수신", "인가", "진입", "완료", "설정", "동작", "충족", "발생", "조건", "모드", "MODE", "OFF", "ON")
        if 2 <= len(pieces) <= 12 and all(any(k in p for k in condition_words) for p in pieces):
            units = pieces
    if len(units) < 2:
        return text
    output = []
    for index, unit in enumerate(units, 1):
        unit = re.sub(r"^(?:[①-⑳]|\d+[.)])\s*", "", unit)
        prefix = _CIRCLED_NUMBERS[index-1] if index <= len(_CIRCLED_NUMBERS) else f"{index})"
        output.append(f"{prefix} {unit}")
    return "\n".join(output)


def _format_tc_execution(value: Any) -> str:
    """Remove engine-only English prefixes from human TC procedures, without inventing actions."""
    text = _format_human_multiline(value)
    text = re.sub(r"^Source-backed SWE\.6 검증 intent:\s*", "", text, flags=re.I)
    # The original truncated phrase '전달 받아' is grammatically unfinished.
    # Only complete that exact trailing form (don't infer any ensuing action).
    text = re.sub(r"전달\s*받아\s*$", "전달받는다.", text)
    return text


def _number_requirement_meaning_units(value: Any) -> str:
    """V0.94 presentation-only semantic unit numbering inside the same cell.

    This never creates a new Requirement row/column and never mutates Source/JSON truth.
    """
    text=_format_human_multiline(value)
    if not text:
        return ""
    units=[]
    for line in text.splitlines():
        line=line.strip()
        if not line:
            continue
        # Preserve explicit user/source numbering rather than double-numbering it.
        if re.match(r"^(?:[①-⑳]|\d+[\)\.])\s*",line):
            units.append(line)
            continue
        # _format_human_multiline already splits common Korean sentence endings; this is a
        # conservative fallback for two normative clauses still sharing one line.
        parts=re.split(r"(?<=[.!?])\s+(?=(?:HU|ECU|시스템|System|[가-힣A-Za-z]))",line)
        units.extend(p.strip() for p in parts if p.strip())
    if len(units)<=1:
        return text
    out=[]
    for i,u in enumerate(units,1):
        prefix=_CIRCLED_NUMBERS[i-1] if i<=len(_CIRCLED_NUMBERS) else f"{i})"
        # Normalize any pre-existing numeric prefix only when the whole field is being numbered.
        u=re.sub(r"^(?:[①-⑳]|\d+[\)\.])\s*","",u).strip()
        out.append(f"{prefix} {u}")
    return "\n".join(out)



def _format_behavior_definition(value: Any) -> str:
    """V0.94 human presentation: keep behavior only, remove internal step/action syntax and source dumps."""
    text=_format_human_multiline(value)
    if not text:
        return ""
    text=re.split(r"\n\s*\[(?:출처 기반 세부 동작|Source-backed Atomic Behavior)\]\s*\n?",text,maxsplit=1,flags=re.I)[0].strip()
    lines=[]
    for raw in text.splitlines():
        line=_text(raw).strip()
        if not line:
            continue
        line=re.sub(r"^(?:\d+[\.)]\s*)?step\s*=\s*\d+\s*;?\s*action\s*=\s*", "", line, flags=re.I)
        line=re.sub(r"^(?:\d+[\.)]\s*)?action\s*=\s*", "", line, flags=re.I)
        line=re.sub(r"^(?:\d+[\.)]\s*)?step\s*\d+\s*[:;\-]\s*", "", line, flags=re.I)
        line=re.sub(r"^\d+[\.)]\s*", "", line).strip()
        # Human-facing E2E requirements should not expose machine trace keys.
        line=re.sub(r"^(?:flow_id\s*=\s*[^;\s]+\s*;?\s*)?(?:description\s*=\s*)", "", line, flags=re.I).strip()
        line=re.sub(r"^flow_id\s*=\s*[^;]+;?\s*", "", line, flags=re.I).strip()
        if line and line not in lines:
            lines.append(line)
    if not lines:
        return ""
    if len(lines)==1:
        return lines[0]
    return "\n".join(f"{i}. {line}" for i,line in enumerate(lines,1))


def _human_reference_note(value: Any) -> str:
    """Only humanize visible '기타'; raw artifact metadata remains in JSON/Trace."""
    raw=_format_human_multiline(value)
    if not raw:
        return ""
    if not re.search(r"artifact_type\s*=",raw,re.I):
        return raw
    kind_match=re.search(r"artifact_type\s*=\s*([^;\n]+)",raw,re.I)
    ref_match=re.search(r"reference\s*=\s*(.*?)(?=;\s*source_location\s*=|$)",raw,re.I|re.S)
    typ=(kind_match.group(1).strip().lower() if kind_match else "")
    ref=re.sub(r"\s+", " ", ref_match.group(1)).strip() if ref_match else ""
    if typ=="table":
        m=re.search(r"(?:Table|표)\s*(\d+)",ref,re.I)
        return f"표 {m.group(1)}" if m else (f"참조 표: {ref}" if ref else "표 참조")
    if typ in {"figure","diagram","image","visual"}:
        m=re.search(r"(?:Figure|Fig\.?|그림)\s*(\d+)",ref,re.I)
        return f"그림 {m.group(1)}" if m else (f"참조 그림: {ref}" if ref else "그림 참조")
    if typ=="external_specification":
        return f"참조 규격: {ref}" if ref else "외부 규격 참조"
    return f"참고 자료: {ref}" if ref else "관련 근거 참조"


def _evidence_kind(item: dict[str, Any]) -> str:
    tokens=" ".join(str(item.get(k) or "") for k in ("evidence_type","source_type","modality","kind","location","document")).lower()
    if any(x in tokens for x in ("figure","diagram","image","visual","그림","도식","도면")) or item.get("visual_asset_id"):
        return "그림"
    return "문서"


def _compact_requirement_trace(req: dict[str, Any], fallback: Any = "") -> str:
    """V0.94 human Traceability: show where the evidence is, not duplicate the requirement prose."""
    lines=[]
    for idx,item in enumerate(_list(req.get("source_evidence")),1):
        if not isinstance(item,dict):
            txt=_text(item)
            if txt:
                lines.append(f"[{idx}] [문서] {txt}")
            continue
        document=_text(item.get("document"))
        location=_text(item.get("location"))
        kind=_evidence_kind(item)
        where=" / ".join(x for x in (document,location) if x)
        if where:
            lines.append(f"[{idx}] [{kind}] {where}")
        elif _text(item.get("text")):
            lines.append(f"[{idx}] [{kind}] {_compact_meaning(item.get('text'))}")
    seen_refs=set()
    for key in ("source_backed_atomic_behaviors","fact_level_allocations","source_fact_fragments"):
        for item in _list(req.get(key)):
            if not isinstance(item,dict):
                continue
            sem=_text(item.get("source_semantic_unit_id") or item.get("parent_source_semantic_unit_id"))
            fid=_text(item.get("source_fact_fragment_id"))
            loc=_text(item.get("source_location"))
            tokens=" ".join(str(item.get(k) or "") for k in ("evidence_type","source_type","modality","kind","source_location")).lower()
            kind="그림" if any(x in tokens for x in ("figure","diagram","image","visual","그림","도식","도면")) else "문서"
            ref=sem or fid
            keyv=(kind,ref,loc)
            if ref and keyv not in seen_refs:
                seen_refs.add(keyv)
                suffix=f" / {loc}" if loc else ""
                lines.append(f"[근거] [{kind}] {ref}{suffix}")
    for key in ("diagram_refs","figure_refs","visual_evidence_refs"):
        for ref in _list(req.get(key)):
            txt=_text(ref)
            if txt:
                line=f"[근거] [그림] {txt}"
                if line not in lines:
                    lines.append(line)
    unique=[]
    for line in lines:
        if line not in unique:
            unique.append(line)
    if unique:
        return "\n".join(unique)
    return _format_human_multiline(fallback)


def _split_condition_list(value: str) -> list[str]:
    return [x.strip() for x in re.split(r"\s*,\s*", value or "") if x.strip()]


def _format_verification_criteria(value: Any) -> str:
    """V0.94 presentation-only acceptance-criteria structuring."""
    text=_format_human_multiline(value)
    if not text:
        return ""
    flat=" ".join(x.strip() for x in text.splitlines() if x.strip())
    m=re.match(
        r"^(?P<ok>.+?)\s*조건은\s*동작\s*여부\s*O(?:이며|이고)?\s*[,;]?\s*(?P<ng>.+?)\s*조건은\s*X(?:로\s*정의된다|이다|임)?\.?$",
        flat, flags=re.I,
    )
    if m:
        ok=_split_condition_list(m.group("ok")); ng=_split_condition_list(m.group("ng"))
        return "\n".join(["① 동작 가능 (O)"] + [f"- {x}" for x in ok] + ["② 동작 불가 (X)"] + [f"- {x}" for x in ng])
    numbered=_number_requirement_meaning_units(text)
    if "\n" in numbered:
        return numbered
    parts=[p.strip() for p in re.split(r"\s*;\s*",flat) if p.strip()]
    if len(parts)>1:
        return "\n".join(f"{_CIRCLED_NUMBERS[i] if i < len(_CIRCLED_NUMBERS) else str(i+1)+')'} {p}" for i,p in enumerate(parts))
    return text


def _is_nonfunctional_e2e_case(case: dict[str, Any], req: dict[str, Any] | None = None) -> bool:
    """Display-only classification based on explicit measurable nonfunctional objectives.

    Keep original verification allocation, object type and source facts in Trace/Audit.
    Do not infer that any unrecognized HW or cross-domain item is nonfunctional.
    """
    req=req or {}
    if str(case.get('test_object_type') or '') in {'ELECTRICAL_VERIFICATION_INTENT','ENVIRONMENTAL_VERIFICATION_INTENT'}:
        return True
    category = str(req.get('category') or case.get('category') or '').strip()
    if category in {'비기능','Nonfunctional','Non-functional'}:
        return True
    text=' '.join(str(x or '') for x in (
        case.get('evaluation_name'),case.get('source_backed_behavior'),
        case.get('expected_state'),case.get('pass_criterion'),req.get('function_name'),
    ))
    return bool(re.search(
        r'(?:최대\s*소비\s*전류|소모\s*전류|암전류|동작\s*전압\s*범위|'
        r'사용\s*온도|보존\s*온도|허용\s*온도|정격\s*전압|'
        r'작동\s*온도|온도\s*범위|전력\s*소모|전원단\s*(?:인가\s*)?전압)',text,re.I))


def _display_domain_compact(case: dict[str, Any]) -> str:
    typ=str(case.get("test_object_type") or "")
    domain=_text(case.get("verification_domain")).upper()
    if set(case.get("merged_test_object_types") or []) == {"SYS5_CANDIDATE", "SWE6_TC"}:
        return "SYS.5/SWE.6"
    if "SWE6" in typ or "SWE.6" in domain:
        return "SWE.6"
    if "SYS5" in typ or "SYS.5" in domain:
        return "SYS.5"
    return "검토"


def _display_compare(value: Any) -> str:
    raw=str(value or "").strip()
    return {
        "Source-defined": "사양 정의값",
        "source-defined": "사양 정의값",
        "SOURCE_DEFINED": "사양 정의값",
        "transition_to": "상태 전이",
        "순차 입력": "순차",
        "ALL_OF": "모두 만족",
        "ANY_OF": "하나 이상 만족",
    }.get(raw, LOGIC_KO.get(raw, raw))


def _compact_meaning(value: Any) -> str:
    text=re.sub(r"\s+", " ", str(value or "")).strip()
    if not text:
        return ""
    # Remove appended long requirement prose from enum meanings; retain the concise semantic label.
    for sep in (" - ", " – ", " — "):
        if sep in text:
            left,right=text.split(sep,1)
            if len(right)>36 or "HU는" in right or "해야" in right:
                text=left.strip()
                break
    if len(text)>72:
        m=re.match(r"(.{1,72}?)(?:[.!?]|$)", text)
        text=(m.group(1) if m else text[:72]).strip()
    return text


def _compact_input_value(case: dict[str, Any]) -> str:
    vectors=[v for v in _list(case.get("test_vectors")) if isinstance(v,dict)]
    vals=[]
    for i,v in enumerate(vectors,1):
        raw_val=v.get("input_value")
        if isinstance(raw_val, (list,tuple)):
            val="\n".join(f"{j}) {str(x).strip()}" for j,x in enumerate(raw_val,1) if str(x).strip())
        else:
            val=str(raw_val or "").strip()
        if val:
            vals.append(f"{i}) {val}" if len(vectors)>1 else val)
    if vals:
        return "\n".join(vals)
    raw=_format_human_multiline(case.get("input_value") or case.get("value"))
    cleaned=[]
    for line in raw.splitlines():
        m=re.match(r"(\d+\))\s*([^·]+)", line)
        cleaned.append(f"{m.group(1)} {m.group(2).strip()}" if m else line)
    return "\n".join(cleaned)


def _compact_output_value(case: dict[str, Any]) -> str:
    vectors=[v for v in _list(case.get("test_vectors")) if isinstance(v,dict)]
    vals=[]
    for i,v in enumerate(vectors,1):
        val=str(v.get("expected_output") or "").strip()
        if not val:
            continue
        meaning=_compact_meaning(v.get("output_meaning"))
        item=f"{val} · {meaning}" if meaning else val
        vals.append(f"{i}) {item}" if len(vectors)>1 else item)
    if vals:
        return "\n".join(vals)
    raw=_format_human_multiline(case.get("output_value"))
    out=[]
    for line in raw.splitlines():
        line=re.sub(r"(·\s*[^-\n]{0,60})\s+-\s+HU는.*$", r"\1", line)
        out.append(line)
    return "\n".join(out)


def _display_review_reason(case: dict[str, Any]) -> str:
    parts=[]
    for value in (case.get("deferred_reason_code"), case.get("deferred_reason_detail"), case.get("required_resolution")):
        txt=str(value or "").strip()
        if not txt:
            continue
        txt=_humanize_review_text(txt)
        if txt not in parts:
            parts.append(txt)
    if not parts and _test_case_review_status(case)=="사람의 리뷰 필요":
        alloc=str(case.get("allocation_status") or "")
        parts.append(REASON_KO.get(alloc, "사람 검토가 필요한 평가 케이스입니다."))
    return _format_human_multiline("\n".join(parts))


def _test_case_review_status(case: dict[str, Any]) -> str:
    if case.get("expectation_basis") == "ENGINEERING_HYPOTHESIS":
        return "최종 검토 대상"
    if case.get("human_review_required"):
        return "사람의 리뷰 필요"
    readiness=str(case.get("execution_readiness") or "").upper()
    alloc=str(case.get("allocation_status") or "").upper()
    if any(x in readiness for x in ("REVIEW", "DRAFT", "PARTIAL", "HOLD")):
        return "사람의 리뷰 필요"
    if any(x in alloc for x in ("REVIEW", "PENDING", "HOLD")):
        return "사람의 리뷰 필요"
    return "실행 가능"


class E2EExporter:
    """V0.94 reviewer-facing E2E Requirements + user-guided structured Basic Functional Evaluation specifications.

    E2E Requirements is the Source-nearest engineering view (SYS.1 + SWE.1 + native/review
    preservation).  E2E Evaluation is the human-facing verification master (SYS.5 + SWE.6 +
    deferred/external/native) while raw objects remain available in the finalized bundle for audit.
    """

    DARK = "1F4E78"
    HEADER = "D9EAF7"
    SUB = "EAF2F8"
    REVIEW = "FFF2CC"
    FAIL = "F4CCCC"
    PASS = "D9EAD3"
    HYPOTHESIS = "FAF1E5"
    NONFUNCTIONAL = "F5F0FC"  # very pale lavender for nonfunctional requirements
    THIN = Side(style="thin", color="B7B7B7")

    def __init__(self, output_dir: Path):
        self.output_dir=Path(output_dir).resolve(); self.output_dir.mkdir(parents=True, exist_ok=True)
        self.last_decision_log_path: Path | None = None
        self.last_decision_log_error: str = ""
        self.last_semantic_diagnostic_path: Path | None = None
        self.last_semantic_diagnostic_error: str = ""

    def _filename(self, prefix: str, source: Path, ext: str) -> Path:
        return self.output_dir / output_filename(prefix, _safe_stem(source.name), ext)

    def _style_header(self, cell, fill: str | None = None):
        cell.fill=PatternFill("solid", fgColor=fill or self.DARK)
        cell.font=Font(name="Malgun Gothic", size=9, bold=True, color="FFFFFF" if (fill or self.DARK)==self.DARK else "000000")
        cell.alignment=Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border=Border(left=self.THIN,right=self.THIN,top=self.THIN,bottom=self.THIN)

    def _style_cell(self, cell, *, center=False, fill=None):
        cell.font=Font(name="Malgun Gothic", size=9)
        cell.alignment=Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border=Border(left=self.THIN,right=self.THIN,top=self.THIN,bottom=self.THIN)
        if fill: cell.fill=PatternFill("solid", fgColor=fill)

    @staticmethod
    def _human_e2e_text(value: object) -> str:
        """Remove internal audit/review boilerplate from *display-only* TC text.

        Internal cases, Source facts, event logs and provenance are unchanged.
        The A1 beige/purple legend communicates the review status instead.
        """
        if not isinstance(value, str):
            return value
        text=value
        text=re.sub(r"\[(?:REQ|SYS|SWE)[A-Za-z0-9_.-]+\]\s*", "", text, flags=re.I)
        text=re.sub(r"\((?:시스템|SW|소프트웨어)\s*사양서\s*참조\)", "", text)
        text=re.sub(r"\s*(?:…|\.\.\.)\s*-?\s*결과 확인$", "", text)
        text=re.sub(r"\[시험 설계 가설\]\s*", "", text)
        text=re.sub(r"\((?:시험 설계 가설|원본 부정 동작 미명시|시험 신호[·/]판정 방법 확인 필요|조건별 조작 가능 여부 확인 필요|구간 경계점은 별도 검토)\)", "", text)
        text=re.sub(r"\b(?:Source-backed\s*기본 동작|Source-backed\s*검증\s*intent)\b", "기본 동작", text, flags=re.I)
        text=re.sub(r"\((?:사양|원본|시험|사람|담당자)[^()]{0,38}(?:검토 필요|확인 필요)\)", "", text)
        text=re.sub(r"(?m)^[ \t]*(?:확인 필요|검토 필요|사양 확인 필요)[ \t]*[:：][^\n]*\n?", "", text)
        text=re.sub(r"[ \t]{2,}", " ", text)
        # Display-only line structure: long I/O / bus / signal / meaning prefixes
        # should be scannable. Do not split fractions or numeric slashes.
        if re.match(r"^(?:Input|Output)\s*/\s*(?:CAN|LIN|Ethernet)\s*Communication\s*/",text,re.I):
            fields=re.split(r"\s+/\s+",text,maxsplit=3)
            if len(fields)>=3:
                text="\n".join(fields)
        return text.strip()

    def _write_table(self, ws, headers, rows, widths, start_row=3, na_for_blanks=False):
        for c,h in enumerate(headers,1): self._style_header(ws.cell(start_row,c,h), self.HEADER)
        for r,row in enumerate(rows or [["-"]+[""]*(len(headers)-1)], start_row+1):
            for c,val in enumerate(row,1):
                # Human-readable E2E specification: N/A for undefined design fields.
                # Never populate test execution result columns Q:T before a real run.
                if na_for_blanks and c <= 16 and (val is None or (isinstance(val,str) and not val.strip())):
                    val="N/A"
                self._style_cell(ws.cell(r,c,val), center=True)
        ws.freeze_panes=ws.cell(start_row+1,1)
        ws.auto_filter.ref=f"A{start_row}:{get_column_letter(len(headers))}{start_row+max(1,len(rows))}"
        for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w

    def _write_group_headers(self, ws):
        groups = [
            (1,6,"종류"),
            (7,8,"사전 준비"),
            (9,12,"입력 / 수행"),
            (13,15,"출력"),
            (16,16,"판단"),
            (17,20,"실행 결과"),
        ]
        for start_col, end_col, label in groups:
            ws.merge_cells(start_row=2,start_column=start_col,end_row=2,end_column=end_col)
            cell=ws.cell(2,start_col,label)
            self._style_header(cell, self.DARK)
            cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        ws.row_dimensions[2].height=23

    def _cover(self, ws, title: str, source: Path, subtitle: str, *, show_source_fidelity: bool = True):
        ws.sheet_view.showGridLines=False
        ws.merge_cells("B3:G4"); ws["B3"]=title
        ws["B3"].font=Font(name="Malgun Gothic", size=22, bold=True, color=self.DARK); ws["B3"].alignment=Alignment(horizontal="center",vertical="center")
        ws.merge_cells("B6:G6"); ws["B6"]=subtitle; ws["B6"].font=Font(name="Malgun Gothic", size=11, bold=True, color="595959"); ws["B6"].alignment=Alignment(horizontal="center")
        rows=[("원본 문서",source.name),("생성 일시",datetime.now().strftime("%Y-%m-%d %H:%M:%S")),("Requirement Studio","V0.112")]
        if show_source_fidelity:
            rows.append(("Source Fidelity","Source에 없는 값/신호/Timing/Threshold/Test Result를 생성하지 않음"))
        for r,(k,v) in enumerate(rows,9):
            ws.cell(r,2,k); ws.cell(r,3,v); self._style_cell(ws.cell(r,2),center=True,fill=self.SUB); self._style_cell(ws.cell(r,3))
        ws.column_dimensions["B"].width=24; ws.column_dimensions["C"].width=78

    # ------------------------------------------------------------------
    # E2E Requirements
    # ------------------------------------------------------------------
    def export_requirements_word(self, source_document: Path, data: dict[str, Any]) -> Path:
        records=build_engineering_records(data)
        if not records: raise ValueError("E2E 요구사항 명세서로 내보낼 Canonical Engineering Requirement가 없습니다.")
        req_lookup={str(r.get("srs_id") or ""):r for r in _list(data.get("requirements")) if isinstance(r,dict)}
        out=self._filename("E2E_요구사항 명세서", source_document, "docx")
        doc=Document(); doc.styles["Normal"].font.name="Malgun Gothic"; doc.styles["Normal"].font.size=Pt(9)
        p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; run=p.add_run("E2E Engineering Requirements Specification"); run.bold=True; run.font.size=Pt(18)
        meta=doc.add_table(rows=5,cols=2); meta.style="Table Grid"
        meta_rows=[("원본 문서",source_document.name),("생성 일시",datetime.now().strftime("%Y-%m-%d %H:%M:%S")),("Canonical Requirement",str(len(records))),("작성 기준","Requirement Studio V0.112 — Human-facing E2E Requirements"),("표시 원칙","사람이 읽는 본문은 핵심 요구사항만 표시하고 Allocation/Eligibility/Canonical/Fact 메타데이터는 Excel Review/Trace 및 JSON Audit에 보존")]
        for i,(k,v) in enumerate(meta_rows): meta.cell(i,0).text=k; meta.cell(i,1).text=v
        note=doc.add_paragraph(); rr=note.add_run("※ 본 문서는 사람용 E2E 요구사항 Master입니다. 내부 Engineering/Allocation/Eligibility 정보는 삭제하지 않고 Review/Trace/JSON Audit에 보존하되 본문에서는 중복·기술 메타데이터를 최소화합니다."); rr.font.size=Pt(8.5); rr.font.color.rgb=RGBColor(90,98,110)
        section=doc.sections[0]; usable=int(section.page_width-section.left_margin-section.right_margin); left=int(usable*0.24); right=usable-left
        fields=["SRS ID","상위 기능","리뷰 상태","요구사항 내역","동작 조건 / Trigger","작동 명세 정의","사전 조건","예상 결과","검증 기준","출처 / Traceability","기타"]
        multiline={"요구사항 내역","동작 조건 / Trigger","작동 명세 정의","사전 조건","예상 결과","검증 기준","출처 / Traceability","기타"}
        current=None
        for rec in records:
            if rec["상위 기능"]!=current: doc.add_heading(rec["상위 기능"],level=1); current=rec["상위 기능"]
            doc.add_heading(rec["SRS ID"],level=2)
            req=req_lookup.get(rec["SRS ID"],{})
            vals={**rec,"리뷰 상태":_display_review_status(req,rec.get("Review Status"))}
            table=doc.add_table(rows=len(fields),cols=2); table.style="Table Grid"; table.autofit=False; table.columns[0].width=left; table.columns[1].width=right
            for i,f in enumerate(fields):
                a,b=table.cell(i,0),table.cell(i,1); a.width=left; b.width=right; a.text=f
                val=vals.get(f,"")
                if f=="요구사항 내역":
                    b.text=_number_requirement_meaning_units(val)
                elif f=="작동 명세 정의":
                    b.text=_format_behavior_definition(val)
                elif f=="검증 기준":
                    b.text=_format_verification_criteria(val)
                elif f=="출처 / Traceability":
                    b.text=_compact_requirement_trace(req,val)
                elif f=="기타":
                    b.text=_human_reference_note(val)
                else:
                    b.text=_format_human_multiline(val) if f in multiline else _text(val)
                a.vertical_alignment=b.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for r in a.paragraphs[0].runs: r.bold=True; r.font.size=Pt(8.5)
                for pp in b.paragraphs:
                    for r in pp.runs: r.font.size=Pt(8.5)
            doc.add_paragraph()
        doc.save(out); return out

    def export_requirements_excel(self, source_document: Path, data: dict[str, Any]) -> Path:
        records=build_engineering_records(data); reqs=[x for x in _list(data.get("requirements")) if isinstance(x,dict)]
        if not records: raise ValueError("E2E 요구사항 명세서로 내보낼 Requirement가 없습니다.")
        req_lookup={str(r.get("srs_id") or ""):r for r in reqs}; out=self._filename("E2E_요구사항 명세서",source_document,"xlsx")
        wb=Workbook(); cover=wb.active; cover.title="표지"; hist=wb.create_sheet("0_변경이력"); summary=wb.create_sheet("1_요구사항요약"); main=wb.create_sheet("2_E2E_요구사항"); review=wb.create_sheet("3_검토필요"); trace=wb.create_sheet("4_Source_추적성")
        self._cover(cover,"E2E 요구사항 명세서",source_document,"Human-facing E2E Engineering Requirements")
        self._write_table(hist,["No","Version","Date","Change"],[
            [1,"V0.94","기존","E2E 기본 명세서 및 Source 추적·검토 체계"],
            [2,"V0.97","기존","조건·수행 절차 사람용 표현과 가이드 축적"],
            [3,"V0.98","기존","원본 Fact별 기대값 구분 및 셀 표시 개선"],
            [4,"V0.99","기존","AND/OR 대표 조합 시험 설계 및 판단 근거 로그"],
            [5,"V0.100","기존","조건명 표시 및 참·거짓 조합 출력 (이전 표시명 V1.00)"],
            [6,"V0.101","기존","부정 조건 시험 설계 가설과 최종 검토 (이전 표시명 V1.01)"],
            [7,"V0.102","기존","복합 원문 조건절 추적 분리, 사람용 메타 제거, 미분리 원인 로그 보강"],
            [8,"V0.103","기존","가설 TC 베이지 표시, 조건 자연어화, 교차 영역 중복 제한 병합, 검토 사유 열 통합"],
            [9,"V0.104","기존","전압 구간 경계값 후보, 비기능 구분·보라색 표시, TC 검토 상태 열 제거"],
            [10,"V0.105",datetime.now().strftime("%Y-%m-%d"),"20열 E2E 평가, 자연어 PASS 항목화, 독립 경로 TC, 필요할 때만 이름 번호 부여"],
            [11,"V0.106",datetime.now().strftime("%Y-%m-%d"),"독립 검증 목적 의미 분해 및 TC·Step·Vector 판단 이유 중심 로그"],
        ],[8,14,14,110])
        sum_rows=[["Canonical Requirement Count",len(records)],["사람의 리뷰 필요",sum(1 for r in reqs if _display_review_status(r)=="사람의 리뷰 필요")],["리뷰 불필요/완료",sum(1 for r in reqs if _display_review_status(r)!="사람의 리뷰 필요")],["내부 메타데이터 보존 위치","3_검토필요 / 4_Source_추적성 / Review Package JSON"]]
        self._write_table(summary,["항목","Count / Status"],sum_rows,[38,52])
        headers=["SRS ID","상위 기능","리뷰 상태","요구사항 내역","동작 조건 / Trigger","작동 명세 정의","사전 조건","예상 결과","검증 기준","출처 / Traceability","기타"]
        rows=[]; review_rows=[]; trace_rows=[]
        multiline_idx={4,5,6,7,8,9,10,11}
        for rec in records:
            req=req_lookup.get(rec["SRS ID"],{}); sem,fids,loc=_source_trace(req)
            vals=[rec["SRS ID"],rec["상위 기능"],_display_review_status(req,rec.get("Review Status")),rec["요구사항 내역"],rec["동작 조건 / Trigger"],rec["작동 명세 정의"],rec["사전 조건"],rec["예상 결과"],rec["검증 기준"],rec["출처 / Traceability"],rec["기타"]]
            display_vals=[]
            for i,v in enumerate(vals,1):
                if i==4:
                    display_vals.append(_number_requirement_meaning_units(v))
                elif i==6:
                    display_vals.append(_format_behavior_definition(v))
                elif i==9:
                    display_vals.append(_format_verification_criteria(v))
                elif i==10:
                    display_vals.append(_compact_requirement_trace(req,v))
                elif i==11:
                    display_vals.append(_human_reference_note(v))
                elif i in multiline_idx:
                    display_vals.append(_format_human_multiline(v))
                else:
                    display_vals.append(v)
            rows.append(display_vals)
            if _display_review_status(req,rec.get("Review Status"))=="사람의 리뷰 필요":
                review_rows.append([rec["SRS ID"],_display_review_status(req,rec.get("Review Status")),rec.get("Allocation Status",""),rec.get("SYS.1 Eligibility",""),rec.get("SWE.1 Eligibility",""),rec.get("Canonical State",""),rec.get("Hold Reason",""),_text(req.get("clarification_reference") or req.get("clarification_needed")),"PENDING",""])
            for atom in _list(req.get("source_backed_atomic_behaviors")):
                if isinstance(atom,dict):
                    trace_rows.append([rec["SRS ID"],atom.get("source_semantic_unit_id"),atom.get("source_fact_fragment_id"),atom.get("source_location"),_format_human_multiline(atom.get("behavior_text") or atom.get("source_fact")),rec.get("Engineering Domain",""),rec.get("Requirement Level",""),rec.get("Allocation Status",""),rec.get("SYS.1 Eligibility",""),rec.get("SWE.1 Eligibility",""),rec.get("Canonical State","")])
        self._write_table(main,headers,rows,[16,24,20,56,38,58,38,38,44,54,36])
        self._write_table(review,["SRS ID","리뷰 상태","Allocation Status","SYS.1 Eligibility","SWE.1 Eligibility","Canonical State","Hold Reason","Clarification / Required Resolution","Disposition","Rationale"],review_rows,[16,20,34,18,18,28,50,66,20,56])
        self._write_table(trace,["SRS ID","Semantic Unit ID","Fact Fragment ID","Source Location","Source-backed Fact / Behavior","Engineering Domain","Requirement Level","Allocation Status","SYS.1 Eligibility","SWE.1 Eligibility","Canonical State"],trace_rows,[16,28,30,26,72,30,24,34,18,18,28])
        wb.save(out); return out

    # ------------------------------------------------------------------
    # E2E Evaluation
    # ------------------------------------------------------------------
    def export_evaluation_excel(self, source_document: Path, data: dict[str, Any]) -> Path:
        bundle=finalize_verification_single_truth(data, force=True)
        objective_cases=[x for x in _list(bundle.get("e2e_evaluation_cases")) if isinstance(x,dict)]
        cases=[x for x in _list(bundle.get("e2e_basic_functional_cases")) if isinstance(x,dict)] or objective_cases
        basic_reviews=[x for x in _list(bundle.get("e2e_basic_functional_reviews")) if isinstance(x,dict)]
        basic_audit=bundle.get("basic_functional_design_audit") or {}
        objects=[x for x in _list(bundle.get("integrated_test_objects")) if isinstance(x,dict)]
        reqs={str(r.get("srs_id") or ""):r for r in _list(data.get("requirements")) if isinstance(r,dict)}
        if not cases: raise ValueError("E2E 평가 명세서로 내보낼 평가 Case가 없습니다.")
        out=self._filename("E2E_평가 명세서",source_document,"xlsx")
        self.last_decision_log_path = None
        self.last_decision_log_error = ""
        self.last_semantic_diagnostic_path = None
        self.last_semantic_diagnostic_error = ""
        wb=Workbook(); cover=wb.active; cover.title="표지"; hist=wb.create_sheet("0_변경이력"); summary=wb.create_sheet("1_평가요약"); main=wb.create_sheet("2_E2E_평가케이스"); trace=wb.create_sheet("3_요구사항-평가추적성")
        self._cover(cover,"E2E 평가 명세서",source_document,"E2E Test Case Master",show_source_fidelity=False)
        # Version is an INPUT DOCUMENT revision, not the Requirement Studio app release.
        # Fresh input exports always begin at V1.00; update-in-place is not implemented.
        self._write_table(hist,["No.","Version","Date","Change","작성자"],
            [[1,"V1.00",datetime.now().strftime("%Y-%m-%d"),"초안 작성",""]],
            [17,17,17,24,17])
        # Summary uses generated human TC rows and their distinct exported BF IDs.
        # Original parent SRS count is not substituted for BF requirement count.
        # Filled below after the human rows are assembled.

        main_headers=["Test Case ID","요구사항 ID","검증 영역","평가 방법 / 도출 방법","테스트 케이스 이름","테스트 목적","사전 조건","평가 환경 / 준비","입력 변수","비교","입력값","수행 절차","출력 변수 / 관찰 대상","비교","예상 결과","PASS 기준","실제 출력값","판정 (PASS/FAIL)","비고","결과 화면 캡처"]
        rows=[]; trace_rows=[]
        bf_count: dict[str,int]={}; name_count: dict[str,int]={}
        # Suffixes distinguish duplicate titles only; unique titles need no '_01'.
        from collections import Counter
        name_totals=Counter(str(c.get("evaluation_name") or reqs.get(str(c.get("parent_srs_id") or ""),{}).get("function_name") or c.get("test_intent") or c.get("verification_objective") or "기본 기능 확인").strip() for c in cases)
        human_ids=[]
        for global_idx,case in enumerate(cases,1):
            sid=str(case.get("parent_srs_id") or ""); req=reqs.get(sid,{})
            bf_count[sid]=bf_count.get(sid,0)+1
            bf_id=f"{sid}_BF_{bf_count[sid]:02d}" if sid else f"BF_{global_idx:02d}"
            tc_id=f"SRS_TC_{global_idx:03d}"
            human_ids.append(tc_id)
            base_name=str(case.get("evaluation_name") or req.get("function_name") or case.get("test_intent") or case.get("verification_objective") or "기본 기능 확인").strip()
            name_count[base_name]=name_count.get(base_name,0)+1
            tc_name=(f"{base_name}_{name_count[base_name]:02d}" if name_totals[base_name]>1 else base_name)
            method_label="기본 기능 검증" if str(case.get("test_design_mode") or "")!="BASIC_FUNCTIONAL_REVIEW" else "기능 검증"
            objective=_format_human_multiline(case.get("test_objective") or case.get("verification_objective") or case.get("evaluation_name") or req.get("function_name"))
            precondition=_format_tc_preconditions(case.get("precondition") or case.get("test_preparation") or req.get("preconditions") or req.get("activation_trigger"))
            environment=_format_human_multiline(case.get("test_environment"))
            evar=str(case.get("input_variable") or case.get("variable") or "")
            ecomp=_display_compare(case.get("input_compare") or case.get("compare"))
            input_value=_compact_input_value(case)
            exe=_format_tc_execution(case.get("test_execution") or req.get("processing_action"))
            # General execution-readiness cautions are covered by program/manual
            # policy, not repeated in every human-facing procedure cell.
            exe=re.sub(r"\s*\(조건별 조작 가능 여부 확인 필요\)", "", exe)
            ovar=str(case.get("output_variable") or "")
            ocomp=_display_compare(case.get("output_compare"))
            output_value=_compact_output_value(case)
            # A missing negative-path requirement is not evidence of the parent's positive PASS.
            # Never fill a review-only Boolean candidate with the parent's success criterion.
            if str(case.get("expectation_basis") or "")=="ENGINEERING_HYPOTHESIS":
                # Render the proposed, clearly labeled hypothesis (not the parent's
                # positive Source criterion) so that the reviewer can accept/change it.
                expected_state=_format_tc_semicolon_lines(case.get("expected_state"))
                pass_criterion=_format_human_multiline(case.get("pass_criterion"))
            elif str(case.get("split_decision") or "")=="REVIEW_BOOLEAN_NEGATIVE_EXPECTATION":
                expected_state=""
                pass_criterion=""  # legacy saved cases still fail closed
            else:
                expected_state=_format_tc_semicolon_lines(case.get("expected_state") or case.get("expected_result") or req.get("output"))
                pass_criterion=_format_human_multiline(case.get("pass_criterion") or req.get("acceptance_criteria"))
            pass_criterion=_format_boolean_pass_for_humans(case,pass_criterion)
            # Review reminders belong in the user manual/program policy, not
            # repeatedly within every human-facing TC. Raw audit is untouched.
            pass_criterion=re.sub(r"\s*\(시험 신호[·/]판정 방법 확인 필요\)", "", pass_criterion)

            if case.get("expectation_basis")=="ENGINEERING_HYPOTHESIS":
                # Labels remain in audit; reviewer sees the beige legend instead.
                output_value=re.sub(r"\s*\(시험 설계 가설\)", "", output_value)
                expected_state=re.sub(r"\s*\(시험 설계 가설\)", "", expected_state)
                pass_criterion=re.sub(r"^\[시험 설계 가설\]\s*", "", pass_criterion)
                pass_criterion=re.sub(r"\s*\(원본 부정 동작 미명시\)", "", pass_criterion)
            expected_state=_merge_expected_value_and_state(output_value, expected_state)
            show_nonfunctional=_is_nonfunctional_e2e_case(case,req)
            display_domain="비기능" if show_nonfunctional else _display_domain_compact(case)
            human_fields=[tc_name,objective,precondition,environment,evar,ecomp,input_value,exe,ovar,ocomp,expected_state,pass_criterion]
            human_fields=[self._human_e2e_text(v) for v in human_fields]
            rows.append([tc_id,bf_id,display_domain,method_label,*human_fields,"","", "", ""])

            typ=str(case.get("test_object_type") or "")
            raw_ids=list(dict.fromkeys([str(case.get("test_object_id") or "")]+[str(x) for x in _list(case.get("merged_source_object_ids")) if str(x)]+[str(x) for x in _list(case.get("related_test_object_ids")) if str(x)]))
            sem=", ".join(str(x) for x in _list(case.get("source_semantic_unit_ids")) if str(x))
            fids=", ".join(str(x) for x in _list(case.get("source_fact_fragment_ids")) if str(x))
            loc=" | ".join(str(x) for x in _list(case.get("source_locations")) if str(x))
            field_trace=case.get("field_fact_trace") if isinstance(case.get("field_fact_trace"),dict) else {}
            field_trace_text=" | ".join(f"{k}={','.join(str(x) for x in _list(v) if str(x))}" for k,v in field_trace.items() if _list(v))
            # Human-facing trace is intentionally compact. All 12 omitted detail
            # fields remain in the original case/finalized bundle and decision log.
            trace_rows.append([tc_id,bf_id,sid,display_domain,method_label,
                               case.get("evaluation_objective_id") or "",
                               ", ".join(x for x in raw_ids if x),typ])

        nonfunctional_count=sum(1 for row in rows if row[2]=="비기능")
        self._write_table(summary,["평가 항목","건수"],[
            ["전체 TC",len(rows)],
            ["기능 TC",len(rows)-nonfunctional_count],
            ["비기능 TC",nonfunctional_count],
            ["입력 요구사항 (고유 BF ID)",len({row[1] for row in rows if row[1]})],
        ],[42,24])
        widths=[15,20,13,15,35,40,34,30,22,10,18,42,24,10,37,44,18,14,28,20]
        self._write_table(main,main_headers,rows,widths,na_for_blanks=True)
        # V0.105: Textual TC design fields E:P are left-aligned, vertically centered.
        # ID/domain/review/status and test-result columns stay centered. Header stays centered.
        for row_cells in main.iter_rows(min_row=4, max_row=main.max_row, min_col=5, max_col=16):
            for cell in row_cells:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        self._write_group_headers(main)
        main.merge_cells("A1:T1")
        legend=main["A1"]
        legend.value=("베이지 색상으로 된 셀은 원문에는 없으나, 가이드 지침에 따라 생성된 TC입니다. 사람의 확인 후 수정할 수 있습니다.\n"
                      "보라색 색상으로 된 셀은 비기능 TC입니다")
        legend.font=Font(name="Malgun Gothic",size=10,color="5F4A32",bold=True)
        legend.alignment=Alignment(horizontal="left",vertical="center",wrap_text=True)
        main.row_dimensions[1].height=34
        for ix,case in enumerate(cases,4):
            req=reqs.get(str(case.get("parent_srs_id") or ""),{})
            if _is_nonfunctional_e2e_case(case,req):
                for ci in range(1,17):
                    main.cell(ix,ci).fill=PatternFill("solid",fgColor=self.NONFUNCTIONAL)
            if case.get("execution_basis")=="ENGINEERING_PROPOSED_STEP":
                # Human-designed recovery precondition/sequence can be inferred
                # while the recovery outcome remains fully source-backed.
                main.cell(ix,12).fill=PatternFill("solid",fgColor=self.HYPOTHESIS)
            if case.get("expectation_basis")=="ENGINEERING_HYPOTHESIS":
                # Beige highlights only the inferred values where violet otherwise
                # conveys an independently classified nonfunctional test case.
                first=15 if _is_nonfunctional_e2e_case(case,req) else 1
                for ci in range(first,17):
                    main.cell(ix,ci).fill=PatternFill("solid",fgColor=self.HYPOTHESIS)
        dv=DataValidation(type="list",formula1='"PASS,FAIL"',allow_blank=True); main.add_data_validation(dv); dv.add(f"R4:R{max(100,main.max_row+20)}")

        self._write_table(trace,["Test Case ID","요구사항 ID","상위 SRS ID","검증 영역",
            "평가 방법","E2E 평가 객체 ID","관련 원본 객체 ID","원본 객체 유형"],
            trace_rows,[17,22,18,16,19,31,46,34])
        wb.save(out); self._verify_evaluation_artifact(out,cases,human_ids)
        # A compact, auditable explanation is written beside the Excel without any AI call.
        # A log failure is not allowed to turn a valid E2E workbook into an export failure.
        try:
            self.last_decision_log_path = write_e2e_decision_summary(
                output_dir=self.output_dir, source_document=source_document,
                cases=cases, human_ids=human_ids, reqs=reqs,
                design_audit=basic_audit, workbook_name=out.name,
            )
        except (OSError, ValueError, TypeError) as exc:
            # The export remains valid; GUI caller may report the optional log failure.
            self.last_decision_log_error = str(exc)
            print(f"[Requirement Studio] E2E 판단 근거 로그 저장 실패: {exc}")
        # V0.109: independent rule-routing diagnosis; existing decision summary preserved.
        # This is deterministic and uses no extra AI/provider calls.
        try:
            self.last_semantic_diagnostic_path = write_semantic_split_diagnostic(
                output_dir=self.output_dir, source_document=source_document,
                cases=cases, human_ids=human_ids, reqs=reqs,
                design_audit=basic_audit, workbook_name=out.name,
            )
        except (OSError, ValueError, TypeError) as exc:
            self.last_semantic_diagnostic_error = str(exc)
            print(f"[Requirement Studio] 의미 분할 진단 로그 저장 실패: {exc}")
        return out

    def _verify_evaluation_artifact(self, path: Path, cases: list[dict[str,Any]], expected_human_ids: list[str] | None = None):
        wb=load_workbook(path,read_only=False,data_only=False)
        try:
            ws=wb["2_E2E_평가케이스"]
            # V0.105 human layout: result fields Q:T (17~20) are physically blank.
            for r in range(4,ws.max_row+1):
                if not str(ws.cell(r,1).value or "").strip(): continue
                for c in (17,18,19,20):
                    if ws.cell(r,c).value not in (None,""):
                        ws.cell(r,c).value=None
            wb.save(path)
        finally: wb.close()
        check=load_workbook(path,read_only=True,data_only=False)
        try:
            ws=check["2_E2E_평가케이스"]; violations=[]; ids=[]
            for r in range(4,ws.max_row+1):
                tcid=str(ws.cell(r,1).value or "").strip()
                if not tcid: continue
                ids.append(tcid)
                for c in (17,18,19,20):
                    if ws.cell(r,c).value not in (None,""): violations.append(ws.cell(r,c).coordinate)
            expected=expected_human_ids or [f"SRS_TC_{i:03d}" for i in range(1,len(cases)+1)]
            if ids!=expected:
                raise ValueError(f"E2E human Test Case ID mismatch: expected={expected} actual={ids}")
            if len(set(ids))!=len(ids):
                raise ValueError("E2E human Test Case ID must be unique.")
            if violations: raise ValueError("E2E evaluation pre-execution result fields must be blank: "+", ".join(violations[:20]))
        finally: check.close()

