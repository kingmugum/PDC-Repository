"""Compact deterministic rationale for the generated E2E evaluation.

Important: this is a summary of *observable code decisions and provenance*, NOT a
chain of thought, the original LLM reasoning, or proof of engineering correctness.
No model call; no credentials; no raw source dumps. Fits an ordinary support attachment.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import re
from typing import Any
from core.semantic_objective_design import describe_test_structure


def _str(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _clip(value: Any, limit: int = 86) -> str:
    s = _str(value)
    return s if len(s) <= limit else s[:limit-1].rstrip() + "…"


def _aslist(value: Any) -> list[Any]:
    return value if isinstance(value, list) else ([value] if value else [])


def _key(value: Any) -> str:
    return re.sub(r"\s+", "", _str(value)).lower()


def _describe_kind(kind: str) -> str:
    return {
        "SOURCE_BACKED_FALLBACK": "기본 검증 1건 유지: 자동 의미 분기 근거를 충분히 구조화하지 못함",
        "DIRECT_SIGNAL_OUTPUT": "원문에 명시된 신호와 값을 사용한 출력 확인",
        "ENUM": "열거값 매핑 기반 검증",
        "SEMANTIC_BRANCH": "출처에 기재된 의미 분기에 따라 분리",
        "TIMING_CHECKPOINT_EXCEPTION": "명시된 시간/오류 판정 지점 기반 분리",
        "TIMEOUT_EXCEPTION": "명시된 시간 초과/실패 반응 확인",
        "STATE_TRANSITION": "명시된 상태전이 조건 확인",
        "STATE_TRANSITION_INHIBIT": "명시된 상태전이 금지 조건 확인",
        "CONDITIONAL_IO": "명시된 입력과 출력 조건 대응",
        "SOURCE_BACKED_REVIEW": "원문 또는 검증 도메인 추가 검토",
        "BOOLEAN_CONDITION_COVERAGE": "출처에 구분된 조건으로 대표 조합 생성; 미정의 부정 결과는 명시된 시험 설계 가설로 제안",
        "VOLTAGE_BOUNDARY_PARTITION": "원본 전압 구간을 동등분할·경계값 후보로 분리하고 경계 중첩은 검토 대상으로 보존",
        "EXPLICIT_OR_TRIGGER_BRANCH": "원문에서 확인된 대체 진입 경로를 각각 1개의 수행 후보로 분리; 독립 인가 가능성은 최종 확인",
    }.get(kind, "원본 사실·검증 객체를 기준으로 생성(종류: " + (kind or "미기록") + ")")


def _group_explanations(cases: list[dict[str, Any]], ids: list[str], reqs: dict[str, dict[str, Any]]) -> list[str]:
    by_parent: dict[str, list[tuple[str, dict[str, Any]]]] = defaultdict(list)
    for tcid, case in zip(ids, cases):
        by_parent[str(case.get("parent_srs_id") or "미확인")].append((tcid, case))
    groups: list[str] = []
    for sid, group in by_parent.items():
        if len(group) <= 1:
            continue
        types = sorted(set(_str(c.get("test_object_type")) for _, c in group))
        facts = sorted(set(f for _, c in group for f in _aslist(c.get("source_fact_fragment_ids")) if f))
        same_outcome = len(set(_key(c.get("pass_criterion") or c.get("expected_state") or c.get("expected_result")) for _, c in group)) == 1
        group_ids = ", ".join(i for i,_ in group)
        common = (
            f"- {sid}: {len(group)}건 [{group_ids}]; 검증 객체={','.join(types) or '미확인'}, "
            f"출처 조각={len(facts)}개."
        )
        if same_outcome:
            common += " 현재 PASS/기대 결과 문구가 같음 → 중복 가능성 검토(확정 아님)."
        else:
            common += " 서로 다른 출처/목적에서 분리된 항목이며, 실제 독립 검증 필요 여부는 추가 확인."
        groups.append(common)
    return groups


def build_e2e_decision_summary(
    *, source_document: Path, cases: list[dict[str, Any]], human_ids: list[str],
    reqs: dict[str, dict[str, Any]], design_audit: dict[str, Any] | None = None,
    workbook_name: str = "", now: datetime | None = None,
) -> str:
    """V0.106: explain applied engineering rules, split/keep/step/vector decisions.

    This replaces the older boilerplate-heavy result listing with a compact
    support log; a program's rule decisions are traceable, but no hidden model
    chain of thought is stored or claimed.
    """
    if len(cases) != len(human_ids):
        raise ValueError('판단 로그의 TC와 ID 개수가 다릅니다.')
    audit=design_audit or {}
    now_string=(now or datetime.now()).strftime('%Y-%m-%d %H:%M:%S')
    groups: dict[str,list[tuple[str,dict[str,Any]]]] = defaultdict(list)
    for tid,case in zip(human_ids,cases):
        groups[_str(case.get('parent_srs_id')) or '미확인'].append((tid,case))
    kinds=Counter(_str(c.get('basic_case_kind') or c.get('test_design_mode') or '미기록') for c in cases)
    lines=[
        'Requirement Studio V0.112 | E2E 시험 설계 결정 근거 요약', '='*62,
        f'생성: {now_string}', f'입력 문서: {Path(source_document).name}',
        f'평가 명세서: {workbook_name or "(미기록)"}',
        f'평가 TC: {len(cases)}건 | 상위 요구사항: {len(groups)}건',
        '', '[이 로그가 설명하는 내용]',
        '원본 Fact → 검증 목적 → TC/Step/Vector/대표 조합 → 예상 결과의 연결과 선택 사유를 기록합니다.',
        '여기서 말하는 판단은 실제 프로그램의 적용 규칙이며 AI의 비공개 내부 추론 내용이 아닙니다.',
        '시험할 수 있는 입력·관찰 신호의 확정과 원문 자체의 정확성을 보증하지 않습니다.',
        '로그에 API Key, 개인 설정값, 원본 전문, 전체 AI 응답을 복사하지 않습니다.',
        '', '[설계 순서 · V0.112]',
        '1) 원본 Fact ID 및 검증 객체의 책임 범위를 유지합니다.',
        '2) 기존 신호/Enum/시간/AND·OR/전압/대체 진입 경로 등 확정 규칙을 먼저 적용합니다.',
        '3) 미처리 복합 요구사항은 원본에 확인되는 독립 검증 목적을 식별해 TC 분할을 검토합니다.',
        '4) 입력 조건·판정 결과의 조합별 독립 TC를 우선합니다. 한 시험의 필수 연속 동작은 Step으로 보존합니다.',
        '5) 서로 다른 조건-결과의 독립 시험 경로는 기존 특정 도메인 규칙 밖에서도 후보로 분리합니다.',
        '6) 출처 사실과 시험 절차 제안을 구별하고 미확정 입력/관찰 방법은 기록합니다.',
        '※ 원본에 없는 신호값/제어방법은 생성하지 않으며 부정 결과는 시험 설계 가설로 구분합니다.',
        '가설도 최종 TC까지 생성하며 중간 승인으로 분석을 멈추지 않음. 가설은 원본 사실 아님.',
        '', '[분할/유지 규칙 사용 통계]',
    ]
    for kind,n in kinds.most_common(12):
        lines.append(f'- {kind}: {n}건')
    lines += ['', '[같은 요구사항에서 여러 TC가 나온 이유 / 중복 점검]']
    # Preserve concise group insights without mistaking similar PASS text for dedup proof.
    for sid,group in list(groups.items())[:32]:
        if len(group)<2:
            continue
        ids=', '.join(i for i,_ in group[:7])+('…' if len(group)>7 else '')
        decisions=Counter((c.get('engineering_decision_record') or describe_test_structure(c)).get('decision','KEEP') for _,c in group)
        decisions_str=', '.join(f'{k} {n}건' for k,n in decisions.most_common(3))
        same=len({_key(c.get('pass_criterion') or c.get('expected_state')) for _,c in group})==1
        text=f'- {sid}: {len(group)}개 [{ids}]; 판단={decisions_str}.'
        if same:
            text+=' PASS/기대 결과가 같음 → 중복 가능성 검토(확정 아님).'
        else:
            text+=' 검증 목적 또는 대표 조건이 달라 별도 구성이 선택됨.'
        lines.append(text)
    if not any(len(group)>1 for group in groups.values()):
        lines.append('- 복수 TC로 구성된 동일 상위 요구사항 없음.')
    merges=[x for x in _aslist(audit.get('cross_domain_duplicate_merges')) if isinstance(x,dict)]
    lines += ['', '[SYS.5/SWE.6 통합 판단]']
    if not merges: lines.append('- 비교 조건을 충족한 통합 이력 없음.')
    for m in merges[:20]:
        trace=','.join(str(x) for x in _aslist(m.get('source_fact_fragment_ids'))[:4])
        lines.append(f"- {m.get('parent_srs_id')}: {m.get('kept_test_object_id')} + {m.get('merged_test_object_id')} → 공통 목적 통합. 근거=조건·PASS 동일; 보존 Fact={trace}")
    lines += ['', '[TC별 Engineering 판단과 실행 순서의 이유]']
    for tid,case in list(zip(human_ids,cases))[:60]:
        sid=_str(case.get('parent_srs_id'))
        kind=_str(case.get('basic_case_kind') or case.get('test_design_mode'))
        decision=case.get('engineering_decision_record') or describe_test_structure(case)
        fids=[str(x) for x in _aslist(case.get('source_fact_fragment_ids')) if str(x)]
        trace=','.join(fids[:4])+('…' if len(fids)>4 else '') if fids else '미연결'
        title=_clip(case.get('evaluation_name') or case.get('test_objective'),58)
        lines.append(f'- {tid} ({sid}) {title} | {decision.get("decision","KEEP")} / {decision.get("rule",kind)} | 출처={trace}')
        lines.append(f'  이유: {_clip(decision.get("why"),145)} | 시험방법: {_clip(decision.get("method"),74)}')
        # For sequential/complex intent, explain order *without* inventing one.
        if kind=='SEMANTIC_INDEPENDENT_OBJECTIVE' or kind in {'SEQUENCE_REQUEST_RESPONSE','EXPLICIT_OR_TRIGGER_BRANCH'}:
            lines.append(f'  순서·구성: {_clip(decision.get("step_reason"),120)}')
        if kind=='SEMANTIC_INDEPENDENT_OBJECTIVE':
            lines.append(f'  근거 부분: {_clip(case.get("semantic_support_excerpt"),150)}')
        elif kind=='BOOLEAN_CONDITION_COVERAGE':
            labels=[str(x) for x in _aslist(case.get('boolean_condition_human_labels')) if x]
            states=[x for x in _aslist(case.get('boolean_condition_states')) if isinstance(x,dict)]
            if states:
                lines.append('  실제 조건: '+'; '.join(f"{_clip(x.get('name'),42)}={'참' if x.get('expected') else '거짓'}" for x in states[:6]))
            if case.get('condition_source_derivation')=='COMPOSITE_SOURCE_FACT_CLAUSES':
                lines.append('  분리 근거: 단일 원본 Fact의 조건절을 식별했으며 같은 Fact ID를 공유함.')
            lines.append('  '+('AND' if case.get('condition_logic')=='ALL_OF' else 'OR')+' 출처 기반 대표 조합 생성됨.')
            if labels:
                lines.append('  사람용 조건: '+'; '.join(_clip(x,48) for x in labels[:6]))
            if case.get('expectation_basis')=='ENGINEERING_HYPOTHESIS':
                lines.append('  판정 가설(원본 미명시): '+_clip(case.get('pass_criterion') or case.get('expected_state'),170))
        elif kind=='VOLTAGE_BOUNDARY_PARTITION':
            lines.append('  전압 대표 구간: '+_clip(case.get('boundary_region'),58)+'; 정확한 경계점은 별도 확인.')
        elif _str(case.get('condition_logic')) in {'ALL_OF','ANY_OF'}:
            logic='AND' if case.get('condition_logic')=='ALL_OF' else 'OR'
            lines.append(f'  {logic} 논리는 식별됐으나 조건별 대표 조합은 자동 생성되지 않음; '+
                         _clip(case.get('condition_split_diagnostic') or '원문 Fact·조건별 대응 정보 부족',110))
        if not _str(case.get('input_variable')) or not _str(case.get('output_variable')):
            lines.append('  확인 필요: '+('/'.join(x for x in ('입력 신호 미연결' if not _str(case.get('input_variable')) else '',
                                                     '출력 신호 미연결' if not _str(case.get('output_variable')) else '') if x))+
                         '; 근거 없는 신호·값은 생성하지 않음.')
    if len(cases)>60:
        lines.append(f'- 그 밖의 {len(cases)-60}건은 Excel 추적성 시트에서 확인하세요.')
    lines += ['', '[지원 요청 시 필요한 자료]',
        '1) 본 TXT  2) 문제가 되는 TC의 E2E 평가 시트 행  3) 가능하다면 해당 요구사항의 비밀정보를 제외한 근거',
        '같은 목적이 누락되거나 중복되면 상위 SRS ID와 출처 Fact ID를 함께 알려 주세요.',
    ]
    return '\n'.join(lines)+'\n'


def write_e2e_decision_summary(*, output_dir: Path, source_document: Path,
                              cases: list[dict[str, Any]], human_ids: list[str],
                              reqs: dict[str, dict[str, Any]], design_audit: dict[str, Any] | None = None,
                              workbook_name: str = "") -> Path:
    from core.output_naming import output_filename
    stem = re.sub(r'[<>:"/\\|?*]+', '_', Path(source_document).stem).strip('._ ')[:72] or 'source'
    target = Path(output_dir) / output_filename('00_E2E_판단근거_요약', stem, 'txt')
    text = build_e2e_decision_summary(source_document=source_document, cases=cases, human_ids=human_ids,
                                      reqs=reqs, design_audit=design_audit, workbook_name=workbook_name)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(text,encoding='utf-8-sig')  # notepad-friendly UTF-8 BOM
    return target
