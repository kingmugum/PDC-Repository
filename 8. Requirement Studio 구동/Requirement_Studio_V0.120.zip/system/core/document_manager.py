from __future__ import annotations

import os
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


SUPPORTED_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".pptx",
    ".xlsx",
    ".xlsm",
}


@dataclass
class DocumentLookupResult:
    document: Optional[Path] = None
    error: Optional[str] = None


class DocumentManager:
    """Non-destructive input registration.

    input/ is a user-owned working directory, NOT disposable application cache.
    A file chooser/drag-drop selects an active batch; it never removes an input
    document. External files are copied safely, and input/ files are registered
    in place. On an explicit refresh all currently present inputs are selected.
    """

    def __init__(self, input_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self._selected_documents: Optional[list[Path]] = None
        self.ensure_input_dir()

    def ensure_input_dir(self):
        self.input_dir.mkdir(parents=True, exist_ok=True)

    def list_documents(self):
        return sorted(
            [
                path
                for path in self.input_dir.iterdir()
                if path.is_file()
                and not path.name.startswith(".")
                and not path.name.startswith("~$")
                and path.suffix.lower() in SUPPORTED_EXTENSIONS
            ],
            key=lambda p: p.name.lower(),
        )

    def get_documents(self):
        """Active chosen batch, or full input directory if no explicit selection."""
        if self._selected_documents is not None:
            return [p for p in self._selected_documents if p.is_file()]
        return self.list_documents()

    def select_all_from_input(self):
        """Refresh intentionally includes newly pasted documents without deleting any."""
        self._selected_documents = None
        return self.get_documents()

    @staticmethod
    def _same_contents(a: Path, b: Path) -> bool:
        if a.stat().st_size != b.stat().st_size:
            return False
        # Comparing bytes, rather than just size/name, avoids silent overwrites.
        with a.open("rb") as x, b.open("rb") as y:
            while True:
                a_chunk = x.read(256 * 1024)
                b_chunk = y.read(256 * 1024)
                if a_chunk != b_chunk:
                    return False
                if not a_chunk:
                    return True

    def _choose_import_target(self, source: Path) -> tuple[Path, bool]:
        """Return destination and whether a copy is necessary."""
        # An already-present input file is never copied or unlinked.
        if source.parent.resolve() == self.input_dir:
            return source, False

        original_name = source.name
        candidate = self.input_dir / original_name
        seq = 2
        while candidate.exists() or candidate.is_symlink():
            # Never use a symlinked destination as an excuse to read/replace an
            # external file. A genuine existing byte-identical file can be reused.
            if candidate.is_file() and not candidate.is_symlink() and self._same_contents(source, candidate):
                return candidate, False
            candidate = self.input_dir / f"{source.stem}_{seq}{source.suffix}"
            seq += 1
        return candidate, True

    def import_documents(self, paths) -> list[Path]:
        """Register selected documents without deleting or overwriting inputs.

        Existing active batch survives invalid selection or copy failure.
        Files created by earlier successful copies are preserved on a later
        failure, never treated as disposable user documents.
        """
        sources = [Path(p).expanduser() for p in (paths or [])]
        if not sources:
            raise ValueError("선택된 입력 문서가 없습니다.")
        for source in sources:
            if not source.is_file() or source.suffix.lower() not in SUPPORTED_EXTENSIONS:
                raise ValueError(f"지원하지 않거나 존재하지 않는 입력 문서: {source}")
        self.ensure_input_dir()
        selected: list[Path] = []
        for source in sources:
            # Only delete temporary files that THIS operation creates. User
            # source files and previously stored input files are never deleted.
            tmp_path: Path | None = None
            try:
                destination, should_copy = self._choose_import_target(source)
                if should_copy:
                    with tempfile.NamedTemporaryFile(
                        mode="wb", dir=self.input_dir, prefix="._rs_import_", suffix=".partial", delete=False
                    ) as tmp:
                        tmp_path = Path(tmp.name)
                    shutil.copy2(source, tmp_path)
                    # Recheck to avoid accidentally replacing any new target.
                    if destination.exists() or destination.is_symlink():
                        destination, should_copy = self._choose_import_target(source)
                    if should_copy:
                        # Hard-linking a staged file in the same input directory
                        # is atomic and fails if the final name suddenly exists.
                        # Unlike os.replace(), this CANNOT overwrite a user's
                        # file during a concurrent Explorer copy or drag/drop.
                        try:
                            os.link(tmp_path, destination)
                        except FileExistsError:
                            raise FileExistsError(
                                f"입력 문서 등록 중 같은 이름의 파일이 생성되었습니다: {destination.name}. "
                                "기존 파일은 보존했습니다. 다시 선택해주세요."
                            )
                        except OSError:
                            # Filesystems that do not support hard links still
                            # get exclusive creation (xb), never replacement.
                            created = False
                            try:
                                with destination.open("xb") as output:
                                    created = True
                                    with tmp_path.open("rb") as staged:
                                        shutil.copyfileobj(staged, output)
                            except Exception:
                                if created:
                                    destination.unlink(missing_ok=True)  # only ours
                                raise
                if destination not in selected:
                    selected.append(destination)
            finally:
                if tmp_path is not None:
                    tmp_path.unlink(missing_ok=True)
        self._selected_documents = selected
        return list(selected)

    def get_single_document(self) -> DocumentLookupResult:
        """Legacy helper kept for compatibility with older callers."""
        documents = self.get_documents()
        if not documents:
            return DocumentLookupResult(error="입력 문서가 없습니다.")
        if len(documents) > 1:
            return DocumentLookupResult(
                error=f"입력 문서가 {len(documents)}개입니다. 단일 문서 호출에서는 1개만 선택할 수 있습니다."
            )
        return DocumentLookupResult(document=documents[0])

    @staticmethod
    def format_size(size_bytes: int) -> str:
        size = float(size_bytes)
        for unit in ("B", "KB", "MB", "GB"):
            if size < 1024 or unit == "GB":
                if unit == "B":
                    return f"{int(size)} {unit}"
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size_bytes} B"
