"""Read-only diagnostic of observable semantic TC design decisions (V0.109).

Never recovers model private reasoning, never invokes an AI provider, never copies
source paragraphs or credential-bearing configuration values into the report.
It records rule order, skipped semantic passes, candidate type counts, and
coverage *signals* rather than asserting that missing candidate == missed TC.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import re
from typing import Any


def _list(v: Any) -> list[Any]:
    return v if isinstance(v, list) else ([v] if v else [])


def _text(v: Any, limit: int = 110) -> str:
    s = re.sub(r"\s+", " ", str(v or "")).strip()
    return s[:limit] + ("…" if len(s) > limit else "")


def prompt_guide_visibility(root: Path | None = None) -> dict[str, Any]:
    """Read static *configuration*, not a record of actual sent prompts."""
    root = Path(root) if root else Path(__file__).resolve().parents[1]
    guide = root / 'Build AI Better Decision' / 'Decision Complete' / 'AI_E2E_GUIDELINE_CONSTITUTION.txt'
    if not guide.is_file():
        return {'guide_file_found': False, 'editorial_chars': 0, 'editorial_sent_limit': 3200,
                'editorial_truncated_chars': 0, 'note': '가이드 파일 없음. 실제 AI 호출 여부는 확인할 수 없음.'}
    contents = guide.read_text(encoding='utf-8-sig')
    a,b='[USER_EDITORIAL_GUIDE_START]','[USER_EDITORIAL_GUIDE_END]'
    editorial = contents.split(a,1)[1].split(b,1)[0].strip() if a in contents and b in contents else ''
    priority=contents.split('[V0.110_USER_POLICY_START]',1)[1].split('[V0.110_USER_POLICY_END]',1)[0].strip() if '[V0.110_USER_POLICY_START]' in contents and '[V0.110_USER_POLICY_END]' in contents else ''
    return {'guide_file_found': True, 'total_chars': len(contents),
            'priority_policy_chars': len(priority), 'priority_policy_limit': 2200,
            'editorial_chars': len(editorial), 'editorial_sent_limit': 3200,
            'editorial_truncated_chars': max(0,len(editorial)-3200),
            'approved_tail_ref_chars': 2800 if '[사용자 확정 사례 배치:' in contents else 0,
            'note':'프롬프트 코드의 길이 제한과 현재 가이드 파일을 비교한 정적 추정입니다. 실제 AI 송신·수신 사실은 이 로그만으로 확인할 수 없습니다.'}


def build_semantic_split_diagnostic(*, source_document: Path,
    cases: list[dict[str,Any]], human_ids: list[str],
    reqs: dict[str,dict[str,Any]], design_audit: dict[str,Any] | None = None,
    workbook_name: str = '', project_root: Path | None = None,
    now: datetime | None = None, max_groups: int = 45) -> str:
    if len(cases) != len(human_ids):
        raise ValueError('진단 대상 TC와 ID 개수가 일치하지 않습니다.')
    audit=design_audit or {}
    events=[ev for ev in _list(audit.get('semantic_split_diagnostic_events')) if isinstance(ev,dict)]
    casegroups:dict[str,list[tuple[str,dict[str,Any]]]]=defaultdict(list)
    for tcid,case in zip(human_ids,cases):
        casegroups[str(case.get('parent_srs_id') or '미확인')].append((tcid,case))
    byparent:dict[str,list[dict[str,Any]]]=defaultdict(list)
    for event in events:
        byparent[str(event.get('parent_srs_id') or '미확인')].append(event)
    count_skipped=sum(1 for e in events if e.get('semantic_evaluation')=='SKIPPED_AFTER_PRECEDING_RULE')
    count_augmented=sum(1 for e in events if e.get('semantic_evaluation')=='AUGMENTED_AFTER_PRECEDING_RULE')
    counts=Counter(str(c.get('basic_case_kind') or c.get('test_design_mode') or '미기록') for c in cases)
    guide=prompt_guide_visibility(project_root)
    lines=[
        'Requirement Studio V0.112 | E2E 의미 분할 진단', '='*62,
        '생성: '+(now or datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
        '입력 문서: '+Path(source_document).name,
        'E2E 파일: '+(workbook_name or '(미기록)'),
        f'최종 TC {len(cases)}개 / 상위 요구사항 {len(casegroups)}개 / 계측된 분할 경로 {len(events)}개',
        '', '[읽는 법]',
        '이 파일은 실제 로컬 코드가 실행한 규칙·생략 조건·추적 ID를 기록합니다.',
        'AI가 실제로 어떤 의미를 이해했는지 또는 모델의 비공개 판단 경로는 복원하지 않습니다.',
        '검증 목적 후보가 TC로 따로 나오지 않았다고 반드시 누락인 것은 아닙니다. 앞선 규칙이나 Step/Vector에서 처리했을 수 있습니다.',
        '고객 원본 전문, 실제 문장, API 키, 사용자 설정값, 전체 프롬프트는 복사하지 않습니다.',
        '', '[진단 단계 결과]',
        f'1) 원본 요구사항 구조: 전달된 SRS {len(reqs)}건 (원본 파일 직접 재파싱 아님)',
        '2) AI 요구사항 분석: 실제 모델이 이해한 검증 목적 목록은 현재 산출 계약에 없음 → 독립 비교 불가능',
        f'3) 로컬 분할 규칙: 계측 {len(events)}건; 선행 규칙 후 의미 분할 추가 {count_augmented}건; 후속 의미 TC 미적용 {count_skipped}건',
        f'4) 최종 TC: {len(cases)}건; 아래에서 SRS별 적용 경로와 출처 ID를 비교',
        '5) 누락 판단: 별도 의미 후보와 TC의 비교는 *진단 신호*이며 완전성 검증이 아님',
        '', '[AI E2E 가이드 전달 범위: 정적 구성 점검]',
        f"- 가이드 파일 존재: {'예' if guide.get('guide_file_found') else '아니요'}",
        f"- 파일 전체 글자 수: {guide.get('total_chars','미확인')}",
        f"- V0.112 우선 정책: {guide.get('priority_policy_chars',0)}자 / 별도 전달 한도 {guide.get('priority_policy_limit',2200)}자",
        f"- 기존 사용자 작성 원칙: {guide.get('editorial_chars',0)}자 / 앞부분 한도 {guide.get('editorial_sent_limit',3200)}자",
        f"- 길이 제한으로 제외될 수 있는 뒤쪽: {guide.get('editorial_truncated_chars',0)}자",
        f"- 확정 사례 마지막 부분 별도 참조 한도: {guide.get('approved_tail_ref_chars',0)}자",
        '- '+str(guide.get('note','')),
        '', '[생성 분포]',
    ]
    for kind,n in counts.most_common(10):
        lines.append(f'- {_text(kind,55)}: {n}건')
    # V0.110: coarse safety signals for generated prose; do not copy source text.
    integrity=[]
    for tc_id,case in zip(human_ids,cases):
        title=str(case.get('evaluation_name') or '')
        expected=str(case.get('expected_state') or '')
        pre=str(case.get('precondition') or '')
        own=str(case.get('semantic_condition_source') or '')
        flags=[]
        if re.search(r'(?:복구를\s*시|\b[A-Za-z]+\s+to)$',title):
            flags.append('TRUNCATED_TITLE_CANDIDATE')
        if re.match(r'^(?:도\s+하되|고\s+|며\s+|다만\s+)',expected):
            flags.append('EXPECTED_FRAGMENT_CANDIDATE')
        if own and pre and re.sub(r'\s+','',own) not in re.sub(r'\s+','',pre):
            flags.append('OTHER_BRANCH_PRECONDITION_CANDIDATE')
        if re.search(r'\[(?:REQ|SRS)[\w.\-]+\]|.{2,}…\s*-?\s*결과 확인',title,re.I):
            flags.append('UNREWRITTEN_REQUIREMENT_TITLE')
        if str(case.get('basic_case_kind'))=='DECISION_TABLE' and any(len(str(case.get(k) or ''))>250 for k in ('test_objective','precondition','pass_criterion')):
            flags.append('POSSIBLE_SIGNAL_DICTIONARY_AS_DECISION_TABLE')
        if flags:
            integrity.append(f"- {_text(tc_id,30)}: {','.join(flags)}")
    lines += ['', '[V0.112 의미 무결성 진단 (원본 본문 비포함)]',
              f'- 경고 신호: {len(integrity)}건',
              '- 단순 문자열 신호이며 0건이라도 의미 정확성을 완전히 보증하지 않습니다.']
    lines.extend(integrity[:40])
    lines += ['', '[SRS별 의미 분할 경로 · 원본 본문 비포함]']
    interesting=sorted(set(byparent)|set(casegroups))
    for sid in interesting[:max_groups]:
        entries=byparent.get(sid,[])
        finals=casegroups.get(sid,[])
        ids=', '.join(tid for tid,_ in finals[:9])+(' 외' if len(finals)>9 else '')
        lines.append(f'- {sid}: 최종 TC {len(finals)}건 [{ids or "없음"}], 진단 경로 {len(entries)}건')
        if not entries:
            lines.append('  · 규칙 단계 계측 정보 없음(예: 저장된 기존 번들/진단 전 생성 데이터).')
            continue
        for e in entries[:7]:
            obj=_text(e.get('test_object_id'),45)
            kinds=','.join(_text(x,38) for x in _list(e.get('applied_case_kinds'))) or '없음'
            candidates=list(dict.fromkeys(_text(x,40) for x in _list(e.get('candidate_goal_kinds'))))
            fids=','.join(_text(x,36) for x in _list(e.get('source_fact_fragment_ids'))[:5]) or '미연결'
            lines.append(f'  · 객체 {obj or "미확인"} | 경로={_text(e.get("decision_path"),45)} | 생성규칙={kinds}')
            lines.append(f'    Fact ID: {fids}')
            if e.get('semantic_evaluation')=='SKIPPED_AFTER_PRECEDING_RULE':
                prior=', '.join(str(x) for x in _list(e.get('preceding_rule_kinds'))[:5])
                lines.append('    원인: 선행 규칙이 TC를 생성하여 후속 독립 의미 분석이 실행되지 않음.'+(f' [선행={prior}]' if prior else ''))
                if candidates:
                    lines.append('    미적용 가능 후보 종류: '+', '.join(candidates[:8]))
                    lines.append('    판단: 다른 생성 TC에서 이미 다뤘는지 추적성 비교 필요(누락 확정 아님).')
            elif e.get('semantic_evaluation')=='NOT_RUN_SOURCE_BLOCK':
                lines.append('    원인: 원본 Fact가 TBD/Conflict로 표시되어 생성 전에 제한됨.')
            elif 'SEMANTIC_INDEPENDENT_OBJECTIVE' in _list(e.get('applied_case_kinds')):
                lines.append('    결과: 의미 분할 규칙이 실행되어 독립 검증 목적 후보를 TC로 구성함.')
            else:
                lines.append('    결과: 의미 규칙이 실행 가능했으나 분리 후보가 부족하거나 다른 규칙으로 처리됨.')
                if not candidates:
                    lines.append('    추가 진단: 현재 의미 파서에서 복수 독립 목적이 식별되지 않음.')
        if len(entries)>7: lines.append(f'  · 추가 진단 경로 {len(entries)-7}건 생략(로그 크기 제한)')
    if len(interesting)>max_groups:
        lines.append(f'- 추가 SRS {len(interesting)-max_groups}건 생략(로그 크기 제한)')
    lines += ['', '[다음 개선을 결정할 때 확인할 사항]',
        '① 선행 규칙 성공 시에도 미처리 독립 목적을 분석할 필요가 있는가?',
        '② 원본 Fact에 두 개 이상의 독립 조건/결과가 있으나 파서가 후보를 식별하지 못하는가?',
        '③ TC가 별도로 없더라도 Step/Vector에 해당 판정이 이미 포함되어 있는가?',
        '④ AI가 추출한 요구사항 JSON에서 관련 조건·동작·결과가 빠진 것인가?',
        '⑤ 실행 방법이 미정인 것과 검증 목적을 분리할 수 없는 것을 혼동하고 있지는 않은가?',
        '', '[지원 요청에 필요한 최소 자료]',
        '1) 이 파일과 기존 판단 근거 요약 TXT',
        '2) 관련 E2E 평가 명세서의 TC 행',
        '3) 가능하다면 비밀정보를 제외한 해당 요구사항/Fact 연결 근거',
        '※ 로컬 테스트는 실제 Windows GUI, 외부 H-Chat, 고객 사양서 검증을 대신하지 않습니다.',
    ]
    return '\n'.join(lines)+'\n'


def write_semantic_split_diagnostic(*, output_dir: Path, source_document: Path,
        cases: list[dict[str,Any]], human_ids: list[str],
        reqs: dict[str,dict[str,Any]], design_audit: dict[str,Any] | None = None,
        workbook_name: str = '', project_root: Path | None = None) -> Path:
    from core.output_naming import output_filename
    stem=re.sub(r'[<>:"/\\|?*]+','_',Path(source_document).stem).strip('._ ')[:72] or 'source'
    path=Path(output_dir)/output_filename('00_E2E_의미분할_진단',stem,'txt')
    rendered=build_semantic_split_diagnostic(source_document=source_document,
        cases=cases,human_ids=human_ids,reqs=reqs,design_audit=design_audit,
        workbook_name=workbook_name,project_root=project_root)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(rendered,encoding='utf-8-sig')
    return path
