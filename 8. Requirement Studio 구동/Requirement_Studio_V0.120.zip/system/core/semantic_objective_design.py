"""V0.106: source-traced independent verification objectives, before TC formatting.

This is an intentionally bounded, deterministic semantic-intent classifier.  It uses
existing Source Fact records (not fresh model calls) and does not invent numerical
I/O values or pretend that separate objectives have separate Source Fact IDs.
A production-grade universal semantic parser is NOT claimed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SemanticGoal:
    kind: str
    title: str
    purpose: str
    execution: str
    expected: str
    evidence_excerpt: str
    source_fact_fragment_ids: tuple[str, ...]
    verification_method: str
    notes: str
    condition: str = ""  # exact complete condition, only for general conditional paths


# A pattern group is a *different verification intent*, not a clause-count rule.
# Intent pairs such as recovery/Watchdog and error-response/recovery are supported
# across controllers.  Other relations remain unexpanded rather than guessed.
_GOAL_TYPES: tuple[tuple[str, str, str, str, str, str, str], ...] = (
    (
        'LIN_RECOVERY_WHILE_CAN_NORMAL',
        r'(?:CAN\s*통신\s*(?:이\s*)?정상[^.\n]{0,85}LIN\s*통신\s*(?:오류|이상)[^.\n]{0,100}복구\s*(?:를\s*)?시도|CAN\s*통신\s*정상[^.\n]{0,110}LIN\s*통신\s*복구\s*(?:를\s*)?시도)',
        'CAN 정상 상태의 LIN 통신 복구 시도',
        'CAN 통신 정상 상태에서 LIN 오류에 대한 복구 시도를 확인한다.',
        'CAN 통신을 정상으로 유지한 뒤 LIN 오류 조건을 구성하고 LIN 복구 동작을 관찰한다.',
        'CAN 정상 상태에서 원본에 정의된 LIN 복구 시도',
        '통신 오류 주입 및 LIN 복구 관찰',
    ),
    (
        'CAN_LIN_COMBINED_FAILURE_SAFE_STATE',
        r'(?:CAN\s*(?:및|과|와|/)\s*LIN\s*통신\s*(?:오류|이상)|CAN\s*통신\s*(?:오류|이상)[^.\n]{0,45}LIN\s*통신\s*(?:오류|이상))[^.\n]{0,110}(?:LOW\s*POWER|Low\s*Power|저전력)',
        'CAN·LIN 동시 통신 오류 시 저전력 진입',
        'CAN과 LIN 통신이 모두 오류인 경우의 저전력 진입을 확인한다.',
        'CAN과 LIN 통신 오류 조건을 구성하고 원본에 정의된 Low Power Mode 진입을 관찰한다.',
        'CAN·LIN 동시 오류 시 원본에 정의된 Low Power Mode',
        '복합 통신 오류 주입 및 상태 관찰',
    ),
    (
        'USER_SETTING_DEFAULT_RECOVERY',
        r'(?:사용자\s*설정(?:값|정보)?)[^.\n]{0,90}(?:복구\s*(?:불가|불가능|실패)|복구할\s*수\s*없)[^.\n]{0,90}(?:초기값|기본값)|(?:사용자\s*설정(?:값|정보)?)[^.\n]{0,70}(?:초기값|기본값)[^.\n]{0,70}(?:동작|복구)',
        '사용자 설정 복구 실패 시 초기값 적용',
        '사용자 설정 복구가 불가능한 경우 초기값으로 동작하는지 확인한다.',
        '사용자 설정값 복구 실패 조건을 구성하고 초기값 적용 및 정상 동작을 관찰한다.',
        '원본에 명시된 초기값 기반의 정상 동작',
        '복구 실패 조건 및 기본값 적용 관찰',
    ),
    (
        'SOFTWARE_ERROR_RECOVERY', r'(?:SW|소프트웨어|MCU).{0,45}(?:오류|Reset|리셋).{0,95}(?:복귀|복구|정상\s*상태)',
        '소프트웨어 오류 후 정상 복귀', 'SW 오류 이후 정상 복귀와 재초기화 상태를 확인한다.',
        '원본에 명시된 SW 오류 조건을 구성하고 복귀 상태를 관찰한다.',
        '원본에 명시된 정상 복귀 상태', '동적 시험 / 오류 발생 조건 확인',
    ),
    (
        'WATCHDOG_ARCHITECTURE', r'(?:Watchdog|WDT).{0,180}(?:Task|태스크|인터럽트|ISR|루틴|배치|작동\s*순서)',
        'Watchdog 실행·배치 제약', 'Watchdog의 Task 실행 순서와 ISR 내 배치 금지 제약을 검증한다.',
        '소프트웨어의 Watchdog 호출 위치 및 태스크/인터럽트 구조를 검토한다.',
        '원본에 명시된 Watchdog 배치·실행 순서 제약', '정적 분석 / 실행 추적 검토',
    ),
    (
        'DATA_INTEGRITY_CHECK', r'(?:정합성|Check[- ]?sum|Checksum).{0,135}(?:검사|점검|확인|Check)|(?:검사|점검).{0,65}(?:정합성|Check[- ]?sum)',
        '저장 데이터 정합성 검사', '저장 데이터 정합성 검사 수행 여부를 확인한다.',
        '원본에 명시된 진입 조건을 구성하고 저장 데이터 정합성 검사 수행을 확인한다.',
        '원본에 정의된 정합성 검사 수행', '동적 시험 / 내부 관찰 수단 확인',
    ),
    (
        'DATA_FAULT_SAFE_REACTION', r'(?:정합성\s*(?:이상|오류)|데이터\s*(?:오류|이상)).{0,155}(?:출력|OFF|Low\s*Power|LOW POWER|안전\s*상태)',
        '정합성 이상 시 안전 동작', '저장 데이터의 정합성 이상에 따른 안전 동작을 확인한다.',
        '정합성 이상 조건을 구성하고 원본에 지정된 출력 및 상태전이를 순서대로 관찰한다.',
        '원본에 지정된 이상 대응 출력·상태', '오류 주입 가능 여부 / 상태 전이 관찰',
    ),
    (
        'COMMUNICATION_FAILURE_RESPONSE', r'(?:CAN|LIN).{0,60}(?:통신\s*(?:오류|유지\s*불가)|BUS\s*OFF).{0,160}(?:중지|LOW POWER|Low Power|진입)',
        '통신 이상 시 안전 대응', '통신 오류 발생 시 안전 동작 및 전원 모드 전환을 확인한다.',
        '원본에 명시된 통신 이상 조건을 구성하고 출력 중지 및 상태전이 순서를 관찰한다.',
        '원본에 명시된 통신 오류 대응 상태', '오류 유발 및 상태전이 검증',
    ),
    (
        'COMMUNICATION_RESTORATION', r'(?:CAN|LIN).{0,45}(?:복구|정상\s*화).{0,70}(?:정상\s*동작|재개|복귀)|(?:복구|정상\s*화).{0,70}(?:CAN|LIN).{0,70}(?:정상\s*동작|재개)',
        '통신 복구 후 정상 동작', '통신 복구 시 정상 동작 복귀 여부를 확인한다.',
        '통신 이상 상태를 선행 구성하고 통신을 복구한 후 정상 동작을 관찰한다.',
        '원본에 명시된 복구 후 정상 동작', '오류→복구 순차 시나리오 검증',
    ),
    (
        'PERSISTENT_CONFIGURATION_STORE', r'(?:사용자\s*설정|설정\s*정보|설정값).{0,100}(?:비휘발성|EEPROM|NVM|저장)|(?:비휘발성|EEPROM|NVM).{0,80}(?:사용자\s*설정|설정값|설정\s*정보)',
        '사용자 설정 비휘발성 저장', '사용자 설정이 비휘발성 저장소에 기록되는지 확인한다.',
        '원본에 명시된 설정 입력을 적용하고 저장 상태를 확인한다.',
        '원본에 명시된 사용자 설정 저장 상태', '설정 입력 및 저장 상태 검증',
    ),
    (
        'LED_ONOFF_ACTUATION', r'(?:LED|무드\s*램프|무드등|슬레이브).{0,120}(?:On\s*/\s*Off|ON\s*/\s*OFF|점등|소등)',
        'LED On/Off 동작', 'LED의 On/Off 제어 동작을 확인한다.',
        '원본에 정의된 On/Off 제어 정보를 적용하고 LED 동작을 관찰한다.',
        '원본에 명시된 LED On/Off 동작', '입력 신호 및 관찰값 연결 필요',
    ),
    (
        'LED_BRIGHTNESS_ACTUATION', r'(?:LED|무드\s*램프|무드등|슬레이브).{0,130}밝기',
        'LED 밝기 제어', 'LED 밝기 제어 동작을 확인한다.',
        '원본에 정의된 밝기 설정 정보를 적용하고 LED 밝기 동작을 관찰한다.',
        '원본에 명시된 LED 밝기 제어', '밝기 명령 및 기대값 매핑 필요',
    ),
    (
        'LED_COLOR_ACTUATION', r'(?:LED|무드\s*램프|무드등|슬레이브).{0,130}색상',
        'LED 색상 제어', 'LED 색상 제어 동작을 확인한다.',
        '원본에 정의된 색상 설정 정보를 적용하고 LED 색상 동작을 관찰한다.',
        '원본에 명시된 LED 색상 제어', '색상 명령 및 기대값 매핑 필요',
    ),
)


def _sentence_excerpt(text: str, match: re.Match[str]) -> str:
    """Show a short source excerpt without copying an entire specification paragraph."""
    start, end = match.span()
    left = max(text.rfind('.', 0, start), text.rfind('\n', 0, start), text.rfind(';', 0, start))
    right_candidates = [pos for pos in (text.find('.', end), text.find('\n', end), text.find(';', end)) if pos >= 0]
    right = min(right_candidates) if right_candidates else len(text)
    value = re.sub(r'\s+', ' ', text[left+1:right]).strip(' ,.;')
    if len(value) > 175:
        # Keep the matched segment; don't silently claim this excerpt is the full Source.
        value = re.sub(r'\s+', ' ', text[max(0,start-40):min(len(text),end+75)]).strip()
    return value[:175]


def identify_independent_goals(records: list[dict[str, Any]], *, minimum_goals: int = 2) -> list[SemanticGoal]:
    """Extract separately testable *intent candidates* from actual traced Fact text.

    A goal is included only if a real, nonempty fact ID supports its evidence.
    Multiple goals may share a single Fact ID. If evidence cannot establish at least
    `minimum_goals` distinct intentions, callers should preserve the existing TC.
    """
    goals: list[SemanticGoal] = []
    for kind, pattern, title, purpose, execution, expected, method in _GOAL_TYPES:
        evidence: list[tuple[str,str]] = []
        for rec in records:
            fid = str(rec.get('fid') or '')
            text = str(rec.get('text') or '').strip()
            if not fid or not text:
                continue
            match = re.search(pattern, text, re.I | re.S)
            if match:
                evidence.append((fid, _sentence_excerpt(text, match)))
        if not evidence:
            continue
        source_ids = tuple(dict.fromkeys(fid for fid,_ in evidence))
        # The clause is the exact retained reason for this choice, not an AI thought trace.
        sample = next((snippet for _, snippet in evidence if snippet), '')
        note = '독립 판정 목적과 시험 방법이 다름. 미확인 신호값은 생성하지 않음.'
        if kind.startswith('LED_'):
            note = '제어 목적은 분리하되 구체 신호값·색상·밝기 단계는 Source/DB 확인 전 생성하지 않음.'
        elif kind == 'COMMUNICATION_RESTORATION':
            note = '오류 대응과 달리 복구 이후 상태를 판정하므로 별도 TC. 오류 발생→복구는 순차 Step으로 유지.'
        elif kind == 'LIN_RECOVERY_WHILE_CAN_NORMAL':
            note = 'CAN 정상/LIN 오류라는 고유 진입 조건과 LIN 복구 시도를 독립 판정함.'
        elif kind == 'CAN_LIN_COMBINED_FAILURE_SAFE_STATE':
            note = 'CAN·LIN 동시 오류 경로는 CAN 정상/LIN 오류와 조건·예상 결과가 달라 별도 TC.'
        elif kind == 'USER_SETTING_DEFAULT_RECOVERY':
            note = '데이터 정합성 이상 안전 동작과 설정값 복구 실패 후 초기값 적용은 독립 실패 목적임.'
        elif kind == 'WATCHDOG_ARCHITECTURE':
            note = '외부 동작 시험과 정적 구현 제약은 평가 방법·실패 원인이 다름.'
        goals.append(SemanticGoal(kind,title,purpose,execution,expected,sample,source_ids,method,note))
    # Specific multi-bus error handling supersedes a generic communication error
    # goal for exactly the same evidence. Preserve genuinely separate generic facts.
    specific={fid for g in goals if g.kind=='CAN_LIN_COMBINED_FAILURE_SAFE_STATE'
              for fid in g.source_fact_fragment_ids}
    if specific:
        goals=[g for g in goals if not (g.kind=='COMMUNICATION_FAILURE_RESPONSE'
               and set(g.source_fact_fragment_ids).issubset(specific))]
    return goals if len(goals) >= minimum_goals else []




def human_conditional_tc_title(condition: str, outcome: str) -> str:
    """V0.111: concise observable purpose; source Req IDs remain in trace only.

    Do not take the first N characters of a conditional clause or append
    a boilerplate '- 결과 확인' suffix.  Avoid inventing a device/signal name.
    """
    clean = lambda s: re.sub(r"\s+", " ", re.sub(r"\[(?:REQ|SRS|SYS|SWE)[\w.\-]+\]", "", s, flags=re.I)).strip(' ,.;:')
    cond, result = clean(condition), clean(outcome)
    combined = f"{cond} {result}"
    if '풋램프' in combined or re.search(r'FootLp', combined, re.I):
        if re.search(r'Dimout|DimeOut|감광', combined, re.I):
            return '풋램프 감광 제어'
        if re.search(r'\bOFF\b|\bOff\b|소등', combined, re.I) and not re.search(r'\bON\b|\bOn\b|점등', result, re.I):
            return '풋램프 OFF 제어'
        if re.search(r'\bON\b|\bOn\b|점등|밝기', result, re.I):
            return '풋램프 ON 및 밝기 제어' if '밝기' in result or 'Brightness' in result else '풋램프 ON 제어'
    if re.search(r'비휘발|EEPROM|NVM|저장', result, re.I) and re.search(r'저장|기록', result):
        return ('밝기 정보 비휘발 저장' if '밝기' in combined else '설정 정보 비휘발 저장')
    if re.search(r'카운터.*초기화', result):
        return '카운터 초기화'
    if re.search(r'팝업|OSD', result, re.I):
        return ('사용자 동의 팝업 요청' if '동의' in combined else '조건 불만족 OSD 요청')
    if re.search(r'유틸리티.?모드|Utility.?Mode', combined, re.I) and re.search(r'전환|천이', result):
        return '유틸리티 모드 전환 요청'
    if re.search(r'(?:Par_Timer|대기).*?(?:Off|OFF|소등)', combined, re.I):
        return '무드램프 OFF 명령 수신 후 지연 제어'
    if re.search(r'대기.*?(?:On|ON|점등)', combined, re.I):
        return 'OFF 대기 중 ON 조건 재진입 제어'
    if re.search(r'(?:이미지|영상).*(?:송신|전송).*?(?:않|차단|중지|금지)|(?:이미지|영상).*?(?:않|차단|중지|금지).*?(?:송신|전송)', result, re.I):
        return '이미지 전송 차단 및 오류 응답 확인' if re.search(r'오류|고장|NOK|Fail',result,re.I) else '이미지 전송 차단'
    if re.search(r'이미지.*(?:송신|전송)|파일.*전송', result):
        return '이미지 전송 제어'
    if re.search(r'Low\s*Power|저전력', result, re.I):
        return '저전력 모드 진입' + (' - CAN/LIN 통신 오류' if re.search(r'CAN.{0,12}LIN.*오류',cond,re.I) else '')
    if re.search(r'복구|복귀', result):
        return '통신 복구 제어' if '통신' in combined else '오류 복구 제어'
    # Choose semantic predicate, not arbitrary first 47 chars of the condition.
    value = re.sub(r'^(?:마스터|슬레이브|해당|본)\s*제어기(?:는|가|의)?\s*', '', result)
    value = re.sub(r'^(?:제어기|시스템)(?:는|가)?\s*', '', value)
    value = re.sub(r'(?:해야\s*한다|하여야\s*한다|한다|된다)\.?$', '', value).strip(' ,.;')
    # Retain complete meaningful tail when short; shorten only at phrase boundaries.
    terms = re.split(r'[,;]|\s+(?:그리고|또한|단,)\s+', value)
    best = (terms[0] if terms else value).strip()
    if len(best) > 62:
        chunks = best.split()
        out=[]
        for chunk in chunks:
            if len(' '.join(out+[chunk]))>60: break
            out.append(chunk)
        best=' '.join(out)
    return best or '조건별 동작 확인'


def _independent_observable_actions(outcome: str) -> list[str]:
    """Separate only explicit, independently observable verbs in a single result.

    Dependent ordered actions (arrow / '후' / '다음') remain one STEP scenario.
    This is intentionally not a universal Korean semantic parser.
    """
    if re.search(r'→|\bafter\b|후에|이후에|다음에', outcome, re.I):
        return [outcome]
    # re lookbehind must be fixed-width, so enumerate verb-ending alternatives.
    border = r'(?:삭제|차단|송신|저장|출력|전환|진입|요청|제어|복귀|중지|발생)하고\s*[,，]?\s*'
    parts = []
    last = 0
    for match in re.finditer(border, outcome):
        first = outcome[last:match.start()] + match.group().split('하고')[0]
        if len(first.strip()) < 5: continue
        parts.append(first.strip().rstrip(' ,，') + '한다')
        last = match.end()
    remainder = outcome[last:].strip()
    if parts and remainder and len(remainder) >= 5 and re.search(r'한다|된다|해야|출력|송신|요청|전환|진입|동작', remainder, re.I):
        parts.append(remainder)
        return parts if len(parts) <= 4 else [outcome]
    return [outcome]


def identify_conditional_path_goals(
    records: list[dict[str, Any]], *, minimum_goals: int = 2, maximum_goals: int = 10,
) -> list[SemanticGoal]:
    """V0.108: infer *candidate test organization* from different source clauses.

    Unlike the known-intent patterns above, this recognizes the general relation
    (explicit condition -> explicit expected action/result). It permits shared
    Fact IDs and does not require a hard-coded subject such as LIN or Watchdog.
    Source facts/thresholds are never invented. Steps needed to make a condition
    controllable are *test-design proposals*, not claims about the target ECU.

    Boundaries intentionally conservative: independently conditional sentences,
    not arbitrary comma-separated actions or every AND input, become TC candidates.
    """
    entries: list[tuple[str, str, str, str]] = []
    seen: set[tuple[str, str]] = set()
    for rec in records:
        fid = str(rec.get('fid') or '').strip()
        source = str(rec.get('text') or '').strip()
        if not fid or not source:
            continue
        # A single fact can contain multiple independent conditional paths.
        sentences = re.split(r'(?<=[.!?。])\s+|[\r\n;；]+', source)
        for sentence in sentences:
            sentence = re.sub(r'\s+', ' ', sentence).strip(' .。\t-•')
            if not (12 <= len(sentence) <= 400):
                continue
            m = re.match(
                r'^(?P<condition>.{2,180}?(?:\s+시(?=[\s,，])|\s+때(?=[\s,，])|아닌\s*경우|않은\s*경우|않을\s*경우|미충족\s*시|불만족\s*시|인\s*경우|일\s*경우|한\s*경우|되는\s*경우|하면|되면|면(?=[\s,，])))'
                r'\s*[,，]?\s*(?P<result>.{5,300})$', sentence, re.I,
            )
            if not m:
                continue
            condition=m.group('condition').strip(' ,')
            result=m.group('result').strip(' ,.')
            # A result must contain at least a plausible state/action assertion.
            if not re.search(r'(?:한다|된다|해야|수행|확인|진입|제어|출력|중지|복구|설정|저장|금지|유지|OFF|ON|작동|동작)', result, re.I):
                continue
            key=(re.sub(r'\s+', '', condition).lower(), re.sub(r'\s+', '', result).lower())
            if key in seen:
                continue
            seen.add(key)
            subactions=_independent_observable_actions(result)
            for subaction in subactions:
                entries.append((fid, condition, subaction, sentence))
    # A single conditional fact is an objective but not evidence for *splitting*.
    # More than the bound means the input needs a structured model, not a TC flood.
    if not (minimum_goals <= len(entries) <= maximum_goals):
        return []
    distinct_conditions={re.sub(r'\s+', '', c).lower() for _,c,_,_ in entries}
    distinct_outcomes={re.sub(r'\s+', '', x).lower() for _,_,x,_ in entries}
    if len(distinct_conditions) < 2 and len(distinct_outcomes) < 2:
        return []
    result=[]
    for index,(fid,condition,outcome,original) in enumerate(entries,1):
        title=human_conditional_tc_title(condition,outcome)
        result.append(SemanticGoal(
            kind=f'GENERAL_CONDITIONAL_PATH_{index:02d}',
            title=title,
            purpose=f'{condition} 조건에서 {outcome} 동작을 확인한다.',
            execution=f'{condition} 조건을 구성하고 원본에 기재된 동작·상태를 관찰한다.',
            expected=outcome,
            evidence_excerpt=original[:175],
            source_fact_fragment_ids=(fid,),
            verification_method='원본에 명시된 조건별 동작·상태 확인 (입력/관찰 수단은 별도 연계)',
            notes='출처 문장에서 서로 다른 조건과 결과를 식별함. 구체 조작과 관찰 인터페이스는 원문 범위로 제한.',
            condition=condition,
        ))
    return result


def describe_test_structure(case: dict[str, Any]) -> dict[str, str]:
    """Document *actual applied rule* and why TC/STEP/VECTOR was used.

    Called on generated cases; does not infer or expose an LLM's hidden reasoning.
    """
    kind = str(case.get('basic_case_kind') or '')
    goal = str(case.get('semantic_goal_kind') or '')
    if goal:
        return {
            'decision':'SPLIT',
            'rule':('EXPLICIT_CONDITIONAL_PATH_PROPOSAL' if goal.startswith('GENERAL_CONDITIONAL_PATH_') else 'SOURCE_TRACED_INDEPENDENT_OBJECTIVE'),
            'why':str(case.get('semantic_decision_reason') or '원본 근거가 있는 별도 검증 목적 및 독립 판정 항목.'),
            'method':str(case.get('semantic_verification_method') or '검증 방법 확인 필요'),
            'step_reason':str(case.get('semantic_sequence_reason') or '선후관계가 확인되지 않아 순서를 임의 생성하지 않음.'),
            'alternatives':'입력 조합 및 독립 판정별 TC 우선; 동일 단계는 STEP으로 유지.',
        }
    if kind == 'SEQUENCE_REQUEST_RESPONSE':
        return {'decision':'KEEP+STEP/VECTOR','rule':'EXPLICIT_ORDERED_REQUEST_RESPONSE',
            'why':'원본의 순차 요청·응답이 하나의 공통 시나리오에 속하며 단계별 관찰이 가능함.',
            'method':'요청/응답 매핑 및 순서 검증','step_reason':'원본에 명시된 전환 순서를 Step으로 유지.',
            'alternatives':'독립 실패 시나리오나 재설정이 필요한 경우 별도 TC 검토.'}
    if kind == 'BOOLEAN_CONDITION_COVERAGE':
        return {'decision':'SPLIT+REPRESENTATIVE_COMBINATIONS','rule':'TRACED_BOOLEAN_COVERAGE',
            'why':'원본의 AND/OR 조건별 영향을 대표 조합으로 구별함; 2^n 전체 조합 생성은 생략.',
            'method':'조건 충족·미충족의 독립 영향 확인',
            'step_reason':'동일 조합 내 조건 구성 후 전환 관찰 순서; 조건 간 순차 실행은 원본 보장 아님.',
            'alternatives':'부정 기대 결과가 원본에 없으면 가설로만 제안.'}
    if kind == 'VOLTAGE_BOUNDARY_PARTITION':
        return {'decision':'SPLIT+EQUIVALENCE_REGIONS','rule':'SOURCE_VOLTAGE_PARTITIONS',
            'why':'서로 다른 전압 구간에서 기대 동작이 달라 대표 구간별 판정이 필요함.',
            'method':'전압 구간/경계값 대표 시험','step_reason':'전압 설정 후 동작·통신 상태를 관찰함.',
            'alternatives':'정확한 경계점의 중복/충돌은 별도 검토.'}
    if kind == 'EXPLICIT_OR_TRIGGER_BRANCH':
        return {'decision':'SPLIT','rule':'TRACED_ALTERNATIVE_TRIGGERS',
            'why':'서로 다른 진입 경로가 공통 결과를 발생시키므로 경로별 도달성을 확인함.',
            'method':'진입 경로별 동일 결과 판정','step_reason':'각 경로 설정 후 결과 확인; 경로 자체의 순서를 의미하지 않음.',
            'alternatives':'독립 인가 불가능 시 실행 조건·통합 여부 재검토.'}
    if kind == 'SOURCE_BACKED_FALLBACK':
        return {'decision':'KEEP_PENDING_SEMANTIC_REVIEW','rule':'SOURCE_BACKED_FALLBACK',
            'why':'추적 가능한 서로 다른 독립 검증 목적을 현재 분석 규칙으로 2개 이상 확정하지 못함.',
            'method':'원본 Fact와 검증 수단 확인',
            'step_reason':'명시되지 않은 선후관계를 임의 추가하지 않음.',
            'alternatives':'별도 목적의 Source 근거를 확인하면 SPLIT, 동일 목적 값 변화는 VECTOR, 연속 동작은 STEP.'}
    if case.get('test_vectors') and len(case['test_vectors']) > 1:
        return {'decision':'KEEP+VECTOR','rule':kind or 'SOURCE_VECTOR_MAPPING',
            'why':'동일 검증 목적에서 여러 입력·예상 결과의 매핑을 반복 수행함.',
            'method':'원본 명시 매핑 및 단계 확인',
            'step_reason':'Vector의 반복 번호는 시간 순서 보증이 아님.',
            'alternatives':'시험 목적이나 PASS 기준이 독립이면 SPLIT 후보.'}
    return {'decision':str(case.get('split_decision') or 'KEEP'), 'rule':kind or 'SOURCE_OBJECTIVE',
            'why':'현재 Source·검증 목적에서 선택된 기존 생성 규칙을 적용함.',
            'method':'원본 출처 및 시험 환경에 따른 확인',
            'step_reason':'명시된 시간/순차 관계만 Step 순서로 인정함.',
            'alternatives':'독립 목적이 추가 확인될 때 SPLIT/KEEP/VECTOR/STEP 재평가.'}
