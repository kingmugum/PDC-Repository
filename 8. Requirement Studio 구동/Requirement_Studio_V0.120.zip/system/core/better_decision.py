"""V0.98 experimental, opt-in E2E engineering decision learning.

No model calls are made here. This module reuses already-finalized Source-backed
TCs and writes exactly one workbook plus one editable TXT per input document.
User-reviewed examples are stored separately; no executable rule is auto-approved.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
from typing import Any
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED

from core.e2e_exporter import (
    _compact_input_value, _compact_output_value, _display_compare,
    _display_domain_compact, _display_review_reason, _format_human_multiline,
    _test_case_review_status, _format_tc_preconditions, _format_tc_execution,
)
from core.verification_single_truth import finalize_verification_single_truth

DIR_NAME = 'Build AI Better Decision'
GUIDE_NAME = 'AI_E2E_GUIDELINE_CONSTITUTION.txt'
HEADERS = [
    'Test Case ID','요구사항 ID','검증 영역','평가 방법 / 도출 방법','테스트 케이스 이름',
    '테스트 목적','사전 조건','평가 환경 / 준비','입력 변수','비교','입력값',
    '수행 절차','출력 변수 / 관찰 대상','비교','기대 출력값','기대 상태 / 결과',
    'PASS 기준','TC 검토 상태','검토 사유 / 필요 조치','실제 출력값',
    '판정 (PASS/FAIL)','비고','결과 화면 캡처',
]

INTRO = '''AI E2E 가이드 헌법 — V0.98 시험 운용
============================================================
목적: 사용자가 최종 확정한 모범 TC의 Engineering 판단을 축적하고 후속 분석 시 참고합니다.
상위 원칙: 승인된 Requirements / AI 개발 헌법 / LOCK-008 / Source Fidelity 우선.
본 파일의 학습 사례는 참고 지침이며, 실행용 HUMAN_APPROVED Rule Registry를 자동 변경하지 않습니다.
원본 Source에 없는 Signal/Timing/Expected/Variant를 사실로 만들어서는 안 됩니다.

[운영 규칙]
- 학습 후보 옵션은 4개 SWE/E2E 문서 옵션과 독립적입니다. 학습 자료만 선택한 실행에서는 3-AI 품질 평가 및 일반 Word/Excel 산출을 생략합니다.
- 학습 후보와 일반 문서를 함께 선택하면 기존 분석 결과를 재활용해 둘 다 생성합니다. 별도 3-AI 품질 평가는 사용자가 명시적으로 활성화한 경우에만 실행합니다.
- 생성된 학습 후보는 결정적 휴리스틱으로 선정되며 H-Chat 추가 호출은 하지 않습니다.
- 판단 후보의 역추론을 확정 사실로 간주하지 않고, 사용자가 별도로 제공한 판단을 다음 패키지의 가이드에 명시 반영합니다. 대화 자동 동기화는 제공하지 않습니다.
- 이미 승인된 판단과 원본 내용이 상충하면 원본을 우선하고 최종 검토 대상으로 표시합니다.
- 새 상황에 대한 AI의 추가 판단은 허용하되 승인된 기존 규칙을 임의 승격/수정하지 않습니다.
- 일반 실행에서는 별도 중간 승인을 요구하지 않고 최종 결과에서 사람이 검토합니다.
'''


def _text(value: Any) -> str:
    if isinstance(value, list):
        return '\n'.join(_text(x) for x in value)
    if isinstance(value, dict):
        return ' / '.join(f'{k}: {_text(v)}' for k,v in value.items() if v not in ('',[],None,{}))
    return str(value or '').strip()


def _flat(value: Any) -> str:
    return re.sub(r'\s+', ' ', _text(value)).strip()


def _safe(value: str) -> str:
    return re.sub(r'[^\w가-힣.-]+', '_', value, flags=re.UNICODE).strip('_')[:55] or 'Source'


def _signature(category: str, source: str, name: str, objective: str) -> str:
    raw = '|'.join([category, _flat(source).casefold(), _flat(name).casefold(), _flat(objective).casefold()])
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:24]


def _category(case: dict, req: dict) -> tuple[str, str]:
    kind = str(case.get('test_design_mode') or '').lower()
    typ = str(case.get('test_object_type') or '').upper()
    desc = ' '.join(_flat(case.get(k)) for k in ('evaluation_name','test_objective','verification_objective','precondition','test_execution','pass_criterion','review_reason')).lower()
    if any(x in kind+' '+desc for x in ['timing','timeout','5초','15초','초 이내','시간 내','checkpoint']):
        return 'F_TIMING','독립 타이밍 조건의 TC 분리/선행조건 확인'
    if any(x in kind+' '+desc for x in ['sequence','순차','순서','step','이후','전이']):
        return 'G_SEQUENCE','순차 동작과 상태전이의 처리 방식 확인'
    if any(x in kind+' '+desc for x in ['decision_table','decision table','조합','vector']):
        return 'D_VECTOR','동일 검증 목적에 대한 조합/벡터 처리 확인'
    if any(x in kind+' '+desc for x in ['semantic_branch','분기','folding 가능','folding 불가능']):
        return 'C_SPLIT','독립 의미 분기에 대한 TC 분리 판단 확인'
    if any(x in kind+' '+desc for x in ['variant','hev','phev','차종','옵션']):
        return 'I_VARIANT','차종/구성 조건 처리 방식 확인'
    if (case.get('human_review_required') or _test_case_review_status(case) == '사람의 리뷰 필요') and not _flat(case.get('output_variable')):
        return 'J_REVIEW', '출력 및 판정 근거 부족 또는 미확정 검토 필요'
    if (case.get('output_variable') or case.get('input_variable')):
        return 'E_IO','입력/출력 및 기대값의 필드 배치 확인'
    if typ == 'SYS5_CANDIDATE' or 'sys.5' in desc or 'swe.6' in desc:
        return 'B_ALLOCATION','검증 영역과 목적의 할당 적합성 확인'
    if _flat(case.get('pass_criterion')):
        return 'H_PASS','PASS 기준의 원본 근거/판정성 확인'
    if req.get('source_evidence'):
        return 'A_SOURCE','원본 사실과 TC 목적 사이의 추적성 확인'
    return 'J_REVIEW','정해진 판단 유형으로 분류하기 어려운 신규 사례'


def _case_row(tc_id: str, bf_id: str, case: dict, req: dict, numbered: int) -> list[str]:
    title = _flat(case.get('evaluation_name') or req.get('function_name') or case.get('test_intent') or '기본 기능 확인')
    return [
        tc_id, bf_id, _display_domain_compact(case),
        '기본 기능 검증' if case.get('test_design_mode') != 'BASIC_FUNCTIONAL_REVIEW' else '검토 필요',
        f'{title}_{numbered:02d}',
        _format_human_multiline(case.get('test_objective') or case.get('verification_objective') or title),
        _format_tc_preconditions(case.get('precondition') or case.get('test_preparation') or req.get('preconditions') or req.get('activation_trigger')),
        _format_human_multiline(case.get('test_environment')),
        _flat(case.get('input_variable') or case.get('variable')),
        _display_compare(case.get('input_compare') or case.get('compare')),
        _compact_input_value(case),
        _format_tc_execution(case.get('test_execution') or req.get('processing_action')),
        _flat(case.get('output_variable')),
        _display_compare(case.get('output_compare')),
        _compact_output_value(case),
        _format_human_multiline(case.get('expected_state') or case.get('expected_result') or req.get('output')),
        _format_human_multiline(case.get('pass_criterion') or req.get('acceptance_criteria')),
        _test_case_review_status(case),
        _display_review_reason(case), '', '', '', '',
    ]


def _letter(n: int) -> str:
    result = ''
    while n:
        n, r = divmod(n-1, 26)
        result = chr(65+r) + result
    return result


def _sheet_xml(rows: list[list[str]], widths: list[float], editable: bool=False) -> bytes:
    # XLSX created with standard OOXML packaging; no extra AI or application dependencies.
    out=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
      '<sheetViews><sheetView workbookViewId="0"><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>',
      '<sheetFormatPr defaultRowHeight="18"/><cols>']
    for n,w in enumerate(widths,1):
        out.append(f'<col min="{n}" max="{n}" width="{w}" customWidth="1"/>')
    out.append('</cols><sheetData>')
    for ridx,row in enumerate(rows,1):
        style = 1 if ridx == 1 else (2 if ridx == 2 else 3)
        height = 28 if ridx<=2 else 52
        out.append(f'<row r="{ridx}" ht="{height}" customHeight="1">')
        for cidx, value in enumerate(row,1):
            s = _text(value)[:32760]
            # Blank design fields are displayed as N/A; the four unexecuted result
            # columns are intentionally untouched and remain physically empty.
            if not s and ridx > 3 and (cidx <= 19 or cidx > 23):
                s = 'N/A'
            cell_style = 4 if editable and ridx>2 and cidx>23 else style
            if s:
                out.append(f'<c r="{_letter(cidx)}{ridx}" s="{cell_style}" t="inlineStr"><is><t xml:space="preserve">{escape(s)}</t></is></c>')
            else:
                out.append(f'<c r="{_letter(cidx)}{ridx}" s="{cell_style}"/>')
        out.append('</row>')
    out.append('</sheetData></worksheet>')
    return ''.join(out).encode('utf-8')


def _write_xlsx(path: Path, sheets: list[tuple[str,list[list[str]],list[float],bool]]) -> None:
    # Minimal valid SpreadsheetML workbook with strong visual styles & editable cells.
    content=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    for ix in range(1,len(sheets)+1):
        content.append(f'<Override PartName="/xl/worksheets/sheet{ix}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
    content.append('</Types>')
    wxml=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
    rels=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for ix, (name,_,_,_) in enumerate(sheets,1):
        wxml.append(f'<sheet name="{escape(name)}" sheetId="{ix}" r:id="rId{ix}"/>')
        rels.append(f'<Relationship Id="rId{ix}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{ix}.xml"/>')
    wxml.append('</sheets></workbook>')
    rels.append(f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>')
    rels.append('</Relationships>')
    styles='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="3"><font><sz val="10"/><name val="Malgun Gothic"/></font><font><b/><sz val="13"/><color rgb="FFFFFFFF"/><name val="Malgun Gothic"/></font><font><b/><sz val="10"/><color rgb="FF12375A"/><name val="Malgun Gothic"/></font></fonts>
<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF163A62"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDEEDF9"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF1C9"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD6E0EA"/></left><right style="thin"><color rgb="FFD6E0EA"/></right><top style="thin"><color rgb="FFD6E0EA"/></top><bottom style="thin"><color rgb="FFD6E0EA"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs>
</styleSheet>'''
    with ZipFile(path,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',''.join(content))
        z.writestr('_rels/.rels','''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>''')
        z.writestr('xl/workbook.xml',''.join(wxml))
        z.writestr('xl/_rels/workbook.xml.rels',''.join(rels))
        z.writestr('xl/styles.xml',styles)
        for ix, (_,rows,widths,editable) in enumerate(sheets,1):
            z.writestr(f'xl/worksheets/sheet{ix}.xml',_sheet_xml(rows,widths,editable))


def _read_index(root: Path) -> dict:
    path = root / DIR_NAME / 'Decision Registry' / 'decision_learning_index.json'
    try:
        d = json.loads(path.read_text(encoding='utf-8'))
        return d if isinstance(d,dict) else {}
    except (OSError,ValueError):
        return {}


def _save_index(root: Path, index: dict) -> None:
    path = root / DIR_NAME / 'Decision Registry' / 'decision_learning_index.json'
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(path)


def ensure_structure(root: Path) -> Path:
    dest=Path(root) / DIR_NAME
    for p in ('Decision Pending','Decision Complete','Decision Complete/Archive','Decision Registry'):
        (dest/p).mkdir(parents=True,exist_ok=True)
    guide=dest / 'Decision Complete' / GUIDE_NAME
    if not guide.exists():
        guide.write_text(INTRO,encoding='utf-8')
    return dest


def create_learning_sample(root: Path, source_document: Path, data: dict, limit: int=10) -> dict:
    root=Path(root)
    base=ensure_structure(root)
    bundle=finalize_verification_single_truth(data)
    cases=[c for c in bundle.get('e2e_basic_functional_cases',[]) if isinstance(c,dict)]
    if not cases:
        cases=[c for c in bundle.get('e2e_evaluation_cases',[]) if isinstance(c,dict)]
    if not cases:
        raise ValueError('학습할 E2E 평가 TC가 생성되지 않았습니다.')
    reqs={_flat(r.get('srs_id')):r for r in data.get('requirements',[]) if isinstance(r,dict)}
    approved = _read_index(root)
    excluded={s for s in approved.get('completed_signatures',[]) if isinstance(s,str)}
    by_srs=defaultdict(int)
    name_count=defaultdict(int)
    ranked=[]
    for idx,c in enumerate(cases,1):
        sid=_flat(c.get('parent_srs_id'))
        by_srs[sid]+=1
        tc=f'SRS_TC_{idx:03d}'; bf=f'{sid}_BF_{by_srs[sid]:02d}' if sid else f'BF_{idx:02d}'
        req=reqs.get(sid,{})
        key=_flat(c.get('evaluation_name') or req.get('function_name'))
        name_count[key]+=1
        row=_case_row(tc,bf,c,req,name_count[key]); cat, why=_category(c,req)
        src='\n'.join(_flat(x.get('text') or x.get('behavior_text') or x.get('source_fact')) for x in (req.get('source_evidence') or []) if isinstance(x,dict))
        if not src:
            src=_flat(req.get('requirement') or req.get('processing_action'))
        loc=' | '.join(_flat(x.get('location') or x.get('source_location')) for x in (req.get('source_evidence') or []) if isinstance(x,dict))
        if not loc: loc=' | '.join(_flat(x) for x in c.get('source_locations',[]) if x)
        sig=_signature(cat,src,row[4],row[5])
        if sig in excluded: continue
        trace=', '.join(_flat(x) for x in c.get('source_fact_fragment_ids',[]) if x)
        # Never call the model to compute a speculative certainty score.
        priority=int(bool(trace))*3 + int(bool(loc))*2 + int(bool(c.get('human_review_required'))) + int(bool(row[12]))
        ranked.append({'tc_id':tc,'bf_id':bf,'category':cat,'why':why,'req':req,'case':c,'row':row,
          'source':src,'location':loc,'trace':trace,'signature':sig,'priority':priority})
    ranked.sort(key=lambda d:(-d['priority'],d['tc_id']))
    selected=[]; used_categories=set(); used_signatures=set()
    # Pick distinctive decision categories first. Avoid exact duplicate candidates.
    for distinct in (True, False):
        for item in ranked:
            if len(selected)>=limit: break
            if item['signature'] in used_signatures or (distinct and item['category'] in used_categories): continue
            selected.append(item); used_signatures.add(item['signature']); used_categories.add(item['category'])
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    batch=f'{_safe(Path(source_document).stem)}_{stamp}'
    pending=base/'Decision Pending'
    workbook=pending/f'Decision_Learning_{batch}.xlsx'
    txt=pending/f'Decision_Feedback_{batch}.txt'
    top=[['AI E2E 학습 후보 — 사용자 수정 전용, 자동 확정 아님'],['학습 배치',batch,'원본 문서',Path(source_document).name,'선정 수',str(len(selected))],
         ['TC ID','판단 유형','선정 이유','SRS ID','원문/요구사항','원본 위치','Fact ID','신규 여부']]
    top.extend([[i['tc_id'],i['category'],i['why'],_flat(i['case'].get('parent_srs_id')),i['source'][:1400],i['location'],i['trace'],'후보'] for i in selected])
    tc_header=[HEADERS+['사용자 판단','사용자 의견 / 수정 이유']]
    notes=[['안내: 02_TC수정 시트에서 기존 23개 필드를 직접 고치고 마지막 2열에 판단/이유를 적을 수 있습니다.'],
           ['검토 의견은 대화로 전달하세요. 다음 개발 버전의 가이드 헌법에 검토 후 반영합니다. Excel 수정본은 자동 수입되지 않습니다.']]
    edit=notes + tc_header + [i['row']+['검토 전',''] for i in selected]
    original=[['원본 TC (변경하지 마세요)'],['비교 기준'] , HEADERS] + [i['row'] for i in selected]
    _write_xlsx(workbook,[
        ('01_학습대상',top,[18,30,48,18,68,30,30,18],False),
        ('02_TC수정',edit,[17,20,12,20,38,40,40,30,25,12,24,50,28,12,25,35,50,24,38,20,16,24,25,18,55],True),
        ('03_원본TC',original,[17,20,12,20,38,40,40,30,25,12,24,50,28,12,25,35,50,24,38,20,16,24,25],False),
    ])
    lines=[f'학습 피드백 TXT — {batch}',f'원본 문서: {Path(source_document).name}',
      '안내: 각 CASE에서 [판단]과 [수정 내용] 또는 [이유]를 작성하세요.',
      '판단 예: 유지, 수정, 분리, 통합, 삭제, 보류. 빈칸/보류는 자동 학습되지 않습니다.',
      '원본과 무관한 새 신호·값을 입력한 경우 Source 검토가 필요하며 자동 승인되지 않습니다.',
      'Excel/TXT 자료의 판단 의견을 대화로 전달하면, 검토 후 다음 개발 버전의 가이드 헌법에 반영할 수 있습니다. 자동 동기화되지 않습니다.','']
    for i in selected:
        lines.extend([f'=== CASE {i["tc_id"]} ===',f'서명: {i["signature"]}',
             f'판단 유형: {i["category"]}',f'선정 이유: {i["why"]}',
             f'요구사항 ID: {i["bf_id"]}',f'원문 위치: {i["location"]}',f'근거 Fact: {i["trace"]}',
             f'원문 발췌: {i["source"][:1000]}',f'기존 TC 목적: {i["row"][5]}',
             '[판단]: ','[수정 내용]: ','[이유]: ',''])
    txt.write_text('\n'.join(lines),encoding='utf-8')
    registry=_read_index(root)
    registry.setdefault('schema_version','0.95-experiment')
    registry.setdefault('completed_signatures',[])
    registry.setdefault('completed_batches',{})
    registry.setdefault('pending_batches',{})[batch]={
        'source':str(Path(source_document).name), 'workbook':str(workbook.relative_to(base)),
        'feedback':str(txt.relative_to(base)), 'created_at':datetime.now().isoformat(),
        'cases':[{k:i[k] for k in ('tc_id','category','signature','why','location','trace','source')} | {'original_objective':i['row'][5],'original_expected':i['row'][14]} for i in selected]}
    _save_index(root,registry)
    return {'batch_id':batch,'excel':workbook,'feedback':txt,'candidate_count':len(selected),'candidate_categories':sorted(used_categories)}


def import_user_feedback(root: Path, feedback_file: Path) -> dict:
    root=Path(root); feedback_file=Path(feedback_file)
    base=ensure_structure(root)
    text=feedback_file.read_text(encoding='utf-8-sig')
    m=re.search(r'^학습 피드백 TXT — (.+)$',text,re.M)
    if not m: raise ValueError('V0.95 학습 피드백 TXT 형식이 아닙니다.')
    batch=m.group(1).strip()
    idx=_read_index(root)
    pending=idx.get('pending_batches',{}).get(batch)
    if not pending: raise ValueError('등록되지 않았거나 이미 완료된 학습 배치입니다.')
    known={x['tc_id']:x for x in pending['cases']}
    approved=[]
    for block in re.split(r'(?=^=== CASE )',text,flags=re.M):
        a=re.match(r'=== CASE (SRS_TC_\d+) ===',block)
        if not a: continue
        tc=a.group(1); item=known.get(tc)
        if not item: continue
        def field(label):
            m=re.search(rf'^\[{re.escape(label)}\]:[ \t]*(.*)$',block,re.M)
            return m.group(1).strip() if m else ''
        decision=field('판단')
        summary=field('수정 내용')
        why=field('이유')
        if decision not in ('유지','수정','분리','통합','삭제','확정'):
            continue
        if not (summary or why):
            continue
        approved.append({**item,'decision':decision,'summary':summary,'reason':why,'batch_id':batch})
    if not approved: raise ValueError('확정 가능한 사례가 없습니다. [판단]과 [수정 내용] 또는 [이유]를 작성하세요.')
    # A feedback entry is an explicitly confirmed example, not a general executable rule.
    complete=base/'Decision Complete'
    guide=complete/GUIDE_NAME
    archived=complete/'Archive'/feedback_file.name
    if archived.exists(): raise ValueError('동일한 피드백 TXT가 이미 보관되어 있습니다.')
    # Only append after provenance and registry validation; preserve existing data.
    with guide.open('a',encoding='utf-8') as f:
        f.write(f'\n\n[사용자 확정 사례 배치: {batch}]\n')
        for item in approved:
            f.write(f'\n- CASE: {item["tc_id"]}\n  판단 유형: {item["category"]}\n  선택: {item["decision"]}\n'
                    f'  수정 내용: {item["summary"] or "(없음)"}\n  판단 이유: {item["reason"] or "(없음)"}\n'
                    f'  원문 근거: {item["source"][:700]}\n  원본 TC 목적: {item["original_objective"]}\n'
                    f'  원본 기대값: {item["original_expected"]}\n  원본 위치: {item["location"]}\n'
                    f'  원본 Fact ID: {item["trace"]}\n'
                    '  상태: 사용자 확정 사례 (일반 규칙 자동 승격 아님)\n')
    shutil.copy2(feedback_file,archived)
    source_excel=base/pending['workbook']
    if source_excel.is_file():
        shutil.copy2(source_excel,complete/'Archive'/source_excel.name)
    idx.setdefault('completed_signatures',[])
    for item in approved:
        if item['signature'] not in idx['completed_signatures']:
            idx['completed_signatures'].append(item['signature'])
    idx.setdefault('completed_batches',{})[batch]={'confirmed':approved,'approved_at':datetime.now().isoformat()}
    idx['pending_batches'].pop(batch,None)
    _save_index(root,idx)
    # Keep unconfirmed cases in original pending TXT; do not treat as learned.
    return {'batch_id':batch,'approved_count':len(approved),'guide':guide,'archive':archived}
