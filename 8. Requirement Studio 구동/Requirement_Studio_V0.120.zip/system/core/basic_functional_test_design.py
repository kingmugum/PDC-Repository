from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from core.guideline_mining import build_guideline_mining_snapshot, is_rule_approved
from core.semantic_objective_design import identify_independent_goals, describe_test_structure

BASIC_FUNCTIONAL_MODE = "BASIC_FUNCTIONAL_SOURCE_BACKED"
NOT_CONFIRMED = "입력문서에서 확인되지 않음"


def _list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, dict):
        return " ".join(_text(v) for v in value.values() if v not in (None, "", [], {}))
    if isinstance(value, (list, tuple, set)):
        return " ".join(_text(v) for v in value if v not in (None, "", [], {}))
    return str(value).strip()


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", _text(value)).strip()


def _source_text(req: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in ("requirement", "activation_trigger", "preconditions", "processing_action", "output", "acceptance_criteria"):
        value = _text(req.get(key))
        if value:
            parts.append(value)
    for atom in _list(req.get("source_backed_atomic_behaviors")):
        if isinstance(atom, dict):
            value = _text(atom.get("behavior_text") or atom.get("source_fact"))
        else:
            value = _text(atom)
        if value:
            parts.append(value)
    for ev in _list(req.get("source_evidence")):
        if isinstance(ev, dict):
            value = _text(ev.get("text"))
        else:
            value = _text(ev)
        if value:
            parts.append(value)
    for fact in _list(req.get("source_table_fact_matches")):
        if isinstance(fact, dict):
            value = _text(fact.get("source_literal"))
            if value:
                parts.append(value)
    # Preserve newlines where Source evidence used them; they help enum parsing.
    return "\n".join(dict.fromkeys(x for x in parts if x))


def _fact_records(req: dict[str, Any]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for atom in _list(req.get("source_backed_atomic_behaviors")):
        if isinstance(atom, dict):
            text = _norm(atom.get("behavior_text") or atom.get("source_fact"))
            fid = str(atom.get("source_fact_fragment_id") or "")
            sem = str(atom.get("source_semantic_unit_id") or "")
            loc = _norm(atom.get("source_location"))
        else:
            text = _norm(atom); fid = sem = loc = ""
        if not text:
            continue
        key=(fid,text.lower())
        if key in seen:
            continue
        seen.add(key)
        out.append({"text":text,"fid":fid,"sem":sem,"location":loc})
    for alloc in _list(req.get("fact_level_allocations")):
        if not isinstance(alloc, dict):
            continue
        text=_norm(alloc.get("source_fact")); fid=str(alloc.get("source_fact_fragment_id") or "")
        if not text:
            continue
        key=(fid,text.lower())
        if key in seen:
            continue
        seen.add(key)
        out.append({"text":text,"fid":fid,"sem":str(alloc.get("source_semantic_unit_id") or ""),"location":_norm(alloc.get("source_location"))})
    return out


def _core_requirement_text(req: dict[str, Any]) -> str:
    parts=[]
    for key in ("requirement", "activation_trigger", "preconditions", "processing_action", "output", "acceptance_criteria"):
        v=_text(req.get(key))
        if v: parts.append(v)
    for rec in _fact_records(req):
        if rec.get("text"): parts.append(rec["text"])
    return "\n".join(dict.fromkeys(parts))


def _clean_variable(text: str) -> str:
    text = re.sub(r"^[\s,.;:()]+|[\s,.;:()]+$", "", text or "")
    text = re.sub(r"\b(?:HU|ECU|제어기|시스템)\s*(?:는|은)?\s*", "", text, flags=re.I)
    text = re.sub(r"(?:이|가|은|는)$", "", text).strip()
    return text[-42:].strip()


_VALUE = r"(?:0x[0-9A-Fa-f]+|[-+]?\d+(?:\.\d+)?\s*(?:mV|V|mA|A|ms|s|초|%|MB|KB|℃|°C)?|ON|OFF|HIGH|LOW|High|Low|True|False)"


def _parse_conditional_io(text: str) -> dict[str, str] | None:
    raw=_norm(text)
    if not raw:
        return None
    # Korean functional relation: "입력 전원이 12V가 되면 출력 전원이 5V가 되어야 한다"
    pat = re.compile(
        rf"(?P<ivar>[^,.;]{{2,48}}?)\s*(?P<ival>{_VALUE})\s*(?:가|이)?\s*(?:되면|이면|일\s*경우|일\s*때|때|시)\s*"
        rf"(?P<ovar>[^,.;]{{2,52}}?)\s*(?P<oval>{_VALUE})\s*(?:가|이)?\s*(?:되어야|돼야|되야|이어야|여야|된다|되어야\s*한다)",
        re.I,
    )
    m=pat.search(raw)
    if not m:
        return None
    ivar=_clean_variable(m.group("ivar")); ovar=_clean_variable(m.group("ovar"))
    if not ivar or not ovar:
        return None
    return {"input_variable":ivar,"input_compare":"=","input_value":m.group("ival").strip(),"output_variable":ovar,"output_compare":"=","output_value":m.group("oval").strip()}


def _signal_role(name: str) -> tuple[str, str]:
    raw=name or ""
    lower=raw.lower()
    suffixes = [
        ("request","request"),("req","request"),("command","request"),("cmd","request"),
        ("response","response"),("resp","response"),("status","response"),("state","response"),("stat","response"),
    ]
    for suffix, role in suffixes:
        if lower.endswith(suffix):
            return raw[:len(raw)-len(suffix)].rstrip("_"), role
    return raw, "unknown"


def _extract_signal_enum_blocks(source: str) -> dict[str, list[dict[str, str]]]:
    # Identify only explicit SignalName + "값" blocks to avoid treating arbitrary hex prose as an enum table.
    names = list(dict.fromkeys(re.findall(r"\b([A-Za-z][A-Za-z0-9_]{3,})\s*값\b", source)))
    out: dict[str, list[dict[str,str]]] = {}
    for name in names:
        best_pairs=[]
        for start in re.finditer(re.escape(name) + r"\s*값", source, re.I):
            tail=source[start.end():]
            next_m=re.search(r"\b[A-Za-z][A-Za-z0-9_]{3,}\s*값\b", tail)
            body=tail[:next_m.start()] if next_m else tail[:2200]
            pairs=[]
            for m in re.finditer(r"(0x[0-9A-Fa-f]+|\d+)\s*:\s*(.*?)(?=(?:0x[0-9A-Fa-f]+|\d+)\s*:|$)", body, re.S):
                meaning=re.sub(r"\s+", " ", m.group(2)).strip(" -|•\n\t")
                if len(meaning)>160:
                    meaning=meaning[:160].rstrip()+"…"
                pairs.append({"value":m.group(1),"meaning":meaning})
            if len(pairs)>len(best_pairs):
                best_pairs=pairs
        if best_pairs:
            out[name]=best_pairs
    return out


def _semantic_label(meaning: str) -> str:
    low=(meaning or "").lower()
    if "invalid" in low or "무효" in low:
        return "invalid"
    if "error" in low or "고장" in meaning or "오류" in meaning:
        return "error"
    if "default" in low:
        return "default"
    for label in ("front","rear","left","right","top"):
        if re.search(rf"\b{label}\b", low):
            return label
    ko={"전방":"front","후방":"rear","좌측":"left","우측":"right","탑":"top"}
    for token,label in ko.items():
        if token in meaning:
            return label
    return ""


def _sequence_labels(source: str) -> list[str]:
    best: list[str] = []
    for m in re.finditer(r"([A-Za-z가-힣]+(?:\s*(?:->|→)\s*[A-Za-z가-힣]+){1,8})", source):
        terms=re.split(r"\s*(?:->|→)\s*", m.group(1))
        labels=[]
        for t in terms:
            lbl=_semantic_label(t)
            if lbl:
                labels.append(lbl)
        if len(labels)>len(best):
            best=labels
    return best


def _fact_ids_matching(req: dict[str, Any], needles: list[str]) -> list[str]:
    low_needles=[n.lower() for n in needles if n]
    ids=[]
    for rec in _fact_records(req):
        low=rec["text"].lower()
        if any(n in low for n in low_needles):
            if rec["fid"] and rec["fid"] not in ids:
                ids.append(rec["fid"])
    return ids


def _source_trace_for_fids(req: dict[str, Any], fids: list[str]) -> tuple[list[str],list[str]]:
    sems=[]; locs=[]; wanted=set(fids)
    for rec in _fact_records(req):
        if wanted and rec["fid"] not in wanted:
            continue
        if rec["sem"] and rec["sem"] not in sems: sems.append(rec["sem"])
        if rec["location"] and rec["location"] not in locs: locs.append(rec["location"])
    if not sems:
        sems=[str(x) for x in _list(req.get("source_semantic_unit_ids")) if str(x)]
    if not locs:
        for ev in _list(req.get("source_evidence")):
            if isinstance(ev,dict):
                loc=_norm(ev.get("location"))
                if loc and loc not in locs: locs.append(loc)
    return sems,locs




FACT_ROLE_ORDER = (
    "PRECONDITION", "TRIGGER", "INPUT", "ACTION", "SEQUENCE",
    "OBSERVABLE", "EXPECTED", "CONSTRAINT", "EXCEPTION", "NEGATIVE_REQUIREMENT",
    "STATE_TRANSITION", "VARIANT_CONDITION", "TBD_CONFLICT",
)


def classify_source_backed_facts(req: dict[str, Any]) -> list[dict[str, Any]]:
    """Classify finalized Source-backed facts by verification role.

    This is deliberately multi-label.  V0.93 uses the roles to decide where a fact is
    projected in the human test case; it does not rewrite or split the Canonical SRS.
    """
    out: list[dict[str, Any]] = []
    for rec in _fact_records(req):
        text = rec["text"]
        low = text.lower()
        roles: list[str] = []
        if re.search(r"(?:완료\s*후|이후|사전\s*조건|상태에서|인\s*경우|일\s*경우|때|시\b)", text):
            roles.append("PRECONDITION")
        if re.search(r"(?:요청|command|cmd|수신|trigger|입력)", low):
            roles.append("TRIGGER")
        if re.search(r"(?:적용|주입|설정|입력|request|command|cmd)", low):
            roles.append("INPUT")
        if re.search(r"(?:송출|송신|전송|제어|수행|처리|저장|resiz|crop)", low):
            roles.append("ACTION")
        if re.search(r"(?:->|→|순서|순차|step)", low):
            roles.append("SEQUENCE")
        if re.search(r"(?:확인|관찰|피드백|상태\s*신호|state|status|출력)", low):
            roles.append("OBSERVABLE")
        if re.search(r"(?:되어야|해야\s*한다|이어야|여야|일치|0x[0-9a-f]+|\bon\b|\boff\b)", low):
            roles.append("EXPECTED")
        if re.search(r"(?:이하|미만|이상|초과|최대|최소|허용|금지|\d+(?:\.\d+)?\s*(?:ms|s|초|mb|kb|v|a|%))", low):
            roles.append("CONSTRAINT")
        if re.search(r"(?:미수신|timeout|error|invalid|고장|오류|예외|실패)", low):
            roles.append("EXCEPTION")
        if re.search(r"(?:하지\s*않|없음|금지|no\s*retry|retry\s*없)", low):
            roles.append("NEGATIVE_REQUIREMENT")
        if re.search(r"(?:전이|transition|target\s*state|상태로)", low):
            roles.append("STATE_TRANSITION")
        if re.search(r"(?:hev|phev|ev|ice|차종|variant)", low):
            roles.append("VARIANT_CONDITION")
        if re.search(r"(?:tbd|충돌|conflict|미확정|확정되지)", low):
            roles.append("TBD_CONFLICT")
        if not roles:
            roles.append("ACTION")
        # stable order for deterministic regression
        roles = [r for r in FACT_ROLE_ORDER if r in roles]
        out.append({**rec, "roles": roles})
    return out


def _field_trace(case: dict[str, Any], field: str, fids: list[str] | set[str] | tuple[str, ...]) -> None:
    trace = case.setdefault("field_fact_trace", {})
    trace[field] = list(dict.fromkeys(str(x) for x in fids if str(x)))


def _set_structured_case_fields(
    case: dict[str, Any], *, objective: str = "", precondition: str = "", environment: str = "",
    input_variable: str = "", input_compare: str = "", input_value: str = "", execution: str = "",
    output_variable: str = "", output_compare: str = "", output_value: str = "", expected_state: str = "",
    pass_criterion: str = "", field_fids: dict[str, list[str]] | None = None,
) -> dict[str, Any]:
    case["test_objective"] = _norm(objective or case.get("verification_objective") or case.get("test_intent") or case.get("evaluation_name"))
    case["precondition"] = _norm(precondition)
    case["test_environment"] = _norm(environment)
    case["input_variable"] = _norm(input_variable)
    case["input_compare"] = _norm(input_compare)
    case["input_value"] = _norm(input_value)
    case["test_execution"] = _text(execution).strip()
    case["output_variable"] = _norm(output_variable)
    case["output_compare"] = _norm(output_compare)
    case["output_value"] = _text(output_value).strip()
    case["expected_state"] = _text(expected_state).strip()
    case["pass_criterion"] = _text(pass_criterion).strip()
    for k, vals in (field_fids or {}).items():
        _field_trace(case, k, vals)
    return case


def _fact_ids_for_value(req: dict[str, Any], *needles: str) -> list[str]:
    clean=[_norm(x) for x in needles if _norm(x)]
    if not clean:
        return []
    return _fact_ids_matching(req, clean)



def _related_context_fids(req: dict[str, Any], context: str) -> list[str]:
    """Find exact facts that establish a Source-backed precondition/trigger named in context."""
    ctx=_norm(context)
    if not ctx:
        return []
    anchors=[]
    # Signal/identifier anchors.
    anchors.extend(re.findall(r"\b[A-Za-z][A-Za-z0-9_-]{2,}\b",ctx))
    # Korean/compound phrase directly preceding completion/after/condition words.
    for m in re.finditer(r"([A-Za-z가-힣0-9_ /-]{2,48}?)(?:완료\s*후|이후|인\s*경우|일\s*경우)",ctx):
        anchors.append(_norm(m.group(1)))
    generic={"HU","ECU","System","Source","Command","CMD","On","Off"}
    anchors=[a for a in anchors if a not in generic and len(a)>=2]
    ids=[]
    for rec in _fact_records(req):
        low=rec["text"].lower()
        if any(a.lower() in low for a in anchors):
            if rec["fid"] and rec["fid"] not in ids:
                ids.append(rec["fid"])
    return ids


def _trace_integrity_review(req: dict[str, Any], case: dict[str, Any]) -> dict[str, Any] | None:
    """Review-route populated verification values that lack exact Fact Fragment provenance."""
    trace = case.get("field_fact_trace") if isinstance(case.get("field_fact_trace"), dict) else {}
    required = []
    # V1.01: an explicitly labeled Engineering hypothesis is not a claimed Source fact.
    # Its condition/target origin remains traceable, but its expected negative reaction
    # must NEVER be given a fake exact-field Fact attribution.
    inferred = set(_list(case.get("inferred_expected_fields"))) if case.get("expectation_basis") == "ENGINEERING_HYPOTHESIS" else set()
    hypothesis_fids = [str(x) for x in _list(case.get("inference_evidence_fids")) if str(x)]
    for field in ("input_value", "output_value", "pass_criterion"):
        value = _text(case.get(field))
        if value and not _list(trace.get(field)):
            if field in inferred and hypothesis_fids:
                continue  # visible final-review hypothesis, not an exact Source assertion
            required.append(field)
    # V0.93: grouped properties may have one traced value and one untraced value.
    # When a vector explicitly declares source_fact_fragment_ids, every populated factual
    # vector value must have at least one exact fragment; otherwise case-level PASS is false.
    for n,vector in enumerate(_list(case.get("test_vectors")),1):
        if not isinstance(vector,dict) or "source_fact_fragment_ids" not in vector:
            continue
        vfids=[str(x) for x in _list(vector.get("source_fact_fragment_ids")) if str(x)]
        if (vector.get("input_value") or vector.get("expected_output") or vector.get("expected_state")) and not vfids:
            required.append(f"test_vector[{n}]")
    required=list(dict.fromkeys(required))
    if not required:
        case["exact_field_trace_status"] = ("SOURCE_TRACED_WITH_INFERRED_EXPECTATION" if inferred else "PASS")
        return None
    case["exact_field_trace_status"] = "REVIEW_REQUIRED"
    case["human_review_required"] = True
    case["execution_readiness"] = "REVIEW_REQUIRED"
    case["deferred_reason_code"] = "EXACT_FIELD_FACT_TRACE_REQUIRED"
    case["deferred_reason_detail"] = "Input/Expected/PASS 값의 정확한 Source Fact Fragment 연결이 필요합니다."
    case["required_resolution"] = "해당 값의 정확한 Source Fact Fragment를 연결하거나, 연결 전까지 Review 상태로 유지합니다."
    return {
        "parent_srs_id": str(req.get("srs_id") or case.get("parent_srs_id") or ""),
        "review_type": "EXACT_FIELD_FACT_TRACE_REQUIRED",
        "signal": _norm(case.get("output_variable") or case.get("input_variable")),
        "value": " / ".join(required),
        "meaning": _norm(case.get("evaluation_name")),
        "role": "Traceability",
        "reason": "사람용 TC에 채워진 Input/Expected/PASS 값 중 일부가 정확한 Source Fact Fragment와 연결되지 않았습니다.",
        "required_resolution": "해당 값의 정확한 Source Fact Fragment를 연결하거나, 연결 전까지 실행 가능 TC가 아닌 Review 상태로 유지합니다.",
    }



def _source_identifier_tokens(req: dict[str, Any]) -> set[str]:
    source=_source_text(req)+"\n"+_core_requirement_text(req)
    return set(re.findall(r"\b[A-Za-z][A-Za-z0-9_]{2,}\b",source))


def _standalone_source_token(req: dict[str, Any], token: str) -> bool:
    token=str(token or "").strip()
    if not token:
        return True
    source=_source_text(req)+"\n"+_core_requirement_text(req)
    if re.fullmatch(r"0x[0-9A-Fa-f]+|\d+(?:\.\d+)?(?:ms|s|초)?",token,re.I):
        return bool(re.search(rf"(?<![A-Za-z0-9_]){re.escape(token)}(?![A-Za-z0-9_])",source,re.I))
    if re.fullmatch(r"ON|OFF|HIGH|LOW",token,re.I):
        return bool(re.search(rf"\b{re.escape(token)}\b",source,re.I))
    return token in source


def _semantic_integrity_review(req: dict[str, Any], case: dict[str, Any]) -> dict[str, Any] | None:
    identifiers=_source_identifier_tokens(req)
    invalid=[]
    for field in ("input_variable","output_variable"):
        val=_norm(case.get(field))
        # Format/Resolution are fixed artifact attribute labels, not ECU signals.
        is_artifact_property=(case.get('basic_case_kind')=='OUTPUT_ARTIFACT_PROPERTIES'
                              and field=='output_variable' and val in {'Format','Resolution'})
        if not is_artifact_property and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{2,}",val) and val not in identifiers:
            invalid.append(f"{field}:{val}")
    for field in ("input_value","output_value"):
        raw=_text(case.get(field))
        if re.fullmatch(r"ON|OFF|HIGH|LOW",raw,re.I) and not _standalone_source_token(req,raw):
            invalid.append(f"{field}:{raw}")
    for n,v in enumerate(_list(case.get("test_vectors")),1):
        if not isinstance(v,dict):
            continue
        im=_semantic_label(str(v.get("input_meaning") or ""))
        om=_semantic_label(str(v.get("output_meaning") or ""))
        if im in {"front","rear","left","right","top"}:
            if om != im:
                invalid.append(f"test_vector[{n}]:{im}->{om or 'UNKNOWN'}")
            if om in {"invalid","error"}:
                invalid.append(f"test_vector[{n}]:normal-request-to-{om}")
    if not invalid:
        case["semantic_integrity_status"]="PASS"
        return None
    case["semantic_integrity_status"]="REVIEW_REQUIRED"
    case["human_review_required"]=True
    case["execution_readiness"]="REVIEW_REQUIRED"
    case["deferred_reason_code"]="GENERATED_SEMANTIC_INTEGRITY_REQUIRED"
    case["deferred_reason_detail"]="생성된 Identifier/Enum/요청-응답 의미 매핑이 Source literal과 일치하는지 확인이 필요합니다."
    case["required_resolution"]="Source의 정확한 Identifier와 Enum mapping을 다시 연결한 뒤 TC를 재생성해야 합니다."
    return {"parent_srs_id":str(req.get("srs_id") or case.get("parent_srs_id") or ""),"review_type":"GENERATED_SEMANTIC_INTEGRITY_REQUIRED","signal":_norm(case.get("output_variable") or case.get("input_variable")),"value":" / ".join(invalid),"meaning":_norm(case.get("evaluation_name")),"role":"Semantic Integrity","reason":"생성된 TC의 Identifier/Enum 또는 요청-응답 의미 매핑이 Source literal과 불일치할 가능성이 있습니다.","required_resolution":"Source literal과 exact enum mapping을 기준으로 재생성하고 일치 전에는 실행 가능 TC로 사용하지 않습니다."}


def _expand_chained_timing_precondition(previous_clause: str, current_trigger: str) -> str:
    prev=_norm(previous_clause); cur=_norm(current_trigger)
    if not prev or not cur:
        return cur
    vm=re.search(r"(?P<value>0x[0-9A-Fa-f]+)\s*(?:이|가)?\s*수신\s*후",cur,re.I)
    if not vm:
        return cur
    value=vm.group("value")
    tm=re.search(r"(?P<time>\d+(?:\.\d+)?\s*(?:초|ms|s))\s*이내",prev,re.I)
    sig=None
    if tm:
        tail=prev[tm.end():]
        sm=re.search(r"([A-Za-z][A-Za-z0-9_]{2,})(?![A-Za-z0-9_])",tail)
        sig=sm.group(1) if sm else None
    action=_norm(prev[:tm.start()]).strip(" ,.;") if tm else ""
    if sig and tm:
        pieces=[]
        if action: pieces.append(action)
        pieces.append(f"{tm.group('time')} 이내 {sig}={value} 수신 완료")
        return " 후 ".join(pieces)
    return cur


def _condition_from_prefix(prefix: str) -> str:
    p=_norm(prefix)
    if not p:
        return ""
    p=re.sub(r"^(?:HU|ECU|시스템)(?:은|는|이|가)?\s*", "", p, flags=re.I)
    p=re.sub(r"^(?:하고|그리고|또는)\s*", "", p, flags=re.I)
    # Keep the Source wording but trim obvious actor/action scaffolding.
    m=re.search(r"(.{2,100}?)(?:완료\s*후|이후|인\s*경우|일\s*경우|수신(?:하면|\s*시)|때|시)\s*$", p)
    return _norm(m.group(0) if m else p[-100:])


def _extract_signal_assignments(text: str) -> list[dict[str, str]]:
    """Extract literal signal/value output assignments with nearby Source conditions."""
    raw=_norm(text)
    if not raw:
        return []
    pat=re.compile(
        r"(?P<prefix>[^.;]{0,150}?)"
        r"(?:신호\s*\()?\s*(?P<signal>[A-Za-z][A-Za-z0-9_]{2,})\)?"
        r"(?:\s*(?:를|을)\s*|\s*[=:]\s*|\s+)"
        r"(?P<value>0x[0-9A-Fa-f]+|ON|OFF|On|Off|HIGH|LOW)"
        r"(?:\s*\((?P<meaning>[^)]{1,80})\))?\s*(?:로|으로)?\s*"
        r"(?P<verb>송출|송신|전송|출력|제어|설정)", re.I,
    )
    out=[]
    for m in pat.finditer(raw):
        out.append({
            "prefix": _norm(m.group("prefix")), "signal": m.group("signal"),
            "value": m.group("value"), "meaning": _norm(m.group("meaning")), "verb": m.group("verb"),
        })
    return out


def _input_label_from_condition(prefix: str) -> str:
    p=_norm(prefix)
    # Prefer explicit Command/request phrase when available.
    for pat in (
        r"([^,.;]{2,48}?(?:Command|CMD|요청))\s*(?:을|를)?\s*수신",
        r"([^,.;]{2,48}?차종)인\s*경우",
    ):
        m=re.search(pat,p,re.I)
        if m:
            label=_norm(m.group(1))
            label=re.sub(r"^(?:HU|ECU|시스템)(?:은|는|이|가)?\s*", "", label, flags=re.I)
            label=re.sub(r"^(?:하고|그리고|또는)\s*", "", label, flags=re.I)
            label=re.sub(r"^(?:실시간\s*감시모드\s*)", "실시간 감시모드 ", label)
            return label.strip()
    return ""


def _direct_signal_output_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]], int]:
    cases=[]; idx=start_index
    for rec in _fact_records(req):
        if rec["fid"] and rec["fid"] in occupied_fids:
            continue
        assigns=_extract_signal_assignments(rec["text"])
        if not assigns:
            continue
        by_signal: dict[str,list[dict[str,str]]] = defaultdict(list)
        for a in assigns:
            by_signal[a["signal"]].append(a)
        for signal,items in by_signal.items():
            value_fids=[rec["fid"]] if rec["fid"] else _fact_ids_for_value(req,signal,*[x["value"] for x in items])
            context_fids=[]
            for x in items:
                context_fids.extend(_related_context_fids(req,x["prefix"]))
            fid=list(dict.fromkeys(context_fids+value_fids))
            vectors=[]
            for n,a in enumerate(items,1):
                vectors.append({
                    "step": n,
                    "input_variable": _input_label_from_condition(a["prefix"]),
                    "input_value": _input_label_from_condition(a["prefix"]),
                    "output_variable": signal,
                    "expected_output": a["value"],
                    "output_meaning": a["meaning"],
                    "source_fact_fragment_ids": fid,
                })
            title=f"{signal} 출력 확인"
            obj=f"Source 조건에 따라 {signal}의 출력 값이 정의와 일치하는지 확인한다."
            case=_base_case(base,req,idx,kind="DIRECT_SIGNAL_OUTPUT",title=title,objective=obj,fids=fid)
            conditions=[_condition_from_prefix(a["prefix"]) for a in items if _condition_from_prefix(a["prefix"])]
            in_labels=[_input_label_from_condition(a["prefix"]) for a in items if _input_label_from_condition(a["prefix"])]
            input_var="조건 / Command" if in_labels else ""
            input_val="\n".join(dict.fromkeys(in_labels))
            output_val="\n".join(f"{n}) {a['value']}"+(f" · {a['meaning']}" if a['meaning'] else "") for n,a in enumerate(items,1))
            if len(items)==1:
                output_val=items[0]["value"]+(f" · {items[0]['meaning']}" if items[0]["meaning"] else "")
            passc=(f"Source 조건에서 {signal}={items[0]['value']}이면 PASS" if len(items)==1 else f"각 조건에서 {signal}의 출력 값이 Source 정의와 모두 일치하면 PASS")
            _set_structured_case_fields(
                case, objective=obj, precondition="\n".join(dict.fromkeys(conditions)),
                input_variable=input_var, input_compare="조건별" if input_val else "", input_value=input_val,
                execution=f"Source에 정의된 조건을 적용하고 {signal}을 관찰한다.",
                output_variable=signal, output_compare="조건별" if len(items)>1 else "=", output_value=output_val,
                expected_state="\n".join(x["meaning"] for x in items if x["meaning"]), pass_criterion=passc,
                field_fids={"precondition":context_fids,"input_value":fid if input_val else [],"output_value":value_fids or fid,"pass_criterion":fid},
            )
            case["test_vectors"]=vectors
            case["split_decision"]="KEEP_AS_VECTOR" if len(items)>1 else "KEEP_SINGLE_OBJECTIVE"
            cases.append(case); idx+=1
    return cases,idx


def _variant_state_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]], int]:
    cases=[]; idx=start_index
    pat=re.compile(r"(?P<variants>(?:HEV|PHEV|EV|ICE)(?:\s*/\s*(?:HEV|PHEV|EV|ICE)){1,4})\s*차종인\s*경우.*?\b(?P<state>[A-Za-z][A-Za-z0-9_]{1,})\s*(?P<value>On|Off|ON|OFF)\b",re.I)
    for rec in _fact_records(req):
        if rec["fid"] and rec["fid"] in occupied_fids:
            continue
        m=pat.search(rec["text"])
        if not m:
            continue
        fid=[rec["fid"]] if rec["fid"] else _fact_ids_for_value(req,m.group("variants"),m.group("state"),m.group("value"))
        obj=f"{m.group('variants')} 차종에서 {m.group('state')} 상태가 Source 정의와 일치하는지 확인한다."
        case=_base_case(base,req,idx,kind="VARIANT_EXPECTED_STATE",title=f"{m.group('state')} Variant 상태 확인",objective=obj,fids=fid)
        _set_structured_case_fields(
            case, objective=obj, precondition=f"차종 = {m.group('variants')}",
            input_variable="차종", input_compare="∈", input_value=m.group("variants"),
            execution="Source에 정의된 기능 흐름을 수행하고 Variant 전용 상태를 확인한다.",
            output_variable=m.group("state"), output_compare="=", output_value=m.group("value"),
            expected_state=f"{m.group('state')} {m.group('value')}",
            pass_criterion=f"대상 차종에서 {m.group('state')}={m.group('value')}이면 PASS",
            field_fids={"input_value":fid,"output_value":fid,"pass_criterion":fid},
        )
        case["split_decision"]="SPLIT_BY_VARIANT_OBJECTIVE"
        cases.append(case); idx+=1
    return cases,idx



def _semantic_branch_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]], int]:
    """V0.93 user-guided split of explicit semantic branches.

    Example: Mirror_MirFldOpt=0x1 Folding 가능, 0x0 Folding 불가능으로 판단한다.
    Branches are split only when Source literally carries a different semantic verdict per value.
    Large combinatorial Decision Tables remain vectorized by the separate table rule.
    """
    if not is_rule_approved("HR-TC-002"):
        return [], start_index
    cases=[]; idx=start_index
    for rec in _fact_records(req):
        fid=str(rec.get("fid") or "")
        if fid and fid in occupied_fids:
            continue
        text=rec.get("text") or ""
        if not re.search(r"(?:판단|가능|불가능|접힘|펼침)",text,re.I):
            continue
        sm=re.search(r"\b([A-Za-z][A-Za-z0-9_]{2,})\s*=\s*(0x[0-9A-Fa-f]+|\d+)",text)
        if not sm:
            continue
        signal=sm.group(1)
        # Match explicit branch values. Signal may be omitted after the first branch.
        pat=re.compile(
            rf"(?:\b{re.escape(signal)}\s*=\s*)?(?P<value>0x[0-9A-Fa-f]+|\d+)\s*(?:은|는|일\s*때|인\s*경우)?\s*"
            r"(?P<meaning>[^,.;]{0,48}?(?:불가능|가능|접힘|펼침|Active|Inactive|ON|OFF|On|Off))(?=\s*(?:,|\.|;|으로\s*판단|로\s*판단|$))",
            re.I,
        )
        branches=[]
        for m in pat.finditer(text):
            value=m.group("value").strip(); meaning=_norm(m.group("meaning"))
            if meaning and (value,meaning) not in branches:
                branches.append((value,meaning))
        if len(branches)<2:
            continue
        fids=[fid] if fid else _fact_ids_for_value(req,signal,*[x[0] for x in branches])
        # Guard against large combinatorial tables; this heuristic is for concise semantic branches.
        if len(branches)>4:
            continue
        for value,meaning in branches:
            obj=f"{signal}={value} 조건의 Engineering 의미가 '{meaning}'으로 판단되는지 확인한다."
            case=_base_case(base,req,idx,kind="SEMANTIC_BRANCH",title=f"{signal} {value} 의미 판단",objective=obj,fids=fids or None)
            _set_structured_case_fields(
                case, objective=obj,
                input_variable=signal,input_compare="=",input_value=value,
                execution=f"{signal}을 {value}로 설정/관찰하고 Source-defined 의미 판단 결과를 확인한다.",
                output_variable=f"{signal} 의미 상태",output_compare="=",output_value=meaning,
                expected_state=meaning,pass_criterion=f"{signal}={value}일 때 의미 상태가 '{meaning}'이면 PASS",
                field_fids={"input_value":fids,"output_value":fids,"pass_criterion":fids},
            )
            case["test_vectors"]=[{"step":1,"input_variable":signal,"input_value":value,"output_variable":f"{signal} 의미 상태","expected_output":meaning,"source_fact_fragment_ids":fids}]
            case["split_decision"]="SPLIT_SEMANTIC_BRANCH"
            case["guideline_rule_ids"]=["HR-TC-002"]
            cases.append(case); idx+=1
    return cases,idx


def _split_source_sentences(text: str) -> list[str]:
    raw=str(text or "").strip()
    if not raw:
        return []
    parts=re.split(r"(?<=[.!?])\s+|(?<=다\.)\s*|(?<=한다\.)\s*",raw)
    out=[]
    for p in parts:
        p=_norm(p)
        if p and p not in out:
            out.append(p)
    return out or [_norm(raw)]

def _timeout_exception_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]], int]:
    cases=[]; idx=start_index
    split_timing=is_rule_approved("GR-TC-001")
    for rec in _fact_records(req):
        if rec["fid"] and rec["fid"] in occupied_fids:
            continue
        text=rec["text"]
        clauses=_split_source_sentences(text) if split_timing else [text]
        timing_matches=list(re.finditer(r"\d+(?:\.\d+)?\s*(?:초|ms|s)\s*(?:이내|동안)?",text,re.I))
        checkpoint_count=len(timing_matches)
        # If punctuation was lost during normalization, detect each timing checkpoint by local windows.
        if split_timing:
            matches=timing_matches
            if len(matches)>1 and len(clauses)<len(matches):
                clauses=[]
                for n,m in enumerate(matches):
                    a=0 if n==0 else matches[n-1].end()
                    b=len(text) if n+1==len(matches) else matches[n+1].start()
                    clauses.append(_norm(text[a:b]))
        global_outcomes=[]
        for token in ("Retry 없음", "재시도 없음"):
            if token.lower() in text.lower():
                normalized=token
                if normalized not in global_outcomes:
                    global_outcomes.append(normalized)
        seen_clause=set()
        previous_clause=""
        for clause in clauses:
            if clause in seen_clause: continue
            seen_clause.add(clause)
            if not re.search(r"(?:미수신|수신되지|수신하지\s*못|timeout|실패)",clause,re.I):
                continue
            tm=re.search(r"(\d+(?:\.\d+)?)\s*(초|ms|s)\s*(?:이내|동안)?",clause,re.I)
            if not tm:
                continue
            time_value=f"{tm.group(1)}{tm.group(2)}"
            # Source-backed start condition immediately preceding the timing window.
            prefix=_norm(clause[:tm.start()])
            prefix=re.sub(r"^(?:그리고|또는|이후)\s*", "", prefix)
            trigger=prefix[-120:].strip(" ,.;")
            if split_timing and previous_clause:
                trigger=_expand_chained_timing_precondition(previous_clause,trigger)
            # Prefer explicit status/signal near the timed expectation.
            tail=clause[tm.end():]
            signal_m=re.search(r"([A-Za-z][A-Za-z0-9_]{2,})(?![A-Za-z0-9_])",tail)
            output_signal=signal_m.group(1) if signal_m else ("피드백 신호" if "피드백" in clause else "응답 / 상태 신호")
            expected_tokens=[]
            for token in re.findall(r"0x[0-9A-Fa-f]+|ON|OFF|On|Off",tail):
                if token not in expected_tokens: expected_tokens.append(token)
            expected_event=(" 또는 ".join(expected_tokens)+" 수신") if expected_tokens else "Source-defined 응답 수신"
            outcomes=[]; seen_out=set()
            for token in ("미응답", "실패 판단", "촬영 중단", "촬영을 중단", "Retry 없음", "재시도 없음"):
                hit=(token=="실패 판단" and re.search(r"실패.*판단",clause)) or token.lower() in clause.lower()
                if hit:
                    normalized=token.replace("촬영을 중단","촬영 중단")
                    key=normalized.lower()
                    if key not in seen_out: seen_out.add(key); outcomes.append(normalized)
            for token in global_outcomes:
                if token not in outcomes:
                    outcomes.append(token)
            if not outcomes:
                # A timed negative condition still has a Source-backed fail verdict when "실패" is literal.
                if "실패" in clause: outcomes=["실패 판단"]
                else: continue
            fid=[rec["fid"]] if rec["fid"] else _fact_ids_for_value(req,time_value,*expected_tokens,*outcomes)
            expected_failure=" / ".join(dict.fromkeys(outcomes))
            obj=(f"{trigger+' 후 ' if trigger else ''}{time_value} timing checkpoint에서 {output_signal}의 "
                 f"Source-defined 응답/실패 판정을 확인한다.")
            case_kind="TIMING_CHECKPOINT_EXCEPTION" if checkpoint_count>1 else "TIMEOUT_EXCEPTION"
            case=_base_case(base,req,idx,kind=case_kind,title=f"{time_value} Timing / 실패 판정",objective=obj,fids=fid)
            _set_structured_case_fields(
                case, objective=obj, precondition=trigger,
                input_variable="관찰 시간", input_compare="이내", input_value=time_value,
                execution=f"{trigger+' 후 ' if trigger else ''}{time_value} 동안 {output_signal} 응답을 관찰한다.",
                output_variable=output_signal, output_compare="시간 내 응답 / 미응답 판정", output_value=expected_event,
                expected_state=f"정상: {expected_event}; 미충족 시: {expected_failure}",
                pass_criterion=f"{time_value} timing 조건의 Source-defined 응답 또는 실패 판정이 일치하면 PASS",
                field_fids={"precondition":fid if trigger else [],"input_value":fid,"output_value":fid,"pass_criterion":fid},
            )
            use_distinct_timing = bool(split_timing and checkpoint_count > 1)
            case["split_decision"]="SPLIT_DISTINCT_TIMING_CHECKPOINT" if use_distinct_timing else "SPLIT_EXCEPTION_PATH"
            case["guideline_rule_ids"]=["GR-TC-001"] if use_distinct_timing else []
            case["test_vectors"]=[{"step":1,"input_variable":"관찰 시간","input_value":time_value,"output_variable":output_signal,"expected_output":expected_event,"expected_state":expected_failure,"source_fact_fragment_ids":fid}]
            cases.append(case); idx+=1
            previous_clause=clause
    return cases,idx

def _looks_like_actual_decision_table(header: list[str], rows: list[list[str]], result_idx: int) -> bool:
    """V0.111: prevent enumeration dictionaries and signal catalogs from becoming TCs.

    A valid decision table has distinct condition columns and compact result
    cells; a signal definition table lists direction, bus, signal, and long enum
    descriptions, not separately executable input->result vectors.
    """
    if len(header) < 3 or len(rows) < 2 or result_idx < 1:
        return False
    def plain(x: str) -> str: return re.sub(r'\s+', ' ', str(x or '')).strip()
    meta_headers = re.compile(r'^(?:I/O|Input\s*/\s*Output|Direction|통신\s*구분|Communication|Bus|Signal(?:\s*Name)?|신호명|신호\s*정의|Description|설명|단위|Units?|Index)$', re.I)
    if sum(bool(meta_headers.fullmatch(plain(h))) for h in header) >= 2:
        return False
    if any(re.search(r'(?:CAN|LIN)\s*Communication',plain(v),re.I) for row in rows for v in row):
        return False
    if any(plain(v).lower() in {'input','output','i/o','can communication','lin communication'} for row in rows for v in row):
        return False
    # Several enum entries or very long cells indicate a data dictionary.
    if any(len(plain(v)) > 125 or len(re.findall(r'0x[0-9a-f]+\s*:',str(v),re.I)) >= 3
           for row in rows for v in row):
        return False
    input_headers = [h for j,h in enumerate(header) if j!=result_idx]
    if len(input_headers)<2 or any(not plain(h) for h in input_headers):
        return False
    # A table must have distinguishable combinations; copies of a signal's
    # enum definition with no varying input are not decision table rows.
    if len({tuple(plain(v).lower() for j,v in enumerate(row) if j!=result_idx) for row in rows}) < 2:
        return False
    return True


def _pipe_decision_table_cases(req: dict[str,Any], base: dict[str,Any], start_index: int) -> tuple[list[dict[str,Any]], int]:
    """Map literal pipe decision-table rows to independent PASS/FAIL TCs.

    Requires a traced table and at least two input columns; never invent result values.
    """
    source=_source_text(req)
    lines=[ln.strip() for ln in source.splitlines() if "|" in ln and not re.match(r"^\s*[-:| ]+$",ln)]
    if len(lines)<2:
        return [],start_index
    cases=[]; idx=start_index; i=0
    while i < len(lines)-1:
        header=[x.strip() for x in lines[i].split("|")]
        if len(header)<3:
            i+=1; continue
        result_idx=None
        for j,h in enumerate(header):
            if re.search(r"(?:동작\s*여부|상태|결과|sidemirroropen|expected|output)",h,re.I):
                result_idx=j
        if result_idx is None or result_idx==0:
            i+=1; continue
        rows=[]; j=i+1
        while j<len(lines):
            vals=[x.strip() for x in lines[j].split("|")]
            if len(vals)!=len(header): break
            rows.append(vals); j+=1
        if not rows:
            i+=1; continue
        if not _looks_like_actual_decision_table(header, rows, result_idx):
            i=j; continue
        table_text=" ".join(header + [v for row in rows for v in row])
        fids=_fact_ids_for_value(req,*header,*[v for row in rows for v in row])
        # V0.110 user-approved policy: each independently observable table row
        # becomes an individual TC instead of one TC hiding several PASS/FAILs.
        # Preserve the source's exact input/output values and original Fact IDs.
        fids=_fact_ids_for_value(req,*header,*[v for row in rows for v in row])
        input_cols=[h for n,h in enumerate(header) if n!=result_idx]
        if not fids:
            i=j;continue
        for row_number,row in enumerate(rows,1):
            input_text=" / ".join(v for k,v in enumerate(row) if k!=result_idx)
            expected=row[result_idx]
            objective=(f"{', '.join(f'{h}={v}' for h,v in zip(input_cols,[v for k,v in enumerate(row) if k!=result_idx]))} "
                       f"조건에서 {header[result_idx]} 결과를 확인한다.")
            case=_base_case(base,req,idx,kind="DECISION_TABLE",
                title=f"{header[result_idx]} - 조건 조합 {row_number:02d}",
                objective=objective,fids=fids)
            _set_structured_case_fields(case,objective=objective,
                precondition="\n".join(f"{n}) {h}={v}" for n,(h,v) in enumerate(zip(input_cols,[v for k,v in enumerate(row) if k!=result_idx]),1)),
                input_variable=" / ".join(input_cols),input_compare="조합",input_value=input_text,
                execution=f"{input_text} 조건을 적용하고 {header[result_idx]}의 상태를 관찰한다.",
                output_variable=header[result_idx],output_compare="=",output_value=expected,
                expected_state=expected,
                pass_criterion=f"{input_text} 조건에서 {header[result_idx]}={expected}이면 PASS",
                field_fids={"input_value":fids,"output_value":fids,"pass_criterion":fids},)
            case["test_vectors"]=[{"step":1,"input_variable":" / ".join(input_cols),
                "input_value":input_text,"output_variable":header[result_idx],
                "expected_output":expected,"source_fact_fragment_ids":fids}]
            case["split_decision"]="SPLIT_EACH_DECISION_TABLE_ROW"
            cases.append(case);idx+=1
        i=j
    return cases,idx


def _state_transition_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]], int]:
    cases=[]; idx=start_index
    for rec in _fact_records(req):
        if rec["fid"] and rec["fid"] in occupied_fids:
            continue
        text=rec["text"]
        if "전이" not in text and "transition" not in text.lower():
            continue
        fid=[rec["fid"]] if rec["fid"] else []
        # Negative/inhibit transition first.
        mneg=re.search(r"(?P<cond>[^.;]{2,80}?)(?:상태에서는|인\s*경우).*?(?P<target>[A-Za-z가-힣][A-Za-z가-힣0-9 _-]{1,40})\s*(?:상태로\s*)?전이.*?(?:하지\s*않|금지)",text,re.I)
        if mneg:
            cond=_norm(mneg.group("cond")); target=_norm(mneg.group("target"))
            target=re.sub(r"^(?:시스템|System|HU|ECU)(?:은|는|이|가)?\s*", "", target, flags=re.I).strip()
            obj=f"{cond} 조건에서 {target} 전이가 금지되는지 확인한다."
            case=_base_case(base,req,idx,kind="STATE_TRANSITION_INHIBIT",title=f"{target} 전이 금지 확인",objective=obj,fids=fid or None)
            case["condition_logic"]="INHIBIT"
            case["expected_target_state"]=f"NOT {target}"
            _set_structured_case_fields(case,objective=obj,precondition=cond,input_variable="System State",input_compare="=",input_value=cond,
                execution=f"{cond} 상태에서 {target} 전이 발생 여부를 관찰한다.",output_variable=f"{target} Transition",output_compare="금지",output_value="발생하지 않음",
                expected_state=f"{target} 전이 금지",pass_criterion=f"{cond} 상태에서 {target} 전이가 발생하지 않으면 PASS",
                field_fids={"input_value":fid,"output_value":fid,"pass_criterion":fid})
            case["split_decision"]="SPLIT_NEGATIVE_PATH"; cases.append(case); idx+=1; continue
        m=re.search(r"(?P<cond>[^.;]{2,120}?)(?:인\s*경우|일\s*경우|이면).*?(?P<target>[A-Za-z가-힣][A-Za-z가-힣0-9 _-]{1,40})\s*상태로\s*전이",text,re.I)
        if not m:
            continue
        cond=_norm(m.group("cond")); target=_norm(m.group("target"))
        target=re.sub(r"^(?:시스템|System|HU|ECU)(?:은|는|이|가)?\s*", "", target, flags=re.I).strip()
        logic="ANY_OF" if re.search(r"(?:또는|\bor\b)",cond,re.I) else ("ALL_OF" if re.search(r"(?:이고|그리고|\band\b)",cond,re.I) else "SINGLE")
        obj=f"{cond} 조건에서 {target} 상태 전이를 확인한다."
        case=_base_case(base,req,idx,kind="STATE_TRANSITION",title=f"{target} 상태 전이 확인",objective=obj,fids=fid or None)
        case["condition_logic"]=logic; case["expected_target_state"]=target
        _set_structured_case_fields(case,objective=obj,precondition=cond,input_variable="전이 조건",input_compare=logic,input_value=cond,
            execution="Source-defined 전이 조건을 적용하고 시스템 상태를 관찰한다.",output_variable="System State",output_compare="=",output_value=target,
            expected_state=target,pass_criterion=f"{cond}일 때 System State={target}이면 PASS",
            field_fids={"input_value":fid,"output_value":fid,"pass_criterion":fid})
        case["split_decision"]="SPLIT_BY_TARGET_STATE"; cases.append(case); idx+=1
    return cases,idx


def _blocking_source_reviews(req: dict[str, Any]) -> tuple[list[dict[str, Any]], set[str]]:
    reviews=[]; blocking_fids:set[str]=set()
    for rec in classify_source_backed_facts(req):
        if "TBD_CONFLICT" not in rec.get("roles",[]):
            continue
        fid=str(rec.get("fid") or "")
        if fid: blocking_fids.add(fid)
        text=rec.get("text") or ""
        review_type="SOURCE_TBD_REVIEW" if re.search(r"(?:tbd|미확정|확정되지)",text,re.I) else "SOURCE_CONFLICT_REVIEW"
        reviews.append({
            "parent_srs_id":str(req.get("srs_id") or ""),
            "review_type":review_type,
            "signal":"",
            "value":fid,
            "meaning":text,
            "role":"Source Governance",
            "reason":"Source에 TBD/Conflict/미확정 정보가 있어 deterministic executable TC로 확정할 수 없습니다.",
            "required_resolution":"승인된 Source/변경 결정 또는 외부 의존 근거를 연결한 뒤 해당 Fact의 TC를 재생성합니다.",
            "source_fact_fragment_ids":[fid] if fid else [],
        })
    for item in _list(req.get("tbd_items")):
        txt=_norm(item)
        if txt:
            reviews.append({"parent_srs_id":str(req.get("srs_id") or ""),"review_type":"SOURCE_TBD_REVIEW","signal":"","value":"","meaning":txt,"role":"Source Governance","reason":"Requirement에 연결된 TBD 항목이 미종결 상태입니다.","required_resolution":"TBD 항목의 최종 정의를 연결하거나 명시적 disposition을 기록합니다.","source_fact_fragment_ids":[]})
    for key in ("canonical_conflict_ids","conflict_ids","canonical_gap_ids"):
        for value in _list(req.get(key)):
            if str(value):
                reviews.append({"parent_srs_id":str(req.get("srs_id") or ""),"review_type":"SOURCE_CONFLICT_REVIEW","signal":"","value":str(value),"meaning":str(value),"role":"Source Governance","reason":"Requirement에 Open Conflict/Gap 참조가 존재합니다.","required_resolution":"Open Conflict/Gap의 authoritative decision을 연결한 뒤 affected TC를 재생성합니다.","source_fact_fragment_ids":[]})
    return reviews,blocking_fids


def _review_only_case(base: dict[str,Any], req: dict[str,Any], idx: int, reason: str) -> dict[str,Any]:
    case=dict(base)
    sid=str(base.get("parent_srs_id") or req.get("srs_id") or "SRS")
    case["evaluation_objective_id"]=f"EVAL_{re.sub(r'[^A-Za-z0-9_]+','_',sid).strip('_')}_REVIEW{idx:02d}"
    case["basic_functional_tc_id"]=""
    case["test_design_mode"]="BASIC_FUNCTIONAL_REVIEW"
    case["basic_case_kind"]="SOURCE_CONFLICT_TBD_REVIEW"
    case["evaluation_name"]="Source 미확정 / Conflict 검토"
    case["test_objective"]="Source 미확정 또는 Conflict 해소 후 실행 가능한 TC를 재생성한다."
    case["precondition"]=""
    case["test_environment"]=""
    case["input_variable"]=""; case["input_compare"]=""; case["input_value"]=""
    case["test_execution"]=""
    case["output_variable"]=""; case["output_compare"]=""; case["output_value"]=""
    case["expected_state"]=""
    case["pass_criterion"]=""
    case["human_review_required"]=True
    case["execution_readiness"]="REVIEW_REQUIRED"
    case["deferred_reason_code"]="SOURCE_CONFLICT_TBD_REVIEW"
    case["deferred_reason_detail"]=reason
    case["required_resolution"]="Authoritative Source decision을 연결한 뒤 재생성합니다."
    case["split_decision"]="REVIEW"
    case["field_fact_trace"]={}
    case["exact_field_trace_status"]="NOT_APPLICABLE"
    case["test_vectors"]=[]
    return case


def _base_case(base: dict[str,Any], req: dict[str,Any], idx: int, *, kind: str, title: str, objective: str, fids: list[str] | None = None) -> dict[str,Any]:
    case=dict(base)
    sid=str(base.get("parent_srs_id") or req.get("srs_id") or "SRS")
    case["evaluation_objective_id"] = f"EVAL_{re.sub(r'[^A-Za-z0-9_]+','_',sid).strip('_')}_BF{idx:02d}"
    case["basic_functional_tc_id"] = f"E2E_TC_{sid}_{idx:02d}"
    case["test_design_mode"] = BASIC_FUNCTIONAL_MODE
    case["basic_case_kind"] = kind
    case["evaluation_name"] = title
    case["verification_objective"] = objective
    case["test_intent"] = objective
    if fids is not None:
        case["source_fact_fragment_ids"] = list(dict.fromkeys(x for x in fids if x))
        sems,locs=_source_trace_for_fids(req, case["source_fact_fragment_ids"])
        if sems: case["source_semantic_unit_ids"] = sems
        if locs: case["source_locations"] = locs
    case.setdefault("test_vectors", [])
    case.setdefault("field_fact_trace", {})
    case.setdefault("test_objective", _norm(objective or title))
    case.setdefault("precondition", "")
    case.setdefault("test_environment", "")
    case.setdefault("expected_state", "")
    case.setdefault("pass_criterion", "")
    case.setdefault("split_decision", "KEEP_SINGLE_OBJECTIVE")
    case.setdefault("exact_field_trace_status", "NOT_EVALUATED")
    return case


def _enum_cases(req: dict[str,Any], base: dict[str,Any], start_index: int) -> tuple[list[dict[str,Any]], list[dict[str,Any]], int]:
    source=_source_text(req)
    blocks=_extract_signal_enum_blocks(source)
    if len(blocks)<2:
        return [],[],start_index
    grouped: dict[str,dict[str,tuple[str,list[dict[str,str]]]]] = defaultdict(dict)
    for name,pairs in blocks.items():
        stem,role=_signal_role(name)
        if role in {"request","response"}:
            grouped[stem.lower()][role]=(name,pairs)
    cases=[]; reviews=[]; idx=start_index
    seq=_sequence_labels(source)
    for stem,roles in grouped.items():
        if "request" not in roles or "response" not in roles:
            continue
        in_name,in_pairs=roles["request"]; out_name,out_pairs=roles["response"]
        core_text=_core_requirement_text(req).lower()
        if in_name.lower() not in core_text and out_name.lower() not in core_text:
            continue
        in_by_label={_semantic_label(p["meaning"]):p for p in in_pairs if _semantic_label(p["meaning"])}
        out_by_label={_semantic_label(p["meaning"]):p for p in out_pairs if _semantic_label(p["meaning"])}
        used:set[str]=set()
        if len(seq)>=2:
            missing=[lbl for lbl in seq if lbl not in in_by_label or lbl not in out_by_label]
            if missing:
                reviews.append({"parent_srs_id":str(req.get("srs_id") or base.get("parent_srs_id") or ""),"review_type":"ENUM_MAPPING_INTEGRITY_REQUIRED","signal":f"{in_name} / {out_name}","value":" / ".join(missing),"meaning":"명시된 순차 요청/응답 mapping의 Source semantic label이 완전하게 복원되지 않았습니다.","role":"Semantic Mapping","reason":"정상 요청을 Invalid/Error 응답과 연결하지 않도록 exact enum mapping 확인이 필요합니다.","required_resolution":"Source enum 표에서 요청/응답 값을 label별로 다시 연결하고 누락/충돌이 없을 때만 순차 TC를 생성합니다."})
        if len(seq)>=2 and all(lbl in in_by_label and lbl in out_by_label for lbl in seq):
            vectors=[]
            for order,lbl in enumerate(seq,1):
                ip=in_by_label[lbl]; op=out_by_label[lbl]
                vfids=_fact_ids_for_value(req,in_name,ip["value"],out_name,op["value"],lbl)
                vectors.append({"step":order,"input_variable":in_name,"input_value":ip["value"],"input_meaning":ip["meaning"],"output_variable":out_name,"expected_output":op["value"],"output_meaning":op["meaning"],"source_fact_fragment_ids":vfids})
                used.add(lbl)
            fids=_fact_ids_matching(req,[in_name,out_name]+seq)
            case=_base_case(base,req,idx,kind="SEQUENCE_REQUEST_RESPONSE",title="순차 요청 / 응답 확인",objective=f"{in_name} 요청 순서와 {out_name} 응답의 단계별 대응을 확인한다.",fids=fids)
            case.update({
                "test_preparation":"요청/응답 Signal을 관찰할 수 있는 평가 환경을 준비한다.",
                "prep_variable":"","prep_compare":"","prep_value":"",
                "test_execution":"Source에 정의된 순서로 요청 값을 적용하고 각 단계의 응답 값을 관찰한다.",
                "input_variable":in_name,"input_compare":"순차 입력",
                "input_value":"\n".join(f"{v['step']}) {v['input_value']}" for v in vectors),
                "expected_result":"각 요청 단계에서 Source에 정의된 대응 응답이 동일 순서로 확인되어야 한다.",
                "output_variable":out_name,"output_compare":"순차 일치",
                "output_value":"\n".join(f"{v['step']}) {v['expected_output']} · {v['output_meaning']}" for v in vectors),
                "test_vectors":vectors,
            })
            in_fids=_fact_ids_for_value(req,in_name,*[v["input_value"] for v in vectors])
            out_fids=_fact_ids_for_value(req,out_name,*[v["expected_output"] for v in vectors])
            _set_structured_case_fields(
                case, objective=f"{in_name} 요청 순서와 {out_name} 응답의 단계별 대응을 확인한다.",
                environment="요청/응답 Signal을 관찰할 수 있는 평가 환경",
                input_variable=in_name,input_compare="순차 입력",input_value=case["input_value"],
                execution=case["test_execution"], output_variable=out_name,output_compare="순차 일치",output_value=case["output_value"],
                expected_state="Source-defined 요청/응답 순서 일치",
                pass_criterion="모든 단계의 요청 값과 응답 값 및 순서가 Source 정의와 일치하면 PASS",
                field_fids={"input_value":in_fids or fids,"output_value":out_fids or fids,"pass_criterion":list(dict.fromkeys((in_fids or [])+(out_fids or [])+fids))},
            )
            case["split_decision"]="KEEP_AS_SEQUENCE"
            cases.append(case); idx+=1
        # Common functional mappings outside the explicit sequence (e.g. Top View) remain separate.
        for lbl in ("front","rear","left","right","top"):
            if lbl in used or lbl not in in_by_label or lbl not in out_by_label:
                continue
            ip=in_by_label[lbl]; op=out_by_label[lbl]
            fids=_fact_ids_matching(req,[in_name,out_name,lbl])
            case=_base_case(base,req,idx,kind="ENUM_REQUEST_RESPONSE",title=f"{lbl.title()} 요청 / 응답 확인",objective=f"{in_name}의 {ip['value']} 요청에 대해 {out_name}의 Source-defined 응답을 확인한다.",fids=fids)
            case.update({
                "test_preparation":"요청/응답 Signal을 관찰할 수 있는 평가 환경을 준비한다.",
                "test_execution":f"{in_name}에 Source-defined 요청 값을 적용한다.",
                "input_variable":in_name,"input_compare":"=","input_value":ip["value"],
                "expected_result":f"{out_name}에서 Source-defined 대응 값이 확인되어야 한다.",
                "output_variable":out_name,"output_compare":"=","output_value":op["value"],
                "test_vectors":[{"step":1,"input_variable":in_name,"input_value":ip["value"],"input_meaning":ip["meaning"],"output_variable":out_name,"expected_output":op["value"],"output_meaning":op["meaning"]}],
            })
            in_fids=_fact_ids_for_value(req,in_name,ip["value"],lbl)
            out_fids=_fact_ids_for_value(req,out_name,op["value"],lbl)
            _set_structured_case_fields(
                case, objective=f"{in_name}={ip['value']} 요청에 대해 {out_name}={op['value']} 응답을 확인한다.",
                environment="요청/응답 Signal을 관찰할 수 있는 평가 환경",
                input_variable=in_name,input_compare="=",input_value=ip["value"],execution=case["test_execution"],
                output_variable=out_name,output_compare="=",output_value=op["value"],expected_state=op["meaning"],
                pass_criterion=f"{in_name}={ip['value']} 요청에 {out_name}={op['value']}가 확인되면 PASS",
                field_fids={"input_value":in_fids or fids,"output_value":out_fids or fids,"pass_criterion":list(dict.fromkeys((in_fids or [])+(out_fids or [])+fids))},
            )
            case["split_decision"]="SPLIT_INDEPENDENT_MAPPING"
            cases.append(case); idx+=1
        # Invalid/error values without Source-defined reaction are review items, not executable PASS/FAIL cases.
        for name,pairs,role in ((in_name,in_pairs,"입력"),(out_name,out_pairs,"출력")):
            for p in pairs:
                lbl=_semantic_label(p["meaning"])
                if lbl not in {"invalid","error"}:
                    continue
                reviews.append({
                    "parent_srs_id":str(req.get("srs_id") or base.get("parent_srs_id") or ""),
                    "review_type":"SOURCE_DEFINED_VALUE_WITHOUT_EXPECTED_BEHAVIOR",
                    "signal":name,"value":p["value"],"meaning":p["meaning"],"role":role,
                    "reason":f"{name}={p['value']} ({p['meaning']}) 값은 Source에 정의되어 있으나 이 값에 대한 HU/ECU의 기대 처리 결과가 현재 Source에서 확인되지 않습니다.",
                    "required_resolution":"기대 동작이 정의된 Source 절/외부 사양을 연결하거나 사람 검토 후 Deferred/시험 케이스 여부를 결정합니다.",
                })
    return cases,reviews,idx


def _conditional_cases(req: dict[str,Any], base: dict[str,Any], start_index: int, occupied_fids: set[str]) -> tuple[list[dict[str,Any]],int]:
    cases=[]; idx=start_index
    for rec in _fact_records(req):
        if rec["fid"] and rec["fid"] in occupied_fids:
            continue
        parsed=_parse_conditional_io(rec["text"])
        if not parsed:
            continue
        case=_base_case(base,req,idx,kind="CONDITIONAL_INPUT_OUTPUT",title="조건별 입력 / 출력 확인",objective=rec["text"],fids=[rec["fid"]] if rec["fid"] else None)
        case.update({
            "test_preparation":"해당 입력 조건을 설정하고 출력 값을 관찰할 수 있는 환경을 준비한다.",
            "test_execution":f"{parsed['input_variable']} 조건을 Source-defined 값으로 적용한다.",
            "input_variable":parsed["input_variable"],"input_compare":parsed["input_compare"],"input_value":parsed["input_value"],
            "expected_result":rec["text"],
            "output_variable":parsed["output_variable"],"output_compare":parsed["output_compare"],"output_value":parsed["output_value"],
            "test_vectors":[{"step":1,**parsed}],
        })
        fids=[rec["fid"]] if rec["fid"] else _fact_ids_for_value(req,parsed["input_variable"],parsed["input_value"],parsed["output_variable"],parsed["output_value"])
        _set_structured_case_fields(
            case, objective=f"{parsed['input_variable']}={parsed['input_value']} 조건에서 {parsed['output_variable']}={parsed['output_value']} 출력 관계를 확인한다.",
            environment="입력 조건 설정 및 출력 관찰 가능 환경",
            input_variable=parsed["input_variable"],input_compare=parsed["input_compare"],input_value=parsed["input_value"],
            execution=case["test_execution"], output_variable=parsed["output_variable"],output_compare=parsed["output_compare"],output_value=parsed["output_value"],
            expected_state=rec["text"], pass_criterion=f"{parsed['input_variable']}={parsed['input_value']}일 때 {parsed['output_variable']}={parsed['output_value']}이면 PASS",
            field_fids={"input_value":fids,"output_value":fids,"pass_criterion":fids},
        )
        case["split_decision"]="SPLIT_INDEPENDENT_CONDITION"
        cases.append(case); idx+=1
    return cases,idx


def _dimension_case(req: dict[str,Any], base: dict[str,Any], start_index: int) -> tuple[list[dict[str,Any]],int]:
    core=_core_requirement_text(req)
    if not re.search(r"resiz|리사이즈|해상도|crop|변환",core,re.I):
        return [],start_index
    source=core + "\n" + _source_text(req)
    iv=ov=""; in_fids=[]; out_fids=[]
    # First preference: literal relation in one Source-backed sentence.
    m=re.search(r"(\d+\s*[x×*]\s*\d+)\s*(?:을|를)?\s*(\d+\s*[x×*]\s*\d+)\s*(?:으로|로)?\s*(?:resiz(?:e|ing)|리사이즈|변환)",source,re.I)
    if m:
        iv=re.sub(r"\s+","",m.group(1)).replace("*","×").replace("x","×")
        ov=re.sub(r"\s+","",m.group(2)).replace("*","×").replace("x","×")
        in_fids=_fact_ids_for_value(req,m.group(1),iv)
        out_fids=_fact_ids_for_value(req,m.group(2),ov,"resiz")
    else:
        # V0.92 also supports a relation spread over two exact fragments within one Canonical SRS:
        # an explicit input dimension fact + an explicit resize/output dimension fact.
        in_rec=None; out_rec=None; in_dim=out_dim=""
        for rec in _fact_records(req):
            mi=re.search(r"(?:입력|원본|input)[^\d]{0,40}(\d+\s*[x×*]\s*\d+)",rec["text"],re.I)
            if mi and in_rec is None:
                in_rec=rec; in_dim=mi.group(1)
            mo=re.search(r"(\d+\s*[x×*]\s*\d+)[^.;]{0,40}(?:resiz(?:e|ing)|리사이즈|변환|조정)",rec["text"],re.I)
            if not mo:
                mo=re.search(r"(?:resiz(?:e|ing)|리사이즈|변환|조정)[^\d]{0,40}(\d+\s*[x×*]\s*\d+)",rec["text"],re.I)
            if mo and out_rec is None:
                out_rec=rec; out_dim=mo.group(1)
        if in_rec and out_rec:
            iv=re.sub(r"\s+","",in_dim).replace("*","×").replace("x","×")
            ov=re.sub(r"\s+","",out_dim).replace("*","×").replace("x","×")
            in_fids=[in_rec["fid"]] if in_rec.get("fid") else []
            out_fids=[out_rec["fid"]] if out_rec.get("fid") else []
    if not iv or not ov:
        return [],start_index
    fids=list(dict.fromkeys(in_fids+out_fids)) or _fact_ids_matching(req,[iv,ov,"resiz"])
    case=_base_case(base,req,start_index,kind="DIMENSION_TRANSFORM",title="영상 크기 변환 확인",objective=f"Source-defined 영상 크기 변환 {iv} → {ov}를 확인한다.",fids=fids or None)
    case.update({
        "test_preparation":"Source-defined 입력 해상도의 영상을 준비한다.",
        "test_execution":"Source에 정의된 Resize 처리를 수행한다.",
        "input_variable":"입력 영상 해상도","input_compare":"=","input_value":iv,
        "expected_result":"Resize 결과가 Source-defined 출력 해상도와 일치해야 한다.",
        "output_variable":"출력 영상 해상도","output_compare":"=","output_value":ov,
        "test_vectors":[{"step":1,"input_variable":"입력 영상 해상도","input_value":iv,"output_variable":"출력 영상 해상도","expected_output":ov,"source_fact_fragment_ids":fids}],
    })
    _set_structured_case_fields(
        case, objective=f"입력 영상 {iv}가 Source-defined 처리 후 {ov}로 변환되는지 확인한다.",
        environment="입력/출력 영상 해상도 확인 가능 환경",
        input_variable="입력 영상 해상도",input_compare="=",input_value=iv,execution=case["test_execution"],
        output_variable="출력 영상 해상도",output_compare="=",output_value=ov,expected_state=f"Resize 결과 {ov}",
        pass_criterion=f"{iv} 입력이 {ov}로 변환되면 PASS",
        field_fids={"input_value":in_fids or fids,"output_value":out_fids or fids,"pass_criterion":fids},
    )
    case["split_decision"]="SPLIT_TRANSFORM_OBJECTIVE"
    return [case],start_index+1


def _artifact_property_case(req: dict[str,Any], base: dict[str,Any], start_index: int) -> tuple[list[dict[str,Any]],int]:
    """Build Source-backed artifact-property cases with exact per-property provenance.

    V0.92 keeps closely related Format+Resolution in one objective when both are explicit, while
    numeric Size constraints become a separate criterion so a missing fragment cannot hide behind
    another property fragment.
    """
    core=_core_requirement_text(req)
    if not re.search(r"format|resolution|size|jpeg|저장|해상도|크기",core,re.I):
        return [],start_index
    source=core + "\n" + _source_text(req)
    props=[]
    # Accept both key:value and natural Korean/English forms.
    m=re.search(r"\bFormat\s*[:：]\s*([A-Za-z0-9_-]+)",source,re.I) or re.search(r"\b(JPEG|PNG|BMP)\s*(?:형식|format)",source,re.I)
    if m: props.append(("Format","=",m.group(1),_fact_ids_for_value(req,m.group(1))))
    m=re.search(r"\bResolution\s*[:：]\s*(\d+\s*[x×*]\s*\d+)",source,re.I) or re.search(r"(?:해상도(?:는|가)?\s*)(\d+\s*[x×*]\s*\d+)",source,re.I)
    if m:
        val=re.sub(r"\s+","",m.group(1)).replace("*","×").replace("x","×")
        props.append(("Resolution","=",val,_fact_ids_for_value(req,m.group(1),val)))
    m=re.search(r"\bSize\s*[:：]\s*([-+]?\d+(?:\.\d+)?)\s*(MB|KB)?\s*(이하|미만|이상|초과)?",source,re.I)
    if not m:
        m=re.search(r"(?:크기(?:는|가)?\s*)([-+]?\d+(?:\.\d+)?)\s*(MB|KB)\s*(이하|미만|이상|초과)",source,re.I)
    size_prop=None
    if m:
        op={"이하":"<=","미만":"<","이상":">=","초과":">"}.get(m.group(3) or "","=")
        val=m.group(1)+(f" {m.group(2)}" if m.group(2) else "")
        size_prop=("Size",op,val,_fact_ids_for_value(req,m.group(1),val,"크기","Size"))

    cases=[]; idx=start_index
    grouped=[p for p in props if p[0] in {"Format","Resolution"}]
    # V0.112: Format and Resolution are independently observable PASS/FAIL
    # objectives. One TC/one expected mapping, not two VECTOR rows.
    for prop_name,compare,value,fids in grouped:
        title='저장 '+prop_name+' 확인'
        criterion=f'저장 산출물의 {prop_name}이 Source 정의 {compare} {value}와 일치하면 PASS'
        case=_base_case(base,req,idx,kind='OUTPUT_ARTIFACT_PROPERTIES',
                        title=title,objective=f'저장 산출물의 {prop_name} 속성을 독립적으로 검증한다.',
                        fids=fids or None)
        _set_structured_case_fields(
            case,objective=f'저장 산출물의 {prop_name} 속성을 독립적으로 검증한다.',
            environment='처리/저장된 산출물 속성 확인 가능 환경',input_variable='처리 완료 산출물',
            input_compare='',input_value='',
            execution=f'Source-defined 처리/저장 동작 후 최종 산출물의 {prop_name}을 확인한다.',
            output_variable=prop_name,output_compare=compare,output_value=value,
            expected_state=f'{prop_name} {compare} {value}',pass_criterion=criterion,
            field_fids={'input_value':[],'output_value':fids,'pass_criterion':fids},
        )
        case['test_vectors']=[{'step':1,'output_variable':prop_name,'output_compare':compare,
                              'expected_output':value,'source_fact_fragment_ids':fids}]
        case['split_decision']='SPLIT_INDEPENDENT_ARTIFACT_PROPERTY'
        cases.append(case);idx+=1
    if size_prop:
        p=size_prop; fids=p[3]
        case=_base_case(base,req,idx,kind="OUTPUT_ARTIFACT_SIZE_CONSTRAINT",title="저장 이미지 크기 제한 확인",objective=f"저장 산출물의 크기가 Source 제한 {p[1]} {p[2]}를 만족하는지 확인한다.",fids=fids or None)
        _set_structured_case_fields(
            case, objective=f"저장 산출물의 크기가 Source 제한 {p[1]} {p[2]}를 만족하는지 확인한다.",
            environment="저장 산출물 파일 크기 측정 가능 환경",input_variable="저장 산출물",input_compare="측정",input_value="",
            execution="Source-defined 처리/저장 후 파일 크기를 측정한다.",output_variable="파일 크기",output_compare=p[1],output_value=p[2],
            expected_state=f"파일 크기 {p[1]} {p[2]}",pass_criterion=f"저장 산출물 파일 크기가 {p[1]} {p[2]}이면 PASS",
            field_fids={"input_value":[],"output_value":fids,"pass_criterion":fids},
        )
        case["test_vectors"]=[{"step":1,"output_variable":"파일 크기","output_compare":p[1],"expected_output":p[2],"source_fact_fragment_ids":fids}]
        case["split_decision"]="SPLIT_NUMERIC_CONSTRAINT"
        cases.append(case); idx+=1
    return cases,idx



def _independent_semantic_objective_cases(
    req: dict[str,Any], base: dict[str,Any], idx: int, *, only_conditional: bool = False,
) -> tuple[list[dict[str,Any]],int]:
    """V0.106: source-traced, distinct intents before the generic fallback.

    Only primary SYS.5/SWE.6 objects are eligible. Native-domain assessments and
    stronger Boolean/enum rules are untouched. A shared Fact ID is not duplicated
    into invented independent source fragments.
    """
    if str(base.get('test_object_type') or '') not in {'SYS5_CANDIDATE','SWE6_TC'}:
        return [],idx
    records=_fact_records(req)
    owned={str(x) for x in _list(base.get('source_fact_fragment_ids')) if str(x)}
    records=[r for r in records if not owned or str(r.get('fid') or '') in owned]
    # In the residual pass, only source-literal condition→result paths qualify;
    # this does not turn previously handled generic goals into duplicate TCs.
    goals=[] if only_conditional else identify_independent_goals(records)
    if not goals:
        from core.semantic_objective_design import identify_conditional_path_goals
        goals=identify_conditional_path_goals(records)
    if not goals:
        return [],idx
    out=[]
    for goal in goals:
        fids=list(goal.source_fact_fragment_ids)
        c=_base_case(base,req,idx,kind='SEMANTIC_INDEPENDENT_OBJECTIVE',
                     title=goal.title,objective=goal.purpose,fids=fids)
        c['semantic_goal_kind']=goal.kind
        if goal.condition:
            c['precondition']=goal.condition  # Do not inherit the parent/other branch's trigger.
            c['semantic_condition_source']=goal.condition
        if goal.kind.startswith('GENERAL_CONDITIONAL_PATH_'):
            c['execution_basis']='ENGINEERING_PROPOSED_STEP'
            c['semantic_proposal_scope']='CONDITION_TO_RESULT_CASE_DESIGN_ONLY'
        if goal.kind=='COMMUNICATION_RESTORATION':
            # The expected recovered behavior may be Source-backed while the
            # prerequisite injection/sequence is an Engineering test-design step.
            # Keep a separate provenance marker for display; never label the
            # source outcome itself as invented.
            c['execution_basis']='ENGINEERING_PROPOSED_STEP'
        c['semantic_support_excerpt']=goal.evidence_excerpt
        c['semantic_verification_method']=goal.verification_method
        c['semantic_decision_reason']=(
            '원문에 명시된 서로 다른 조건-결과 문장을 식별하여, 각 경로의 독립 검증을 제안함. 입력 조작 방법은 미확정.'
            if goal.kind.startswith('GENERAL_CONDITIONAL_PATH_')
            else '원본 Fact에서 독립 검증 목적을 식별했고, 평가 방법 또는 독립 판정 항목이 달라 별도 TC로 구성.'
        )
        c['semantic_goal_count']=len(goals)
        c['split_decision']='SPLIT_SOURCE_TRACED_INDEPENDENT_OBJECTIVE'
        c['human_review_required']=True
        c['execution_readiness']='FINAL_REVIEW_PROPOSAL'
        c['deferred_reason_code']='SEMANTIC_OBJECTIVE_EXECUTION_MAPPING_REVIEW'
        c['deferred_reason_detail']=goal.notes
        c['required_resolution']='원본 Fact 연결 및 실제 입력/관찰 신호, 시험 방법을 최종 확인합니다.'
        _set_structured_case_fields(
            c, objective=goal.purpose, precondition=goal.condition, environment='',
            execution=goal.execution, expected_state=goal.expected,
            pass_criterion=(f'1) {goal.condition} 조건 구성\n2) {goal.expected} 상태가 관찰되면 PASS'
                if goal.kind.startswith('GENERAL_CONDITIONAL_PATH_')
                else f'{goal.expected} 상태가 관찰되면 PASS'),
            field_fids={'pass_criterion':fids,'expected_state':fids},
        )
        c['source_backed_behavior']=goal.evidence_excerpt
        c['test_preparation']=''
        c['expected_result']=goal.expected
        c['test_vectors']=[]
        c['semantic_sequence_reason']=(
            '동일 목적 내 오류 발생→복구의 순차 조건은 유지하되, 별도의 복구 결과 확인은 독립 TC로 구성.'
            if goal.kind=='COMMUNICATION_RESTORATION' else
            '원본이 명시한 수행-관찰 순서만 유지함. 서로 독립된 목적 간 선후관계는 가정하지 않음.'
        )
        out.append(c);idx+=1
    return out,idx


def _fallback_case(req: dict[str,Any], base: dict[str,Any], idx: int) -> dict[str,Any]:
    title=_norm(req.get("function_name")) or "기본 기능 확인"
    case=_base_case(base,req,idx,kind="SOURCE_BACKED_FALLBACK",title=title,objective=f"{title}의 Source-backed 기본 동작을 확인한다.")
    pre_parts=[]
    for value in _list(req.get("preconditions")):
        if _norm(value): pre_parts.append(_norm(value))
    if _norm(req.get("activation_trigger")): pre_parts.append(_norm(req.get("activation_trigger")))
    expected=_norm(req.get("output") or req.get("acceptance_criteria"))
    base_fids=[str(x) for x in _list(base.get("source_fact_fragment_ids")) if str(x)]
    passc=_norm(req.get("acceptance_criteria")) if base_fids else ""
    # Native-domain facts can share one SRS while having three distinct objectives
    # (e.g. consumption current / operating temperature / storage temperature).
    # Copying the parent's entire acceptance criterion into each child destroys
    # their semantic boundaries and creates three misleading duplicate-looking TCs.
    # Inherit *only the child's own* factual constraint; execution remains REVIEW.
    native_types={"ELECTRICAL_VERIFICATION_INTENT","ENVIRONMENTAL_VERIFICATION_INTENT",
                  "MECHANICAL_VERIFICATION_INTENT","MANUFACTURING_VERIFICATION_INTENT"}
    native_scope=str(base.get("test_object_type") or "") in native_types
    if native_scope:
        child_fact=_norm(base.get("source_backed_behavior") or base.get("verification_objective"))
        if child_fact:
            expected=child_fact
            passc=child_fact if base_fids else ""
            case["test_objective"]=f"{child_fact} 검증 범위와 시험 방법을 확인한다."
            case["evaluation_name"]=child_fact[:72]
    _set_structured_case_fields(
        case, objective=(f"{child_fact}의 검증 범위와 시험 방법을 확인한다." if native_scope and child_fact else f"{title}의 Source-backed 기본 동작을 확인한다."), precondition="\n".join(dict.fromkeys(pre_parts)),
        environment="", input_variable=_norm(base.get("variable")), input_compare=_norm(base.get("compare")), input_value=_norm(base.get("value")),
        execution=("" if native_scope else (_norm(base.get("test_execution")) or _norm(req.get("processing_action")))),
        expected_state=expected, pass_criterion=passc,
        field_fids={"input_value":base_fids if _norm(base.get("value")) else [], "pass_criterion":base_fids if passc else []},
    )
    case["test_preparation"]="\n".join(dict.fromkeys(pre_parts))
    case["expected_result"]=expected
    case["test_vectors"]=[]
    case["split_decision"]="REVIEW_FALLBACK" if case.get("human_review_required") else "KEEP_SINGLE_OBJECTIVE"
    return case


def _readable_boolean_condition(name: str, truth: bool) -> str:
    """Presentation-only condition wording. Never infer a new physical state.

    A negated WAKE-UP state does *not* prove SLEEP; a negated transition
    does not prove that the reverse transition happened. Raw terms/booleans
    and source Fact IDs are kept in boolean_condition_states for auditing.
    """
    label = re.sub(r"\s+", " ", str(name or "")).strip().rstrip(":")
    if not label:
        return "미확인 조건"
    label = re.sub(r"\s*시$", "", label).strip()
    if truth:
        return label
    if re.search(r"명령\s*수신$", label):
        return re.sub(r"수신$", "수신 안됨", label)
    if re.search(r"HIGH\s*(?:에서|→|->|to)\s*LOW.*(?:변환|전환)$", label, re.I):
        return label + "이 발생하지 않음"
    if re.search(r"최초\s*B\+\s*인가", label, re.I):
        return "최초 B+ 인가 상황이 아님"
    # For true binary on/off labels, describe the opposite value. Preserve
    # complex states (SLEEP(OFF), WAKE UP, etc.) as logical non-satisfaction.
    if re.search(r"\bOFF\s*상태$", label, re.I) and "SLEEP" not in label.upper():
        return re.sub(r"\bOFF\s*상태$", "ON 상태", label, flags=re.I)
    if re.search(r"\bON\s*상태$", label, re.I) and "SLEEP" not in label.upper():
        return re.sub(r"\bON\s*상태$", "OFF 상태", label, flags=re.I)
    if re.search(r"(?:모드|MODE|상태)$", label, re.I):
        return label + "가 아님"
    if label.endswith("수신"):
        return label + " 안됨"
    return label + " 조건 미충족"


def _cross_domain_equivalence_key(case: dict[str, Any]) -> tuple[str, ...] | None:
    """Narrow, exact, outcome-based SYS.5/SWE.6 duplicate check.

    A difference in controlled I/O, scenario, verification method, or
    observable result must never be silently merged. Only same-SRS cases
    with the same source-backed precondition, objective and pass/outcome
    are eligible. Different source Fact IDs remain attached after a merge.
    """
    if case.get("expectation_basis") == "ENGINEERING_HYPOTHESIS":
        return None
    if str(case.get("basic_case_kind") or "") not in {"SOURCE_BACKED_FALLBACK", "DIRECT_SIGNAL_OUTPUT"}:
        return None
    if not str(case.get("pass_criterion") or "").strip() or not str(case.get("expected_state") or "").strip():
        return None
    norm=lambda x: re.sub(r"[^0-9A-Za-z가-힣]+", "", _text(x)).lower()
    sid=norm(case.get("parent_srs_id"))
    direct_trace=(tuple(sorted(str(x) for x in _list(case.get('source_fact_fragment_ids')) if x))
                  if case.get('basic_case_kind')=='DIRECT_SIGNAL_OUTPUT' else ())
    return tuple([sid, str(case.get('basic_case_kind') or ''),repr(direct_trace)]+[norm(case.get(k)) for k in (
        "evaluation_name", "test_objective", "precondition", "input_variable", "input_compare", "input_value",
        "output_variable", "output_compare", "output_value", "expected_state", "pass_criterion",
    )])


def _deduplicate_cross_domain(cases: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Merge only confirmed cross-domain repeats; record exact provenance."""
    indexed: dict[tuple[str, ...], list[int]]={}
    output: list[dict[str, Any]]=[]
    removed=[]
    for case in cases:
        typ=str(case.get("test_object_type") or "")
        key=_cross_domain_equivalence_key(case) if typ in {"SWE6_TC", "SYS5_CANDIDATE"} else None
        chosen=None
        if key is not None:
            for j in indexed.get(key, []):
                target=output[j]
                types=set(target.get("merged_test_object_types") or [target.get("test_object_type")])
                if typ not in types and types | {typ} == {"SWE6_TC", "SYS5_CANDIDATE"}:
                    chosen=j; break
        if chosen is None:
            output.append(case)
            if key is not None:
                indexed.setdefault(key, []).append(len(output)-1)
            continue
        kept=output[chosen]
        # Preserve the full source, verification object, and field-level trace.
        types=list(dict.fromkeys(list(kept.get("merged_test_object_types") or [kept.get("test_object_type")])+[typ]))
        kept["merged_test_object_types"]=types
        kept["cross_domain_deduplicated"]=True
        for item_key in ("source_fact_fragment_ids", "source_semantic_unit_ids", "source_locations", "related_test_object_ids"):
            kept[item_key]=list(dict.fromkeys([str(x) for x in _list(kept.get(item_key))+_list(case.get(item_key)) if str(x)]))
        ids=[str(x) for x in (kept.get("test_object_id"),case.get("test_object_id")) if str(x)]
        kept["merged_source_object_ids"]=list(dict.fromkeys(_list(kept.get("merged_source_object_ids"))+ids))
        for f,values in (case.get("field_fact_trace") or {}).items():
            obj=kept.setdefault("field_fact_trace",{})
            obj[f]=list(dict.fromkeys([str(x) for x in _list(obj.get(f))+_list(values) if str(x)]))
        kept["human_review_required"]=bool(kept.get("human_review_required") or case.get("human_review_required"))
        removed.append({"parent_srs_id":case.get("parent_srs_id"),"kept_test_object_id":kept.get("test_object_id"),"merged_test_object_id":case.get("test_object_id"),"reason":"SWE.6/SYS.5 공통 검증 목적·조건·기대 결과·PASS 기준 일치", "source_fact_fragment_ids":list(kept.get("source_fact_fragment_ids") or [])})
    return output,removed


def _deduplicate_exact_semantic_goals(cases: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """V0.111: merge *identical traced* semantic cases, not merely similar labels.

    The SRS, observed outcome, condition, goal kind AND actual source Fact IDs
    must agree; distinct input conditions or different source evidence survive.
    """
    retained: list[dict[str, Any]] = []
    indexed: dict[tuple[str,...], int] = {}
    merged: list[dict[str, Any]] = []
    for case in cases:
        if case.get('basic_case_kind') != 'SEMANTIC_INDEPENDENT_OBJECTIVE':
            retained.append(case)
            continue
        ids = tuple(sorted(set(str(x) for x in _list(case.get('source_fact_fragment_ids')) if x)))
        if not ids:
            retained.append(case)
            continue
        norm=lambda value: re.sub(r'\s+', ' ', str(value or '')).strip().lower()
        key=(norm(case.get('parent_srs_id')), norm(case.get('semantic_goal_kind')),
             norm(case.get('semantic_condition_source')), norm(case.get('evaluation_name')),
             norm(case.get('expected_state')),norm(case.get('pass_criterion')),repr(ids))
        if key not in indexed:
            indexed[key]=len(retained);retained.append(case);continue
        current=retained[indexed[key]]
        for label in ('related_test_object_ids','merged_source_object_ids'):
            source=[case.get('test_object_id')] if label=='merged_source_object_ids' else []
            current[label]=list(dict.fromkeys([str(x) for x in _list(current.get(label))+_list(case.get(label))+source if x]))
        for label in ('source_fact_fragment_ids','source_semantic_unit_ids','source_locations'):
            current[label]=list(dict.fromkeys([str(x) for x in _list(current.get(label))+_list(case.get(label)) if x]))
        merged.append({'parent_srs_id':case.get('parent_srs_id'), 'test_object_id':case.get('test_object_id'),
                       'reason':'동일 Source Fact·조건·검증 목적·PASS로부터 중복 생성된 의미 TC 통합'})
    return retained, merged


def _explicit_boolean_transition_cases(req: dict[str,Any], base: dict[str,Any], idx: int) -> tuple[list[dict[str,Any]],int]:
    """Traced AND/OR coverage, with clearly labeled inferred negative hypotheses.

    A&B -> LowPower does NOT prove !A -> !LowPower.  We offer an assumption-based
    negative trial for final human review, never as Source-proven behavior.
    Native domains and untraced source fragments are not expanded.
    """
    if str(base.get("test_object_type") or "") not in {"SYS5_CANDIDATE", "SWE6_TC"}:
        return [],idx
    logic=str(base.get("condition_logic") or "")
    if logic not in {"ALL_OF","ANY_OF","EXACTLY_ONE_OF","ONE_OF","XOR","NONE_OF","NOR"} or not base.get("transition_family"):
        return [],idx
    target=_norm(base.get("expected_target_state"))
    texts=[_norm(x) for x in _list(base.get("condition_texts"))]
    fids=[str(x) for x in _list(base.get("condition_fragment_ids"))]
    if not target or not (2 <= len(texts) <= 8) or len(texts)!=len(fids) or not all(fids):
        return [],idx
    # Do not split a compound Source atom into synthetic conditions or duplicate names.
    if len(set(x.lower() for x in texts))!=len(texts):
        return [],idx
    # Explicit condition atoms have independent Fact IDs. For a *compound*
    # Source Fact, multiple literal clauses may share one original Fact ID;
    # never promote those clauses into imaginary independent source facts.
    records=_fact_records(req)
    owned={(r["fid"],r["text"]) for r in records}
    if str(base.get("condition_source_derivation") or "") == "COMPOSITE_SOURCE_FACT_CLAUSES":
        source_blob=_norm(req.get("requirement"))
        if any(text.lower() not in source_blob.lower() or not any(r["fid"]==fid and text.lower() in r["text"].lower() for r in records)
               for fid,text in zip(fids,texts)):
            return [],idx
    elif any((fid,text) not in owned for fid,text in zip(fids,texts)):
        return [],idx
    # Only link factual clauses to a literally stated target/criterion (not an inferred target).
    expected_blob=_norm(req.get("output"))+" "+_norm(req.get("acceptance_criteria"))+" "+_norm(req.get("requirement"))
    if target.lower() not in expected_blob.lower() and " ".join(target.lower().split()[:2]) not in expected_blob.lower():
        return [],idx
    # Preserve original Fact literals/IDs and strip only presentation-only bullets.
    pretty=[re.sub(r"^(?:[-•*]\s*)+", "", text).strip() for text in texts]
    # Explicit XOR/NOR: independent PASS/FAIL for each meaningful combination.
    if logic in {"EXACTLY_ONE_OF","ONE_OF","XOR","NONE_OF","NOR"}:
        from core.engineering_condition_combinations import independent_scenarios
        normalized="XOR" if logic in {"EXACTLY_ONE_OF","ONE_OF","XOR"} else "NOR"
        result=[]
        for item in independent_scenarios(normalized,len(texts)):
            state=item["inputs"];positive=item["expected"]
            human=[_readable_boolean_condition(t,state[j]) for j,t in enumerate(pretty)]
            readable="\n".join(f"{j+1}) {item}" for j,item in enumerate(human))
            title=f"{target} - {normalized} 조건 조합 {item['case_index']:02d}"
            outcome=target if positive else f"{target}로 전환되지 않음"
            objective=f"{normalized} 조건 조합별 {target} 상태를 확인한다."
            fids_all=list(dict.fromkeys(fids+[str(x) for x in _list(base.get('source_fact_fragment_ids')) if str(x)]))
            case=_base_case(base,req,idx,kind="BOOLEAN_CONDITION_COVERAGE",title=title,
                           objective=objective,fids=fids_all)
            case['condition_logic']=logic
            case['boolean_condition_labels']=pretty
            case['boolean_condition_human_labels']=human
            case['boolean_condition_states']=[{'source_fact_fragment_id':fid,'name':name,'expected':truth}
                for fid,name,truth in zip(fids,pretty,state)]
            case['expectation_basis']='SOURCE_EXPLICIT' if positive else 'ENGINEERING_HYPOTHESIS'
            case['split_decision']='SPLIT_INDEPENDENT_LOGIC_COMBINATION'
            if not positive:
                case['hypothesis_rule']=f'{normalized}_NEGATIVE_OUTPUT'
                case['hypothesis_assumptions']='원본에 없는 조합별 부정 동작은 가이드 기반 시험 설계 판단이다.'
                case['inference_evidence_fids']=fids_all
                case['inferred_expected_fields']=['output_value','expected_state','pass_criterion']
            _set_structured_case_fields(case,objective=objective,precondition=readable,
                input_variable='조건별 상태',input_compare='조합',input_value=readable,
                execution=f'{readable}\n각 조건을 적용하고 {target} 상태를 관찰한다.',
                output_variable='제어기 동작 상태',output_compare='=',output_value=outcome,
                expected_state=outcome,pass_criterion=f'{outcome} 상태가 관찰되면 PASS',
                field_fids={'precondition':fids,'input_value':fids,
                    'output_value':fids_all if positive else [],
                    'pass_criterion':fids_all if positive else []})
            case['test_vectors']=[{'step':1,'input_value':human,'expected_state':outcome,
                'source_fact_fragment_ids':fids_all}]
            result.append(case);idx+=1
        return result,idx
    cases=[]
    # AND: all true + each one false; OR: each one true + all false.
    # Unspecified negative response is offered as a hypothesis, never a Source assertion.
    exhaustive_pair = len(texts)==2
    # Two conditions are inexpensive to exhaust (four combinations). 3..8 use
    # bounded representative single-false/single-true coverage, not 2^N explosion.
    count=len(texts)+1+(1 if exhaustive_pair else 0)
    for n in range(count):
        if logic=="ALL_OF":
            negative=n>0
            is_all_false=exhaustive_pair and n==count-1
            focus="모든 진입 조건" if is_all_false else (pretty[n-1] if negative else "")
            state=([False]*len(texts) if is_all_false else
                   [False if negative and j==n-1 else True for j in range(len(texts))])
            decision=("모든 진입 조건 미충족" if is_all_false else
                      f"{focus} 단독 미충족" if negative else "모든 전환 조건 충족")
        else:
            is_all_true=exhaustive_pair and n==count-1
            negative=n==len(texts)
            focus="모든 진입 조건" if negative else ("모든 진입 조건" if is_all_true else pretty[n])
            state=([True]*len(texts) if is_all_true else
                   [False for _ in texts] if negative else [j==n for j in range(len(texts))])
            decision=("모든 진입 조건 충족" if is_all_true else
                      "모든 진입 조건 미충족" if negative else f"{focus} 단독 충족")
        # Readable named conditions, never Python repr(list) or position-only labels.
        labels=[f"{label}: {'참' if state[j] else '거짓'}" for j,label in enumerate(pretty)]
        human_labels=[_readable_boolean_condition(label, state[j]) for j,label in enumerate(pretty)]
        readable="\n".join(f"{j+1}) {label}" for j,label in enumerate(human_labels))
        related_fids=list(dict.fromkeys(fids+[str(x) for x in _list(base.get("source_fact_fragment_ids")) if str(x)]))
        title=f"{target} - {decision}"
        if negative and logic=="ALL_OF":
            objective=(f"모든 진입 조건이 미충족인 경우 {target}의 기대 동작을 확인한다."
                       if exhaustive_pair and n==count-1 else
                       f"{focus} 조건만 미충족이고 나머지 조건이 충족된 경우 {target}의 기대 동작을 확인한다.")
        elif negative and logic=="ANY_OF":
            objective=f"모든 진입 조건이 미충족인 경우 {target} 전환 억제 여부를 확인한다."
        elif logic=="ANY_OF":
            objective=f"{focus}: 다른 전환 조건은 미충족인 상태에서 {target} 전환 여부를 확인한다."
        else:
            objective=f"{', '.join(pretty)} 조건이 모두 충족된 경우 {target} 전환 여부를 확인한다."
        c=_base_case(base,req,idx,kind="BOOLEAN_CONDITION_COVERAGE",title=title,objective=objective,fids=related_fids)
        c["condition_logic"]=logic
        c["condition_source_derivation"]=base.get("condition_source_derivation") or "SEPARATE_SOURCE_FACTS"
        c["condition_split_diagnostic"]=base.get("condition_split_diagnostic") or ""
        c["boolean_condition_labels"]=pretty
        c["boolean_condition_human_labels"]=human_labels
        c["boolean_condition_states"]=[{"source_fact_fragment_id":fid,"name":name,"expected":truth} for fid,name,truth in zip(fids,pretty,state)]
        execution=f"{readable}\n위 조건을 구성한 뒤 제어기의 {target} 전환 여부를 관찰한다(조건별 조작 가능 여부 확인 필요)."
        if negative:
            # This is an automatically proposed *test hypothesis*, not a Source fact.
            # The original positive implication alone never proves the negative result.
            expected=f"{target}로 전환되지 않음 (시험 설계 가설)"
            if logic=="ALL_OF":
                status=("모든 진입 조건이 미충족인 상태" if exhaustive_pair and n==count-1
                        else f"{focus} 조건만 미충족이고 나머지는 충족한 상태")
                passc=(f"[시험 설계 가설] {status}에서 "
                       f"{target}로 전환되지 않으면 PASS (원본 부정 동작 미명시)")
            else:
                passc=(f"[시험 설계 가설] 모든 진입 조건이 미충족인 상태에서 "
                       f"{target}로 전환되지 않으면 PASS (원본 부정 동작 미명시)")
            c["expectation_basis"]="ENGINEERING_HYPOTHESIS"
            c["inferred_expected_fields"]=["output_value", "expected_state", "pass_criterion"]
            c["inference_evidence_fids"]=related_fids
            c["hypothesis_rule"]=("AND_SINGLE_FALSE_INHIBIT" if logic=="ALL_OF" else "OR_ALL_FALSE_INHIBIT")
            c["hypothesis_assumptions"]=(
                "나열된 진입 조건 외에 별도의 독립 진입 경로가 없으며, "
                "원본의 충분 조건을 시험 설계상 필요 조건이라고 가정한 경우에만 성립합니다."
            )
            c["human_review_required"]=True  # final-result review, not a blocking intermediate approval
            c["execution_readiness"]="FINAL_REVIEW_PROPOSAL"
            c["deferred_reason_code"]="INFERRED_NEGATIVE_EXPECTATION"
            c["deferred_reason_detail"]=(
                f"{focus} 미충족의 부정 동작은 원본에 확정되지 않았습니다. "
                "예상 결과는 자동 도출된 시험 설계 가설입니다."
            )
            c["required_resolution"]=(
                "중간 승인 없이 TC 후보를 생성했습니다. 최종 명세서 검토 시 원본의 다른 진입 조건, "
                "실제 제어 가능성, 기대 결과를 확인하십시오."
            )
            c["split_decision"]="PROPOSE_BOOLEAN_NEGATIVE_EXPECTATION"
        else:
            expected=target
            c["expectation_basis"]="SOURCE_EXPLICIT"
            if logic=="ANY_OF":
                passc=f"{focus}: 다른 전환 조건이 모두 미충족인 상태에서 {target}로 전환되면 PASS"
            else:
                passc=("모든 조건("+", ".join(pretty)+f")을 충족한 상태에서 {target}로 전환되면 PASS")
            c["split_decision"]="SPLIT_BOOLEAN_SOURCE_CONDITIONS"
        _set_structured_case_fields(c,objective=objective, precondition=readable,
            input_variable="조건별 상태", input_compare=("조건별 참/거짓 조합" if negative else logic), input_value=readable,
            execution=execution, output_variable="제어기 동작 상태", output_compare="=" if expected else "",
            output_value=expected, expected_state=expected, pass_criterion=passc,
            field_fids={"precondition":fids,"input_value":fids,
                        "output_value":related_fids if not negative else [],
                        "pass_criterion":related_fids if not negative else []})
        c["test_vectors"]=[{"step":1,"input_variable":"조건별 상태","input_value":list(human_labels),
                              "expected_state":expected, "expectation_basis":c["expectation_basis"],
                              "source_fact_fragment_ids":related_fids}]
        cases.append(c); idx+=1
    return cases,idx




def _voltage_boundary_value_cases(req: dict[str, Any], base: dict[str, Any], idx: int) -> tuple[list[dict[str, Any]], int]:
    """V0.104: numeric voltage regions, NOT Boolean combinations.

    Only derive a boundary partition from explicitly source-backed voltage ranges.
    Never infer what the ECU does outside a declared operating range. Exact shared
    boundaries are preserved as unresolved overlap evidence, never arbitrarily
    assigned to one side of the discontinuity. This works for any SRS title/IDs.
    """
    from decimal import Decimal

    if str(base.get("test_object_type") or "") not in {
        "SYS5_CANDIDATE", "SWE6_TC", "ELECTRICAL_VERIFICATION_INTENT",
    }:
        return [], idx
    text = _core_requirement_text(req)
    if not re.search(r"(?:전압|voltage|\bV\b)", text, re.I):
        return [], idx
    # Intentionally don't parse negatives, voltages without a range, percentages,
    # currents or temperatures as voltage BVA. A parser may broaden in later releases.
    pat = re.compile(r"(?<![\d.])(?P<lo>\d+(?:\.\d+)?)\s*(?:V)?\s*[~～∼–-]\s*(?P<hi>\d+(?:\.\d+)?)\s*V(?![A-Za-z])", re.I)
    ranges = []
    for match in pat.finditer(text):
        lo,hi = Decimal(match.group('lo')),Decimal(match.group('hi'))
        if 0 <= lo < hi <= 1000 and (lo,hi) not in ranges:
            ranges.append((lo,hi))
    if not ranges:
        return [],idx
    # Avoid unverified classification when different voltage measurements are mixed
    # or the statement is primarily about an unrelated parameter.
    if not re.search(r"(?:전원단\s*전압|동작\s*전압|입력\s*전압|인가\s*전압|DC\s*\d|\bvoltage\b)", text, re.I):
        return [],idx

    def fmt(num):
        return format(num,'f').rstrip('0').rstrip('.') if '.' in format(num,'f') else format(num,'f')

    normal = []
    for lo,hi in ranges:
        pattern = re.compile(rf"{re.escape(fmt(lo))}\s*V?\s*[~～∼–-]\s*{re.escape(fmt(hi))}\s*V", re.I)
        near = next((text[m.end():m.end()+86] for m in pattern.finditer(text)), '')
        if re.search(r'정상\s*동작|normal\s*operat', near, re.I):
            normal.append((lo,hi))
    # Same text may include a non-normal condition after a range. Prefer ranges
    # which have their own positive-state phrase; a larger normal range is typical.
    main = max(normal, key=lambda x:x[1]-x[0]) if normal else None
    if main is None:
        return [],idx
    low,high=main
    # Multi-region: low-hysteresis, main-normal, high-hysteresis, outer disables.
    lower = next(((a,b) for a,b in ranges if b==low and a<low),None)
    upper = next(((a,b) for a,b in ranges if a==high and b>high),None)
    has_multiregion=bool(lower and upper)
    if has_multiregion:
        l0,l1=lower; h0,h1=upper
        if not (re.search(rf'{re.escape(fmt(l0))}\s*V\s*이하',text) and re.search(rf'{re.escape(fmt(h1))}\s*V\s*이상',text)):
            has_multiregion=False
    if has_multiregion:
        if not (re.search(r'송신.*금지|통신.*금지',text) and re.search(r'통신.*disable|통신.*비활성',text,re.I)):
            has_multiregion=False

    if has_multiregion:
        # All five open intervals have an explicitly stated expected behavior.
        spec=[
            (f'V < {fmt(l0)}V','통신 disable','통신 disable',False),
            (f'{fmt(l0)}V < V < {fmt(low)}V','통신 송신 금지 및 제어기 정상동작','통신 송신 금지 및 제어기 정상동작',False),
            (f'{fmt(low)}V < V < {fmt(high)}V','제어기 정상동작','제어기 정상동작',False),
            (f'{fmt(high)}V < V < {fmt(h1)}V','통신 송신 금지 및 제어기 정상동작','통신 송신 금지 및 제어기 정상동작',False),
            (f'V > {fmt(h1)}V','통신 disable','통신 disable',False),
        ]
        edges=[fmt(x)+'V' for x in (l0,low,high,h1)]
    else:
        if len(ranges)>1:  # unrelated overlapping ranges: avoid guessing
            return [],idx
        spec=[
            (f'V < {fmt(low)}V','원본에 범위 밖 기대 동작이 명시되지 않음','범위 밖 동작 미확정',True),
            (f'{fmt(low)}V < V < {fmt(high)}V','제어기 정상동작','제어기 정상동작',False),
            (f'V > {fmt(high)}V','원본에 범위 밖 기대 동작이 명시되지 않음','범위 밖 동작 미확정',True),
        ]
        edges=[fmt(low)+'V',fmt(high)+'V']

    fids=list(dict.fromkeys([str(x) for x in _list(base.get('source_fact_fragment_ids')) if str(x)]+[
        r['fid'] for r in _fact_records(req) if r.get('fid') and any(fmt(lo) in r['text'] and fmt(hi) in r['text'] for lo,hi in ranges)
    ]))
    if not fids: # Require at least one source fact in the actual candidate scope.
        return [],idx
    result=[]
    for i,(region,expected,meaning,hypothesis) in enumerate(spec,1):
        objective=f'전원단 전압 {region} 구간에서 제어기 동작 및 통신 상태 확인'
        c=_base_case(base,req,idx,kind='VOLTAGE_BOUNDARY_PARTITION',
                     title=f'전원단 전압 구간별 검증 - {region}',objective=objective,fids=fids)
        c['condition_split_diagnostic']='전압 구간의 동등분할·경계값 후보를 적용하되, 임계점 정확값은 경계중첩 여부 검토 필요'
        c['boundary_partition_type']='MULTI_REGION' if has_multiregion else 'SINGLE_DECLARED_RANGE'
        c['boundary_region']=region
        c['boundary_exact_points_review']=edges
        c['boundary_source_is_explicit']=not hypothesis
        c['expectation_basis']='ENGINEERING_HYPOTHESIS' if hypothesis else 'SOURCE_EXPLICIT'
        if hypothesis:
            c['human_review_required']=True
            c['execution_readiness']='FINAL_REVIEW_PROPOSAL'
            c['split_decision']='REVIEW_UNDEFINED_VOLTAGE_OUTSIDE_RANGE'
            c['hypothesis_rule']='VOLTAGE_OUTSIDE_RANGE_OBSERVATION_ONLY'
            c['hypothesis_assumptions']='원본 전압 범위 밖에서 동작이 반드시 실패하는 것은 아닙니다. 최종 예상 결과와 PASS 기준은 원본/외부 규격 확인이 필요합니다.'
            passc='전압 범위 밖에서 동작과 통신 상태를 관찰하고, 별도 승인된 규격의 기대값과 비교하여 최종 판정한다 (기대값 미확정)'
        else:
            c['split_decision']='SPLIT_SOURCE_VOLTAGE_REGIONS'
            passc=f'{region} 조건에서 {meaning} 상태가 관찰되면 PASS (구간 경계점은 별도 검토)'
        _set_structured_case_fields(c,objective=objective,precondition='시험용 전원 인가 및 상태 관찰 가능',
            input_variable='제어기 전원단 인가 전압',input_compare='구간',input_value=region,
            execution=f'제어기 전원단 인가 전압을 {region} 구간으로 설정하고 제어기 동작 및 통신 상태를 관찰한다.',
            output_variable='제어기 동작 / 통신 상태',output_compare='관찰',
            output_value=expected,expected_state=expected,pass_criterion=passc,
            field_fids={'input_value':fids,'expected_state':fids if not hypothesis else [],
                        'pass_criterion':fids if not hypothesis else []})
        c['test_vectors']=[{'step':1,'input_variable':'제어기 전원단 인가 전압',
                            'input_value':region,'expected_state':expected,'source_fact_fragment_ids':fids}]
        result.append(c);idx+=1
    return result,idx



def _source_explicit_alternative_trigger_cases(
    req: dict[str, Any], base: dict[str, Any], idx: int
) -> tuple[list[dict[str, Any]], int]:
    """Split independent literal A OR B triggers when both share one explicit consequence.

    This narrow source-anchored case intentionally does not infer arbitrary signal
    values or split unrelated multi-output functions from a single vague sentence.
    When the branches have different consequences, the mapping requires review.
    """
    if str(base.get('test_object_type') or '') not in {'SYS5_CANDIDATE','SWE6_TC'}:
        return [],idx
    # Don't re-expand boolean transitions or voltage ranges.
    if base.get('condition_logic') in {'ALL_OF','ANY_OF'} or base.get('transition_family'):
        return [],idx
    triggers=_norm(req.get('activation_trigger') or req.get('preconditions'))
    if not triggers or triggers.count('또는')!=1 or len(triggers)>125:
        return [],idx
    pieces=[re.sub(r'(?:인\s*경우|되는\s*경우|하는\s*경우|시)$','',t).strip(' ,.;')
            for t in triggers.split('또는')]
    if len(pieces)!=2 or any(len(t)<4 for t in pieces) or pieces[0]==pieces[1]:
        return [],idx
    # Both paths must literally appear in an auditable source clause, and the
    # common action must be explicit in the requirement rather than assumed.
    fact_matches=[r for r in _fact_records(req) if r.get('fid') and all(
        (p.lower() in r['text'].lower()) for p in pieces)]
    if not fact_matches:
        return [],idx
    action=_norm(req.get('processing_action'))
    expected=_norm(req.get('acceptance_criteria') or req.get('output'))
    if len(action)<6 or len(expected)<6:
        return [],idx
    # Avoid falsely reusing combined outputs if input branches have different
    # semantic responsibilities (e.g., store settings versus command an LED).
    if ('저장' in expected and ('제어' in expected or '출력' in expected)
            and any('설정' in p for p in pieces)
            and any('제어' in p or '명령' in p for p in pieces)):
        return [],idx
    source_fids=list(dict.fromkeys([r['fid'] for r in fact_matches]+[
        str(x) for x in _list(base.get('source_fact_fragment_ids')) if str(x)]))
    if not source_fids: return [],idx
    result=[]
    for trigger in pieces:
        c=_base_case(base,req,idx,kind='EXPLICIT_OR_TRIGGER_BRANCH',
            title=f'{_norm(req.get("function_name")) or "대체 진입 경로"} - {trigger}',
            objective=f'{trigger} 경로에서 명시된 동작과 결과를 확인한다.',fids=source_fids)
        c['split_decision']='SPLIT_SOURCE_EXPLICIT_OR_TRIGGERS'
        c['alternative_trigger']=trigger
        c['alternative_trigger_list']=pieces[:]
        c['alternative_trigger_source_fids']=source_fids
        c['expectation_basis']='SOURCE_EXPLICIT'
        # Controllability is not proven by the literal OR; retain final review.
        c['human_review_required']=True
        c['execution_readiness']='FINAL_REVIEW_PROPOSAL'
        c['deferred_reason_code']='OR_TRIGGER_INDEPENDENCE_CONFIRMATION'
        c['deferred_reason_detail']='원문에 구분된 대체 진입 경로이지만 실제 독립 인가 가능성은 시험 환경에서 확인 필요.'
        c['required_resolution']='해당 트리거만 독립 인가할 수 있는지와 관찰 경로를 최종 검토합니다.'
        _set_structured_case_fields(c,
            objective=f'{trigger}을(를) 통해 동작을 시작하고 요구 결과를 확인한다.',
            precondition=f'{trigger} 조건 구성',
            input_variable='대체 진입 트리거 (논리 조건)',input_compare='선택',input_value=trigger,
            execution=f'{trigger} 경로를 구성한 뒤 {action} 수행 여부를 관찰한다.',
            output_variable=_norm(base.get('output_variable')),
            output_compare=_norm(base.get('output_compare')),
            output_value=_norm(base.get('output_value')),
            expected_state=_norm(req.get('output') or expected),
            pass_criterion=f'{trigger} 조건에서 {expected}',
            field_fids={'input_value':source_fids,'expected_state':source_fids,'pass_criterion':source_fids})
        c['test_vectors']=[{'step':1,'input_value':trigger,
            'source_fact_fragment_ids':source_fids}]
        result.append(c);idx+=1
    return result,idx


def build_basic_functional_cases(data: dict[str,Any], e2e_objective_cases: list[dict[str,Any]]) -> tuple[list[dict[str,Any]], list[dict[str,Any]], dict[str,Any]]:
    """Build Source-backed Basic Functional cases with traced voltage BVA; no fault injection.

    Source-traced relations drive coverage. An AND/OR negative branch can carry an
    explicitly labeled, non-binding Engineering hypothesis for final review; unrelated
    undefined Invalid/Error reactions still do not become Source-backed expectations.
    """
    reqs={str(r.get("srs_id") or ""):r for r in _list(data.get("requirements")) if isinstance(r,dict)}
    by_srs: dict[str,list[dict[str,Any]]] = defaultdict(list)
    for case in e2e_objective_cases:
        if isinstance(case,dict): by_srs[str(case.get("parent_srs_id") or "")].append(case)
    out=[]; reviews=[]; srs_expansion={}; split_diagnostic_events=[]
    primary_types={"SWE6_TC","SYS5_CANDIDATE","ELECTRICAL_VERIFICATION_INTENT","ENVIRONMENTAL_VERIFICATION_INTENT","MECHANICAL_VERIFICATION_INTENT","MANUFACTURING_VERIFICATION_INTENT"}
    for sid, bases in by_srs.items():
        req=reqs.get(sid,{})
        primary=[b for b in bases if str(b.get("test_object_type") or "") in primary_types]
        review_only=[b for b in bases if b not in primary]
        produced=[]
        next_idx=1
        # Expand each primary scope independently so SYS.5/SWE.6 fact boundaries remain intact.
        for base in primary:
            base_fids={str(x) for x in _list(base.get("source_fact_fragment_ids")) if str(x)}
            local=[]
            source_reviews,blocking_fids=_blocking_source_reviews(req)
            reviews.extend(source_reviews)
            if base_fids and blocking_fids and base_fids.issubset(blocking_fids):
                split_diagnostic_events.append({
                    'parent_srs_id':sid,'test_object_id':str(base.get('test_object_id') or ''),
                    'test_object_type':str(base.get('test_object_type') or ''),
                    'source_fact_fragment_ids':sorted(base_fids),
                    'decision_path':'BLOCKED_SOURCE_TBD_OR_CONFLICT',
                    'preceding_rule_kinds':[],'candidate_goal_kinds':[],
                    'applied_case_kinds':['BASIC_FUNCTIONAL_REVIEW'],
                    'semantic_evaluation':'NOT_RUN_SOURCE_BLOCK',
                })
                produced.append(_review_only_case(base,req,next_idx,"해당 검증 범위의 Source Fact가 TBD/Conflict 상태입니다.")); next_idx+=1
                continue
            enum_cases, enum_reviews, next_idx=_enum_cases(req,base,next_idx)
            # If a parent has multiple primary verification scopes, never project a derived case
            # across a fact boundary without an exact fragment intersection.
            def _scope(items):
                if len(primary)>1 and base_fids:
                    return [c for c in items if set(str(x) for x in _list(c.get("source_fact_fragment_ids")) if str(x)) & base_fids]
                return items
            enum_cases=_scope(enum_cases)
            local.extend(enum_cases); reviews.extend(enum_reviews)
            occupied={fid for c in enum_cases for fid in _list(c.get("source_fact_fragment_ids")) if fid}

            conditional,next_idx=_conditional_cases(req,base,next_idx,occupied)
            conditional=_scope(conditional); local.extend(conditional)
            occupied.update(fid for c in conditional for fid in _list(c.get("source_fact_fragment_ids")) if fid)

            semantic_branches,next_idx=_semantic_branch_cases(req,base,next_idx,occupied)
            semantic_branches=_scope(semantic_branches); local.extend(semantic_branches)
            occupied.update(fid for c in semantic_branches for fid in _list(c.get("source_fact_fragment_ids")) if fid)

            direct,next_idx=_direct_signal_output_cases(req,base,next_idx,occupied)
            direct=_scope(direct); local.extend(direct)
            occupied.update(fid for c in direct for fid in _list(c.get("source_fact_fragment_ids")) if fid)

            variant,next_idx=_variant_state_cases(req,base,next_idx,occupied)
            variant=_scope(variant); local.extend(variant)
            occupied.update(fid for c in variant for fid in _list(c.get("source_fact_fragment_ids")) if fid)

            # Exception/timeout is intentionally allowed to reuse the same fact as a normal path;
            # independent failure behavior is a separate Primary Objective in V0.92.
            timeout,next_idx=_timeout_exception_cases(req,base,next_idx,set())
            timeout=_scope(timeout); local.extend(timeout)

            transitions,next_idx=_state_transition_cases(req,base,next_idx,occupied)
            transitions=_scope(transitions); local.extend(transitions)
            occupied.update(fid for c in transitions for fid in _list(c.get("source_fact_fragment_ids")) if fid)

            decision_tables,next_idx=_pipe_decision_table_cases(req,base,next_idx)
            decision_tables=_scope(decision_tables); local.extend(decision_tables)

            dim,next_idx=_dimension_case(req,base,next_idx)
            dim=_scope(dim); local.extend(dim)
            props,next_idx=_artifact_property_case(req,base,next_idx)
            props=_scope(props); local.extend(props)

            # Diagnostic shadow analysis: collect candidate *types*, never source text.
            # This must not modify the generation decision or call an AI Provider.
            rule_kinds_before_semantic=list(dict.fromkeys(str(c.get('basic_case_kind') or c.get('test_design_mode') or '') for c in local))
            if not local:
                voltage_cases,next_idx=([],next_idx) if any(
                    x.get('basic_case_kind')=='VOLTAGE_BOUNDARY_PARTITION' for x in produced
                ) else _voltage_boundary_value_cases(req,base,next_idx)
                if voltage_cases:
                    local.extend(_scope(voltage_cases))
            if not local:
                alternative,next_idx=_source_explicit_alternative_trigger_cases(req,base,next_idx)
                if alternative:
                    local.extend(_scope(alternative))
            # Even if a previous rule produced a TC, inspect recognized semantic
            # goal *kinds* for diagnostic comparison. This is read-only shadow work.
            owned_records=[r for r in _fact_records(req) if not base_fids or str(r.get('fid') or '') in base_fids]
            candidate_goals=identify_independent_goals(owned_records)
            if not candidate_goals:
                from core.semantic_objective_design import identify_conditional_path_goals
                candidate_goals=identify_conditional_path_goals(owned_records)
            semantic_skip=bool(local)
            previous_kinds=list(dict.fromkeys(str(c.get('basic_case_kind') or c.get('test_design_mode') or '') for c in local))
            residual_added=False
            if local:
                # Do not replicate already-split established rule coverage.
                # Only expand if the explicit conditional goals outnumber the
                # independent cases already created in this source scope.
                residual=[]
                from core.semantic_objective_design import identify_conditional_path_goals
                uncovered=identify_conditional_path_goals(owned_records)
                if len(uncovered)>len(local):
                    residual,next_idx=_independent_semantic_objective_cases(
                        req,base,next_idx,only_conditional=True)
                accepted=[]
                for candidate in _scope(residual):
                    if len(accepted)>=4: break  # Safe per-source upper bound
                    cond=_norm(candidate.get('semantic_condition_source')).lower()
                    expected=_norm(candidate.get('expected_state')).lower()
                    cids=set(_list(candidate.get('source_fact_fragment_ids')))
                    already=False
                    for old in local+accepted:
                        oldcond=_norm(old.get('semantic_condition_source') or old.get('precondition')).lower()
                        oldexp=_norm(old.get('expected_state')).lower()
                        oldids=set(_list(old.get('source_fact_fragment_ids')))
                        # Exact requirement/objective/condition/source equivalence only;
                        # never merge dissimilar inputs merely because the signal matches.
                        if cids and cids==oldids and cond and expected and cond==oldcond and expected==oldexp:
                            already=True;break
                    if not already:accepted.append(candidate)
                if accepted:
                    local.extend(accepted)
                    residual_added=True
            else:
                semantic,next_idx=_independent_semantic_objective_cases(req,base,next_idx)
                if semantic:
                    local.extend(_scope(semantic))
            if not local:
                # Only explicit, separately traced condition atoms may expand a mode
                # transition. A missing negative-path expectation remains REVIEW.
                bool_cases,next_idx=_explicit_boolean_transition_cases(req,base,next_idx)
                if bool_cases:
                    local.extend(bool_cases)
                else:
                    local.append(_fallback_case(req,base,next_idx)); next_idx+=1
            # Persist only observable routing information for the output diagnostic.
            applied_kinds=list(dict.fromkeys(str(c.get('basic_case_kind') or c.get('test_design_mode') or '') for c in local))
            split_diagnostic_events.append({
                'parent_srs_id':sid,'test_object_id':str(base.get('test_object_id') or ''),
                'test_object_type':str(base.get('test_object_type') or ''),
                'source_fact_fragment_ids':sorted(base_fids),
                'preceding_rule_kinds':previous_kinds,
                'candidate_goal_kinds':[str(g.kind) for g in candidate_goals],
                'applied_case_kinds':applied_kinds,
                'decision_path':('PRECEDING_RULE_WITH_SEMANTIC_AUGMENT' if residual_added else
                                 'PRECEDING_RULE_HANDLED' if semantic_skip else
                                 'SEMANTIC_OBJECTIVES_EMITTED' if 'SEMANTIC_INDEPENDENT_OBJECTIVE' in applied_kinds else
                                 'FALLBACK_OR_OTHER'),
                'semantic_evaluation':('AUGMENTED_AFTER_PRECEDING_RULE' if residual_added else
                                       'SKIPPED_AFTER_PRECEDING_RULE' if semantic_skip else 'EXECUTED'),
            })
            # V0.106: applied rule/decision metadata, not hidden LLM reasoning.
            for c in local:
                c['engineering_decision_record']=describe_test_structure(c)
            # V0.94 fail-closed gates: exact field provenance + generated semantic integrity.
            for c in local:
                review_item=_trace_integrity_review(req,c)
                if review_item:
                    reviews.append(review_item)
                semantic_review=_semantic_integrity_review(req,c)
                if semantic_review:
                    reviews.append(semantic_review)
            produced.extend(local)
        # Preserve review-only scopes when no executable primary represents them.
        if not primary:
            for n,base in enumerate(review_only,1):
                case=dict(base)
                case["test_design_mode"]="BASIC_FUNCTIONAL_REVIEW"
                case["basic_functional_tc_id"]=""
                out.append(case)
        else:
            # Parent/review objects remain related context on the generated functional cases.
            review_ids=[str(x.get("test_object_id") or "") for x in review_only if str(x.get("test_object_id") or "")]
            for case in produced:
                related=list(dict.fromkeys([str(x) for x in _list(case.get("related_test_object_ids")) if str(x)] + review_ids))
                case["related_test_object_ids"]=related
                out.append(case)
        srs_expansion[sid]={"objective_case_count":len(bases),"basic_functional_case_count":sum(1 for x in produced if str(x.get("test_design_mode") or "")==BASIC_FUNCTIONAL_MODE) if primary else 0,"review_only_case_count":sum(1 for x in produced if str(x.get("test_design_mode") or "")=="BASIC_FUNCTIONAL_REVIEW")}
    # V0.103: de-duplicate only exact cross-domain scenario/outcome repeats;
    # preserve both Source fact sets and object IDs for a single E2E TC.
    out, cross_domain_merges = _deduplicate_cross_domain(out)
    out, exact_semantic_merges = _deduplicate_exact_semantic_goals(out)
    for _sid, _statistics in srs_expansion.items():
        _statistics["basic_functional_case_count"] = sum(
            1 for _case in out
            if str(_case.get("parent_srs_id") or "") == _sid
            and _case.get("test_design_mode") == BASIC_FUNCTIONAL_MODE
        )
    # Stable sequential human-facing TC ids, while evaluation IDs stay SRS-scoped.
    n=1
    for case in out:
        if str(case.get("test_design_mode") or "") == BASIC_FUNCTIONAL_MODE:
            case["basic_functional_tc_id"] = f"E2E_TC_{n:03d}"
            n+=1
    dedup_reviews=[]; seen_reviews=set()
    for item in reviews:
        key=(item.get("parent_srs_id"),item.get("review_type"),item.get("signal"),item.get("value"),item.get("meaning"))
        if key in seen_reviews: continue
        seen_reviews.add(key); dedup_reviews.append(item)
    reviews=dedup_reviews
    role_map={sid: classify_source_backed_facts(reqs.get(sid,{})) for sid in reqs}
    decision_examples=[]
    for case in out:
        if str(case.get("test_design_mode") or "") != BASIC_FUNCTIONAL_MODE:
            continue
        decision_examples.append({
            "decision_example_id":f"DEX-{len(decision_examples)+1:04d}",
            "parent_srs_id":str(case.get("parent_srs_id") or ""),
            "context":_norm(case.get("test_objective") or case.get("evaluation_name")),
            "ai_initial_decision":str(case.get("split_decision") or "KEEP_SINGLE_OBJECTIVE"),
            "user_final_decision":"",
            "user_comment":"",
            "test_case_id":str(case.get("basic_functional_tc_id") or ""),
            "source_fact_fragment_ids":[str(x) for x in _list(case.get("source_fact_fragment_ids")) if str(x)],
        })
    audit={
        "schema_version":"REQ-STUDIO-BASIC-FUNCTIONAL-DESIGN-0.92",
        "mode":BASIC_FUNCTIONAL_MODE,
        "basic_functional_case_count":sum(1 for x in out if str(x.get("test_design_mode") or "")==BASIC_FUNCTIONAL_MODE),
        "review_only_case_count":sum(1 for x in out if str(x.get("test_design_mode") or "")=="BASIC_FUNCTIONAL_REVIEW"),
        "review_item_count":len(reviews),
        "undefined_value_review_count":sum(1 for x in reviews if x.get("review_type")=="SOURCE_DEFINED_VALUE_WITHOUT_EXPECTED_BEHAVIOR"),
        "exact_field_trace_review_count":sum(1 for x in reviews if x.get("review_type")=="EXACT_FIELD_FACT_TRACE_REQUIRED"),
        "semantic_integrity_review_count":sum(1 for x in reviews if x.get("review_type") in {"GENERATED_SEMANTIC_INTEGRITY_REQUIRED","ENUM_MAPPING_INTEGRITY_REQUIRED"}),
        "srs_expansion":srs_expansion,
        "fact_role_map":role_map,
        "decision_example_candidates":decision_examples,
        "cross_domain_duplicate_merges":cross_domain_merges,
        "exact_semantic_duplicate_merges":exact_semantic_merges,
        "semantic_split_diagnostic_events":split_diagnostic_events,
        "semantic_independent_objective_count":sum(
            1 for item in out if item.get('basic_case_kind')=='SEMANTIC_INDEPENDENT_OBJECTIVE'),
        "guideline_mining":build_guideline_mining_snapshot(),
        "guardrails":[
            "No EP/BVA/fault-injection expansion in V0.94 Basic Functional mode.",
            "V0.103 uses traced AND/OR conditions to generate one-negative or all-negative trial hypotheses; general EP/BVA/fault injection remains not enabled.",
            "An AND-positive Source statement does not imply inhibition: any proposed negative PASS is explicitly labeled Engineering hypothesis for final review.",
            "Source assertions require exact Fact trace; inferred expected/criterion fields retain separate inference provenance and never claim exact Source support.",
            "Invalid/Error/TBD/Conflict facts without Source-defined reaction remain review items, not synthetic PASS/FAIL cases.",
            "One Canonical SRS may produce multiple Primary Test Objectives without automatically splitting the Canonical SRS.",
            "Same objective + same execution flow may remain one TC with N vectors/steps; independent failure objectives are split.",
            "Every populated Input/Expected/PASS value must carry exact Source Fact Fragment trace or be review-routed.",
            "V0.94 retains transparent Guideline Mining; mined candidates never auto-promote and only HUMAN_APPROVED registry rules may affect generation.",
        ],
    }
    return out,reviews,audit
