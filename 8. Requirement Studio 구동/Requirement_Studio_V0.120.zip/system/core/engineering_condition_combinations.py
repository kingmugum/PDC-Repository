"""V0.110 — source-neutral test-design combinations, not a domain lookup table.

Returns *proposed* independent input scenarios, never asserts they are physical
facts. Execution/expected provenance is assigned by the calling generator. 
No provider call or hard-coded ECU/TC ID is required.
"""
from __future__ import annotations
from itertools import product

LOGIC_ALIASES={
    'ALL_OF':'AND','AND':'AND', 'ANY_OF':'OR','OR':'OR',
    'EXACTLY_ONE_OF':'XOR','ONE_OF':'XOR','XOR':'XOR',
    'NONE_OF':'NOR','NOR':'NOR',
}


def expected_truth(logic: str, inputs: tuple[bool, ...]) -> bool:
    logic=LOGIC_ALIASES.get(logic.upper(),logic.upper())
    if logic=='AND':return all(inputs)
    if logic=='OR':return any(inputs)
    if logic=='XOR':return sum(inputs)==1
    if logic=='NOR':return not any(inputs)
    raise ValueError(f'unsupported logic: {logic}')


def independent_scenarios(logic: str, count: int, *, max_conditions: int=8) -> list[dict]:
    """Bounded reproducible coverage; 2 inputs exhaustive, larger inputs selective.

    Does not silently generate all 2**N for long conditions. Each returned item
    is a separate TC proposal and includes its own outcome and combination.
    """
    if not 1<=count<=max_conditions:raise ValueError('condition count out of range')
    typ=LOGIC_ALIASES.get(logic.upper())
    if typ is None: raise ValueError('unsupported logic')
    if count<=2:
        states=list(product((False,True),repeat=count))
    else:
        if typ=='AND':
            states=[(True,)*count]+[tuple(False if j==i else True for j in range(count)) for i in range(count)]+[(False,)*count]
        else:
            states=[(False,)*count]+[tuple(True if j==i else False for j in range(count)) for i in range(count)]+[(True,)*count]
            if typ=='XOR':
                states.append(tuple(j<2 for j in range(count)))
    states=list(dict.fromkeys(states))
    return [{'case_index':i+1,'inputs':list(s),'expected':expected_truth(typ,s),
             'trace_basis':'DERIVED_INPUT_COMBINATION'} for i,s in enumerate(states)]
