"""V0.112: bounded, deterministic recovery for completed JSON content with missing closing brackets.

Never invent a missing requirement, guess text, change an existing value, or silently
accept a mid-string truncation. All repaired data passes a structural gate.
"""
from __future__ import annotations

import json
import re
from typing import Any


class UnsafeJSONRecovery(ValueError):
    """Automatic local recovery cannot preserve a complete JSON payload safely."""


def _payload(text: str) -> str:
    raw=(text or '').strip()
    if raw.startswith('```'):
        raw=re.sub(r'^```(?:json)?\s*','',raw,flags=re.I)
        raw=re.sub(r'\s*```$','',raw)
    return raw.strip()


def complete_closing_delimiters(text: str, *, max_missing: int = 8) -> tuple[str, str]:
    """Append only unmatched `]` or `}` when the final JSON value is complete.

    Refuses unclosed strings, incomplete keys/values, and other syntax errors.
    No content is deleted or replaced. Parsing still must succeed afterwards.
    """
    raw=_payload(text)
    if not raw or raw[0]!='{':
        raise UnsafeJSONRecovery('최상위 JSON 객체 시작을 찾지 못함')
    stack=[];in_string=False;escaping=False
    for c in raw:
        if in_string:
            if escaping:escaping=False
            elif c=='\\':escaping=True
            elif c=='"':in_string=False
        elif c=='"':in_string=True
        elif c in '[{':stack.append(c)
        elif c in ']}':
            if not stack or stack.pop() != ('[' if c==']' else '{'):
                raise UnsafeJSONRecovery('중간에 일치하지 않는 닫는 기호 존재')
    if in_string or escaping:
        raise UnsafeJSONRecovery('문자열 중간 종료: 안전한 로컬 복구 불가')
    if not stack:
        raise UnsafeJSONRecovery('닫는 기호 누락 없음: 다른 문법 오류')
    if len(stack)>max_missing:
        raise UnsafeJSONRecovery('닫는 기호 누락 과다')
    # An object/list member must itself be finished, not a partial JSON literal.
    if raw.rstrip().endswith((':',',','{','[')):
        raise UnsafeJSONRecovery('마지막 필드 또는 값이 완성되지 않음')
    suffix=''.join(']' if o=='[' else '}' for o in reversed(stack))
    candidate=raw+suffix
    try:
        data=json.loads(candidate)
    except (ValueError,TypeError) as exc:
        raise UnsafeJSONRecovery(f'닫는 기호만 추가하여도 JSON이 복구되지 않음: {exc}') from exc
    if not isinstance(data,dict):
        raise UnsafeJSONRecovery('복원 최상위 값이 JSON 객체가 아님')
    return candidate,suffix


def validate_repaired_requirements(data: dict[str, Any]) -> None:
    """Conservative acceptance gate; never mistake a partial empty list for success."""
    required=('schema_version','source_document','scenario_candidates','requirements','gaps')
    if any(k not in data for k in required):
        raise UnsafeJSONRecovery('복원 후 필수 최상위 필드 누락')
    if not str(data['schema_version']).startswith('REQ-STUDIO-CANONICAL-REQ-'):
        raise UnsafeJSONRecovery('스키마 버전 불일치')
    if not isinstance(data['source_document'],dict):
        raise UnsafeJSONRecovery('문서 정보 타입 불일치')
    if not isinstance(data['scenario_candidates'],list) or not isinstance(data['gaps'],list):
        raise UnsafeJSONRecovery('시나리오/Gap 타입 불일치')
    reqs=data['requirements']
    if not isinstance(reqs,list) or not reqs:
        raise UnsafeJSONRecovery('요구사항 목록이 없거나 비어 있음')
    required_req=('candidate_id','requirement','source_evidence')
    if any(not isinstance(x,dict) or any(k not in x for k in required_req)
           or not str(x.get('requirement') or '').strip() or not x.get('source_evidence') for x in reqs):
        raise UnsafeJSONRecovery('복원 요구사항 중 본문/ID/근거 누락')


def restore_complete_json(text: str) -> tuple[dict[str, Any], str]:
    candidate,suffix=complete_closing_delimiters(text)
    data=json.loads(candidate)
    validate_repaired_requirements(data)
    return data,suffix
