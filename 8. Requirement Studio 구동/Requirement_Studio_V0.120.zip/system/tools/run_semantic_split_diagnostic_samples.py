"""Offline reproducibility sample for V0.109; no customer source, no AI API."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from core.basic_functional_test_design import build_basic_functional_cases
from core.semantic_split_diagnostic import build_semantic_split_diagnostic


def run(*, output_dir: Path | None = None, fixture: Path | None = None) -> tuple[Path,list[str]]:
    sample=fixture or (ROOT/'diagnostics'/'Semantic_Split_Diagnostic'/'SAMPLE_CASES.json')
    examples=json.loads(sample.read_text(encoding='utf-8'))['cases']
    output=output_dir or (ROOT/'output')
    output.mkdir(parents=True,exist_ok=True)
    reqs={};cases=[];events=[];results=[]
    for example in examples:
        sid='SRS_'+str(example['sample_id']);fid='SYNTHETIC-'+str(example['sample_id'])
        body=str(example['text'])
        req={'srs_id':sid,'function_name':str(example['title']),
             'requirement':body,'processing_action':body,'acceptance_criteria':body,
             'source_backed_atomic_behaviors':[{'source_fact_fragment_id':fid,
                 'source_location':'fictional sample','behavior_text':body}]}
        base={'parent_srs_id':sid,'test_object_id':f'SAMPLE_OBJ_{sid}',
              'test_object_type':'SYS5_CANDIDATE','source_fact_fragment_ids':[fid]}
        generated, reviews, audit=build_basic_functional_cases({'requirements':[req]},[base])
        reqs[sid]=req;cases.extend(generated);events.extend(audit.get('semantic_split_diagnostic_events',[]))
        count=len(generated);expected=int(example['expected_tc_count'])
        results.append(f'{"PASS" if count==expected else "FAIL"} | {example["sample_id"]} | 기대 {expected} / 생성 {count}')
    ids=[f'SRS_TC_{i:03d}' for i in range(1,len(cases)+1)]
    text=build_semantic_split_diagnostic(source_document=Path('synthetic_test_cases.json'),
          cases=cases,human_ids=ids,reqs=reqs,
          design_audit={'semantic_split_diagnostic_events':events},
          workbook_name='가상 재현 시험(Excel 별도 미생성)',project_root=ROOT)
    label=datetime.now().strftime('%Y%m%d_%H%M%S')
    target=output/f'99_의미분할_가상재현시험_{label}.txt'
    text += '\n[가상 입력 기대 결과 비교]\n'+'\n'.join(results)+'\n'
    target.write_text(text,encoding='utf-8-sig')
    return target,results


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Requirement Studio V0.109 의미 분할 진단 샘플(오프라인)')
    parser.add_argument('--output-dir',type=Path,default=None)
    args=parser.parse_args()
    path,checks=run(output_dir=args.output_dir)
    print('결과 저장:',path)
    for result in checks: print(result)
    if any(result.startswith('FAIL') for result in checks):sys.exit(1)
