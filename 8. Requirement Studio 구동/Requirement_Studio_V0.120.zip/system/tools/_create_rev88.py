from artifact_tool import Blob,SpreadsheetFile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
wb=SpreadsheetFile.import_xlsx(Blob.load(str(root/'Requirement_Studio_Requirements_Management_rev87.xlsx')))
sc=wb.worksheets.get_item('사용자 시나리오')
sc.get_range('A136:G136').values=[[
 'ALR-SC-130','V0.104 전압 경계값·비기능 가시화·검토 상태 중복 제거',
 '사용자는 전압 수치/동작 구간이 한 TC로 남고 검토 상태가 다른 검토 시트와 중복되며, 비기능 TC 구분이 어렵다고 요청하였다.',
 '근거가 있는 전원단 전압 범위는 구간별 시험 후보로 구성하되 중첩 경계 및 미정의 범위 밖 기대값을 원본 사실로 확정하지 않는다. 평가 시트에서 TC 검토 상태 열을 제거하고 비기능 유형을 옅은 보라색으로 표시한다. 원본 추적성은 보존한다.',
 '전압 구간은 다중 5건/단일 범위 3건 후보로 전개되며 경계 정확값은 별도 검토가 기록된다. 사람용 시트 21열, R:U 결과 공란, 색상 범례 및 추적성 보존이 검증된다.',
 'FR-576~FR-579','V0.104 시험 적용']]
fr=[
 ['FR-576','ALR-SC-130','E2E 평가 21열·검토 상태 중복 제거',
  '2_E2E_평가케이스에서 TC 검토 상태 열을 제거하여 총 21열로 출력한다. 상세 승인 상태/사유는 3_검토필요 및 추적성/Audit에 보존한다. 결과 네 열 R:U는 미실행 시 공란으로 유지한다.',
  'Critical','승인(시험 버전)','Export/Excel/Regression','V0.104 / FR-571 대체'],
 ['FR-577','ALR-SC-130','전압 범위 시험 설계 후보',
  '원본 Fact에 전원단 동작 전압 범위가 명확하면 수치 구간을 동등분할·경계값 후보로 분리한다. 다중 영역은 최대 5개 구간, 단일 범위는 내부·아래·위 3개 구간. 정확한 중첩 경계값은 검토로 남기고, 원본에 없는 범위 밖 미동작을 확정된 PASS로 생성하지 않는다. 신호명/TC 번호/MLM 이름에 의존하지 않는다.',
  'Critical','승인(시험 버전)','TestDesign/Boundary/Source','V0.104 / boundary source-grounded'],
 ['FR-578','ALR-SC-130','비기능 TC 분류와 보라색 표시',
  '원본에서 검증 대상이 소비전류·전압·온도 등 계측 가능한 전기/환경 성능에 해당하면 E2E 사람용 검증 영역을 비기능으로 표시하고 A:Q 셀을 옅은 보라색으로 구분한다. A1에 두 줄의 베이지/보라 범례를 10pt로 표시한다. SYS/SWE 실제 원본 할당은 Trace에서 보존하며 가설 셀에는 베이지 표시를 병행할 수 있다.',
  'High','승인(시험 버전)','Export/Nonfunctional/Trace','V0.104 / source classification'],
 ['FR-579','ALR-SC-130','경계 판정 로그·가이드·단일 배포',
  '전압 구간 분리, 정확한 임계점 충돌, 범위 밖 가설 및 비기능 표시의 이유를 판단 근거 TXT에 기록한다. AI E2E 가이드 헌법, 요구사항 rev88, 회귀시험, 단일 ZIP, 결과 보고서 PDF에 반영하고 민감한 원본 전문은 외부 샘플에 복사하지 않는다.',
  'High','승인(시험 버전)','Audit/Release/Safety','V0.104 / release']]
wb.worksheets.get_item('AI_02_요구사항목록').get_range('A579:H582').values=fr
active=wb.worksheets.get_item('AI_11_현재유효요구사항')
active.get_range('A535:J538').values=[r[:5]+['승인(시험 버전)','ACTIVE',None,'V0.104',r[7]] for r in fr]
# Previous 22-column format is superseded while existing audit remains unchanged.
active.get_range('G530:I530').values=[['SUPERSEDED','FR-576','V0.104']]
target=root/'Requirement_Studio_Requirements_Management_rev88.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(target))
print('SAVED',target, target.stat().st_size)
