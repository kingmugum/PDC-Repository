"""V0.109 release PDF, generated with ReportLab (Korean fonts embedded)."""
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, PageBreak, Spacer
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

root=Path(__file__).resolve().parents[1]
out=root/'review_exchange'/'baseline'/'release_reports'/'Requirement_Studio_V0.109_결과_보고서.pdf'
out.parent.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('NG109','/usr/share/fonts/truetype/nanum/NanumGothic.ttf'))
pdfmetrics.registerFont(TTFont('NG109B','/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf'))
pdfmetrics.registerFontFamily('NG109',normal='NG109',bold='NG109B')
NAVY=colors.HexColor('#16263D');BLUE=colors.HexColor('#2462B5');BORDER=colors.HexColor('#D9E5F2');GREY=colors.HexColor('#58708B');BG=colors.HexColor('#F3F8FE');TEAL=colors.HexColor('#178580')
st={
 'title':ParagraphStyle('ttl',fontName='NG109B',fontSize=17.8,leading=25,textColor=NAVY,spaceAfter=9,wordWrap='CJK'),
 'sub':ParagraphStyle('sub',fontName='NG109',fontSize=9,leading=15,textColor=GREY,spaceAfter=12,wordWrap='CJK'),
 'h':ParagraphStyle('h',fontName='NG109B',fontSize=11.1,leading=16,textColor=BLUE,spaceBefore=11,spaceAfter=5,wordWrap='CJK'),
 'b':ParagraphStyle('b',fontName='NG109',fontSize=8.9,leading=15,textColor=NAVY,spaceAfter=6,wordWrap='CJK'),
 'sm':ParagraphStyle('sm',fontName='NG109',fontSize=8.2,leading=13,textColor=NAVY,spaceAfter=4,wordWrap='CJK'),
 'th':ParagraphStyle('th',fontName='NG109B',fontSize=8.1,leading=12.5,textColor=colors.white,wordWrap='CJK'),
 'td':ParagraphStyle('td',fontName='NG109',fontSize=8.1,leading=12.5,textColor=NAVY,wordWrap='CJK'),
}
def P(text,style='b'): return Paragraph(str(text).replace('&','&amp;'),st[style])
def T(headers,rows,widths):
  data=[[P(h,'th') for h in headers]]+[[P(x,'td') for x in r] for r in rows]
  obj=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
  obj.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,BG]),('LINEBELOW',(0,1),(-1,-1),0.27,BORDER),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
  return obj

def footer(c,d):
 c.saveState();w,h=A4;c.setStrokeColor(BORDER);c.line(18*mm,17*mm,w-18*mm,17*mm)
 c.setFillColor(GREY);c.setFont('NG109',7.8)
 c.drawString(18*mm,12*mm,'Requirement Studio V0.109  |  2026-11-05  |  진단 기능 배포 보고')
 c.drawRightString(w-18*mm,12*mm,str(d.page));c.restoreState()

doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=22*mm,
 title='Requirement Studio V0.109 결과 보고서',author='Requirement Studio')
w=A4[0]-36*mm
s=[P('Requirement Studio V0.109','title'),P('의미 분할 진단 기능 · 가상 재현 시험 · 결과 저장 경로 | 2026.11.05','sub')]
s +=[P('01  이번 버전의 목적','h'),P('V0.108의 의미 분할 규칙이 제한되는 지점을 확인하기 위한 진단 중심 릴리스입니다. 기존 Excel 20열, 판단 근거 TXT, 가이드 헌법과 원본 추적 정보를 유지하고, 후속 의미 분석이 실행되거나 생략된 이유를 추가로 기록합니다.')]
s +=[P('02  사용자 실행 결과가 저장되는 위치','h'),T(['파일','저장 위치와 목적'],[
 ('E2E 평가 명세서','output/E2E_평가 명세서_*.xlsx  |  실제 TC의 20열 출력'),
 ('기존 판단 로그','output/00_E2E_판단근거_요약_*.txt  |  어떤 TC를 생성했는지'),
 ('신규 진단 로그','output/00_E2E_의미분할_진단_*.txt  |  선행 규칙·생략 여부·원본 Fact ID'),
 ('가상 재현 시험 로그','output/99_의미분할_가상재현시험_*.txt  |  가상 입력 기대값과 실제 개수'),
 ('PDF 보고서','review_exchange/baseline/release_reports/Requirement_Studio_V0.109_결과_보고서.pdf'),
 ],[64*mm,w-64*mm])]
s +=[P('03  진단 로그가 확인하는 내용','h'),P('상위 요구사항별 원본 Fact ID와 Primary 검증 객체, 선행 규칙이 생성한 Case 종류, 후속 독립 의미 분석 실행 여부 및 후보 검증 목적 종류를 기록합니다. 후보가 별도 TC로 표시되지 않았더라도 그것만으로 누락 확정은 아닙니다. 다른 생성 규칙이나 Step·Vector에 포함됐는지 비교해야 합니다.')]
s.append(PageBreak())
s +=[P('실제 처리 흐름과 진단 한계','title'),P('기존 결과를 유지하고 로컬 로직의 선택 경로만 관측했습니다.','sub')]
s +=[P('04  단계별 관찰 구조','h'),T(['단계','확인 항목','V0.109 동작'],[
 ('AI 추출','모델이 이해한 독립 검증 목적','현재 출력 계약에 별도의 AI 의미계획이 없어 독립 비교 불가'),
 ('Source Fact','원본 사실 조각 ID','기존 Fact ID를 유지하고 원본 문장을 로그에 복사하지 않음'),
 ('선행 규칙','Enum·신호·상태·전압 등','어떤 규칙이 먼저 Case를 만들어 다음 의미 분석이 생략됐는지 기록'),
 ('의미 분석','독립 목적 후보 종류','실행/생략, 후보 종류 및 실제 적용된 종류의 차이를 표시'),
 ('TC 출력','최종 Case 구성','기존 TC 생성·추적성·가설 표시 정책을 최대한 유지'),
 ],[27*mm,51*mm,w-78*mm])]
s +=[P('05  새로 추가한 파일','h'),P('core/semantic_split_diagnostic.py 는 진단 TXT의 생성과 한도·집계를 담당하며, core/basic_functional_test_design.py 는 실제 규칙의 순서와 생략 사유를 계측합니다. core/e2e_exporter.py 는 기존 E2E Excel과 판단 근거 TXT를 생성한 뒤 새 진단 TXT를 같은 output 폴더에 작성합니다.')]
s +=[P('06  가이드 헌법 전달 범위 점검','h'),P('현재 PromptBuilder에는 사용자 작성 원칙의 앞 3,200자만 포함하는 길이 제한이 있습니다. V0.109는 현재 가이드의 해당 구역 길이를 비교해 잘릴 수 있는 글자 수를 표시합니다. 이는 실제 모델에 전달된 프롬프트를 기록한 것은 아니며, 원본 사양의 정확성이나 AI 추론 내용을 보증하지 않습니다.')]
s +=[P('07  보안과 데이터 보호','h'),P('가상 테스트 문장은 실제 고객 자료와 무관하게 새로 작성했습니다. 진단 TXT에는 API Key·사용자 설정값·전체 고객 원문·전체 AI 응답을 담지 않습니다. 사용자가 고객 결과를 공유할 때도 파일명과 Fact ID 등의 사내 반출 규정은 별도로 확인해야 합니다.')]
s.append(PageBreak())
s +=[P('재현 시험과 검증 결과','title'),P('진단 경로가 동작한다는 근거와 실제 사용 미검증 범위를 구분했습니다.','sub')]
s +=[P('08  가상 재현 시험 3종','h'),T(['가상 요구사항 유형','기대 TC','실제 TC','결과'],[
 ('독립 조건 A/B → 서로 다른 결과','2','2','통과'),
 ('SW 오류 복귀 + Watchdog 구조 제약','2','2','통과'),
 ('단일 조건 → 단일 결과','1','1','통과'),
 ],[96*mm,23*mm,23*mm,w-142*mm])]
s +=[P('09  코드 및 패키지 시험','h'),T(['검증 항목','결과'],[
 ('pytest 전체 자동시험','305개 통과 (기존 299 + 신규 6)'),
 ('Python/PYW AST 구문 검사','113개 정상'),
 ('JSON 구문 검사','17개 정상'),
 ('요구사항 관리대장','rev93 / FR-598~600 / RT-548~553'),
 ('E2E Excel + 진단 TXT 연결','가상 입력으로 같은 output 폴더 저장 검사'),
 ('가상 오프라인 실행','기대/실제 TC 개수 확인'),
 ('Windows GUI / H-Chat·GPT / 고객 MLM','실제 실행 미검증'),
 ],[59*mm,w-59*mm])]
s +=[P('10  사용 방법','h'),P('① 전체 ZIP을 해제합니다. ② 통상적으로 E2E 평가 명세서를 생성합니다. ③ output 폴더에서 E2E Excel과 기존 판단 로그 및 새 진단 TXT를 비교합니다. ④ 가상 독립 재현은 diagnostics/Semantic_Split_Diagnostic/RUN_V0.109_DIAGNOSTIC_SAMPLE.cmd 를 실행합니다.')]
s +=[P('11  아직 해결되지 않은 문제','h'),P('현재 분할 엔진이 모든 복합 자연어 요구사항을 완전하게 분해한다고 볼 수는 없습니다. 또한 로컬 진단 로그만으로 AI가 실제로 식별했으나 출력 과정에서 잃어버린 목적을 증명할 수 없습니다. 다음 단계에서는 AI의 구조화된 의미 목적 계획과 로컬 TC/Step/Vector 결과를 별도 근거로 대조해야 합니다.')]
s +=[P('12  배포 원칙','h'),P('V0.109 단일 전체 ZIP에는 프로그램 전체 코드, 누적 가이드, 요구사항 rev93, 기존 이력, 가상 재현 입력, 자동시험 및 본 PDF를 포함합니다. 기존 V0.108과 rev92는 이력으로 보존합니다.')]
doc.build(s,onFirstPage=footer,onLaterPages=footer)
print('PDF',out,'bytes',out.stat().st_size)
