"""V0.106 approved change tracking; retain all existing workbook sheets/styles/formulas.

Only append scenario FR-586..588 to rev89's three management tables.
"""
from pathlib import Path
from artifact_tool import Blob, SpreadsheetFile

root=Path(__file__).resolve().parents[1]
src=root/'history/requirements/Requirement_Studio_Requirements_Management_rev89.xlsx'
wb=SpreadsheetFile.import_xlsx(Blob.load(str(src)))
wb.worksheets.get_item('사용자 시나리오').get_range('A138:G138').values=[[
  'ALR-SC-132',
  'V0.106 독립 검증 목적 및 순서 판단 근거 로그',
  '한 상위 요구사항에 SW 오류 복구와 Watchdog 제약, 데이터 정합성 검사와 안전 동작 등 여러 독립적인 평가 목적이 묶여 TC 하나로 생성됨. 사용자 요청은 TC/Step/Vector 선택 이유를 간결한 output TXT로 확인하는 것.',
  '기존 강한 Source 기반 생성 규칙을 우선하고 fallback 전 원본 Fact 추적 기반 독립 검증 목적 분석을 수행한다. 원본에 없는 신호·값은 추가하지 않는다. 기존 장황한 판단 로그 1개는 적용 규칙·원본 Fact·분리/유지/Step/Vector 근거 중심의 로그 1개로 대체한다.',
  '독립 목적 2개/공유 Fact 1개/기존 순서 Vector 보존/최종 시험 결과 공란/로그 한 개/비밀정보 비포함에 대한 단위시험 및 기존 회귀시험.',
  'FR-586~FR-588','V0.106 시험 적용',
]]
FR=[
 ['FR-586','ALR-SC-132','원본 Fact 기반 독립 검증 목적 중간 분석',
  '강한 원본 기반 시험 규칙을 유지하고, fallback 전 원본 Fact ID가 확인된 복합 요구사항에서 서로 다른 검증 목적 및 시험 방법을 식별해 TC 후보를 분리한다. 각 후보는 원본 Fact 연결을 보존한다. 모든 자연어 의미 구조를 범용 지원한다고 보장하지 않는다.',
  'Critical','승인(시험 버전)','TCDesign/Semantic/Trace','V0.106'],
 ['FR-587','ALR-SC-132','TC/Step/Vector 선택 이유 판단 근거 TXT',
  'E2E 평가 Excel 생성 시 기존 00_E2E_판단근거_요약_*.txt 한 파일을 규칙 실행 결정 중심 요약 로그로 교체한다. 적용 규칙, 원본 Fact, 분할/유지/Vector/Step 이유, 순차 관계 근거, 가설/추가 확인을 기록하며 API Key·원본문서 전문·AI 비공개 추론을 저장하지 않는다. 추가 AI 호출 없이 생성한다.',
  'High','승인(시험 버전)','Output/DecisionLog/Privacy','V0.106'],
 ['FR-588','ALR-SC-132','최종 검토·추적성·기존 산출물 계약 보존',
  '새 목적 후보에 구체 입력/출력값이 없으면 임의 신호값이나 PASS 정량값을 생성하지 않는다. 검증 방법 확인을 최종 검토로 표시하고 기존 20열 E2E, 가설 색상, SYS/SWE 추적성, 승인 규칙 우선, 5개 출력 체크박스, 단일 ZIP 및 기준선 내 PDF 보고서를 유지한다.',
  'Critical','승인(시험 버전)','Regression/Trace/Release','V0.106'],
]
wb.worksheets.get_item('AI_02_요구사항목록').get_range('A589:H591').values=FR
active=[
 [r[0],r[1],r[2],r[3],r[4],r[5],'ACTIVE',None,'V0.106',r[7]] for r in FR
]
wb.worksheets.get_item('AI_11_현재유효요구사항').get_range('A545:J547').values=active
out=root/'Requirement_Studio_Requirements_Management_rev90.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print(out)
for sheet,area in [('사용자 시나리오','A138:G138'),('AI_02_요구사항목록','A589:H591'),('AI_11_현재유효요구사항','A545:J547')]:
 print(sheet,wb.worksheets.get_item(sheet).get_range(area).values)
