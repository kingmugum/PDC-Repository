"""Build Korean PDF report; output lives inside approved baseline folder only."""
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.lib.units import mm

root=Path(__file__).resolve().parents[1]
out=root/'review_exchange/baseline/release_reports/Requirement_Studio_V0.106_결과_보고서.pdf'
out.parent.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('KR','/usr/share/fonts/truetype/nanum/NanumGothic.ttf'))
pdfmetrics.registerFont(TTFont('KR-B','/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf'))
pdfmetrics.registerFontFamily('KR',normal='KR',bold='KR-B')
navy=colors.HexColor('#14243F');blue=colors.HexColor('#255BBA');grey=colors.HexColor('#5C6C83');line=colors.HexColor('#DCE4F1');pale=colors.HexColor('#F3F7FD')
styles={
 'title':ParagraphStyle('xTitle',fontName='KR-B',fontSize=20,leading=28,textColor=navy,spaceAfter=9),
 'subtitle':ParagraphStyle('xSub',fontName='KR',fontSize=10.4,leading=16,textColor=grey,spaceAfter=15),
 'h':ParagraphStyle('xH',fontName='KR-B',fontSize=12,leading=17,textColor=navy,spaceBefore=14,spaceAfter=8),
 'body':ParagraphStyle('xBody',fontName='KR',fontSize=9.6,leading=16,textColor=navy,spaceAfter=7,wordWrap='CJK'),
 'small':ParagraphStyle('xSmall',fontName='KR',fontSize=8.8,leading=14,textColor=navy,spaceAfter=4,wordWrap='CJK'),
 'headcell':ParagraphStyle('xHeadCell',fontName='KR-B',fontSize=8.8,leading=13,textColor=colors.white,wordWrap='CJK'),
 'cell':ParagraphStyle('xCell',fontName='KR',fontSize=8.6,leading=13,textColor=navy,wordWrap='CJK'),
 'note':ParagraphStyle('xNote',fontName='KR',fontSize=8.9,leading=14,textColor=grey,wordWrap='CJK'),
}
def P(txt,key='body'):return Paragraph(txt,styles[key])
def Tbl(headers,rows,widths):
 data=[[P(x,'headcell') for x in headers]]+[[P(str(x),'cell') for x in r] for r in rows]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([
  ('BACKGROUND',(0,0),(-1,0),blue),('VALIGN',(0,0),(-1,-1),'TOP'),
  ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,pale]),
  ('LINEBELOW',(0,0),(-1,0),0.6,blue),('LINEBELOW',(0,1),(-1,-1),0.35,line),
  ('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),
  ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
 ]))
 return t

def footer(c,doc):
 c.saveState();w,h=A4
 c.setStrokeColor(line);c.line(17*mm,17*mm,w-17*mm,17*mm)
 c.setFont('KR',8);c.setFillColor(grey)
 c.drawString(17*mm,12*mm,'Requirement Studio V0.106 | 2026-11-05 | 기능 검증용 시험판')
 c.drawRightString(w-17*mm,12*mm,str(doc.page))
 c.restoreState()

doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=19*mm,leftMargin=19*mm,topMargin=20*mm,bottomMargin=23*mm,title='Requirement Studio V0.106 결과 보고서',author='Requirement Studio')
w=A4[0]-38*mm
s=[]
s += [P('Requirement Studio V0.106','title'), P('독립 검증 목적 분석 및 TC·Step·Vector 판단 근거 로그 개선 | 2026년 11월 5일','subtitle')]
s += [P('01. 이번 버전의 핵심','h'), P('<b>원본 요구사항에 서로 독립적인 검증 목적이 여러 개 존재하는데도 하나의 TC로 남는 현상</b>을 줄이기 위해, 기존 기본 TC 생성 경로 앞에 원본 Fact 기반 의미 목적 분석을 추가했습니다.')]
s += [Tbl(['구분','V0.105','V0.106'],[
 ('의미 분할','AND/OR·전압·명시적 트리거 등 일부 패턴','기존 규칙 우선 후, 미처리 복합 요구사항의 독립 목적 탐지'),
 ('TC 설계 기록','분할 유형·TC 목록·원본 요약 위주','왜 분리·유지·Vector·Step을 선택했는지 근거·방법·순서 설명'),
 ('output TXT','기존 00_E2E_판단근거_요약 로그','같은 이름과 경로를 유지하고 내용 교체. 별도 로그 추가 없음'),
 ('근거 관리','Source Fact ID 및 추적성','원본 Fact ID 보존 및 목적별 짧은 근거 부분 연결'),
 ('제약','실행 방법이 미정인 경우 검토 필요','원본 미기재 신호·값 미생성 / 중간 승인 불필요 / 최종 검토 유지'),
 ],[30*mm,65*mm,w-95*mm])]
s += [P('02. 무엇을 자동 분리하도록 확장했나요?','h'), P('아래는 명시된 Fact에서 서로 다른 검증 목적을 찾아내는 <b>제한적 분류 규칙</b>입니다. 자연어 전체를 범용 이해한다는 의미는 아닙니다.')]
s += [Tbl(['원본 검증 내용','분할 목적 후보','선택 이유'],[
 ('SW 오류 + Watchdog','① 오류 후 정상 복귀<br/>② Watchdog 배치·순서','동적 동작 확인과 정적 구조 검토는 시험방법이 다름'),
 ('저장 데이터 정합성 + 안전 동작','① Check-sum 검사<br/>② 데이터 오류 시 출력/상태','정상 검사 수행과 이상 반응은 별도 판정 목적'),
 ('통신 장애 + 복구','① 오류 대응<br/>② 통신 복귀 후 정상 동작','오류→복구 선행 흐름은 유지하면서 결과 검증 목적 분리'),
 ('설정 저장 + LED 제어','① 비휘발 저장<br/>② On/Off<br/>③ 밝기<br/>④ 색상','서로 다른 관찰 대상. 실제 명령값이 없다면 추가 검토'),
 ],[42*mm,57*mm,w-99*mm])]
s.append(PageBreak())
s += [P('검증 목적과 수행 순서의 구분','title'),P('실제 생성한 이유를 어떻게 로그에 남기는가','subtitle')]
s += [P('03. TC·Step·Vector를 결정하는 순서','h')]
s += [Tbl(['단계','무엇을 확인하나요?','기록할 결정'],[
 ('1. 출처 확인','실제 원본 Fact ID 및 검증 객체의 책임 범위','어느 Fact에서 목적을 식별했는지'),
 ('2. 의미 목적 분리','독립 PASS 목적/평가 방법/오류 유형','SPLIT 또는 KEEP과 근거'),
 ('3. 구조 선택','동일 목적 값 변화 / 동일 시나리오 선후관계','VECTOR 또는 STEP과 이유'),
 ('4. 기존 강한 규칙 우선','Enum, 시퀀스, 타이밍, AND/OR, 전압 등','어느 기존 규칙이 우선 실행됐는지'),
 ('5. 최종 확인','신호 매핑·실제 시험 가능성·가설 여부','근거 불충분 사항을 최종 검토 대상으로 표시'),
 ],[31*mm,67*mm,w-98*mm])]
s += [P('04. 로그 예시 — 가상 요구사항','h')]
s += [P('가상 입력: <b>“SW 오류가 발생하면 MCU Reset으로 정상 복귀한다. Watchdog은 Task 후에 동작하고 ISR 내부에는 존재하지 않는다.”</b>','small')]
s += [Tbl(['구분','자동 기록 예시'],[
 ('목적 A','정상 복귀 확인 / SPLIT / F-RESET / 오류 인가 후 정상 상태 관찰'),
 ('목적 B','Watchdog 배치 검토 / SPLIT / F-WDT / 정적 코드·태스크 구조 확인'),
 ('판단 이유','검증 방법과 실패 원인이 다른 두 목표. 동일한 TC로 묶지 않음'),
 ('순서에 대한 판단','오류 발생→복귀 순서를 유지하나, Watchdog 배치 검토를 임의로 후속 동작으로 연결하지 않음'),
 ('미확정 사항','오류 유발 수단·관찰 신호·정량 기대값은 원본/환경 확인 필요'),
 ],[43*mm,w-43*mm])]
s += [Spacer(1,7*mm), P('중요: 위 기록은 <b>프로그램이 적용한 판단 규칙의 근거</b>입니다. AI 모델의 비공개 내부 추론을 역으로 복원하거나 공개하는 기록은 아닙니다. 또한 특정 시험 환경에서 검증이 가능한지까지 자동 보장하지는 않습니다.','note')]
s.append(PageBreak())
s += [P('검증과 적용 한계','title'),P('이번에 실제 확인한 범위와 아직 확인되지 않은 범위를 구분합니다.','subtitle')]
s += [P('05. 구현 및 검증 현황','h')]
s += [Tbl(['항목','결과'],[
 ('자동 회귀시험','291개 PASS (기존 283 + 신규 8개)'),
 ('새 의미 분리 모의시험','SW 오류/Watchdog, 정합성/안전 동작, CAN 오류/복귀, 설정 저장/LED 목적 구분 확인'),
 ('출처 경계','한 Fact에서 둘 이상 목적이 확인돼도 원래 Fact ID를 공유해 추적, 가짜 Fact ID 미생성'),
 ('Excel 생성 경로 시험','E2E 평가 Workbook 생성 및 `output` 폴더에 판단 로그 1개 생성 확인'),
 ('요구사항 대장','rev90 / FR-586~588 / 사용자 시나리오 ALR-SC-132 기록'),
 ('기존 산출물','사람용 E2E 20열·Q~T 실제 결과 공란·5개 독립 체크박스·비기능/가설 구분 유지'),
 ],[50*mm,w-50*mm])]
s += [P('06. 아직 해결되지 않은 부분','h')]
s += [P('이번 단계는 <b>제한된 종류의 독립 목적 식별</b>을 도입한 것입니다. 임의의 모든 복합 요구사항을 정확히 분해하는 AI 구조화 파서, 범용 MC/DC, 전류·온도 경계값 일반화, 상황별 최적 TC/Vector 탐색, 모든 실행 신호의 자동 매핑은 여전히 추가 개발이 필요합니다.','body')]
s += [P('특히 원문에 특정 신호명·값·타이밍·검증 방법이 없을 때 이를 가정하여 정답 TC로 확정하지 않습니다. 별개 검증 목적은 식별해도 상세 수행 방법은 최종 검토 대상으로 남습니다.','body')]
s += [P('07. 실사용 확인 방법','h')]
s += [P('1) E2E 평가 명세서를 생성합니다.<br/>2) 동일한 `output` 폴더의 `00_E2E_판단근거_요약_*.txt`를 엽니다.<br/>3) 문제가 있는 TC ID를 찾아 SPLIT/KEEP/VECTOR/STEP 판단 및 Factor 출처를 확인합니다.<br/>4) 잘못 분리되거나 유지된 항목은 해당 TC 행, 상위 SRS ID, 원본 Fact ID를 함께 제시합니다.','body')]
s += [Spacer(1,7*mm),P('실행 환경 제약: 이 제작 환경에서는 Windows PySide6 GUI, 라이브 H-Chat/GPT 연결, 고객 실제 MLM 원본 전체 재분석을 검증하지 못했습니다. 따라서 V0.106은 프로그램 실행 결과에 따른 추가 확인이 필요한 시험판입니다.','note')]
doc.build(s,onFirstPage=footer,onLaterPages=footer)
print(out,out.stat().st_size)
