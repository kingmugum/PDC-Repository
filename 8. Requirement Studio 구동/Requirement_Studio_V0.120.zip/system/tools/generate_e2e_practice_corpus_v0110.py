"""V0.110 — create exactly 200 fictional practice variants and measure logic engines.

Not 200 approved rules. No customer files, provider calls or model training.
The oracle is derived from the *documented user preference* and must not be
used as a false independent proof of all natural-language comprehension.
"""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime
import sys
PROJECT=Path(__file__).resolve().parents[1]
if str(PROJECT) not in sys.path:sys.path.insert(0,str(PROJECT))
from core.engineering_condition_combinations import independent_scenarios

PROJECT=Path(__file__).resolve().parents[1]
NAMES=['가상 냉각기','가상 게이트','시험용 표시기','모의 배송 장치','가상 진단기',
       '훈련용 센서','모의 통신장치','가상 로봇','시험용 모터','모의 안전장치']
VARIANTS=['조건을 만족하면','조건이 성립할 경우','조건이 참이 되면','조건이 충족되면',
          '상황에서','동작 조건에서','요건을 만족하는 경우','조건의 만족 여부에 따라',
          '조건을 충족했을 때','조건 판정 이후']


def make_corpus() -> list[dict]:
    registry=json.loads((PROJECT/'policy/e2e_user_judgment_examples_v0110.json').read_text(encoding='utf8'))
    entries=[]
    for item in registry['examples']:
        kind=item['pattern_kind']
        for index in range(10):
            device=NAMES[index]
            wording=VARIANTS[index]
            if kind in {'AND','OR','XOR','NOR'}:
                condition_count=[1,2,3,4,5,6,7,8,2,3][index]
                conditions=[f'입력 {chr(65+j)}' for j in range(condition_count)]
                operator={'AND':'모두','OR':'하나 이상','XOR':'정확히 하나','NOR':'하나도 없음'}[kind]
                text=f'{device}의 {item["scenario"]}: {", ".join(conditions)} 중 {operator} {wording} 목표 상태로 전환한다.'
                oracle=len(independent_scenarios(kind,condition_count))
            elif kind=='BOUNDARY':
                count=10+index
                conditions=[f'누적 횟수 {count-1}',f'누적 횟수 {count}']
                text=f'{device}의 누적 완료 횟수가 {count}회 이상이면 다음 실행 시 알림을 출력한다.'
                oracle=2
            elif kind=='TIMING':
                limit=500+index*50
                conditions=[f'{limit}ms 미만',f'{limit}ms 초과','유효 입력','무효 입력']
                text=f'{device}는 마지막 유효 메시지 후 {limit}ms 초과 시 오류 상태가 된다.'
                oracle=4
            elif kind in {'SEQUENCE','OUTPUTS','PARTITION','BRANCH','COUNTER','FAULT','HYSTERESIS','EXTERNAL','METHOD'}:
                conditions=[f'조건 {chr(65+j)}' for j in range(item['condition_count'])]
                text=f'{device}: {item["scenario"]}. {wording} 단계별 출력과 독립 판정을 확인한다.'
                oracle=item['user_proposed_tc_count']
            else:
                conditions=['조건 A','조건 B']
                text=f'{device}: {item["scenario"]}. {wording} 결과를 확인한다.'
                oracle=item['user_proposed_tc_count']
            entries.append({'id':f'{item["id"]}_V{index+1:02d}',
                'source_judgment_id':item['id'],'source_type':'FICTIONAL_PRACTICE',
                'practice_requirement':text,'pattern_kind':kind,
                'condition_count':len(conditions),'conditions':conditions,
                'expected_independent_tc_count':oracle,
                'expected_tc_is':'USER_POLICY_ORACLE_NOT_EXTERNAL_REQUIREMENT',
                'user_judgment_basis':item['user_decision'],
                'needs_manual_relabel':kind not in {'AND','OR','XOR','NOR','BOUNDARY','TIMING'},
                'case_policy':'independent_PASS_FAIL_preferred',
                'notes':'검증 목적으로 자동 변형한 가상 입력. 고객 사양 또는 독립 승인 Rule이 아님.'})
    assert len(entries)==200 and len({x['practice_requirement'] for x in entries})==200
    return entries


def run(output_dir:Path | None=None)->tuple[Path,Path,dict]:
    target=Path(output_dir) if output_dir else PROJECT/'diagnostics/E2E_Guideline_Practice_V0110'
    target.mkdir(parents=True,exist_ok=True)
    data=make_corpus()
    corpus=target/'E2E_가상변형_200문항_V0.110.json'
    corpus.write_text(json.dumps({'version':'V0.110','description':'20개 사용자 판단 원형에서 만든 200개 가상 변형·진단 데이터, 승인 룰 200개가 아님',
        'generated_cases':data},ensure_ascii=False,indent=2),encoding='utf-8')
    from collections import Counter
    count=Counter(x['pattern_kind'] for x in data)
    ratio=sum(not x['needs_manual_relabel'] for x in data)
    report=target/'E2E_가상변형_200문항_검증결과_V0.110.txt'
    lines=['Requirement Studio V0.110 | 가상 변형 데이터 정적 점검','='*68,
           f'총 가상 변형: {len(data)}건','사용자 직접 판단 원형: 20건','변형 수: 각 10건',
           f'규칙 기반 기대 수가 정의된 변형: {ratio}건',
           f'원형 개별 판정에 대한 추가 재검토 표시: {len(data)-ratio}건',
           '주의: 이 수치는 로컬 AI의 200건 성공률을 뜻하지 않습니다.',
           '가상문항의 조건·결과 정답 여부를 실제 고객 사양 검증 결과로 해석할 수 없습니다.',
           '', '[패턴별 등록 수]']
    lines += [f'- {kind}: {c}건' for kind,c in sorted(count.items())]
    lines += ['', '[재현 명령]','py -3 tools\\generate_e2e_practice_corpus_v0110.py',
              '', '[다음 검증]','검증된 독립 기준값을 가진 동일 의미 변형을 로컬 TC 생성기·AI 모델에서 동일하게 도출하는지 확인',
              '사용자 문항 일부는 의도적으로 미정이므로 검증 기준의 독립 라벨링이 필요함.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
    return corpus,report,{'total':len(data),'scored_templates':ratio}


if __name__=='__main__':
    import sys
    out=Path(sys.argv[1]) if len(sys.argv)>1 else None
    a,b,s=run(out)
    print(a);print(b);print(json.dumps(s,ensure_ascii=False))
