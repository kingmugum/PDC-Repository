"""V0.108 Korean release report; package baseline PDF."""
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from xml.sax.saxutils import escape

root=Path(__file__).resolve().parents[1]
out=root/'review_exchange/baseline/release_reports/Requirement_Studio_V0.108_결과_보고서.pdf'
out.parent.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('NG108','/usr/share/fonts/truetype/nanum/NanumGothic.ttf'))
pdfmetrics.registerFont(TTFont('NG108B','/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf'))
pdfmetrics.registerFontFamily('NG108',normal='NG108',bold='NG108B')
navy=colors.HexColor('#122642'); blue=colors.HexColor('#255FBC'); grey=colors.HexColor('#526681'); pale=colors.HexColor('#F1F6FD'); border=colors.HexColor('#DCE5F0'); teal=colors.HexColor('#0C827C')
st={
  'title':ParagraphStyle('t108',fontName='NG108B',fontSize=18.2,leading=26,textColor=navy,spaceAfter=8,wordWrap='CJK'),
  'sub':ParagraphStyle('sub108',fontName='NG108',fontSize=10,leading=16,textColor=grey,spaceAfter=12,wordWrap='CJK'),
  'h':ParagraphStyle('h108',fontName='NG108B',fontSize=11.4,leading=18,textColor=blue,spaceBefore=12,spaceAfter=7,wordWrap='CJK'),
  'body':ParagraphStyle('b108',fontName='NG108',fontSize=9.0,leading=15,textColor=navy,spaceAfter=7,wordWrap='CJK'),
  'sm':ParagraphStyle('sm108',fontName='NG108',fontSize=8.5,leading=13.5,textColor=navy,spaceAfter=4,wordWrap='CJK'),
  'th':ParagraphStyle('th108',fontName='NG108B',fontSize=8.5,leading=13,textColor=colors.white,wordWrap='CJK'),
  'td':ParagraphStyle('td108',fontName='NG108',fontSize=8.5,leading=13.5,textColor=navy,wordWrap='CJK'),
}
def P(v,style='body'): return Paragraph(str(v),st[style])
def T(headers,rows,widths):
 data=[[P(str(s),'th') for s in headers]]+[[P(str(v),'td') for v in r] for r in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),blue),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,pale]),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.8,blue),('LINEBELOW',(0,1),(-1,-1),.25,border),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
 return t

def pagefoot(c,d):
 c.saveState();wd,ht=A4;c.setStrokeColor(border);c.line(18*mm,17*mm,wd-18*mm,17*mm)
 c.setFont('NG108',8);c.setFillColor(grey);c.drawString(18*mm,12*mm,'Requirement Studio V0.108  |  2026-11-05  |  시험판 결과 보고');c.drawRightString(wd-18*mm,12*mm,f'{d.page}');c.restoreState()

doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=22*mm,title='Requirement Studio V0.108 결과 보고서',author='Requirement Studio')
w=A4[0]-36*mm
story=[P('Requirement Studio V0.108','title'),P('미리 정해진 규칙을 넘어선 독립 조건·결과 TC 분할  |  2026.11.05','sub')]
story+=[P('01  사용자 요청과 확인된 원인','h'),P('V0.107에서는 미리 정의된 검증 목적 패턴에 해당할 때 독립 TC로 분리되지만, 새로운 종류의 복합 요구사항은 SOURCE_BACKED_FALLBACK으로 남는 경우가 있습니다. 이번 요청은 안전을 유지하면서도 실제로 사용 가능한 TC의 의미 분할을 확대하자는 것입니다.')]
story+=[T(['구분','V0.107','V0.108'],[
 ('분할 적용 조건','미리 정의된 기능/제약 패턴 중심','원본 Fact의 서로 다른 조건→결과 관계까지 인식'),
 ('원본 근거','Fact ID 필수','Fact ID 유지, 동일 ID 내 복수 경로도 허용'),
 ('실행 절차','Source에 불명확하면 일부 공란','조건 구성 및 관찰 순서를 Engineering 제안으로 구분'),
 ('예상 결과','Source 근거 우선','원본의 해당 조건별 결과를 그대로 보존'),
 ('사람용 추적성','4_요구사항-평가추적성','3_요구사항-평가추적성 (8열 유지)'),
],[31*mm,64*mm,w-95*mm])]
story+=[P('02  새로운 일반화된 분할 기준','h'),P('원본에 서로 다른 조건과 예상 결과가 <b>2개 이상 분명하게 연결</b>되어 있으면, LIN·CAN·LED 등 기존에 미리 알려진 단어에 해당하지 않아도 별도 TC 후보를 생성할 수 있습니다. 단순한 쉼표 개수, 문장 개수, 같은 결과에 도달하는 AND 요소 각각을 무조건 하나씩 분리하지 않습니다.')]
story+=[P('03  데이터 안전 경계','h'),P('원본의 신호·수치·상태·판정 결과와, 시험 설계를 위해 추가로 제안한 단계는 구분합니다. 원본에 없는 제어 명령/시험 장비 설정을 임의로 사실로 만들지 않습니다. 사람의 중간 승인은 요구하지 않지만, 최종 검토가 완료된 것이라고 주장하지 않습니다.')]
story.append(PageBreak())
story+=[P('실제 적용 사례와 분할 판단','title'),P('회사 자료 대신 새로 만든 가상 요구사항으로 재현했습니다.','sub')]
story+=[P('04  범용 조건→결과 사례','h'),P('가상 입력: <b>센서 A 감지 시 장비는 청색 램프를 점등한다. 센서 B 감지 시 장비는 컨베이어를 정지한다.</b>')]
story+=[T(['구분','분리된 검증 목적','판단 근거'],[
 ('TC 후보 1','센서 A 감지 시 청색 램프 점등','A 감지 조건과 결과 점등을 독립 관찰'),
 ('TC 후보 2','센서 B 감지 시 컨베이어 정지','B 감지 조건과 결과 정지를 독립 관찰'),
 ('공통 Trace','두 후보 모두 원본 Fact ID 공유','한 Fact에 두 문장이 있다고 Fact ID를 발명하지 않음'),
 ('베이지 표시','조건 구성 수행 절차','시뮬레이션/실제 장비 입력 방법을 Source에 없는 확정 사실로 쓰지 않음'),
],[28*mm,75*mm,w-103*mm])]
story+=[P('05  과도한 분할 방지','h'),P('원본에 조건→결과 한 쌍만 있거나 Source Fact ID가 없는 경우에는 새 분할이 적용되지 않도록 확인했습니다. 원본 문장 안에서 독립적인 조건과 결과를 분리해 읽을 수 없는 경우에는 이번 규칙만으로 별도 TC를 만들지 않습니다.')]
story+=[P('06  기존 출력 파일과 차이','h'),P('E2E 평가 Excel의 사람용 추적성 시트명은 <b>3_요구사항-평가추적성</b>으로 바뀝니다. 예전 E2E Excel 파일의 시트명을 소급하여 바꾸지 않습니다. 평가 본문은 20열, 추적성은 8열, 실제 시험 결과는 공란으로 보존합니다.')]
story+=[P('07  결정 근거 TXT','h'),P('기존 단일 TXT 파일명 `00_E2E_판단근거_요약_*.txt`를 유지합니다. 실제 선택한 분할 규칙, Source Fact ID, 조건별 기대 결과와 구체적인 조작 방법의 미확정 상태를 구분합니다. 이 로그는 코드의 결정 요약이지 AI 모델의 비공개 사고 기록이 아닙니다.')]
story.append(PageBreak())
story+=[P('검증·한계·배포','title'),P('자동시험의 성공 범위와 아직 수행하지 않은 확인을 구분합니다.','sub')]
story+=[P('08  자동시험 결과','h'),T(['검증 항목','결과'],[
 ('전체 pytest','299개 PASS (V0.107 295개 + 신규 4개)'),
 ('새로운 조건·결과 분할','가상 두 경로 → 독립 TC 2개 / 기존 특정 도메인 규칙 없음'),
 ('과도한 TC 생성 방지','단일 조건, 원본 Fact ID 없는 입력에서는 추가 분할하지 않음'),
 ('E2E Export / 판단 로그','사람용 추적성 시트명 변경, 20열/8열 유지, 절차 셀 베이지 구분, 새 판단 로그 규칙 확인'),
 ('요구사항 기준선','rev92 / FR-595~597 / RT-544~547 / ALR-SC-134'),
 ],[51*mm,w-51*mm])]
story+=[P('09  미구현·미검증 항목','h'),P('이번 기능은 특정 한글 조건→결과 문장 구조를 일반화하는 첫 단계이지, <b>범용 자연어 의미 파서 또는 완전한 시험 설계 AI</b>가 아닙니다. 중첩 조건, 표 내부 의미, 한 문장에 여러 결과가 결합된 복잡한 논리, 이미지/DBC 연계값, 모든 원문 제어 가능성을 자동으로 확정하지 않습니다.')]
story+=[P('10  실제 고객 환경의 검증 상태','h'),P('Windows GUI의 실제 표시, H-Chat·GPT 등 외부 Provider의 라이브 연결, 고객 MLM 원본 전체 재분석은 수행하지 못했습니다. 테스트 통과는 모의 입력과 기존 자동화 범위의 결과입니다.')]
story+=[P('11  배포 방식','h'),P('V0.108은 <b>단일 전체 ZIP 1종</b>으로 제공합니다. V0.107과 rev91은 history에 보존하고, V0.108의 요구사항 rev92·AI E2E 가이드 헌법·전체 소스·자동시험·본 PDF를 포함합니다. PDF는 `review_exchange/baseline/release_reports/`에서 확인할 수 있습니다.')]
story+=[Spacer(1,3*mm),P('다음 과제: 원본 한 문장에 여러 결과와 예외 흐름이 섞인 복합 요구사항을 의미 단위로 추출하고, TC/Step/Vector를 근거에 맞게 선택하는 범용 범위를 확장합니다.','sm')]
doc.build(story,onFirstPage=pagefoot,onLaterPages=pagefoot)
print('REPORT',out.name,'bytes',out.stat().st_size)
