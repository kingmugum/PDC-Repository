"""V0.107 Korean PDF release report kept inside single full ZIP baseline."""
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm

root=Path(__file__).resolve().parents[1]
out=root/'review_exchange/baseline/release_reports/Requirement_Studio_V0.107_결과_보고서.pdf'
out.parent.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('KR107','/usr/share/fonts/truetype/nanum/NanumGothic.ttf'))
pdfmetrics.registerFont(TTFont('KR107-B','/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf'))
pdfmetrics.registerFontFamily('KR107',normal='KR107',bold='KR107-B')
navy=colors.HexColor('#13243D'); blue=colors.HexColor('#2557A7'); grey=colors.HexColor('#5A6A82'); pale=colors.HexColor('#F2F6FC'); line=colors.HexColor('#DFE5EE')
styles={
 'title':ParagraphStyle('title_107',fontName='KR107-B',fontSize=19,leading=26,textColor=navy,spaceAfter=8),
 'sub':ParagraphStyle('sub_107',fontName='KR107',fontSize=10.4,leading=15,textColor=grey,spaceAfter=13),
 'h':ParagraphStyle('h_107',fontName='KR107-B',fontSize=11.5,leading=17,textColor=navy,spaceBefore=13,spaceAfter=7),
 'body':ParagraphStyle('body_107',fontName='KR107',fontSize=9.2,leading=15.2,textColor=navy,spaceAfter=7,wordWrap='CJK'),
 'small':ParagraphStyle('small_107',fontName='KR107',fontSize=8.5,leading=13.7,textColor=navy,wordWrap='CJK'),
 'th':ParagraphStyle('th_107',fontName='KR107-B',fontSize=8.4,leading=12,textColor=colors.white,wordWrap='CJK'),
 'td':ParagraphStyle('td_107',fontName='KR107',fontSize=8.35,leading=12.6,textColor=navy,wordWrap='CJK'),
 'note':ParagraphStyle('note_107',fontName='KR107',fontSize=8.5,leading=13.5,textColor=grey,spaceBefore=7,wordWrap='CJK'),
}
def P(s,k='body'): return Paragraph(str(s),styles[k])
def T(headers, rows, widths):
 data=[[P(s,'th') for s in headers]]+[[P(x,'td') for x in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),blue),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,pale]),('LINEBELOW',(0,0),(-1,0),.7,blue),('LINEBELOW',(0,1),(-1,-1),.35,line),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
 return t

def foot(c,d):
 c.saveState();w,h=A4;c.setStrokeColor(line);c.line(18*mm,17*mm,w-18*mm,17*mm)
 c.setFont('KR107',8);c.setFillColor(grey);c.drawString(18*mm,12*mm,'Requirement Studio V0.107  |  2026-11-05  |  시험판 결과 보고');c.drawRightString(w-18*mm,12*mm,str(d.page));c.restoreState()

doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=19*mm,leftMargin=19*mm,topMargin=20*mm,bottomMargin=23*mm,title='Requirement Studio V0.107 결과 보고서',author='Requirement Studio')
w=A4[0]-38*mm
story=[P('Requirement Studio V0.107','title'),P('입력 문서 기준 E2E 평가 명세서 간소화 및 독립 검증 목적 분리  |  2026.11.05','sub')]
story += [P('01  이번 변경의 목적','h'),P('사람에게 전달되는 E2E 평가 Excel은 <b>원본 입력 문서의 시험 계획과 결과</b>를 중심으로 읽을 수 있도록 간소화했습니다. Requirement Studio 프로그램의 과거 개발 이력, 내부 평가 게이트, 반복적인 검토 경고는 사람용 시트에서 제외했습니다. 다만 원본 Fact 추적·검증 정책은 프로그램 내부와 판단 근거 TXT에서 계속 유지합니다.')]
story += [T(['대상 시트','V0.107 출력 계약'],[
 ('표지','Source Fidelity 안내 행 삭제. 보안·원본 충실도 규칙은 시스템 단위로 유지'),
 ('0_변경이력','No. / Version / Date / Change / 작성자. 최초 1행: 1 / V1.00 / YYYY-MM-DD / 초안 작성 / 공란'),
 ('1_평가요약','전체 TC, 기능 TC, 비기능 TC, 고유 BF 요구사항 ID 수의 4가지 숫자만 표시'),
 ('2_E2E_평가케이스','기존 20열 유지, Q~T 실제 결과 공란, 중복된 시험 신호·판정 검토 안내 삭제'),
 ('3_검토필요','사람용 E2E 평가 파일에서 제거. 별도의 E2E 요구사항 명세서는 이번 범위에서 변경하지 않음'),
 ('4_요구사항-평가추적성','ID, 검증 영역·방법, 연결 원본 객체 위주의 8열. 기술 분석용 12개 열은 표시하지 않음'),
],[40*mm,w-40*mm])]
story += [Spacer(1,4*mm), P('02  혼동하기 쉬운 두 버전','h'),P('E2E 평가 Excel의 <b>V1.00</b>은 해당 입력문서로 처음 생성한 <b>평가 문서 버전</b>입니다. 프로그램 배포 번호는 <b>V0.107</b>이며 고객용 변경이력에 표시하지 않습니다. 동일 입력문서의 과거 Excel을 다시 불러와 V1.01로 자동 증분하는 기능은 아직 없습니다.')]
story.append(PageBreak())
story += [P('독립 검증 목적 분리 규칙','title'),P('조건과 결과의 독립성을 먼저 판단하고 TC·Step·Vector를 선택합니다.','sub')]
story += [P('03  원본 기반 의미 분할 사례','h')]
story += [T(['복합 조건 / 상황','독립적인 시험 목적 후보','주의 사항'],[
 ('CAN 정상 + LIN 오류 / CAN·LIN 동시 오류','① CAN 정상에서 LIN 복구 시도<br/>② CAN·LIN 동시 오류에서 저전력 진입','조건과 기대 결과가 서로 다른 두 경로. 원본 Fact ID 공유 가능'),
 ('데이터 정합성 이상 / 사용자 설정 복구 실패','① 데이터 오류 시 출력 OFF 및 안전 상태<br/>② 설정값 복구 실패 시 초기값 정상 동작','오류 안전 대응과 설정 복구는 서로 독립 판정'),
 ('CAN 오류 대응 / CAN 복구 후 정상 동작','① 통신 유지 불가 시 안전 대응<br/>② 복구 후 정상 동작','복구 시험에 추가한 선행 오류 주입 단계는 시험 설계 제안으로 구분'),
 ],[44*mm,72*mm,w-116*mm])]
story += [P('04  검증을 위한 데이터 출처 구분','h'),P('원본에 직접 명시된 복구 기대 결과는 <b>Source-backed</b>으로 보존합니다. 다만 별도의 복구 TC를 실행하기 위한 오류 상태의 선행 구성 등 원본에 구체적인 지시가 없는 실행 단계는 <b>Engineering 제안</b>입니다. 이 경우 사람용 Excel의 수행 절차 셀에만 옅은 베이지색이 사용될 수 있습니다. 실제 주입 명령·신호값은 임의 생성하지 않습니다.')]
story += [P('05  로그의 역할','h'),P('기존 `00_E2E_판단근거_요약_*.txt`는 계속 한 파일로 생성합니다. 각 TC에 적용된 SPLIT/KEEP/STEP/VECTOR 판단, 원본 Fact ID, 결정 이유 및 시나리오 순서를 기록합니다. 이것은 <b>프로그램이 적용한 규칙의 설명</b>이지 AI 내부 사고 과정 공개나 원본 정확성 보증이 아닙니다.')]
story.append(PageBreak())
story += [P('검증 현황과 배포 조건','title'),P('이번 배포에서 시험한 것과 시험하지 못한 것을 분리해 기록합니다.','sub')]
story += [P('06  자동시험 결과','h'),T(['검증 항목','결과'],[
 ('전체 자동시험','295개 PASS (기존 291 + 신규 4개 검사; 과거 시트 계약 검사는 현행 정책으로 개정)'),
 ('새 원문 기반 의미 분할','가상 CAN/LIN 혼합 오류, 메모리 정합성 안전/설정 복구, CAN 장애/복구 각각 독립 TC 후보로 분리'),
 ('E2E 평가 Excel','V1.00 초안 이력, 4항목 요약, 3_검토필요 제거, 8열 추적성, 20열 평가·결과 공란 검사'),
 ('코드 구성','기존 5개 독립 출력 선택 유지. 원본 Fact ID 및 단계 출처 정보 보존'),
 ('요구사항 기준선','rev91 / FR-589~594 / 회귀시험 RT-540~543'),
 ],[50*mm,w-50*mm])]
story += [P('07  아직 확인되지 않은 부분','h'),P('실제 Windows GUI, H-Chat·GPT 등 라이브 제공자, 고객의 MLM 원본 전체 재분석은 이 제작 환경에서 검증하지 못했습니다. 일반 자연어 모든 문장을 의미적으로 완전 분해하는 기능은 구현하지 않았습니다. 이번에는 출처가 있는 제한된 복합 상황 유형에만 신규 규칙을 적용합니다.')]
story += [P('08  배포 내용','h'),P('이번 배포는 <b>V0.107 단일 전체 ZIP 1종</b>입니다. 요구사항 관리대장, 전체 소스, 회귀시험, AI E2E 가이드 헌법, 변경 안내, PDF 보고서를 함께 포함합니다. 보고서는 ZIP 내부 `review_exchange/baseline/release_reports/` 경로에 있습니다.')]
story += [Spacer(1,5*mm),P('안전 원칙: 사람용 문서에서 검토·Source Fidelity 문구를 제거한 것은 사실 검증 책임을 없애거나 AI가 임의로 수치·신호·시험 결과를 생성하도록 허용한 것이 아닙니다.','note')]
doc.build(story,onFirstPage=foot,onLaterPages=foot)
print('pdf generated',out,'size',out.stat().st_size)
