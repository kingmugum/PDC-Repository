# GUI 한정 승인 예외 — 2026-11-07

기존 Requirement Studio 이중계층 요구사항에서 화면 배치·공급자 선택 관련 규칙은 사용자 참조 이미지에 맞게 수정할 수 있습니다. 하지만 GUI 외 기능 요구사항·시험 규칙·E2E 정책은 변경 불가입니다. 그 결과 구버전 GUI의 2행 공급자 배치 검증만 3행 구조로 대체하고 나머지 회귀시험을 유지했습니다. 증거: `docs/reference_gui/V0113_사용자_참고화면.png`, `AI_12_GUI개편_V0113` 시트, `tests/test_v0113_commercial_gui_provider_isolation.py`.
