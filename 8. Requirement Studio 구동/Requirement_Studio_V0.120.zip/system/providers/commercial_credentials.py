"""Local commercial API key files. No network, no persistence and never log key values.

Key layout: api_keys/commercial/{openai,gemini,claude,custom}/*.txt
Selected file (when multiple) stays in memory only; manual keys take precedence.
"""
from __future__ import annotations

from pathlib import Path

SUBFOLDERS = {
    "openai_api": "openai", "gemini_api": "gemini",
    "claude_api": "claude", "custom_api": "custom",
}


def credential_folder(project_root: Path, provider_id: str) -> Path:
    if provider_id not in SUBFOLDERS:
        raise ValueError("지원하지 않는 상용 API 공급자입니다.")
    return Path(project_root).resolve() / "api_keys" / "commercial" / SUBFOLDERS[provider_id]


def list_credential_files(project_root: Path, provider_id: str) -> list[Path]:
    folder = credential_folder(project_root, provider_id)
    if not folder.is_dir():
        return []
    # Strictly one level, ordinary TXT files only. Reject symlinks, even to inside tree.
    return sorted(
        [p for p in folder.iterdir() if p.is_file() and not p.is_symlink() and p.suffix.lower() == ".txt"],
        key=lambda p: (p.name.casefold(), p.name),
    )


def read_credential_file(path: Path, folder: Path) -> str:
    folder = Path(folder).resolve()
    path = Path(path)
    if path.is_symlink() or path.parent.resolve() != folder or path.suffix.lower() != ".txt":
        raise ValueError("허용되지 않는 API 키 파일 경로입니다.")
    if not path.is_file():
        raise FileNotFoundError("API 키 파일을 찾을 수 없습니다.")
    if path.stat().st_size > 4096:
        raise ValueError("API 키 파일은 4KB를 넘을 수 없습니다.")
    text = path.read_text(encoding="utf-8-sig").strip()
    if not text or len(text.splitlines()) != 1 or any(ch.isspace() for ch in text):
        raise ValueError("API 키 파일에는 공백 없는 키 한 줄만 입력해야 합니다.")
    return text


def selected_credential(project_root: Path, provider_id: str, selected_name: str = "") -> tuple[str, str]:
    """Return (secret key, basename). Never return a full path to the user UI."""
    files = list_credential_files(project_root, provider_id)
    if not files:
        return "", ""
    selected = next((p for p in files if p.name == selected_name), None)
    if selected_name and selected is None:
        # Don't silently switch accounts if an explicitly selected file is deleted.
        return "", ""
    selected = selected or files[0]
    return read_credential_file(selected, credential_folder(project_root, provider_id)), selected.name
