from __future__ import annotations

import json
from pathlib import Path
from typing import Any


# Verified official OpenAI API model IDs (not H-Chat gateway model aliases).
# Keep all selectable in the MAIN window with no need to open AI settings.
OPENAI_COMMERCIAL_MODELS = (
    "gpt-6.1-sol",  # balanced default
    "gpt-6.1-terra",
    "gpt-6-astra",
    "gpt-6-luna",
)

# Google Gemini API model IDs verified against Google AI Developers model catalog.
# These are commercial API models, not H-CHAT gateway aliases.
GEMINI_COMMERCIAL_MODELS = (
    "gemini-3.8-flash",            # current GA stable default
    "gemini-3.1-pro-preview",     # complex reasoning (preview)
    "gemini-3.7-flash",           # stable alternative
    "gemini-3.5-flash-lite",      # cost-efficient document extraction
)

# Anthropic official Claude API model aliases, distinct from Claude Code subscription.
CLAUDE_COMMERCIAL_MODELS = (
    "claude-sonnet-5-5",  # document-analysis default
    "claude-opus-5-5",    # complex reasoning / more expensive
    "claude-fable-5-1",  # demanding reasoning / more expensive
    "claude-haiku-5-5",  # fast, efficient extraction
)


DEFAULT_CONFIG: dict[str, Any] = {
    "selected_provider": "hchat_gpt",
    # V0.113: commercially billed APIs have independent settings; legacy custom stays unchanged.
    "commercial": {
        "openai_api": {
            "profile": "openai_responses", "base_url": "https://api.openai.com/v1",
            "model": OPENAI_COMMERCIAL_MODELS[0], "model_options": list(OPENAI_COMMERCIAL_MODELS),
            "auth_mode": "bearer", "api_key_name": "Authorization",
            "api_key_required": True, "supports_images": True,
            "version_header_name": "", "version_header_value": "",
            "max_tokens": 4096, "timeout_seconds": 300, "reasoning_effort": "high",
        },
        "gemini_api": {
            "profile": "gemini_generate_content", "base_url": "https://generativelanguage.googleapis.com/v1beta",
            "model": GEMINI_COMMERCIAL_MODELS[0], "model_options": list(GEMINI_COMMERCIAL_MODELS),
            "auth_mode": "x-api-key", "api_key_name": "x-goog-api-key",
            "api_key_required": True, "supports_images": True,
            "version_header_name": "", "version_header_value": "",
            "max_tokens": 4096, "timeout_seconds": 300, "thinking_level": "high",
        },
        "claude_api": {
            "profile": "anthropic_messages", "base_url": "https://api.anthropic.com",
            "model": CLAUDE_COMMERCIAL_MODELS[0], "model_options": list(CLAUDE_COMMERCIAL_MODELS),
            "auth_mode": "x-api-key", "api_key_name": "x-api-key",
            "api_key_required": True, "supports_images": True,
            "version_header_name": "anthropic-version", "version_header_value": "2023-06-01",
            "max_tokens": 32768, "timeout_seconds": 300,
            "reasoning_effort": "high", "thinking_mode": "adaptive",
        },
    },
    "alira": {
        "model": "hosted_vllm/Qwen/Qwen3.6-27B",
        "model_options": ["hosted_vllm/Qwen/Qwen3.6-27B"],
        "api_base": "http://10.10.10.200:19640/v1",
        "timeout_seconds": 600,
        "supports_images": True,
        "vision_transport": "cli_image_tool",
        "license_path": "alira_license/license.lic",
    },
    "custom": {
        "profile": "openai_compatible",
        "profile_flags": {
            "openai_compatible": True,
            "openai_responses": True,
            "anthropic_messages": True,
            "gemini_generate_content": True,
        },
        "base_url": "",
        "model": "",
        "model_options": [],
        "timeout_seconds": 120,
        "max_tokens": 4096,
        "api_key_required": True,
        "auth_mode": "auto",
        "api_key_name": "Authorization",
        "version_header_name": "",
        "version_header_value": "",
        "supports_images": False,
    },
    "hchat": {
        "backend": "gpt",
        "base_url": "https://internal-apigw-kr.hmg-corp.io/hchat-in/api/v3",
        "project_id": "",
        "api_version": "2025-04-01-preview",
        "gpt_model": "gpt-5.6-terra",
        "gpt_model_options": ["gpt-5.6-terra"],
        "gpt_supports_images": True,
        "gemini_model": "gemini-3.7-flash",
        "gemini_model_options": ["gemini-3.7-flash"],
        "gemini_stream_option": "generateContent",
        "gemini_supports_images": True,
        # V0.55 H-Chat v3 Claude Messages API. Old UI model choices are removed.
        "claude_protocol": "hchat_messages_v3",
        "claude_base_url": "",
        "claude_endpoint": "claude/messages",
        "claude_model": "claude-sonnet-5",
        "claude_model_options": ["claude-sonnet-5"],
        "claude_max_tokens": 4096,
        "claude_thinking_mode": "disabled",
        "claude_supports_images": True,
        "timeout_seconds": 120,
        "max_retry": 3,
        "retry_wait_seconds": 2.0,
    },
}


class ProviderConfigStore:
    def __init__(self, project_root: Path):
        self.project_root = Path(project_root).resolve()
        self.config_dir = self.project_root / "config"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.config_dir / "provider_config.json"
        if not self.path.exists():
            self.save(DEFAULT_CONFIG)

    @staticmethod
    def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
        result = json.loads(json.dumps(base))
        for key, value in (overlay or {}).items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = ProviderConfigStore._deep_merge(result[key], value)
            else:
                result[key] = value
        return result

    @staticmethod
    def _migrate_hchat_catalog(data: dict[str, Any]) -> dict[str, Any]:
        """Normalize the H-Chat GPT/Gemini/Claude catalog to the V0.55 user-approved models.

        The H-Chat dropdown intentionally exposes only the explicitly requested models.
        Arbitrary/future model experiments belong in the Custom API provider.
        """
        hchat = data.setdefault("hchat", {})
        # V0.55 exposes exactly one user-approved H-Chat model per GPT/Gemini/Claude backend.
        # The dropdown structure remains, so a future approved model can be added without redesign.
        hchat["gpt_model"] = "gpt-5.6-terra"
        hchat["gpt_model_options"] = ["gpt-5.6-terra"]
        hchat["gemini_model"] = "gemini-3.7-flash"
        hchat["gemini_model_options"] = ["gemini-3.7-flash"]

        hchat["claude_model"] = "claude-sonnet-5"
        hchat["claude_model_options"] = ["claude-sonnet-5"]

        base_url = str(hchat.get("base_url") or "").strip()
        if not base_url:
            hchat["base_url"] = "https://internal-apigw-kr.hmg-corp.io/hchat-in/api/v3"
        elif "/api/v2" in base_url:
            hchat["base_url"] = base_url.replace("/api/v2", "/api/v3")

        # V0.55 H-Chat Claude is standardized on the corporate v3 Messages endpoint.
        hchat["claude_protocol"] = "hchat_messages_v3"
        hchat["claude_base_url"] = ""
        hchat["claude_endpoint"] = "claude/messages"
        hchat.pop("claude_api_version", None)
        hchat["claude_supports_images"] = True
        hchat.setdefault("claude_max_tokens", 4096)
        hchat.setdefault("claude_thinking_mode", "disabled")
        return data

    @staticmethod
    def _migrate_openai_commercial_catalog(data: dict[str, Any]) -> dict[str, Any]:
        """Upgrade V0.113's single mini-model catalog without changing other providers.

        Always show the four current official models in the main OpenAI dropdown.
        Preserve independently entered custom models instead of discarding a user's
        actual API choices. Treat the old shipped gpt-5-mini as a legacy default.
        """
        openai = data.setdefault("commercial", {}).setdefault("openai_api", {})
        current = str(openai.get("model") or "").strip()
        if not current or current == "gpt-5-mini":
            current = OPENAI_COMMERCIAL_MODELS[0]
        prior = [str(x).strip() for x in (openai.get("model_options") or []) if str(x).strip()]
        extra = [x for x in prior if x not in OPENAI_COMMERCIAL_MODELS and x != "gpt-5-mini"]
        if current not in OPENAI_COMMERCIAL_MODELS and current not in extra:
            extra.insert(0, current)
        openai["model"] = current
        openai["model_options"] = list(OPENAI_COMMERCIAL_MODELS) + extra
        return data

    @staticmethod
    def _migrate_gemini_commercial_catalog(data: dict[str, Any]) -> dict[str, Any]:
        """Promote the V0.117 stock 2.5 Flash model to current official catalog.

        Preserve actual user-selected models (other than shipped legacy default),
        custom model choices, authentication settings and chosen timeouts.
        """
        gemini = data.setdefault("commercial", {}).setdefault("gemini_api", {})
        current = str(gemini.get("model") or "").strip()
        if not current or current == "gemini-2.5-flash":
            current = GEMINI_COMMERCIAL_MODELS[0]
        previous = [str(x).strip() for x in (gemini.get("model_options") or []) if str(x).strip()]
        extras = [x for x in previous if x not in GEMINI_COMMERCIAL_MODELS and x != "gemini-2.5-flash"]
        if current not in GEMINI_COMMERCIAL_MODELS and current not in extras:
            extras.insert(0, current)
        gemini["model"] = current
        gemini["model_options"] = list(GEMINI_COMMERCIAL_MODELS) + extras
        return data

    @staticmethod
    def _migrate_claude_commercial_catalog(data: dict[str, Any]) -> dict[str, Any]:
        claude = data.setdefault("commercial", {}).setdefault("claude_api", {})
        current = str(claude.get("model") or "").strip()
        if not current or current == "claude-sonnet-4-5":
            current = CLAUDE_COMMERCIAL_MODELS[0]
        previous = [str(x).strip() for x in (claude.get("model_options") or []) if str(x).strip()]
        extras = [x for x in previous if x not in CLAUDE_COMMERCIAL_MODELS and x != "claude-sonnet-4-5"]
        if current not in CLAUDE_COMMERCIAL_MODELS and current not in extras:
            extras.insert(0, current)
        claude["model"] = current
        claude["model_options"] = list(CLAUDE_COMMERCIAL_MODELS) + extras
        return data

    def load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        merged = self._deep_merge(DEFAULT_CONFIG, data)
        # V0.117: migrate the stock V0.116 OpenAI timeout without discarding an
        # independently customized limit. Do not touch H-CHAT, Gemini or Claude.
        old_openai = (data.get("commercial") or {}).get("openai_api") or {}
        if ("reasoning_effort" not in old_openai
                and old_openai.get("timeout_seconds") == 120):
            merged["commercial"]["openai_api"]["timeout_seconds"] = 300
        # V0.118 stock migration: the legacy Gemini 120s default should not
        # silently override the new 300s. Respect any custom timeout.
        old_gemini = (data.get("commercial") or {}).get("gemini_api") or {}
        if ("thinking_level" not in old_gemini
                and old_gemini.get("timeout_seconds") == 120):
            merged["commercial"]["gemini_api"]["timeout_seconds"] = 300
        merged = self._migrate_hchat_catalog(merged)
        merged = self._migrate_openai_commercial_catalog(merged)
        merged = self._migrate_gemini_commercial_catalog(merged)
        old_claude = (data.get("commercial") or {}).get("claude_api") or {}
        # Only convert the V0.118 stock limit; preserve separately customized settings.
        if ("reasoning_effort" not in old_claude and old_claude.get("timeout_seconds") == 120):
            merged["commercial"]["claude_api"]["timeout_seconds"] = 300
        if ("reasoning_effort" not in old_claude and old_claude.get("max_tokens") == 4096):
            merged["commercial"]["claude_api"]["max_tokens"] = 32768
        return self._migrate_claude_commercial_catalog(merged)

    def save(self, data: dict[str, Any]) -> None:
        self.path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def update_selection(
        self,
        provider_id: str,
        *,
        model: str | None = None,
    ) -> dict[str, Any]:
        """Persist provider/model selection without hard-coding one backend.

        V0.36 goal: every provider can expose a model dropdown and the selected model
        can be swapped through config rather than code edits.
        """
        data = self.load()
        provider_id = str(provider_id or "hchat_gpt")
        data["selected_provider"] = provider_id

        if provider_id == "hchat_gpt":
            data["hchat"]["backend"] = "gpt"
            if model:
                data["hchat"]["gpt_model"] = model
        elif provider_id == "hchat_gemini":
            data["hchat"]["backend"] = "gemini"
            if model:
                data["hchat"]["gemini_model"] = model
        elif provider_id == "hchat_claude":
            data["hchat"]["backend"] = "claude"
            if model:
                data["hchat"]["claude_model"] = model
        elif provider_id == "alira":
            if model:
                data["alira"]["model"] = model
        elif provider_id == "custom_api":
            if model:
                data["custom"]["model"] = model
        elif provider_id in data.get("commercial", {}):
            if model:
                data["commercial"][provider_id]["model"] = model
        self.save(data)
        return data

    def update_alira_connection(
        self,
        *,
        license_path: str | None = None,
        model: str | None = None,
        api_base: str | None = None,
    ) -> dict[str, Any]:
        data = self.load()
        alira = data.setdefault("alira", {})
        if license_path is not None:
            alira["license_path"] = str(license_path or "").strip()
        if model:
            alira["model"] = str(model).strip()
            options = [str(x).strip() for x in (alira.get("model_options") or []) if str(x).strip()]
            if alira["model"] not in options:
                options.insert(0, alira["model"])
            alira["model_options"] = options
        if api_base:
            alira["api_base"] = str(api_base).strip()
        data["selected_provider"] = "alira"
        self.save(data)
        return data

    def update_custom(
        self,
        *,
        profile: str,
        base_url: str,
        model: str,
        model_options: list[str] | None = None,
        api_key_required: bool,
        auth_mode: str = "bearer",
        api_key_name: str = "Authorization",
        version_header_name: str = "",
        version_header_value: str = "",
        supports_images: bool,
    ) -> dict[str, Any]:
        data = self.load()
        custom = data.setdefault("custom", {})
        options = [str(x).strip() for x in (model_options or []) if str(x).strip()]
        if model and model not in options:
            options.insert(0, model)
        custom.update({
            "profile": str(profile or "openai_compatible"),
            "base_url": str(base_url or "").strip(),
            "model": str(model or "").strip(),
            "model_options": options,
            "api_key_required": bool(api_key_required),
            "auth_mode": str(auth_mode or "bearer"),
            "api_key_name": str(api_key_name or "").strip(),
            "version_header_name": str(version_header_name or "").strip(),
            "version_header_value": str(version_header_value or "").strip(),
            "supports_images": bool(supports_images),
        })
        data["selected_provider"] = "custom_api"
        self.save(data)
        return data

    def update_commercial(self, provider_id: str, **updates: Any) -> dict[str, Any]:
        """Save only the selected commercial provider, without touching H-Chat/ALIRA/Other."""
        if provider_id not in ("openai_api", "gemini_api", "claude_api"):
            raise ValueError(f"지원하지 않는 상용 AI: {provider_id}")
        data = self.load()
        previous = data.setdefault("commercial", {}).setdefault(provider_id, {})
        allowed = {
            "profile", "base_url", "model", "model_options", "api_key_required",
            "auth_mode", "api_key_name", "version_header_name", "version_header_value",
            "supports_images",
        }
        for key, value in updates.items():
            if key in allowed:
                previous[key] = value
        model = str(previous.get("model") or "").strip()
        options = [str(x).strip() for x in previous.get("model_options", []) if str(x).strip()]
        if model and model not in options:
            options.insert(0, model)
        previous["model_options"] = options
        data["selected_provider"] = provider_id
        self.save(data)
        return data
