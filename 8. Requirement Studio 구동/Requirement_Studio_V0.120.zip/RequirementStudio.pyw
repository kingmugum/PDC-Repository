# -*- coding: utf-8 -*-
"""Requirement Studio V0.120 - double-click to launch (standard library only)."""
from pathlib import Path
import runpy
import tkinter as tk
from tkinter import messagebox

ROOT = Path(__file__).resolve().parent
LAUNCHER = ROOT / 'system' / 'app' / 'ALIRA.pyw'
try:
    if not LAUNCHER.is_file():
        raise FileNotFoundError('system/app/ALIRA.pyw 파일을 찾을 수 없습니다.')
    runpy.run_path(str(LAUNCHER), run_name='__main__')
except Exception as error:
    ui = tk.Tk()
    ui.withdraw()
    try:
        messagebox.showerror('Requirement Studio 실행 오류', str(error), parent=ui)
    finally:
        ui.destroy()
    raise
