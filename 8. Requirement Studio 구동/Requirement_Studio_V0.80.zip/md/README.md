# Requirement Studio V0.80

## V0.80 Persistent Human Policy Registry / Review-First Preservation

V0.80 stabilizes the human-guidance feedback loop before the larger SYS/SWE E2E expansion planned for V0.80.

- Approved GP/HP policies live outside the version folder in `%LOCALAPPDATA%\RequirementStudio\human_policy` on Windows (or the documented fallback/override path).
- Package `policy/human_policy_seed.json/.txt` adds only missing Policy IDs and never overwrites an existing local human decision.
- If an engineer edits a generated `guide_person_###.txt` and explicitly marks exactly one YES/NO/CONDITIONAL/DEFER checkbox, the next Run imports that decision into the external Registry, records source SHA/audit history, and suppresses the same resolved question thereafter. AI Suggested Position is never treated as human approval.
- Every Run exports `guide_person/applied_policy_snapshot.txt/.json` so the applied/reused policy context is readable and auditable.
- `REVIEW_REQUIRED/HOLD` Requirements remain visible in the Main Requirement Specification with `사람의 판단 필요` status and also remain in Review/Allocation views. Main visibility is not Official Release approval.
- V0.78 findings are hardened: actual Deferred Intent counting excludes title/header rows, exact-cited provenance can be trace-completed conservatively, and fact-level allocation reason takes precedence over a misleading SOURCE_INSUFFICIENT label.

Current Requirements baseline: `Requirement_Studio_Requirements_Management_rev64.xlsx` (append-only from rev63; V0.80 FR-423~431).

# Requirement Studio V0.78

## V0.78 GUIDE_PERSON / Deterministic Defect Hardening

V0.78 keeps the V0.77 practical controller-software promotion policy and adds a new human-policy question handoff. The goal is not to ask an engineer to approve every SRS repeatedly, but to compress repeated review patterns into a small set of stable cross-document policy questions.

- `automatic_evaluation/guide_person/guide_person_###.txt` and `guide_person_questions.json` are generated alongside CHECK_SITUATION and FINAL_RESULT.
- Stable question families include inferred controller-software promotion, candidate SWE.6 generation before allocation sign-off, mixed-domain parent handling, OPEN Semantic Unit disposition, and context-dependent shared Source facts.
- Each question exposes YES / NO / CONDITIONAL / DEFER, AI suggested position, observed examples, and intended reuse scope.
- V0.78 is **question-generation only**: answers are not persisted or applied automatically. A Human Policy Registry is deliberately deferred until the questions are validated across multiple Sources.
- Deterministic Tool defects are never delegated to GUIDE_PERSON.

V0.78 also repairs findings from the V0.77 MLM/ESTRACK runs:

- allocation-pending Deferred Intents now contribute to Review summary totals, restoring count single-truth with the serialized SWE.6 workbook;
- hex provenance matching is case-insensitive (`0X0 == 0x0`) while raw Source spelling remains unchanged;
- a physical Source Fragment with divergent parent-context allocations is represented through deterministic `SRC-FRAGCTX-*` aliases linked back to the original fragment;
- mixed-domain Main SWE.1 scope isolation applies to every operative field, not only Requirement Text;
- exact-cited high-confidence non-SW clauses can receive conservative provenance completion when material overlap exists.

Current Requirements baseline: `Requirement_Studio_Requirements_Management_rev62.xlsx` (append-only from rev61; FR-408~414).

## V0.76 Package Hygiene / Situation Check

V0.76 intentionally keeps V0.75 requirement extraction and allocation behavior unchanged while adding two operational capabilities.

- Historical `04_CHANGE_DECISION_*.txt` files move to `history/change_decisions/`.
- Historical Requirements workbooks move to `history/requirements/`; only `Requirement_Studio_Requirements_Management_rev60.xlsx` remains in the root.
- Root Markdown operating documents live under `md/`.
- `ReviewExchangeBuilder` resolves the current Change Decision from the history path and still copies the basename into each Run.
- Automatic evaluation now generates `automatic_evaluation/check_situation/check_situation_###.txt` with the same self-identifying, max-110-line handoff pattern used by FINAL_RESULT.
- `check_situation` compares Canonical SRS, Main SWE.1, Pending Annex, SWE.6 eligibility/deferred state, TC count, positive SW evidence, allocation status and Semantic coverage to test whether conservative allocation policy is the main reason for low output.
- V0.76 is diagnostic only: no positive-SW allocation or Source-fidelity/hallucination policy is relaxed automatically.
- Current Requirements baseline: `Requirement_Studio_Requirements_Management_rev60.xlsx` (append-only from rev59; FR-397~400).



## V0.75 Engineering Token Boundary / Shared Critical Ownership

V0.75 is a focused Tool Quality hardening release based on the V0.74 Unified FINAL_RESULT run for `260721_실시간_감시모드_사양서_ESTRACK.pdf`.

- ASCII engineering-token boundaries replace Unicode `\b` where Source identifiers/timing/retry literals can be followed directly by Korean particles or prose.
- `SVM_Typ2의`, `ICMU_RealTimeMonStat를`, `5초동안`, and `1회재시도` remain extractable as exact Source facts without inventing new tokens.
- Dominant-parent cleanup no longer removes a shared Source Fact Fragment from a claimant when the fragment carries a critical signal/timing/hex/retry token explicitly asserted by that claimant's Canonical behavior.
- Non-critical clear parent-child leakage continues to use the V0.74 dominant-parent rule.
- SW allocation pending, OPEN Semantic Units, visual evidence absence, Source conflicts, and missing approved Gold remain Artifact/Release Governance items and are not auto-resolved.
- Current Requirements baseline: `Requirement_Studio_Requirements_Management_rev59.xlsx` (append-only from rev58; FR-395~396).

## V0.74 Source-bounded Critical Facts / Parent Containment / Visual Gap

V0.74 keeps the Unified End-to-End evaluation flow and refines V0.73 trace ownership based on the next blind run.

- Timing literals such as `5초`, `5 초`, `500ms` are recognized without misclassifying communication bitrate such as `500 Kbit/s`.
- Critical Fact completion may recover a literal fragment from a neighboring Semantic Unit only when it is on an explicitly cited Source location and contains the missing critical token.
- Clear shared-fragment leakage is resolved to the materially dominant parent SRS; ambiguous legitimate sharing stays `SHARED_REVIEW_REQUIRED`.
- Requirements already declaring diagram/image dependency receive `UNANALYZED_VISUAL_ASSET` Gap/TBD records when Vision evidence is unavailable; visual semantics remain UNKNOWN.
- Explicit OPEN/non-terminal `REVIEW_NEEDED` is treated as Artifact Readiness/Release Governance rather than Tool Quality defect by itself.
- Current Requirements baseline is `Requirement_Studio_Requirements_Management_rev58.xlsx`; rev57 approved rows were preserved and V0.74 requirements were appended.

## V0.73 Exact Fact Fragment Ownership Precision

V0.73 keeps the Unified End-to-End evaluation flow and hardens Source Fact Fragment ownership precision based on V0.72 FINAL_RESULT findings.

- Exact critical-fact ownership is evaluated over the union of all exact Source Fact Fragments linked to one SRS.
- Audit evidence exposes `owned_fragment_fact_token_sources` so every owned signal/timing/enum/retry token can be traced to one or more fragment IDs.
- Critical-fact-aware completion may add a missing fragment only inside already-matched Source Semantic Units / explicitly cited Source locations and only when the literal critical token is present.
- Broad structured roll-up data cannot create exact ownership for a value absent from the exact fragment literal.
- OPEN Semantic Units, pending SW allocation, unresolved Source conflicts, and missing approved Gold remain review/governance states and are never auto-closed.
- Historical V0.73 baseline was `Requirement_Studio_Requirements_Management_rev57.xlsx`; current V0.74 baseline is rev58.

## V0.72 Unified End-to-End 3-AI Evaluation

V0.72 retains the removal of the old manual H-Chat three-file evaluation constraint from the automatic review path. The default review scope is now `Unified End-to-End`: Source → Canonical/SRS → SWE.1 Word/Excel → Allocation/Eligibility → Child Intent → SWE.6 Excel → Actual Artifact/QA/Regression.

- SWE.1/SWE.6 focused modes remain available only for targeted debugging.
- Automatic evaluation can include every generated review artifact; there is no three-file hand-off limit.
- The evaluator builds one compact Trace/Evidence Graph and artifact snapshots to reduce duplicate token use.
- DOCX table contents are included in evidence, not only paragraphs.
- Missing artifacts that were not selected/generated are not treated as defects.
- `FINAL_RESULT` includes a Completeness Audit proving provider finding occurrences were mapped into consensus.
- `final_result` is split at a maximum of 110 lines per TXT.

## V0.69 결과 품질 검토 진행상황 / SWE.6 평가 Finding 보완

V0.69는 메인 STEP 1~7과 별도로, `결과 품질 검토` 탭에서 3-AI 자동평가의 후속 진행상황을 확인할 수 있게 합니다.

- 단계 기반 자동평가 진행률: Evidence 5% → Reviewer 15~75% → Consensus 82% → Final Result 90% → 파일 검증 96% → 완료 100%
- GPT / Gemini / Claude 각각 `대기 / 진행 중 / 완료 / 실패 / 비활성` 상태 표시
- 완료 후 Tool Quality / Artifact Readiness / Official Release Gate 표시
- `final_result` part 개수와 `final_result 열기` 버튼 제공
- `00_EVALUATION_STATUS.json`을 단일 진행상태 Source로 사용
- V0.68 FINAL_RESULT에서 확인된 `최초B+` Korean/ASCII token boundary ownership 누락 방지
- Mixed-domain Parent expected-result 문구가 SWE.6 TC 설명에 다시 섞이는 경로 차단
- Requirements baseline `rev55`는 byte-for-byte 변경 없음

## V0.68 자동평가 저장 신뢰성 / Gold 외부 폴더 정리

V0.68은 V0.67의 단일 3-AI 자동평가 구조를 유지하면서 실제 사용자 Run에서 확인된 결과 저장 가시성/완료 검증 문제를 보강합니다.

- 자동평가 시작 즉시 `automatic_evaluation/00_EVALUATION_STATUS.json/.txt` 생성
- `06_EVALUATION_EVIDENCE.json`도 `automatic_evaluation` 내부에 저장
- GPT/Gemini/Claude가 각각 끝나는 즉시 JSON/TXT 저장
- 결과 파일은 atomic write + flush/fsync 후 공개
- 모든 필수 파일/크기 검증 후에만 `3-AI 자동 평가 완료` 로그 출력
- 검증 완료 시 `99_EVALUATION_COMPLETE.ok` 생성
- `final_result` 150줄 분할 유지
- 프로그램 바깥 `Requirement_Studio_Gold_Sources` 폴더 생성 제거
- 선택적 Gold 등록은 프로그램 내부 `review_exchange/gold_sources/user_registered` 사용
- Requirements baseline `rev55`는 내용 변경 없이 그대로 유지

자동평가 진행 중에는 폴더가 비어 있지 않아야 하며, 상태는 `00_EVALUATION_STATUS.txt`에서 바로 확인할 수 있습니다.

## V0.67 Reviewer 기능 단일화

V0.67은 V0.66의 실제 3-AI 자동 평가와 V0.45부터 남아 있던 Legacy Reviewer 설정 UI가 중복되는 문제를 정리합니다.

- 실제 Reviewer E2E를 수행하지 않던 `표준 검토` / `중복 검토` / `정밀 검토` 및 1차·2차·3차 Reviewer 선택 UI 제거
- 평가 모드는 `3-AI 자동 평가` / `수동 평가 패키지만 생성` / `평가하지 않음`으로 단일화
- 자동: Review Exchange + GPT/Gemini/Claude 독립 평가 + Consensus/final_result
- 수동: Review Exchange만 생성, 외부 전송 없음
- 없음: Review Exchange/평가용 추가 산출물/외부 호출 모두 생략
- Requirements Baseline을 예외적으로 `rev55`로 갱신하고 FR-316을 실제 동작 기준으로 교체, FR-362~365 추가


V0.66은 V0.65 SWE.6 평가에서 남은 **Fragment Trace / 최소 Ownership / Cross-domain TC Scope**를 보강하고,
수동 H-Chat 평가 절차를 **GPT + Gemini + Claude 독립 3-AI 자동 평가**로 연결한 Hardening Build입니다.

핵심 원칙은 동일합니다.

> Source에 없는 사실은 만들지 않고, Source에 존재하는 사실은 Fragment → Canonical/SRS → Child Intent → SWE.6까지 동일한 identity로 전달하며, 평가 AI는 생성 AI와 독립적으로 동일 Evidence를 검토합니다.

## V0.66 핵심 변경

1. **Fragment → Child Intent Trace 완결**
   - 기존 Atomic Behavior가 Source Fragment와 일치하면 `source_fact_fragment_id`를 강제 전파합니다.
   - Fragment를 소유하면서 Child Intent에 Fragment ID가 없으면 Tool Quality finding으로 검출합니다.

2. **Minimum Material Fragment Ownership**
   - Composite paragraph 전체를 소유하지 않고 Canonical behavior와 직접 관련된 최소 Fragment만 소유합니다.
   - receive/store 또는 receive/control처럼 하나의 요구사항을 구성하는 상보적인 clause는 함께 보존할 수 있습니다.

3. **Mixed-domain SWE.6 TC Scope 제한**
   - 한 SRS에 SWE.6 + SYS.5/External/Allocation Pending fact가 섞여 있어도 TC는 SWE.6 Eligible fact만 주장합니다.
   - 제외된 fact는 Audit/Deferred 근거로 남습니다.

4. **Capture Export Contract**
   - R:U Result boundary 유지.
   - U열 `Capture CANoe (Optional)` header 존재 자체를 실제 XLSX에서 검증합니다.
   - Output Value / PASS-FAIL / Comment / Capture는 실행 전 모두 물리적 Blank여야 합니다.

5. **3-AI 자동 평가**
   - Review Package 생성 후 GPT / Gemini / Claude가 동일 Evidence를 독립 평가합니다.
   - 기본 transport는 기존 H-Chat입니다.
   - `config/evaluation_api_config.json`에서 `direct_api`로 변경할 수 있습니다.
   - API Key는 ZIP에 포함하지 않습니다.

6. **Structured Result + Consensus**
   - 각 Reviewer의 JSON/TXT를 저장합니다.
   - Consensus Finding을 3/3, 2/3, 1/3으로 구분합니다.
   - 일부 Reviewer만 성공한 경우 자동 Official Release PASS를 금지합니다.

7. **final_result 110줄 자동 분할**
   - `automatic_evaluation/final_result/FINAL_RESULT_001.txt ...`
   - 파일당 최대 110줄.
   - `manifest.json`에 line count와 SHA-256을 기록합니다.

## 자동 평가 결과 위치

```text
review_exchange/<run>/automatic_evaluation/
├─ 01_GPT_EVALUATION.json / .txt
├─ 02_GEMINI_EVALUATION.json / .txt
├─ 03_CLAUDE_EVALUATION.json / .txt
├─ 04_EVALUATION_CONSENSUS.json / .txt
├─ 05_EVALUATION_RESULT.json
├─ AUTOMATIC_EVALUATION_MANIFEST.json
└─ final_result/
   ├─ FINAL_RESULT_001.txt
   ├─ FINAL_RESULT_002.txt ...
   └─ manifest.json
```

## 설정

- GUI 기본값: `3-AI 자동 검토 (추천)` + 자동 평가 ON
- 자동 평가 OFF: Review Package까지만 생성, 외부/H-Chat 전송 없음
- 기본 transport: `hchat`
- direct API: `config/evaluation_api_config.json` 참고
- 상세: `docs/V0.68_AUTOMATED_EVALUATION_SETUP.txt`

## Regression

- 전체 Python regression: 95 tests
- 신규: `tests/test_v066_evaluation_automation_traceability.py`
- 실제 Official Release 판단은 신규 Source E2E + 승인 Gold regression 결과와 별도로 수행해야 합니다.


## V0.72 Traceability / Handoff hardening
- FINAL_RESULT self-identifies Version, Evaluation Mode, Source filename/SHA-256, Run ID, evaluated artifacts and Evidence SHA-256.
- Every 110-line FINAL_RESULT part repeats compact identity metadata, so no separate sample title/message is required.
- Provenance token audit uses one structured Source-fact value stream and no longer serializes metadata keys as facts.
- Critical Canonical signal/timing/enum/retry facts must be owned by an exact Fact Fragment or fragment-linked Child Intent.
- Eligible Semantic Units with REVIEW_NEEDED are explicitly OPEN/non-terminal until linked or intentionally dispositioned.

## V0.80 — Persistent Human Policy Registry / Review Preservation

- GUIDE_PERSON policy decisions are persisted outside the extracted version folder and reused across Runs and future versions.
- Package seed (`policy/human_policy_seed.json/.txt`) bootstraps missing policy IDs only; local human decisions are never overwritten.
- Each Run exports `applied_policy_snapshot.json/.txt` so reviewers can see exactly which policies were reused.
- Engineers can mark exactly one checkbox in a generated `guide_person_###.txt`; the next Run imports that explicit decision into the external Registry with source-file SHA/change audit.
- `REVIEW_REQUIRED/HOLD` requirements are preserved in the Main Requirement Specification with a visible `사람의 판단 필요` status and remain available in Review/Allocation views.
- V0.80 also fixes Deferred Intent header over-count, exact-cited Semantic provenance gaps, and fact-level allocation deferred-reason precedence.
- Full SYS/SWE E2E naming/schema expansion is intentionally reserved for V0.80.

## V0.80 Engineering E2E
V0.80 treats Canonical Engineering Requirement as the single preservation layer and projects it to SYS.1/SWE.1 and SYS.5/SWE.6 review views. System/native-domain requirements are no longer discarded merely because they are not SWE.1. System verification candidates are retained even when SWE.6 allocation is not applicable. Legacy SWE.1/SWE.6 filenames remain for compatibility.
