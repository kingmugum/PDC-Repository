from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

from core.document_normalizer import NormalizedDocument
from core.visual_evidence import evidence_block


@dataclass
class PromptPart:
    part_index: int
    part_count: int
    system_message: str
    user_prompt: str


class PromptBuilder:
    """Provider가 바뀌어도 동일한 업무 의미의 Prompt를 만드는 공통 계층."""

    SAFE_REQUEST_CHARS = 180000  # includes the full mandatory constitution and overhead
    MIN_SOURCE_CHARS = 800

    def __init__(self, project_root: Path):
        root = Path(project_root).resolve()
        self.root = root
        self.policy_path = root / "policy" / "requirement_judgment_policy.json"
        self.invariants_path = root / "policy" / "protected_invariants.json"
        self.schema_path = root / "contracts" / "canonical_requirement_schema.json"
        self.extraction_schema_path = root / "contracts" / "extraction_requirement_schema_v1_1.json"
        self.reference_path = root / "reference_library" / "reference_examples.json"
        self.authoring_guide_path = root / "reference" / "OUTPUT_AUTHORING_GUIDE.md"
        self.e2e_guide_path = root / "Build AI Better Decision" / "Decision Complete" / "AI_E2E_GUIDELINE_CONSTITUTION.txt"
        self.e2e_judgment_examples_path = root / "policy" / "e2e_user_judgment_examples_v0110.json"

    @staticmethod
    def _json_min(path: Path):
        return json.loads(path.read_text(encoding="utf-8"))

    def _compact_reference(self) -> dict:
        data = self._json_min(self.reference_path)
        swe1 = []
        for item in data.get("swe1_examples", []):
            fields = item.get("fields", {})
            swe1.append({
                "project": item.get("project"),
                **{k: v for k, v in fields.items() if v not in (None, "")},
            })
        swe6 = []
        for item in data.get("swe6_examples", []):
            fields = item.get("fields", {})
            swe6.append({k: v for k, v in fields.items() if v not in (None, "")})
        return {
            "purpose": data.get("purpose"),
            "swe1_examples": swe1,
            "swe6_examples": swe6,
        }

    def _matched_user_judgment_examples(self, doc: NormalizedDocument, *, limit: int=5) -> str:
        """Select a few *principles*, not private customer specimen text.

        Examples can inform AI's requirement extraction without promoting them
        as customer facts or claiming H-CHAT weight training.
        """
        if not self.e2e_judgment_examples_path.is_file():
            return ""
        try:
            examples=json.loads(self.e2e_judgment_examples_path.read_text(encoding='utf8')).get('examples',[])
        except (OSError,ValueError):
            return ""
        source=' '.join(str(c.text or '') for c in doc.chunks).lower()
        rules={
            'AND':('and','모두','동시에','및','와','과'),
            'OR':('or','또는','하나 이상','어느 하나'),
            'XOR':('xor','정확히 하나','둘 중 하나만'),
            'NOR':('nor','어느 것도','모두 없음'),
            'SEQUENCE':('이후','순서','전에','후에','다음','완료 후'),
            'BOUNDARY':('이하','이상','미만','초과','경계'),
            'TIMING':('ms','지연','시간','timeout'),
            'FAULT':('오류','실패','단선','단락','고장'),
            'COUNTER':('연속','횟수','회 이상'),
            'HYSTERESIS':('히스테리시스','복귀 임계','차단 임계'),
            'OUTPUTS':('출력','송신','저장'),
            'METHOD':('watchdog','정적','isr'),
        }
        scored=[]
        for ex in examples:
            kind=str(ex.get('pattern_kind') or '')
            score=sum(1 for term in rules.get(kind,()) if term in source)
            score+=sum(1 for term in str(ex.get('scenario') or '').split() if len(term)>=4 and term.lower() in source)
            if score:
                scored.append((score,ex))
        scored.sort(key=lambda t:(-t[0],t[1].get('id','')))
        selected=[ex for _,ex in scored]  # no silent fixed-count omission
        if not selected:
            selected=[ex for ex in examples if ex.get('id') in {'Q01','Q04','Q20'}]
        lines=[]
        for ex in selected:
            lines.append(f"{ex.get('id')}: 유형={ex.get('pattern_kind')}; 사용자 판단={ex.get('user_decision')}; 분할 메모={ex.get('notes')}")
        return '\n'.join(lines)

    @staticmethod
    def _blocks(doc: NormalizedDocument) -> list[str]:
        blocks = []
        max_chunk_chars = 50000
        for c in doc.chunks:
            text = c.text or ""
            if len(text) <= max_chunk_chars:
                blocks.append(f"[SRC {c.chunk_id} | {c.location} | {c.kind}]\n{text}")
                continue
            parts = [text[i:i + max_chunk_chars] for i in range(0, len(text), max_chunk_chars)]
            for idx, part in enumerate(parts, start=1):
                blocks.append(
                    f"[SRC {c.chunk_id}.S{idx} | {c.location} | {c.kind} | CONT {idx}/{len(parts)}]\n{part}"
                )
        for item in getattr(doc, "visual_evidence", []) or []:
            blocks.append(evidence_block(item))
        return blocks

    @staticmethod
    def _pack(blocks: list[str], max_chars: int) -> list[str]:
        """Pack without dropping any source text; split oversized *single* blocks too."""
        if max_chars < 512:
            raise ValueError(f"SOURCE를 안전하게 나눌 공간이 부족합니다: {max_chars}자")
        parts, current, size = [], [], 0
        def flush():
            nonlocal current, size
            if current:
                parts.append("\n\n".join(current))
                current, size = [], 0
        for block in blocks:
            # Keep source markers visible for every split piece.
            if len(block) > max_chars:
                flush()
                marker_match = re.match(r"^(\[[^\n]+\]\n)", block)
                marker = marker_match.group(1) if marker_match else "[SRC SPLIT]\n"
                text = block[len(marker_match.group(1)):] if marker_match else block
                step = max_chars - len(marker) - 40
                if step < 64:
                    raise ValueError("SOURCE 분할 메타데이터가 길어 안전 분할할 수 없습니다.")
                for i in range(0, len(text), step):
                    parts.append(marker + f"[CONT {i//step+1}]\n" + text[i:i+step])
                continue
            bsize = len(block) + (2 if current else 0)
            if current and size + bsize > max_chars:
                flush()
                bsize = len(block)
            current.append(block)
            size += bsize
        flush()
        return parts or [""]

    @staticmethod
    def _required_text(path: Path, label: str) -> str:
        if not path.is_file():
            raise FileNotFoundError(f"필수 AI 판단 자료 누락: {label} ({path})")
        value = path.read_text(encoding="utf-8-sig")
        if not value.strip():
            raise ValueError(f"필수 AI 판단 자료가 비어 있습니다: {label} ({path})")
        return value

    def build_analysis(self, doc: NormalizedDocument) -> list[PromptPart]:
        system = (
            "당신은 자동차/소프트웨어 사양 문서를 분석하는 AI입니다. "
            "제공된 SOURCE 내용만 사용하고 문서에 없는 사실은 만들지 마세요."
        )
        header = (
            f"문서명: {doc.source_document}\n"
            f"문서형식: {doc.source_type}\n"
            f"그림/미디어 수: {len(doc.visual_assets)}\n"
            f"Vision 분석 결과 수: {len(getattr(doc, 'visual_evidence', []) or [])}\n\n"
            "다음 내용을 분석하세요. 아직 Requirement를 생성하지 마세요.\n"
            "1. 문서 목적\n2. 주요 구조\n3. 핵심 내용\n4. 요구사항 후보가 존재하는 영역\n"
            "5. 불명확/추가확인 필요 사항\n"
        )
        available = self.SAFE_REQUEST_CHARS - len(header) - len(system) - 2000
        bodies = self._pack(self._blocks(doc), available)
        return [
            PromptPart(i + 1, len(bodies), system, f"{header}\n[PART {i+1}/{len(bodies)}]\n{body}")
            for i, body in enumerate(bodies)
        ]

    def build_requirement_extraction(self, doc: NormalizedDocument, analysis_context: str = "") -> list[PromptPart]:
        policy = self._json_min(self.policy_path)
        invariants = self._json_min(self.invariants_path)
        schema = self._json_min(self.extraction_schema_path)
        reference = self._compact_reference()
        sample_principles = self._matched_user_judgment_examples(doc)
        authoring_guide = self._required_text(self.authoring_guide_path, "SWE.1 작성 가이드")
        e2e_guide = self._required_text(self.e2e_guide_path, "AI E2E 가이드 헌법 전문")
        # Full, unmodified constitution; precedence is declared explicitly in the system instruction.
        guide_sha256 = hashlib.sha256(e2e_guide.encode("utf-8")).hexdigest()

        system = (
            "당신은 자동차/소프트웨어 Requirement Engineer입니다. "
            "현재 SOURCE가 유일한 factual Source of Truth입니다. "
            "시험설계 정책은 사용자 최신 확정 정책 > 승인 규칙 > 이전 참고 사례 순서로 우선합니다. "
            "헌법은 문서 원문이 아니며, 헌법 속 사례를 현재 SOURCE 사실로 복사하지 마세요. "
            "Reference는 산출물 구조와 판단 패턴만 참고하고 도메인 사실을 복사하지 마세요. "
            "원문에 없는 수치/신호/상태/시간을 만들지 말고 부족하면 Gap/TBD로 표시하세요. "
            "반환은 Markdown 설명 없이 REQ-STUDIO-CANONICAL-REQ-1.1 JSON object 하나만 출력하세요."
        )
        context = (
            "[EDITABLE_JUDGMENT_POLICY]\n"
            + json.dumps(policy, ensure_ascii=False, separators=(",", ":"))
            + "\n\n[PROTECTED_INVARIANTS]\n"
            + json.dumps(invariants, ensure_ascii=False, separators=(",", ":"))
            + "\n\n[OUTPUT_SCHEMA]\n"
            + json.dumps(schema, ensure_ascii=False, separators=(",", ":"))
            + "\n\n[REFERENCE_EXAMPLES]\n"
            + json.dumps(reference, ensure_ascii=False, separators=(",", ":"))
            + "\n\n[SWE1_AUTHORING_GUIDE]\n"
            + authoring_guide
            + "\n\n[AI_E2E_CONSTITUTION_FULL_NOT_SOURCE]\n"
            + "다음은 AI E2E 가이드 헌법 원문 전체이며 SOURCE가 아닙니다. 예시를 사실로 사용하지 말고 사용자 최신 확정 정책을 우선합니다.\n"
            + e2e_guide
            + f"\n[AI_E2E_CONSTITUTION_SHA256]={guide_sha256}"
            + "\n\n[V0.112_RELEVANT_USER_JUDGMENT_EXAMPLES_NOT_SOURCE]\n"
            + sample_principles
            + "\n\n[STEP4_ANALYSIS_REFERENCE_NOT_SOURCE]\n"
            + str(analysis_context or "")
            + f"\n\n[DOCUMENT_META]\nname={doc.source_document};type={doc.source_type};visuals={len(doc.visual_assets)};visual_evidence={len(getattr(doc, 'visual_evidence', []) or [])}"
        )
        available = self.SAFE_REQUEST_CHARS - len(context) - len(system) - 4500
        if available < self.MIN_SOURCE_CHARS:
            raise ValueError("헌법·정책·스키마를 무절단 전달할 경우 SOURCE 입력 공간이 부족합니다. "
                             f"context={len(context)} / budget={self.SAFE_REQUEST_CHARS}")
        bodies = self._pack(self._blocks(doc), available)
        prompts = []
        for i, body in enumerate(bodies):
            part_note = (
                f"[PART {i+1}/{len(bodies)}]\n"
                "이 PART에 포함된 SOURCE만 근거로 Requirement Candidate를 추출하세요. "
                "요구사항 수를 미리 정하지 말고 Feature > Parent SRS > Atomic Fact/BF 구조로 판단하세요. 같은 coherent function/responsibility/state relationship의 여러 Source-backed Fact는 하나의 Parent SRS 아래 보존할 수 있으며 Fact 수만으로 SRS를 기계적으로 분할하지 마세요. 기능적으로 독립하거나 ownership/allocation/change/release를 별도 관리해야 할 의무만 별도 SRS 분할을 검토하세요. "
                "category는 기능/비기능/검토 필요 중 하나로 정리하고 classification_basis에 입력문서 명시/규칙 기반 추론/검토 필요 근거를 남기세요. "
                "activation_trigger와 preconditions를 Source가 허용하는 범위에서 구분하고, behavior_flows는 실제 상세 순서가 있을 때만 작성하세요. "
                "V0.123 FLOWCHART: 입력 SOURCE에 흐름도/화살표/결정 다이아그램/시나리오 표가 있으면 텍스트 설명과 그림 분석 근거를 대조하여 ① 진입 조건 ② 분기(참/거짓/거절/실패/예외) ③ 요청-응답·시퀀스 ④ 도착 결과를 구분하세요. "
                "서로 다른 관찰 결과 또는 독립 검증 목적은 scenario_candidates의 별도 경로로 남기고, 관련 Requirement의 behavior_flows·source_evidence에도 보존하세요. 경로 수나 요구사항 수를 임의로 제한하지 마세요. "
                "종속된 요청→응답→동작은 같은 경로의 Step으로 연결하되, 서로 다른 분기/PASS 결과는 하나의 일반 TC로 임의 합치지 마세요. "
                "반대 분기를 문맥에서 해석한 경우 원문 명시와 구분하고, 후속 연결·종료·모터 정지 등 SOURCE에 없는 결과는 만들어내지 마세요. 부족한 부분은 gap/clarification_needed에 기록하세요. "
                "기본/상세 조건, 사용자 동의·거절, 상태 천이 성공·실패, 사전·회전·사후 단계, 동작 중 조건 불만족, 리턴·초기화 등 서로 다른 분기가 실제 SOURCE에 있으면 빠뜨리지 마세요. 이 항목들은 예시일 뿐 SOURCE에 없는 경로는 생성하지 마세요. "
                "evaluation_method, exception_conditions, related_artifacts는 Source에 근거가 있을 때만 작성하고 없으면 빈 값/빈 list로 두세요. "
                "모든 Requirement에 source_evidence(document/location/text)를 넣으세요. "
                "SOURCE에 명시적인 Requirement ID가 있으면 그 ID의 고유 behavior를 누락하지 마세요. 같은 PART의 명시 ID마다 (a) Canonical Requirement의 실제 requirement/behavior_flows에 핵심 trigger/action/output/constraint가 보존되거나, (b) Source만으로 Canonical화가 불가능한 이유가 Gap으로 남아야 합니다. "
                "여러 Source ID를 하나의 Requirement로 묶을 수는 있지만, 단지 인접해 있다는 이유로 ID를 붙이지 말고 각 ID의 서로 다른 behavior를 requirement 본문 또는 behavior_flows에 명시적으로 보존하세요. 특히 상태전이, timing/parameter 적용, 주기 송신, interface output, variant/configuration 동작은 다른 관련 기능에 흡수되어 사라지면 안 됩니다. "
                "Explicit Source ID를 source_evidence에 연결했지만 그 ID의 핵심 behavior가 Requirement 본문/behavior_flows에 표현되지 않는 Source-ID-only linkage를 만들지 마세요. "
                "Explicit/Implicit은 derivation_type으로 구분하고 Implicit은 derivation_reason을 작성하세요. "
                "최종 SWE.6 Excel/Test Case를 AI 응답에서 직접 생성하지 마세요. Requirement Studio가 Canonical Requirement를 기준으로 로컬 SWE.6 Exporter에서 파생합니다."
            )
            user_prompt = f"{context}\n\n{part_note}\n\n[SOURCE]\n{body}"
            if len(user_prompt) + len(system) > self.SAFE_REQUEST_CHARS:
                raise ValueError(f"요구사항 요청이 설정된 안전 크기를 초과했습니다: {len(user_prompt)}")
            prompts.append(PromptPart(i + 1, len(bodies), system, user_prompt))
        return prompts
    def build_requirement_recovery_parts(
        self,
        failed_part: PromptPart,
        *,
        max_source_blocks: int = 4,
        max_source_chars: int = 12000,
    ) -> list[PromptPart]:
        """Split a malformed/truncated Requirement response source into smaller retry prompts.

        The source blocks remain non-overlapping. This reduces model output size instead of
        asking the model to repair a potentially truncated giant JSON object.
        """
        marker = "\n\n[SOURCE]\n"
        if marker not in failed_part.user_prompt:
            return [failed_part]

        prefix, source = failed_part.user_prompt.split(marker, 1)
        blocks = [x.strip() for x in re.split(r"(?=^\[SRC )", source, flags=re.MULTILINE) if x.strip()]
        if not blocks:
            blocks = [source.strip()]

        groups: list[list[str]] = []
        current: list[str] = []
        current_chars = 0
        for block in blocks:
            # Very large single block: split conservatively by character count only as a fallback.
            block_parts = [block]
            if len(block) > max_source_chars:
                block_parts = [block[i:i + max_source_chars] for i in range(0, len(block), max_source_chars)]
            for item in block_parts:
                item_chars = len(item) + 2
                if current and (len(current) >= max_source_blocks or current_chars + item_chars > max_source_chars):
                    groups.append(current)
                    current = []
                    current_chars = 0
                current.append(item)
                current_chars += item_chars
        if current:
            groups.append(current)

        if len(groups) <= 1:
            return [failed_part]

        result: list[PromptPart] = []
        count = len(groups)
        for idx, group in enumerate(groups, start=1):
            note = (
                f"[AUTO_RECOVERY_SPLIT {idx}/{count}]\n"
                "이전 응답이 완전한 JSON으로 종료되지 않아 SOURCE를 더 작은 단위로 재추출합니다. "
                "이 SOURCE 조각에 근거한 항목만 생성하고, 반드시 시작부터 끝까지 완전한 JSON object 하나로 종료하세요. "
                "다른 조각의 내용을 추정하거나 이어서 만들지 마세요."
            )
            user_prompt = f"{prefix}\n\n{note}{marker}" + "\n\n".join(group)
            result.append(PromptPart(idx, count, failed_part.system_message, user_prompt))
        return result

