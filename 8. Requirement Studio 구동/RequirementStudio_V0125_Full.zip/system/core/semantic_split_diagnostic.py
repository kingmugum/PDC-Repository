"""Read-only diagnostic of observable semantic TC design decisions (V0.109).

Never recovers model private reasoning, never invokes an AI provider, never copies
source paragraphs or credential-bearing configuration values into the report.
It records rule order, skipped semantic passes, candidate type counts, and
coverage *signals* rather than asserting that missing candidate == missed TC.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import re
from typing import Any


def _list(v: Any) -> list[Any]:
    return v if isinstance(v, list) else ([v] if v else [])


def _text(v: Any, limit: int = 110) -> str:
    s = re.sub(r"\s+", " ", str(v or "")).strip()
    return s[:limit] + ("…" if len(s) > limit else "")


def prompt_guide_visibility(root: Path | None = None) -> dict[str, Any]:
    """Read static *configuration*, not a record of actual sent prompts."""
    root = Path(root) if root else Path(__file__).resolve().parents[1]
    guide = root / 'Build AI Better Decision' / 'Decision Complete' / 'AI_E2E_GUIDELINE_CONSTITUTION.txt'
    if not guide.is_file():
        return {'guide_file_found': False, 'editorial_chars': 0, 'editorial_sent_limit': None,
                'editorial_truncated_chars': 0, 'note': '가이드 파일 없음. 실제 AI 호출 여부는 확인할 수 없음.'}
    contents = guide.read_text(encoding='utf-8-sig')
    a,b='[USER_EDITORIAL_GUIDE_START]','[USER_EDITORIAL_GUIDE_END]'
    editorial = contents.split(a,1)[1].split(b,1)[0].strip() if a in contents and b in contents else ''
    priority=contents.split('[V0.110_USER_POLICY_START]',1)[1].split('[V0.110_USER_POLICY_END]',1)[0].strip() if '[V0.110_USER_POLICY_START]' in contents and '[V0.110_USER_POLICY_END]' in contents else ''
    return {'guide_file_found': True, 'total_chars': len(contents),
            'priority_policy_chars': len(priority), 'priority_policy_limit': None,
            'editorial_chars': len(editorial), 'editorial_sent_limit': None,
            'editorial_truncated_chars': 0,
            'approved_tail_ref_chars': 0,
            'note':'V0.122부터 AI E2E 헌법 전문을 요구사항 추출에 포함하도록 구성했습니다. 이 출력은 정적 설정 점검이며 실제 API 수신 여부를 보증하지 않습니다.'}


def build_semantic_split_diagnostic(*, source_document: Path,
    cases: list[dict[str,Any]], human_ids: list[str],
    reqs: dict[str,dict[str,Any]], design_audit: dict[str,Any] | None = None,
    workbook_name: str = '', project_root: Path | None = None,
    now: datetime | None = None, max_groups: int | None = None,
    scenario_candidates: list[dict[str, Any]] | None = None) -> str:
    if len(cases) != len(human_ids):
        raise ValueError('진단 대상 TC와 ID 개수가 일치하지 않습니다.')
    audit=design_audit or {}
    events=[ev for ev in _list(audit.get('semantic_split_diagnostic_events')) if isinstance(ev,dict)]
    casegroups:dict[str,list[tuple[str,dict[str,Any]]]]=defaultdict(list)
    for tcid,case in zip(human_ids,cases):
        casegroups[str(case.get('parent_srs_id') or '미확인')].append((tcid,case))
    byparent:dict[str,list[dict[str,Any]]]=defaultdict(list)
    for event in events:
        byparent[str(event.get('parent_srs_id') or '미확인')].append(event)
    count_skipped=sum(1 for e in events if e.get('semantic_evaluation')=='SKIPPED_AFTER_PRECEDING_RULE')
    count_augmented=sum(1 for e in events if e.get('semantic_evaluation')=='AUGMENTED_AFTER_PRECEDING_RULE')
    counts=Counter(str(c.get('basic_case_kind') or c.get('test_design_mode') or '미기록') for c in cases)
    guide=prompt_guide_visibility(project_root)
    lines=[
        'Requirement Studio V0.125 | E2E 의미 분할 진단', '='*62,
        '생성: '+(now or datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
        '입력 문서: '+Path(source_document).name,
        'E2E 파일: '+(workbook_name or '(미기록)'),
        f'최종 TC {len(cases)}개 / 상위 요구사항 {len(casegroups)}개 / 계측된 분할 경로 {len(events)}개',
        '', '[읽는 법]',
        '이 파일은 실제 로컬 코드가 실행한 규칙·생략 조건·추적 ID를 기록합니다.',
        'AI가 실제로 어떤 의미를 이해했는지 또는 모델의 비공개 판단 경로는 복원하지 않습니다.',
        '검증 목적 후보가 TC로 따로 나오지 않았다고 반드시 누락인 것은 아닙니다. 앞선 규칙이나 Step/Vector에서 처리했을 수 있습니다.',
        '고객 원본 전문, 실제 문장, API 키, 사용자 설정값, 전체 프롬프트는 복사하지 않습니다.',
        '', '[진단 단계 결과]',
        f'1) 원본 요구사항 구조: 전달된 SRS {len(reqs)}건 (원본 파일 직접 재파싱 아님)',
        '2) AI 요구사항 분석: 실제 모델이 이해한 검증 목적 목록은 현재 산출 계약에 없음 → 독립 비교 불가능',
        f'3) 로컬 분할 규칙: 계측 {len(events)}건; 선행 규칙 후 의미 분할 추가 {count_augmented}건; 후속 의미 TC 미적용 {count_skipped}건',
        f'4) 최종 TC: {len(cases)}건; 아래에서 SRS별 적용 경로와 출처 ID를 비교',
        '5) 누락 판단: 별도 의미 후보와 TC의 비교는 *진단 신호*이며 완전성 검증이 아님',
        '', '[AI E2E 가이드 전달 범위: 정적 구성 점검]',
        f"- 가이드 파일 존재: {'예' if guide.get('guide_file_found') else '아니요'}",
        f"- 파일 전체 글자 수: {guide.get('total_chars','미확인')}",
        f"- 최우선 사용자 확정 정책: {guide.get('priority_policy_chars',0)}자 / 헌법 전문에 포함",
        f"- 기존 사용자 작성 원칙: {guide.get('editorial_chars',0)}자 / 헌법 전문 전송 정책(분리 축약 없음)",
        f"- 길이 제한으로 제외될 수 있는 뒤쪽: {guide.get('editorial_truncated_chars',0)}자",
        "- 승인 사례: 헌법 원문에 포함 / Source 사실과 분리",
        '- '+str(guide.get('note','')),
        '', '[생성 분포]',
    ]
    for kind,n in counts.most_common(10):
        lines.append(f'- {_text(kind,55)}: {n}건')
    # V0.110: coarse safety signals for generated prose; do not copy source text.
    integrity=[]
    for tc_id,case in zip(human_ids,cases):
        title=str(case.get('evaluation_name') or '')
        expected=str(case.get('expected_state') or '')
        pre=str(case.get('precondition') or '')
        own=str(case.get('semantic_condition_source') or '')
        flags=[]
        if re.search(r'(?:복구를\s*시|\b[A-Za-z]+\s+to)$',title):
            flags.append('TRUNCATED_TITLE_CANDIDATE')
        if re.match(r'^(?:도\s+하되|고\s+|며\s+|다만\s+)',expected):
            flags.append('EXPECTED_FRAGMENT_CANDIDATE')
        if own and pre and re.sub(r'\s+','',own) not in re.sub(r'\s+','',pre):
            flags.append('OTHER_BRANCH_PRECONDITION_CANDIDATE')
        if re.search(r'\[(?:REQ|SRS)[\w.\-]+\]|.{2,}…\s*-?\s*결과 확인',title,re.I):
            flags.append('UNREWRITTEN_REQUIREMENT_TITLE')
        if str(case.get('basic_case_kind'))=='DECISION_TABLE' and any(len(str(case.get(k) or ''))>250 for k in ('test_objective','precondition','pass_criterion')):
            flags.append('POSSIBLE_SIGNAL_DICTIONARY_AS_DECISION_TABLE')
        if flags:
            integrity.append(f"- {_text(tc_id,30)}: {','.join(flags)}")
    lines += ['', '[V0.125 의미 무결성 진단 (원본 본문 비포함)]',
              f'- 경고 신호: {len(integrity)}건',
              '- 단순 문자열 신호이며 0건이라도 의미 정확성을 완전히 보증하지 않습니다.']
    lines.extend(integrity)
    lines += ['', '[SRS별 의미 분할 경로 · 원본 본문 비포함]']
    interesting=sorted(set(byparent)|set(casegroups))
    for sid in interesting if max_groups is None else interesting[:max_groups]:
        entries=byparent.get(sid,[])
        finals=casegroups.get(sid,[])
        ids=', '.join(tid for tid,_ in finals[:9])+(' 외' if len(finals)>9 else '')
        lines.append(f'- {sid}: 최종 TC {len(finals)}건 [{ids or "없음"}], 진단 경로 {len(entries)}건')
        if not entries:
            lines.append('  · 규칙 단계 계측 정보 없음(예: 저장된 기존 번들/진단 전 생성 데이터).')
            continue
        for e in entries:
            obj=_text(e.get('test_object_id'),45)
            kinds=','.join(_text(x,38) for x in _list(e.get('applied_case_kinds'))) or '없음'
            candidates=list(dict.fromkeys(_text(x,40) for x in _list(e.get('candidate_goal_kinds'))))
            fids=','.join(_text(x,36) for x in _list(e.get('source_fact_fragment_ids'))[:5]) or '미연결'
            lines.append(f'  · 객체 {obj or "미확인"} | 경로={_text(e.get("decision_path"),45)} | 생성규칙={kinds}')
            lines.append(f'    Fact ID: {fids}')
            if e.get('semantic_evaluation')=='SKIPPED_AFTER_PRECEDING_RULE':
                prior=', '.join(str(x) for x in _list(e.get('preceding_rule_kinds'))[:5])
                lines.append('    원인: 선행 규칙이 TC를 생성하여 후속 독립 의미 분석이 실행되지 않음.'+(f' [선행={prior}]' if prior else ''))
                if candidates:
                    lines.append('    미적용 가능 후보 종류: '+', '.join(candidates[:8]))
                    lines.append('    판단: 다른 생성 TC에서 이미 다뤘는지 추적성 비교 필요(누락 확정 아님).')
            elif e.get('semantic_evaluation')=='NOT_RUN_SOURCE_BLOCK':
                lines.append('    원인: 원본 Fact가 TBD/Conflict로 표시되어 생성 전에 제한됨.')
            elif 'SEMANTIC_INDEPENDENT_OBJECTIVE' in _list(e.get('applied_case_kinds')):
                lines.append('    결과: 의미 분할 규칙이 실행되어 독립 검증 목적 후보를 TC로 구성함.')
            else:
                lines.append('    결과: 의미 규칙이 실행 가능했으나 분리 후보가 부족하거나 다른 규칙으로 처리됨.')
                if not candidates:
                    lines.append('    추가 진단: 현재 의미 파서에서 복수 독립 목적이 식별되지 않음.')
        # Do not silently abbreviate event groups: the log is a debugging aid.
    if max_groups is not None and len(interesting)>max_groups:
        lines.append(f'- 요청된 로그 개수 제한으로 추가 SRS {len(interesting)-max_groups}건이 제외됨(명시적 경고).')
    # Model-provided scenario candidates are not an independent proof of coverage.
    # Nonetheless, a count/ID inventory makes missing flowchart branches visible.
    source_scenarios=[x for x in (scenario_candidates or []) if isinstance(x,dict)]
    lines += ['', '[AI 추출 시나리오 인벤토리 · TC 완전성 검증 아님]',
              f'- AI 응답의 scenario_candidates: {len(source_scenarios)}건',
              f'- 최종 E2E TC: {len(cases)}건 (후보와 1:1 대응하지 않을 수 있음)',
              '- 이 목록은 AI가 보고한 경로만 보여줍니다. 원본 도식의 전체 분기를 자동 증명하지 않습니다.']
    if len(source_scenarios)>len(cases):
        lines.append('- 검토 신호: AI 시나리오 후보 수가 최종 TC 수보다 많습니다. STEP/Vector/중복/통합 여부를 확인하세요(누락 확정 아님).')
    scenario_to_srs=defaultdict(list)
    for parent,req in reqs.items():
        ident=str(req.get('scenario_candidate_id') or '').strip()
        if ident:
            scenario_to_srs[ident].append(parent)
    linked=0
    for row in source_scenarios:
        ident=_text(row.get('scenario_candidate_id'),70) or 'ID 미부여'
        name=_text(row.get('scenario_name'),110) or '이름 미부여'
        evidence=_list(row.get('source_evidence'))
        mapped=scenario_to_srs.get(ident,[])
        linked+=bool(mapped)
        mapped_tcs=sum(len(casegroups.get(parent,[])) for parent in mapped)
        mapping=(','.join(mapped) + f' / 관련 SRS 내 TC {mapped_tcs}개') if mapped else 'SRS 연결 미확인'
        lines.append(f'  · {ident}: {name} / AI 증거 기록 {len(evidence)}건 / {mapping} (시나리오별 커버리지 미확정)')
    lines.append(f'- AI 시나리오→SRS ID 연결: {linked}/{len(source_scenarios)}건 (직접 사실 검증을 의미하지 않음)')
    # Candidate duplicates are flagged rather than erased. Identical titles
    # are not proof of identical tests unless the source, condition AND PASS agree.
    same=defaultdict(list)
    for tid,case in zip(human_ids,cases):
        fids=tuple(sorted(str(x) for x in _list(case.get('source_fact_fragment_ids')) if x))
        if not fids:
            continue
        norm=lambda v: re.sub(r'\s+', '', str(v or '')).lower()
        key=(norm(case.get('parent_srs_id')),fids,norm(case.get('evaluation_name')),
             norm(case.get('precondition')),norm(case.get('expected_state')),
             norm(case.get('pass_criterion')))
        same[key].append(tid)
    duplicate_groups=[ids for ids in same.values() if len(ids)>1]
    lines += ['', '[동일 조건·출처·예상 결과의 중복 TC 검토 신호]',
              f'- 동일 키의 중복 후보 그룹: {len(duplicate_groups)}건 (자동 삭제하지 않음)']
    for ids in duplicate_groups:
        lines.append('  · '+', '.join(ids))
    lines += ['', '[선행규칙 후 보완 후보 판정 요약]']
    for e in events:
        if e.get('preceding_rule_kinds'):
            lines.append('  · '+_text(e.get('parent_srs_id'),35)
                         +f": 발견 {int(e.get('uncovered_conditional_candidate_count',0))} / 추가 {int(e.get('accepted_residual_count',0))} / 동등 판정 {int(e.get('equivalent_residual_count',0))}")
    lines += ['', '[다음 개선을 결정할 때 확인할 사항]',
        '① 선행 규칙 성공 시에도 미처리 독립 목적을 분석할 필요가 있는가?',
        '② 원본 Fact에 두 개 이상의 독립 조건/결과가 있으나 파서가 후보를 식별하지 못하는가?',
        '③ TC가 별도로 없더라도 Step/Vector에 해당 판정이 이미 포함되어 있는가?',
        '④ AI가 추출한 요구사항 JSON에서 관련 조건·동작·결과가 빠진 것인가?',
        '⑤ 실행 방법이 미정인 것과 검증 목적을 분리할 수 없는 것을 혼동하고 있지는 않은가?',
        '', '[지원 요청에 필요한 최소 자료]',
        '1) 이 파일과 기존 판단 근거 요약 TXT',
        '2) 관련 E2E 평가 명세서의 TC 행',
        '3) 가능하다면 비밀정보를 제외한 해당 요구사항/Fact 연결 근거',
        '※ 로컬 테스트는 실제 Windows GUI, 외부 H-Chat, 고객 사양서 검증을 대신하지 않습니다.',
    ]
    return '\n'.join(lines)+'\n'


def write_semantic_split_diagnostic(*, output_dir: Path, source_document: Path,
        cases: list[dict[str,Any]], human_ids: list[str],
        reqs: dict[str,dict[str,Any]], design_audit: dict[str,Any] | None = None,
        workbook_name: str = '', project_root: Path | None = None,
        scenario_candidates: list[dict[str, Any]] | None = None) -> Path:
    from core.output_naming import output_filename
    stem=re.sub(r'[<>:"/\\|?*]+','_',Path(source_document).stem).strip('._ ')[:72] or 'source'
    path=Path(output_dir)/output_filename('00_E2E_의미분할_진단',stem,'txt')
    rendered=build_semantic_split_diagnostic(source_document=source_document,
        cases=cases,human_ids=human_ids,reqs=reqs,design_audit=design_audit,
        workbook_name=workbook_name,project_root=project_root,
        scenario_candidates=scenario_candidates)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(rendered,encoding='utf-8-sig')
    return path
