
from __future__ import annotations

import json
import hashlib
import copy
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from core.document_normalizer import DocumentNormalizer, NormalizedDocument
from core.prompt_builder import PromptBuilder, PromptPart
from core.requirement_engine import RequirementEngine
from core.json_light_recovery import restore_complete_json, UnsafeJSONRecovery
from core.visual_evidence import VISION_SYSTEM_MESSAGE, build_visual_prompt, parse_visual_response, save_visual_evidence
from providers.base import AIProvider

StageCallback = Optional[Callable[[int, str], None]]
ProgressCallback = Optional[Callable[[int, int, str], None]]
LogCallback = Optional[Callable[[str], None]]
CancelCallback = Optional[Callable[[], bool]]


class PipelineCancelledError(RuntimeError):
    pass


class AIJobRunner:
    STAGES = {
        1: "입력/환경 확인",
        2: "문서 정규화",
        3: "분석 요청 생성",
        4: "문서 분석",
        5: "요구사항 추출",
        6: "결과 검증",
        7: "결과 저장",
    }
    STAGE_WEIGHTS = {1: 6, 2: 14, 3: 10, 4: 20, 5: 28, 6: 12, 7: 10}

    def __init__(self, project_root: Path, provider: AIProvider, normalizer: DocumentNormalizer, prompt_builder: PromptBuilder, requirement_engine: RequirementEngine, vision_provider: AIProvider | None = None):
        self.root = Path(project_root).resolve()
        self.provider = provider
        self.vision_provider = vision_provider or provider
        self.normalizer = normalizer
        self.prompt_builder = prompt_builder
        self.requirement_engine = requirement_engine
        self.request_dir = self.root / "work" / "ai_requests"
        self.response_dir = self.root / "work" / "ai_responses"
        self.failure_dir = self.root / "work" / "recovery_failures"
        self.checkpoint_dir = self.root / "work" / "recovery_checkpoints"
        self.request_dir.mkdir(parents=True, exist_ok=True)
        self.response_dir.mkdir(parents=True, exist_ok=True)
        self.failure_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.last_normalized: NormalizedDocument | None = None
        self.vision_config = self._load_vision_config()
        # Verified observations only; generated at runtime and never shipped with ZIP.
        self.visual_cache_dir = self.root / 'work' / 'verified_visual_cache'


    def _load_vision_config(self) -> dict:
        path = self.root / "config" / "provider_config.json"
        defaults = {
            "enabled": True,
            "mode": "inherit_selected_provider",
            "max_images_per_document": 0,  # unlimited, subject to provider constraints
            "max_image_bytes": 0,  # no silent local size skip
            "incomplete_visual_policy": "block",
            "max_extra_visual_retries": 1,
            "reuse_verified_visual_cache": True,
        }
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            vision = data.get("vision") or {}
            defaults.update({k: v for k, v in vision.items() if v is not None})
        except Exception:
            pass
        return defaults

    def _visual_cache_path(self, document: Path, visual: dict, prompt: str, source_sha256: str | None = None) -> Path:
        """Bind observation to exact source, image bytes, AI identity and full instructions.

        A changed source, image, model, endpoint or prompt cannot reuse old facts.
        No credential/API key enters either cache contents or filename.
        """
        meta = self.vision_provider.metadata()
        image = Path(str(visual.get('extracted_path') or ''))
        image_sha = hashlib.sha256(image.read_bytes()).hexdigest()
        source_sha = source_sha256 or (hashlib.sha256(document.read_bytes()).hexdigest() if document.is_file() else 'no-source-file')
        signature = json.dumps({
            'cache_schema': 'v0.125-vision-1',
            'source_sha256': source_sha,
            'image_sha256': image_sha,
            'provider': meta.provider_id,
            'model': meta.model,
            'api_base': meta.api_base,
            'system': VISION_SYSTEM_MESSAGE,
            'prompt': prompt,
        }, ensure_ascii=False, sort_keys=True)
        return self.visual_cache_dir / (hashlib.sha256(signature.encode('utf-8')).hexdigest() + '.json')

    def _read_visual_cache(self, path: Path) -> dict | None:
        if not bool(self.vision_config.get('reuse_verified_visual_cache', True)):
            return None
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if (data.get('cache_schema') != 'v0.125-vision-1'
                    or data.get('status') != 'analyzed'
                    or not isinstance(data.get('observed'), list)
                    or not isinstance(data.get('interpreted'), list)
                    or not isinstance(data.get('not_confirmed'), list)
                    or not isinstance(data.get('summary'), str)):
                return None
            return data
        except (OSError, ValueError, TypeError, AttributeError):
            return None

    def _save_visual_cache(self, path: Path, parsed: dict) -> None:
        if not bool(self.vision_config.get('reuse_verified_visual_cache', True)) or parsed.get('status') != 'analyzed':
            return
        # Cache is local and may contain customer specification observations.
        # Never include these runtime files in release packages.
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {k: copy.deepcopy(parsed.get(k)) for k in
                   ('status', 'observed', 'interpreted', 'not_confirmed', 'summary')}
        payload['cache_schema'] = 'v0.125-vision-1'
        temp = path.with_suffix('.tmp')
        try:
            with temp.open('w', encoding='utf-8') as stream:
                stream.write(json.dumps(payload, ensure_ascii=False, indent=2))
            try: temp.chmod(0o600)
            except OSError: pass
            temp.replace(path)
        except OSError:
            try: temp.unlink(missing_ok=True)
            except OSError: pass

    def _call_visual(self, source: Path, visual: dict, prompt: str) -> str:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        visual_id = visual.get("visual_id") or "IMG"
        base = f"{stamp}_vision_{source.stem}_{visual_id}"
        req_path = self.request_dir / f"{base}.txt"
        rsp_path = self.response_dir / f"{base}.txt"
        image_path = Path(str(visual.get("extracted_path") or ""))
        request_meta = (
            f"[SYSTEM]\n{VISION_SYSTEM_MESSAGE}\n\n[USER]\n{prompt}\n\n"
            f"[IMAGE_METADATA]\nvisual_id={visual_id}\npath={image_path}\n"
            f"mime={visual.get('mime_type')}\nbytes={visual.get('byte_size')}\nsha256={visual.get('sha256')}\n"
            "[IMAGE_PAYLOAD] Base64 image bytes are intentionally NOT saved in this request snapshot.\n"
        )
        req_path.write_text(request_meta, encoding="utf-8")
        response = self.vision_provider.generate_with_images(
            prompt,
            [image_path],
            system_message=VISION_SYSTEM_MESSAGE,
        )
        tmp = rsp_path.with_suffix(rsp_path.suffix + ".tmp")
        tmp.write_text(response, encoding="utf-8")
        tmp.replace(rsp_path)
        return response

    def _analyze_visual_assets(
        self,
        document: Path,
        normalized: NormalizedDocument,
        *,
        log_callback: LogCallback = None,
        cancel_callback: CancelCallback = None,
    ) -> list[dict]:
        assets = list(normalized.visual_assets or [])
        if not assets or not bool(self.vision_config.get("enabled", True)):
            return []

        def log(message: str):
            if log_callback:
                log_callback(message)

        meta = self.vision_provider.metadata()
        if not meta.supports_images:
            for item in assets:
                item["vision_status"] = "unsupported"
            log(f"시각 요소 {len(assets)}개 감지 · {meta.display_name}은 Vision 경로 미지원")
            if str(self.vision_config.get("incomplete_visual_policy", "block")).lower() == "block":
                raise RuntimeError("원본 문서에 그림이 있으나 선택된 AI가 이미지 분석을 지원하지 않습니다.")
            return []

        source_signature = (normalized.source_sha256
                            or (hashlib.sha256(document.read_bytes()).hexdigest() if document.is_file() else 'no-source-file'))
        max_images = max(0, int(self.vision_config.get("max_images_per_document", 0)))
        max_bytes = max(0, int(self.vision_config.get("max_image_bytes", 0)))
        supported_mimes = {"image/png", "image/jpeg", "image/webp", "image/gif"}
        evidence: list[dict] = []
        analyzed_count = 0
        skipped_count = 0
        failed_count = 0
        duplicate_count = 0
        persistent_reuse_count = 0
        retry_count = 0
        vision_cache: dict[str, dict] = {}
        coverage_accepted = {"analyzed", "covered_by_document_render"}
        for item in assets:
            if item.get("conversion_status") == "source_page_fallback":
                log(f"Vision 대체 경로 대기 · {item.get('visual_id')} · 원본={item.get('mime_type')} · 페이지 렌더 분석 필요")
                continue
            self._ensure_not_cancelled(cancel_callback, log_callback)
            if max_images and analyzed_count >= max_images:
                item["vision_status"] = "skipped_limit"
                skipped_count += 1
                continue
            if max_bytes and int(item.get("byte_size") or 0) > max_bytes:
                item["vision_status"] = "skipped_size"
                skipped_count += 1
                continue
            mime = str(item.get("mime_type") or "")
            if mime not in supported_mimes:
                item["vision_status"] = "unsupported_format"
                skipped_count += 1
                continue
            image_path = Path(str(item.get("extracted_path") or ""))
            if not image_path.is_file():
                item["vision_status"] = "missing"
                failed_count += 1
                continue

            visual_id = item.get("visual_id") or f"IMG-{analyzed_count+1:03d}"
            cache_key = str(item.get("sha256") or "")
            if cache_key and cache_key in vision_cache:
                prior = vision_cache[cache_key]
                # A genuine content-identical image may occur multiple times in
                # different source positions. Reuse only the visual observation,
                # but preserve this occurrence's id/location/provenance.
                import copy
                parsed = copy.deepcopy(prior)
                parsed.update({
                    "visual_id": visual_id,
                    "source_locator": item.get("source_locator") or item.get("source") or "",
                    "image_path": item.get("extracted_path") or "",
                    "sha256": cache_key,
                    "mime_type": item.get("mime_type") or "",
                    "byte_size": item.get("byte_size") or 0,
                })
                item["vision_status"] = parsed["status"]
                item["vision_cache_reused"] = True
                duplicate_count += 1
                evidence.append(parsed)
                log(f"Vision 중복 재사용 · {visual_id} · SHA-256 일치 · 원본 위치는 개별 보존")
                continue
            prompt = build_visual_prompt(item)
            try:
                persistent_path = self._visual_cache_path(document, item, prompt, source_signature)
                prior = self._read_visual_cache(persistent_path)
                if prior is not None:
                    parsed = dict(prior)
                    parsed.update({
                        'visual_id': visual_id,
                        'source_locator': item.get('source_locator') or item.get('source') or '',
                        'image_path': item.get('extracted_path') or '',
                        'sha256': cache_key,
                        'mime_type': item.get('mime_type') or '',
                        'byte_size': item.get('byte_size') or 0,
                    })
                    item['vision_status'] = 'analyzed'
                    item['vision_cache_reused'] = True
                    item['vision_cache_persistent'] = True
                    persistent_reuse_count += 1
                    evidence.append(parsed)
                    if cache_key:
                        vision_cache[cache_key] = parsed
                    log(f"Vision 검증 결과 재사용 · {visual_id} · 동일 원본/이미지/모델/지침 · API 요청 없음")
                    continue
            except (OSError, ValueError) as exc:
                # Cache is an optimization; never allow an unreadable cache to
                # prevent an otherwise valid API analysis.
                persistent_path = None
                log(f"Vision 캐시 확인 경고 · {visual_id} · {type(exc).__name__} · 새 분석으로 진행")
            analyzed_count += 1
            log(f"Vision 분석 {analyzed_count}건째/{len(assets)}개 감지 · {visual_id} · {image_path.name}")
            try:
                raw = self._call_visual(document, item, prompt)
                parsed = parse_visual_response(raw, item)
                # Retry only a received, unparseable response. Network timeouts
                # may already have consumed tokens, so they are NOT auto-retried.
                try:
                    max_retries = min(1, max(0, int(self.vision_config.get('max_extra_visual_retries', 1))))
                except (TypeError, ValueError):
                    max_retries = 1
                if parsed.get('status') == 'parse_error' and max_retries:
                    self._ensure_not_cancelled(cancel_callback, log_callback)
                    retry_count += 1
                    log(f"Vision JSON 검증 실패 · {visual_id} · 해당 이미지 1회만 재요청")
                    repair_prompt = prompt + ("\n\n[RETRY_JSON_ONLY] 이전 응답은 JSON 객체 형식 검증에 실패했습니다. "
                                             "해당 이미지 사실만 다시 확인하여 JSON 객체 하나만 반환하세요. "
                                             "Markdown 코드블록, 부연 설명, 잘린 JSON은 금지합니다.")
                    retry_raw = self._call_visual(document, item, repair_prompt)
                    parsed = parse_visual_response(retry_raw, item)
                item["vision_status"] = str(parsed.get("status") or "parse_error")
                evidence.append(parsed)
                if item["vision_status"] != "analyzed":
                    failed_count += 1
                    log(f"Vision 결과 검증 실패 · {visual_id} · 재요청 후에도 JSON 형식 불완전")
                else:
                    if cache_key:
                        vision_cache[cache_key] = parsed
                    if persistent_path is not None:
                        self._save_visual_cache(persistent_path, parsed)
            except Exception as exc:
                item["vision_status"] = "failed"
                item["vision_error"] = str(exc)
                failed_count += 1
                log(f"Vision 분석 실패 · {visual_id} · {exc} · Text/Table 분석은 계속")

        rendered_ids = {a.get('visual_id') for a in assets if a.get('kind') == 'source_page_render' and a.get('vision_status') == 'analyzed'}
        for item in assets:
            if item.get('vision_status') == 'pending_render_coverage':
                expected_ids = item.get('fallback_render_ids') or []
                if expected_ids and set(expected_ids).issubset(rendered_ids):
                    item['vision_status'] = 'covered_by_document_render'
                    item['render_coverage_note'] = ('원본 이미지가 직접 변환된 것은 아니며, 문서 전체 페이지 렌더링 '
                        '분석으로 시각 정보를 보완했습니다. 원본 개별 이미지와의 1:1 일치는 미확정입니다.')
                    log(f"Vision 페이지 대체 완료 · {item.get('visual_id')} · 페이지 {len(expected_ids)}개 정상 분석")
                else:
                    item['vision_status'] = 'render_coverage_incomplete'
                    item['render_coverage_note'] = ('원본 삽입 미디어의 정확한 페이지가 확인되지 않아 전체 페이지로 대체했습니다. '
                        '페이지 중 일부가 미완료이므로 해당 EMF가 처리된 것이라고 확정하지 않습니다.')
        normalized.visual_evidence = evidence
        unresolved = [f"{a.get('visual_id')}:{a.get('vision_status')}({a.get('mime_type')}:{str(a.get('conversion_error') or '')[:90]})" for a in assets
                      if a.get('vision_status') not in coverage_accepted]
        if unresolved:
            log("시각 요소 미완료 " + str(len(unresolved)) + "건: " + ", ".join(unresolved[:25]))
        try:
            ir_path = Path(normalized.ir_json_path)
            payload = json.loads(ir_path.read_text(encoding="utf-8")) if ir_path.is_file() else {}
            payload["visual_assets"] = normalized.visual_assets
            payload["visual_evidence"] = evidence
            ir_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            save_visual_evidence(ir_path.parent / "visual_evidence.json", evidence)
        except Exception as exc:
            log(f"Visual Evidence 로컬 저장 경고 · {exc}")

        log(
            f"Vision 처리 완료 · 증거 {len(evidence)}개(중복 재사용 {duplicate_count}개) / 실패 {failed_count}개 / Skip {skipped_count}개 · "
            "본문/표와 함께 다음 분석 단계에 반영"
        )
        if unresolved and str(self.vision_config.get("incomplete_visual_policy", "block")).lower() == "block":
            raise RuntimeError("시각 요소를 누락 없이 분석하지 못했습니다. " + ", ".join(unresolved[:25]) +
                               " / Provider·파일 크기·스캔/도식 형식을 확인하세요.")
        return evidence

    def _ensure_not_cancelled(self, cancel_callback: CancelCallback, log_callback: LogCallback = None):
        if cancel_callback and cancel_callback():
            if log_callback:
                log_callback("사용자 중지 요청 감지 · 안전한 중단 지점에서 작업을 종료합니다.")
            raise PipelineCancelledError("사용자 중지 요청으로 작업이 중지되었습니다.")

    def _exchange_name(self, source: Path, kind: str, part: PromptPart) -> str:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return f"{stamp}_{kind}_{source.stem}_p{part.part_index:02d}of{part.part_count:02d}"

    def _call(self, source: Path, kind: str, part: PromptPart, *, log_callback: LogCallback = None) -> str:
        base = self._exchange_name(source, kind, part)
        req_path = self.request_dir / f"{base}.txt"
        rsp_path = self.response_dir / f"{base}.txt"
        req_path.write_text(f"[SYSTEM]\n{part.system_message}\n\n[USER]\n{part.user_prompt}", encoding="utf-8")
        def provider_progress(_percent: int, message: str):
            if log_callback and message:
                log_callback(message)

        response = self.provider.generate(
            part.user_prompt,
            system_message=part.system_message,
            progress_callback=provider_progress,
        )
        tmp = rsp_path.with_suffix(rsp_path.suffix + ".tmp")
        tmp.write_text(response, encoding="utf-8")
        tmp.replace(rsp_path)
        return response

    def _save_parse_failure_detail(self, source: Path, raw: str, error: Exception, *, label: str) -> Path:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        path = self.failure_dir / f"{stamp}_{label}_{source.stem}.txt"
        body = (
            f"source={source}\n"
            f"error={error}\n"
            f"response_chars={len(raw or '')}\n\n"
            "=== RAW RESPONSE ===\n"
            + (raw or "")
        )
        path.write_text(body, encoding="utf-8")
        return path

    def _recovery_options(self) -> dict:
        defaults={"max_extra_ai_calls_per_failed_part":1,"reuse_verified_part_cache":True}
        path=self.root / "config" / "json_recovery_config.json"
        try:
            data=json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data,dict):defaults.update(data)
        except (OSError,ValueError):pass
        try:
            defaults["max_extra_ai_calls_per_failed_part"]=min(1,max(0,int(defaults["max_extra_ai_calls_per_failed_part"])))
        except (ValueError,TypeError):
            defaults["max_extra_ai_calls_per_failed_part"]=1
        return defaults

    def _checkpoint_path(self, document: Path, part: PromptPart) -> Path:
        # Exact source bytes + prompt + selected Provider/model identity: no stale
        # output is reused after changing a document, policy, prompt or model.
        meta=self.provider.metadata()
        source_hash=hashlib.sha256(document.read_bytes()).hexdigest() if document.is_file() else "missing"
        signature=json.dumps({"path":str(document.resolve()),"source_sha256":source_hash,
            "provider":meta.provider_id,"model":meta.model,"api_base":meta.api_base,
            "system":part.system_message,"prompt":part.user_prompt},ensure_ascii=False,sort_keys=True)
        return self.checkpoint_dir / (hashlib.sha256(signature.encode("utf-8")).hexdigest()+".json")

    @staticmethod
    def _validate_cache_payload(data: dict) -> bool:
        if not isinstance(data,dict) or not isinstance(data.get("requirements"),list):
            return False
        return bool(data.get("requirements")) and bool(data.get("source_document"))

    def _checkpoint_write(self,path: Path,data: dict) -> None:
        path.parent.mkdir(parents=True,exist_ok=True)
        # Parsed requirements only, no credentials or unredacted system prompts.
        tmp=path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(path)

    def _extract_requirement_with_recovery(
        self,
        document: Path,
        part: PromptPart,
        *,
        part_index: int,
        part_total: int,
        log_callback: LogCallback = None,
        cancel_callback: CancelCallback = None,
    ) -> list[dict]:
        def log(message: str):
            if log_callback:
                log_callback(message)
        opts=self._recovery_options()
        checkpoint=self._checkpoint_path(document,part)
        if opts.get("reuse_verified_part_cache",True) and checkpoint.is_file():
            try:
                cached=json.loads(checkpoint.read_text(encoding="utf-8"))
                if self._validate_cache_payload(cached):
                    log(f"요구사항 Part {part_index}/{part_total} · 이전 검증 완료 결과 재사용 · 추가 API 0회")
                    return [cached]
            except (OSError,ValueError):
                pass
        self._ensure_not_cancelled(cancel_callback,log_callback)
        raw=self._call(document,"requirements",part,log_callback=log_callback)
        try:
            data=self.requirement_engine.extract_json(raw)
            self._checkpoint_write(checkpoint,data)
            return [data]
        except Exception as first_exc:
            detail_path=self._save_parse_failure_detail(document,raw,first_exc,label=f"requirements_p{part_index:02d}")
            log(f"Requirement JSON 파싱 실패 · Part {part_index}/{part_total} · 원문 저장: {detail_path.name} · 로컬 복구 우선")
        # One-sided EOF recovery only: no numeric/text fields, evidence or
        # unclosed strings are manufactured. The original response is preserved.
        try:
            recovered,suffix=restore_complete_json(raw)
            self._checkpoint_write(checkpoint,recovered)
            log(f"Requirement JSON 로컬 복구 성공 · 종료기호 {suffix!r} 복원 · 추가 API 0회 · 원본 근거 완전성은 별도 검토")
            return [recovered]
        except (UnsafeJSONRecovery,ValueError) as repair_exc:
            log(f"로컬 복구 불가 · {repair_exc}")
        if opts["max_extra_ai_calls_per_failed_part"] < 1:
            raise RuntimeError(f"요구사항 JSON 분석 실패. 자동 재요청 0회 설정. 오류 원문: {detail_path}")
        self._ensure_not_cancelled(cancel_callback,log_callback)
        log(f"경량 복구 재요청 1/1 → {self.provider.metadata().display_name} · 대량 자동 분할 미실행")
        retry_part=PromptPart(part.part_index,part.part_count,part.system_message,
            part.user_prompt + "\n\n[FORMAT_RETRY_V0.112] 이전 응답의 JSON 문법 오류로 재요청합니다. "
            "원본 SOURCE의 요구사항을 빠짐없이 유지하고 설명 없이 유효한 JSON 객체 하나를 완성하세요. "
            "중복 설명과 근거 인용은 간결하게 작성하고 마지막 닫는 기호까지 출력하세요."
        )
        retry_raw=self._call(document,"requirements_light_retry",retry_part,log_callback=log_callback)
        try:
            try:
                data=self.requirement_engine.extract_json(retry_raw)
            except (ValueError,TypeError):
                data,suffix=restore_complete_json(retry_raw)
                log(f"재요청 응답 로컬 종료기호 복원 {suffix!r}")
            self._checkpoint_write(checkpoint,data)
            log("경량 복구 재요청 성공 · 추가 API 1회")
            return [data]
        except Exception as exc:
            retry_path=self._save_parse_failure_detail(document,retry_raw,exc,label=f"requirements_light_retry_p{part_index:02d}")
            raise RuntimeError(
                f"요구사항 JSON 복구 실패 · 추가 AI 요청 최대 1회 도달 · "
                f"93개 자동 분할 재추출은 실행하지 않았습니다. 원문: {detail_path.name}, 재요청 원문: {retry_path.name}"
            ) from exc


    def run_batch_analysis_and_requirements(self, documents, *, persist_result: bool = True, stage_callback: StageCallback = None, progress_callback: ProgressCallback = None, log_callback: LogCallback = None, cancel_callback: CancelCallback = None) -> dict:
        docs = [Path(d).resolve() for d in documents]
        if not docs:
            raise RuntimeError("분석할 입력 문서가 없습니다.")

        batch_results = []
        batch_failures = []
        total_docs = len(docs)

        def log(message: str):
            if log_callback:
                log_callback(message)

        for doc_index, document in enumerate(docs, start=1):
            self._ensure_not_cancelled(cancel_callback, log_callback)
            log(f"[{doc_index}/{total_docs}] 문서 작업 시작 · {document.name}")

            def wrapped_stage(no: int, title: str):
                if stage_callback:
                    stage_callback(no, f"[{doc_index}/{total_docs}] {title}")

            def wrapped_progress(overall: int, current: int, message: str):
                batch_overall = round((((doc_index - 1) + (overall / 100.0)) / total_docs) * 100)
                if progress_callback:
                    progress_callback(batch_overall, current, f"[{doc_index}/{total_docs}] {message}")

            try:
                result = self.run_analysis_and_requirements(
                    document,
                    persist_result=persist_result,
                    stage_callback=wrapped_stage,
                    progress_callback=wrapped_progress,
                    log_callback=log_callback,
                    cancel_callback=cancel_callback,
                )
                result = dict(result)
                result["document"] = str(document)
                batch_results.append(result)
                log(f"[{doc_index}/{total_docs}] 문서 작업 완료 · {document.name}")
            except PipelineCancelledError:
                raise
            except Exception as exc:
                batch_failures.append({"document": document.name, "error": str(exc)})
                log(f"[{doc_index}/{total_docs}] 문서 작업 실패 · {document.name} · {exc}")
                if progress_callback:
                    progress_callback(round((doc_index / total_docs) * 100), 100, f"[{doc_index}/{total_docs}] 실패 후 다음 문서로 이동")

        if not batch_results:
            details = "\n".join(f"- {x['document']}: {x['error']}" for x in batch_failures)
            raise RuntimeError("모든 입력 문서 처리에 실패했습니다.\n" + details)

        if progress_callback:
            progress_callback(100, 100, "Batch 처리 완료")
        return {
            "batch_results": batch_results,
            "batch_failures": batch_failures,
            "document_count": total_docs,
        }

    def normalize_only(self, document: Path) -> NormalizedDocument:
        self.last_normalized = self.normalizer.normalize(document)
        return self.last_normalized

    def run_analysis_and_requirements(self, document: Path, *, persist_result: bool = True, stage_callback: StageCallback = None, progress_callback: ProgressCallback = None, log_callback: LogCallback = None, cancel_callback: CancelCallback = None) -> dict:
        def stage(no: int):
            title = self.STAGES[no]
            self._ensure_not_cancelled(cancel_callback, log_callback)
            if stage_callback:
                stage_callback(no, title)
            log(f"STEP {no} 시작 · {title}")
            report(no, 0, f"{title} 시작")

        def report(no: int, current: int, message: str):
            current = max(0, min(100, int(current)))
            previous = sum(self.STAGE_WEIGHTS[i] for i in range(1, no))
            overall = previous + round(self.STAGE_WEIGHTS[no] * current / 100)
            overall = max(0, min(100, int(overall)))
            if progress_callback:
                progress_callback(overall, current, message)

        def finish_stage(no: int, message: str):
            report(no, 100, message)
            log(f"STEP {no} 완료 · {message}")

        def log(message: str):
            if log_callback:
                log_callback(message)

        document = Path(document).resolve()

        stage(1)
        if not document.is_file():
            raise FileNotFoundError(document)
        meta = self.provider.metadata()
        report(1, 45, f"입력 문서 확인: {document.name}")
        if not meta.model:
            raise RuntimeError("선택된 AI Model 정보가 없습니다.")
        report(1, 80, f"AI Provider 확인: {meta.display_name} / {meta.model}")
        finish_stage(1, "입력 문서와 AI 선택 확인")

        stage(2)
        report(2, 15, "원본 문서 읽기 시작")
        normalized = self.normalize_only(document)
        report(2, 70, f"Document IR 생성: {len(normalized.chunks)} chunks")
        if normalized.visual_assets:
            log(f"시각 요소 {len(normalized.visual_assets)}개 준비 · work/normalized 하위 visuals 저장")
            try:
                ir = json.loads(Path(normalized.ir_json_path).read_text(encoding='utf-8'))
                for message in ir.get('visual_conversion_messages') or []:
                    log('Vision 형식 준비 · ' + message)
            except Exception:
                pass
            report(2, 88, f"시각 요소 {len(normalized.visual_assets)}개 로컬 추출 완료")
        finish_stage(2, "로컬 문서 정규화 완료")

        self._ensure_not_cancelled(cancel_callback, log_callback)
        stage(3)
        if normalized.visual_assets:
            report(3, 10, "그림/도식 Vision 분석 준비")
            main_meta = self.provider.metadata()
            vision_meta = self.vision_provider.metadata()
            route_label = "Native" if main_meta.provider_id == vision_meta.provider_id else "Fallback"
            log(
                f"Vision 경로 · Main={main_meta.display_name} / {main_meta.model} · "
                f"Vision={vision_meta.display_name} / {vision_meta.model} ({route_label}) · "
                f"Credential={vision_meta.credential_status}"
            )
            self._analyze_visual_assets(
                document,
                normalized,
                log_callback=log_callback,
                cancel_callback=cancel_callback,
            )
            report(3, 45, f"Visual Evidence {len(normalized.visual_evidence)}개 준비")
            if len(normalized.visual_evidence) == 0:
                statuses = [str(x.get("vision_status") or "unknown") for x in (normalized.visual_assets or [])]
                log(
                    "⚠ Visual Evidence 0개 · 그림 내용은 후속 분석에 반영되지 않습니다. "
                    f"asset_status={statuses} · work/normalized 하위 visual_evidence.json 및 로그를 확인하세요."
                )
        analysis_parts = self.prompt_builder.build_analysis(normalized)
        report(3, 65, f"분석 요청 {len(analysis_parts)}개 생성")
        report(3, 90, "요구사항 요청은 STEP 4 분석 결과 반영 후 준비")
        finish_stage(3, "Text/Table/Visual 통합 AI 요청 생성 완료")

        self._ensure_not_cancelled(cancel_callback, log_callback)
        stage(4)
        analysis_answers: list[str] = []
        total = max(1, len(analysis_parts))
        for idx, part in enumerate(analysis_parts, start=1):
            self._ensure_not_cancelled(cancel_callback, log_callback)
            before = round(((idx - 1) / total) * 80) + 5
            report(4, before, f"문서 분석 요청 {idx}/{total} · {meta.display_name} 응답 대기")
            log(f"문서 분석 요청 {idx}/{total} 전송 → {meta.display_name}")
            analysis_answers.append(self._call(document, "analysis", part, log_callback=log_callback))
            log(f"문서 분석 응답 {idx}/{total} 수신 ← {meta.display_name}")
            after = round((idx / total) * 90)
            report(4, after, f"문서 분석 응답 {idx}/{total} 수신 · 결과 정리 중")
        analysis_text = analysis_answers[0] if len(analysis_answers) == 1 else "\n\n".join(f"=== Analysis Part {idx}/{len(analysis_answers)} ===\n{text}" for idx, text in enumerate(analysis_answers, start=1))
        finish_stage(4, "문서 분석 완료")
        # Analysis report is supplemental context, not the fact source. If the
        # model omitted a fact, SOURCE remains authoritative in STEP5.
        req_parts = self.prompt_builder.build_requirement_extraction(normalized, analysis_context=analysis_text)
        log(f"헌법 전문 포함 · 요구사항 요청 {len(req_parts)}개 · "
            f"part_sizes={[len(p.user_prompt) for p in req_parts]}")

        self._ensure_not_cancelled(cancel_callback, log_callback)
        stage(5)
        parsed: list[dict] = []
        total = max(1, len(req_parts))
        for idx, part in enumerate(req_parts, start=1):
            self._ensure_not_cancelled(cancel_callback, log_callback)
            before = round(((idx - 1) / total) * 80) + 5
            report(5, before, f"요구사항 추출 요청 {idx}/{total} · {meta.display_name} 응답 대기")
            log(f"요구사항 추출 요청 {idx}/{total} 전송 → {meta.display_name}")
            extracted_parts = self._extract_requirement_with_recovery(
                document,
                part,
                part_index=idx,
                part_total=total,
                log_callback=log_callback,
                cancel_callback=cancel_callback,
            )
            parsed.extend(extracted_parts)
            log(f"요구사항 추출 응답 {idx}/{total} 수신 ← {meta.display_name}")
            after = round((idx / total) * 90)
            report(5, after, f"요구사항 응답 {idx}/{total} 수신 · 구조 확인 완료")
        finish_stage(5, "Requirement Candidate 추출 완료")

        self._ensure_not_cancelled(cancel_callback, log_callback)
        stage(6)
        report(6, 30, "Chunk별 Requirement 결과 병합")
        merged = self.requirement_engine.merge_results(parsed, source_document=normalized.source_document)
        report(6, 55, "Source Coverage / Reference Integrity / Review Evidence 계산")
        merged = self.requirement_engine.apply_quality_audits(merged, source_text=normalized.compact_text())
        report(6, 75, "Canonical Requirement 구조 검사")
        evaluation = self.requirement_engine.evaluate_structure(merged)
        finish_stage(6, f"구조 검사 완료 · {evaluation['structure_score']}/100")

        self._ensure_not_cancelled(cancel_callback, log_callback)
        stage(7)
        report(7, 30, "Canonical Requirement JSON 저장")
        saved_path = self.requirement_engine.save_result(document, merged) if persist_result else None
        report(7, 70, "결과 화면 데이터 준비")
        finish_stage(7, "내부 분석 결과 저장 완료 · 선택 산출물 Export는 후처리에서 계속")

        return {
            "analysis_text": analysis_text,
            "requirement_data": merged,
            "evaluation": evaluation,
            "saved_path": str(saved_path) if saved_path else None,
            "normalized": {
                "source_document": normalized.source_document,
                "source_type": normalized.source_type,
                "chunk_count": len(normalized.chunks),
                "visual_count": len(normalized.visual_assets),
                "visual_evidence_count": len(normalized.visual_evidence),
                "visual_evidence_path": str(Path(normalized.ir_json_path).parent / "visual_evidence.json"),
                "total_chars": normalized.total_chars,
                # Local-only normalized text is passed to deterministic exporters for conservative
                # metadata extraction. It is not a second AI result and remains Provider-independent.
                "compact_text": normalized.compact_text(),
            },
        }
