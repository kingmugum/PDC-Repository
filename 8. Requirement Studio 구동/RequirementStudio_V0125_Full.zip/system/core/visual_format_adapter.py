"""V0.124: Preserve visual coverage across Office/PDF image formats.

Original extracted media is never overwritten. Normal raster images are
converted locally to PNG; vector media get a direct converter where available.
If no direct converter exists, render the *source document* into page images.
Page-based coverage is explicitly identified, never passed off as a successful
one-to-one conversion of a particular embedded image.
"""
from __future__ import annotations

import hashlib
import mimetypes
import os
import re
from pathlib import Path
import shutil
import subprocess
import tempfile

SUPPORTED_MIMES = frozenset(("image/png", "image/jpeg", "image/webp", "image/gif"))


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _is_svg_safe(data: bytes) -> bool:
    """Reject active content/external resource URLs without blocking SVG xmlns."""
    from xml.etree import ElementTree as ET
    text = data.decode('utf-8', errors='replace')
    lowered = text.lower()
    if any(x in lowered for x in ('<!entity', '<!doctype', '<script', '<foreignobject', '@import')):
        return False
    try:
        root = ET.fromstring(text)
    except Exception:
        return False
    for elem in root.iter():
        for key, value in elem.attrib.items():
            k = key.rsplit('}', 1)[-1].lower()
            v = value.strip().lower()
            if k in {'href','src'} and (v.startswith(('http:', 'https:', 'file:', '//')) or v.startswith('data:')):
                return False
            if 'url(' in v and any(x in v for x in ('http:', 'https:', 'file:', '//')):
                return False
    return True


def try_convert_image(asset: dict, target_dir: Path) -> tuple[bool, str]:
    """Create a PNG next to originals, update asset metadata on success.

    Format failures are returned for diagnostic reporting, not swallowed.
    """
    path = Path(str(asset.get('extracted_path') or ''))
    if not path.is_file():
        return False, '원본 이미지 파일이 존재하지 않음'
    mime = str(asset.get('mime_type') or '').lower()
    if mime in SUPPORTED_MIMES:
        return True, '원본 형식 그대로 사용'
    target_dir.mkdir(parents=True, exist_ok=True)
    digest = asset.get('sha256') or _sha(path)
    dst = target_dir / f"{asset.get('visual_id', 'IMG')}_{str(digest)[:12]}.png"
    errors: list[str] = []
    suffix = path.suffix.lower()

    # Try Pillow first. Supports BMP, TIFF, ICO and many non-standardly named
    # embedded raster formats. Explicitly reject non-raster metafiles.
    try:
        from PIL import Image, ImageOps
        with Image.open(path) as source:
            if source.format not in {'WMF', 'EMF'}:
                source.seek(0)
                im = ImageOps.exif_transpose(source)
                if im.mode in ('RGBA', 'LA') or ('transparency' in im.info):
                    rgba = im.convert('RGBA')
                    bg = Image.new('RGBA', rgba.size, (255, 255, 255, 255))
                    im = Image.alpha_composite(bg, rgba).convert('RGB')
                else:
                    im = im.convert('RGB')
                im.save(dst, format='PNG')
    except Exception as exc:
        errors.append(f'Pillow:{type(exc).__name__}')

    if not dst.is_file() and (suffix == '.svg' or mime == 'image/svg+xml'):
        try:
            import cairosvg
            data = path.read_bytes()
            if not _is_svg_safe(data):
                raise ValueError('SVG 외부 리소스/스크립트 참조 제한')
            cairosvg.svg2png(bytestring=data, write_to=str(dst))
        except Exception as exc:
            errors.append(f'SVG:{type(exc).__name__}({str(exc)[:100]})')

    # If Inkscape is installed, it can rasterize WMF/EMF as well as SVG. This
    # is optional: on Windows, Office document rendering provides a fallback.
    if not dst.is_file() and suffix in {'.wmf', '.emf', '.svg'} and (suffix != '.svg' or _is_svg_safe(path.read_bytes())):
        executable = shutil.which('inkscape')
        if executable:
            try:
                run = subprocess.run(
                    [executable, str(path), '--export-type=png', f'--export-filename={dst}'],
                    capture_output=True, text=True, timeout=45,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                )
                if run.returncode or not dst.is_file():
                    raise RuntimeError((run.stderr or 'inkscape 반환 코드 오류')[:160])
            except Exception as exc:
                errors.append(f'Inkscape:{type(exc).__name__}')

    if not dst.is_file() or not dst.stat().st_size:
        dst.unlink(missing_ok=True)
        return False, '; '.join(errors) or f'변환기 없음({suffix or mime})'
    original = {k: asset.get(k) for k in ('extracted_path', 'mime_type', 'byte_size', 'sha256')}
    asset['original_visual'] = original
    asset['extracted_path'] = str(dst)
    asset['mime_type'] = 'image/png'
    asset['byte_size'] = dst.stat().st_size
    asset['sha256'] = _sha(dst)
    asset['conversion_status'] = 'converted_to_png'
    asset['conversion_method'] = 'local_rasterization'
    return True, f'PNG 변환 완료 ({suffix or mime})'


def _office_export_pdf_win(source: Path, pdf_path: Path) -> None:
    """Use the user's installed Microsoft Office on Windows; optional pywin32.

    No input document is modified; Word/PowerPoint/Excel processes are closed.
    """
    import win32com.client  # type: ignore[import-not-found]
    extension = source.suffix.lower()
    app = None
    document = None
    try:
        if extension == '.docx':
            app = win32com.client.DispatchEx('Word.Application')
            app.Visible = False
            app.DisplayAlerts = 0
            try: app.AutomationSecurity = 3  # disable Office macros
            except Exception: pass
            document = app.Documents.Open(str(source.resolve()), ReadOnly=True, AddToRecentFiles=False)
            document.ExportAsFixedFormat(str(pdf_path.resolve()), 17)  # wdExportFormatPDF
        elif extension == '.pptx':
            app = win32com.client.DispatchEx('PowerPoint.Application')
            document = app.Presentations.Open(str(source.resolve()), True, False, False)
            document.SaveAs(str(pdf_path.resolve()), 32)  # ppSaveAsPDF
        elif extension in {'.xlsx', '.xlsm'}:
            app = win32com.client.DispatchEx('Excel.Application')
            app.DisplayAlerts = False
            try: app.AutomationSecurity = 3  # disable Excel macros
            except Exception: pass
            document = app.Workbooks.Open(str(source.resolve()), ReadOnly=True)
            document.ExportAsFixedFormat(0, str(pdf_path.resolve()))  # xlTypePDF
        else:
            raise ValueError('Office PDF Export 미지원 형식')
    finally:
        if document is not None:
            try:
                document.Close(False) if extension != '.pptx' else document.Close()
            except Exception:
                pass
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass


def render_source_pages(source: Path, target_dir: Path, *, page_numbers: set[int] | None = None) -> list[Path]:
    """Render the original document at readable resolution; preserves original.

    For PDFs, only requested pages are rendered. For Office, fallback renders
    all pages/slides, because embedded media paths do not encode page indexes.
    """
    import fitz
    source = Path(source).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    suffix = source.suffix.lower()
    with tempfile.TemporaryDirectory(prefix='rs124_office_pdf_') as temp:
        if suffix == '.pdf':
            pdf_path = source
        else:
            pdf_path = Path(temp) / 'source_render.pdf'
            error = None
            if os.name == 'nt':
                try:
                    _office_export_pdf_win(source, pdf_path)
                except Exception as exc:
                    error = f'Microsoft Office PDF Export 실패: {type(exc).__name__}: {str(exc)[:180]}'
            if not pdf_path.is_file():
                soffice = shutil.which('soffice') or shutil.which('libreoffice')
                if soffice:
                    try:
                        # Use a dedicated LO profile to avoid blocking an active GUI session.
                        profile = Path(temp) / 'profile'
                        args = [soffice, f'-env:UserInstallation={profile.as_uri()}',
                                '--headless', '--convert-to', 'pdf', '--outdir', temp, str(source)]
                        result = subprocess.run(args, capture_output=True, text=True, timeout=240,
                                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                        candidate = Path(temp) / (source.stem + '.pdf')
                        if result.returncode or not candidate.is_file():
                            raise RuntimeError((result.stderr or result.stdout or '')[:180])
                        candidate.replace(pdf_path)
                    except Exception as exc:
                        error = f'LibreOffice PDF Export 실패: {type(exc).__name__}: {str(exc)[:180]}'
            if not pdf_path.is_file():
                raise RuntimeError((error or 'Office 렌더링 환경 없음') +
                                   ' / Windows: Microsoft Office 및 pywin32, 또는 LibreOffice가 필요합니다.')
        pages: list[Path] = []
        with fitz.open(str(pdf_path)) as doc:
            for index in range(len(doc)):
                if page_numbers and (index + 1) not in page_numbers:
                    continue
                page = doc[index]
                pix = page.get_pixmap(matrix=fitz.Matrix(1.7, 1.7), alpha=False)
                dst = target_dir / f'source_page_{index+1:04d}.png'
                pix.save(str(dst))
                pages.append(dst)
        if not pages:
            raise RuntimeError('원본 문서 렌더링 결과에 유효한 페이지 이미지가 없습니다.')
        return pages


def prepare_visual_assets(source: Path, assets: list[dict], visual_dir: Path) -> tuple[list[dict], list[str]]:
    """Make all possible visual evidence processable, preserving all originals.

    If embedded media is unrenderable directly, add page images for visual
    coverage and link each original to the generated page assets. Do not claim
    a per-image conversion where only page-level reconstruction is available.
    """
    messages: list[str] = []
    if not assets:
        return assets, messages
    conversion_dir = visual_dir / 'converted'
    pending: list[dict] = []
    for item in assets:
        ok, detail = try_convert_image(item, conversion_dir)
        if ok:
            if item.get('conversion_status'):
                messages.append(f"{item.get('visual_id')} · {detail} · 원본 보존")
            continue
        item['conversion_error'] = detail
        pending.append(item)

    if not pending:
        return assets, messages
    pages = None
    source_pages = None
    if source.suffix.lower() == '.pdf':
        import re
        parsed = [re.match(r'Page (\d+)\s*/', str(x.get('source_locator') or '')) for x in pending]
        if all(parsed):
            source_pages = {int(m.group(1)) for m in parsed if m}
    try:
        pages = render_source_pages(source, visual_dir / 'page_render_fallback', page_numbers=source_pages)
    except Exception as exc:
        reason = f'원본 문서 페이지 렌더링 실패: {type(exc).__name__}: {str(exc)[:240]}'
        for item in pending:
            item['conversion_error'] = f"{item.get('conversion_error', '')}; {reason}"
        messages.append(f'변환 불가능 이미지 {len(pending)}건 · {reason} · 원본 이미지 보존/완전성 차단 유지')
        return assets, messages

    rendered = []
    for page in pages:
        id_ = f'IMG-{len(assets)+len(rendered)+1:03d}'
        rendered.append({
            'visual_id': id_, 'kind': 'source_page_render',
            'source': f'Document page {page.stem}',
            'source_locator': f'Document page {page.stem} / Rendered fallback',
            'extracted_path': str(page), 'mime_type': 'image/png',
            'byte_size': page.stat().st_size, 'sha256': _sha(page),
            'vision_status': 'pending', 'conversion_status': 'document_page_render',
        })
    render_ids = [item['visual_id'] for item in rendered]
    for item in pending:
        item['vision_status'] = 'pending_render_coverage'
        item['fallback_render_ids'] = render_ids
        item['conversion_status'] = 'source_page_fallback'
        item['conversion_method'] = 'complete_document_page_render'
    messages.append(f'직접 변환 불가 {len(pending)}건 → 원본 문서 페이지 {len(rendered)}개 렌더링으로 대체 분석 예정 (원본 보존)')
    assets.extend(rendered)
    return assets, messages
