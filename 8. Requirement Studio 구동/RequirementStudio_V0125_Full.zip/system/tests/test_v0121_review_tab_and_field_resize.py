"""V0.121 authorized GUI-only change and unchanged Review Exchange/E2E contracts."""
from pathlib import Path
import ast
import textwrap

BASE = Path(__file__).resolve().parents[1]
SOURCE = (BASE / 'main.py').read_text(encoding='utf-8')
PARSED = ast.parse(SOURCE)
MAIN = next(c for c in PARSED.body if isinstance(c, ast.ClassDef) and c.name == 'MainWindow')


def method(name):
    func = next(c for c in MAIN.body if isinstance(c, ast.FunctionDef) and c.name == name)
    return ast.get_source_segment(SOURCE, func)


def test_tab_label_and_visual_mode_placement():
    assert '("result_analysis.png", "AI 품질 검토")' in method('_build_ui')
    assert '결과 품질 검토' not in method('_build_ui')
    section = method('_build_quality_review_box')
    assert 'self.review_mode_group.setExclusive(' not in section  # radio group stays native-exclusive
    assert 'self.review_mode_group.addButton(btn, idx)' in section
    assert 'mode_layout.addWidget(self.learning_only_checkbox)' in section
    assert 'if btn is self.review_mode_manual' in section
    # The learning widget is NOT enrolled into the exclusive radio group.
    assert 'self.review_mode_group.addButton(self.learning_only_checkbox' not in section
    assert section.index('self.review_mode_manual =') < section.index('self.learning_only_checkbox =')
    assert section.index('if btn is self.review_mode_manual:') < section.index('mode_layout.addWidget(self.learning_only_checkbox)')


def test_execution_card_has_four_regular_outputs_only():
    code = method('_build_execution_card')
    assert 'AI E2E 학습 후보 10개 생성' not in code
    assert 'self.output_choice_widgets = (' in code
    assert 'self.learning_only_checkbox' not in code
    assert 'self.start_button = QPushButton' in code


def test_initial_and_reset_defaults_no_auto_evaluation():
    code = method('_reset_quality_review_defaults')
    assert 'self.review_mode_none.setChecked(True)' in code
    assert 'self.learning_only_checkbox.setChecked(False)' in code
    assert 'self.review_mode_auto.setChecked(True)' not in code
    assert 'self.review_artifact_unified.setChecked(True)' in code


def test_reset_restores_two_defaults_using_isolated_method_runtime():
    class Stub:
        def __init__(self, checked=False):
            self.checked=checked
        def setChecked(self, v):
            self.checked=bool(v)
        def isChecked(self):
            return self.checked
    class View:
        review_mode_none=Stub()
        review_mode_auto=Stub(True)
        review_artifact_unified=Stub(False)
        learning_only_checkbox=Stub(True)
        def __init__(self): self.calls=0
        def _update_quality_review_ui_state(self): self.calls+=1
    # Extract only reset method in an isolated fake QWidget-free namespace.
    code = method('_reset_quality_review_defaults')
    namespace={}
    exec('class Runtime:\n'+textwrap.indent(code, '    '),namespace)
    fake=View()
    namespace['Runtime']._reset_quality_review_defaults(fake, initial=True)
    assert (fake.review_mode_none.checked, fake.learning_only_checkbox.checked, fake.review_artifact_unified.checked)==(True,False,True)
    fake.review_mode_none.setChecked(False)
    fake.learning_only_checkbox.setChecked(True)
    namespace['Runtime']._reset_quality_review_defaults(fake, initial=True)
    assert (fake.review_mode_none.checked, fake.learning_only_checkbox.checked)==(True,False)


def test_learning_selection_is_still_independent_of_review_mode():
    code=method('run_combined_pipeline')
    assert 'self.current_learning_only = bool(self.learning_only_checkbox.isChecked())' in code
    assert 'self.current_learning_only and not any(self.current_output_selection.values())' in code
    assert 'review_cfg = self._collect_quality_review_config()' in code
    assert 'if self.current_learning_only_run:' in code
    # No forced switching of 3-AI modes when checking learning.
    assert 'review_mode_auto.setChecked' not in method('_on_learning_mode_toggled')
    assert 'if self.current_learning_only and req_data' in method('_on_pipeline_success')


def test_dynamic_model_and_key_field_widths_reach_action_button():
    code=method('_build_ai_card')
    assert 'provider_grid.setColumnStretch(1, 1)' in code
    assert 'body.addLayout(provider_grid, 1)' in code
    assert 'body.addWidget(action_panel, 0' in code
    assert 'self.provider_model_combo.setMaximumWidth(360)' not in code
    assert 'self.api_key_field.setMaximumWidth(360)' not in code
    assert 'self.provider_model_combo.setSizePolicy(QSizePolicy.Policy.Expanding' in code
    assert 'self.api_key_field.setSizePolicy(QSizePolicy.Policy.Expanding' in code
    assert 'body.setSpacing(10)' in code
    assert 'btn.setFixedSize(124, 42)' in code


def test_existing_e2e_constitution_and_review_exchange_remain():
    assert 'self.review_exchange_builder = ReviewExchangeBuilder' in SOURCE
    assert 'create_learning_sample(self.project_root, document, req_data)' in SOURCE
    assert (BASE / 'Build AI Better Decision' / 'Decision Complete' / 'AI_E2E_GUIDELINE_CONSTITUTION.txt').is_file()
    assert 'self._start_automatic_evaluation(' in SOURCE


def test_api_key_and_provider_logic_not_touched_by_gui_change():
    assert 'self.api_key_field.clicked.connect(self._on_key_status_clicked)' in SOURCE
    assert 'self.radio_openai = QRadioButton("GPT")' in SOURCE
    assert 'self.radio_commercial_gemini = QRadioButton("Gemini")' in SOURCE
    assert 'self.radio_commercial_claude = QRadioButton("Claude")' in SOURCE
