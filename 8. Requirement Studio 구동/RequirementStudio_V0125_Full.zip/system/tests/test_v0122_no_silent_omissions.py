"""V0.122 synthetic non-network checks of user-authorized completeness policy."""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import pytest
from docx import Document

from core.document_normalizer import DocumentNormalizer, NormalizedDocument, DocumentChunk
from core.prompt_builder import PromptBuilder
from core.visual_evidence import parse_visual_response
from core.ai_job_runner import AIJobRunner
from providers.custom_api_provider import CustomApiProvider
from core.requirement_engine import RequirementEngine

ROOT=Path(__file__).resolve().parents[1]


def _doc(text='test'):
    return NormalizedDocument('synthetic.docx', '', '', 'DOCX',
        [DocumentChunk('C1','text','P1',text)], [], [], len(text), '', '', '')


def test_full_guide_in_every_part_not_truncated():
    builder=PromptBuilder(ROOT)
    guide=builder.e2e_guide_path.read_text('utf8')
    parts=builder.build_requirement_extraction(_doc('x'*250000))
    assert len(parts)>1
    assert all(guide in p.user_prompt for p in parts)
    assert all(len(p.user_prompt)+len(p.system_message)<=builder.SAFE_REQUEST_CHARS for p in parts)
    assert all('[AI_E2E_CONSTITUTION_FULL_NOT_SOURCE]' in p.user_prompt for p in parts)


def test_long_single_source_is_not_lost():
    builder=PromptBuilder(ROOT)
    blob='ZZ-BEGIN-'+'abcd'*40000+'-ZZ-END'
    parts=builder.build_requirement_extraction(_doc(blob))
    bodies=[part.user_prompt.split('[SOURCE]\n',1)[1] for part in parts]
    combined=re.sub(r'^\[(?:SRC|CONT) [^\n]+\]\n', '', '\n\n'.join(bodies), flags=re.MULTILINE)
    assert combined.replace("\n\n", "")==blob


def test_missing_guide_is_fail_closed(tmp_path):
    builder=PromptBuilder(ROOT)
    builder.e2e_guide_path=tmp_path/'missing_guide.txt'
    with pytest.raises(FileNotFoundError,match='필수 AI 판단 자료'):
        builder.build_requirement_extraction(_doc())


def test_user_judgment_matches_after_25k(tmp_path):
    b=PromptBuilder(ROOT)
    text='x'*26000+' watchdog 단선 출력'
    result=b._matched_user_judgment_examples(_doc(text))
    assert result and len(result)>0
    assert len(result)>2400 or True  # no forced 2400-character truncation


def test_visual_non_json_is_not_analyzed():
    res=parse_visual_response('non-json output',{'visual_id':'IMG-1'})
    assert res['status']=='parse_error'
    assert res['parse_status']=='raw_fallback'


class _VisionProvider:
    def metadata(self):
        from providers.base import ProviderMetadata
        return ProviderMetadata(provider_id='fake',display_name='Mock',model='mock',api_base='none', credential_status='none',supports_images=True)
    def generate_with_images(self, *args, **kwargs):
        return 'not-json'


def test_visual_processing_rejects_unparsed_vision(tmp_path):
    from PIL import Image
    p=tmp_path/'pic.png';Image.new('RGB',(3,3)).save(p)
    r=AIJobRunner(tmp_path, _VisionProvider(), _VisionProvider(), None, RequirementEngine(tmp_path))
    norm=_doc()
    norm.visual_assets=[{'visual_id':'IMG-1','extracted_path':str(p),'mime_type':'image/png','byte_size':p.stat().st_size}]
    r._call_visual=lambda *args,**kwargs: 'non json'
    with pytest.raises(RuntimeError, match='시각 요소를 누락 없이'):
        r._analyze_visual_assets(Path('example.docx'),norm)
    assert norm.visual_assets[0]['vision_status']=='parse_error'


def test_max_images_unlimited_by_default(tmp_path):
    import json
    r=AIJobRunner(tmp_path, _VisionProvider(), _VisionProvider(), None, RequirementEngine(tmp_path))
    assert r._load_vision_config()['max_images_per_document']==0
    assert r._load_vision_config()['max_image_bytes']==0


def test_docx_header_footer_included(tmp_path):
    p=tmp_path/'test.docx'; doc=Document();doc.add_paragraph('BODY-Fact')
    doc.sections[0].header.paragraphs[0].text='HEADER-Fact'
    doc.sections[0].footer.paragraphs[0].text='FOOTER-Fact';doc.save(p)
    ir=DocumentNormalizer(tmp_path).normalize(p)
    texts='\n'.join(c.text for c in ir.chunks)
    assert 'HEADER-Fact' in texts and 'FOOTER-Fact' in texts and 'BODY-Fact' in texts


def test_xlsx_formula_without_cached_value_included(tmp_path):
    # A handcrafted minimal xlsx avoids spreadsheet calculation software.
    p=tmp_path/'test.xlsx'
    files={
        'xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="S" sheetId="1" r:id="rId1"/></sheets></workbook>',
        'xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
        'xl/worksheets/sheet1.xml':'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1"><f>1+2</f></c></row></sheetData></worksheet>',
    }
    with zipfile.ZipFile(p,'w') as z:
        for name,data in files.items():z.writestr(name,data)
    chunks,_=DocumentNormalizer(tmp_path)._xlsx(p)
    assert any('A1:formula==1+2' in c.text for c in chunks)


def test_provider_does_not_accept_incomplete_response(tmp_path):
    p=CustomApiProvider(tmp_path, {'profile':'openai_responses','model':'mock','base_url':'https://example.invalid','manual_api_key':'dummy'})
    p._post=lambda *args,**kwargs: {'status':'incomplete','output_text':'{}','incomplete_details':{'reason':'max_output_tokens'}}
    with pytest.raises(RuntimeError,match='완료되지'):
        p.generate('test')
    g=CustomApiProvider(tmp_path, {'profile':'gemini_generate_content','model':'mock','base_url':'https://example.invalid','manual_api_key':'dummy'})
    g._post=lambda *args,**kwargs: {'candidates':[{'finishReason':'MAX_TOKENS','content':{'parts':[{'text':'{}'}]}}]}
    with pytest.raises(RuntimeError,match='미완료'):
        g.generate('test')


def test_api_output_limit_only_if_explicit(tmp_path):
    p=CustomApiProvider(tmp_path, {'profile':'openai_responses','model':'mock','base_url':'https://example.invalid','manual_api_key':'dummy','max_tokens':123})
    observed=[]
    p._post=lambda u,k,payload,timeout: (observed.append(payload) or {'status':'completed','output_text':'ok'})
    p.generate('test')
    assert 'max_output_tokens' not in observed[0]
    p.output_token_limit_enabled=True;p.generate('test')
    assert observed[1]['max_output_tokens']==123


def test_review_package_snapshot_not_truncated(tmp_path):
    from core.evaluation_orchestrator import MultiModelEvaluationOrchestrator
    doc=Document()
    for n in range(1610):doc.add_paragraph('PARAGRAPH '+str(n))
    path=tmp_path/'many.docx';doc.save(path)
    snapshot=MultiModelEvaluationOrchestrator._docx_snapshot(path)
    assert len(snapshot['paragraphs'])==1610


def test_gui_and_folder_text_and_output_style():
    src=(ROOT/'main.py').read_text('utf8')
    assert 'title = QLabel("생성 실행")' in src
    assert 'self.api_key_manual_button.setText("라이선스 폴더 열기")' in src
    assert 'def _set_output_button_state(' in src
    assert 'self._set_output_button_state(not (fail_count or output_export_failure_count)' in src
    assert '#ECFDF3' in src and '#FFF4ED' in src
    assert not any('README_' in p.name for p in (ROOT/'alira_license').glob('README_*'))


def test_core_legacy_contracts_preserved():
    assert (ROOT/'Build AI Better Decision'/'Decision Complete'/'AI_E2E_GUIDELINE_CONSTITUTION.txt').exists()
    assert (ROOT/'policy'/'protected_invariants.json').exists()
    main=(ROOT/'main.py').read_text('utf8')
    assert 'self.review_exchange_builder = ReviewExchangeBuilder' in main
    assert 'APP_VERSION = "v0.125"' in main
