"""V0.125 offline vision regression checks; no paid API calls.

Verify that a non-JSON response is retried exactly once, that only verified
observations are cached, and that stale or malformed cache cannot become facts.
"""
import hashlib
import json
from pathlib import Path
from PIL import Image
import pytest
from core.ai_job_runner import AIJobRunner
from core.document_normalizer import NormalizedDocument
from core.requirement_engine import RequirementEngine
from providers.base import ProviderMetadata


def _asset(path, number='IMG-001', kind='embedded_media'):
    b=path.read_bytes()
    return {'visual_id':number, 'kind':kind, 'extracted_path':str(path),
            'mime_type':'image/png', 'sha256':hashlib.sha256(b).hexdigest(),
            'byte_size':len(b), 'source_locator':'Page 1 / Render'}


def _norm(assets):
    return NormalizedDocument('test.docx', '', '', 'DOCX', [], assets, [], 0, '', '', '')


class Provider:
    def __init__(self,responses):
        self.responses=list(responses);self.calls=0;self.model='modelA'
    def metadata(self):
        return ProviderMetadata(provider_id='fake',display_name='Test',model=self.model,
             api_base='https://fake.invalid',credential_status='test',supports_images=True)
    def generate_with_images(self,prompt,paths,**kwargs):
        self.calls+=1
        if not self.responses: raise AssertionError('Unexpected API call')
        response=self.responses.pop(0)
        if isinstance(response,Exception):raise response
        return response

GOOD=json.dumps({'observed':['green icon'], 'interpreted':[], 'not_confirmed':[], 'summary':'ok'})

def _runner(tmp_path,p):
    return AIJobRunner(tmp_path,p,p,None,RequirementEngine(tmp_path))


def _image(tmp_path):
    source=tmp_path/'source.docx';source.write_bytes(b'source version 1')
    img=tmp_path/'page.png';Image.new('RGB',(10,10),'white').save(img)
    return source,img


def test_retry_only_bad_visual_json_once(tmp_path):
    source,img=_image(tmp_path)
    p=Provider(['unparsed',GOOD])
    runner=_runner(tmp_path,p)
    out=runner._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==2 and len(out)==1 and out[0]['status']=='analyzed'
    assert len(list((tmp_path/'work'/'verified_visual_cache').glob('*.json')))==1


def test_retry_failure_blocks_and_is_not_cached(tmp_path):
    source,img=_image(tmp_path)
    p=Provider(['bad','still-bad'])
    runner=_runner(tmp_path,p)
    with pytest.raises(RuntimeError, match='시각 요소를 누락 없이'):
        runner._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==2
    assert not list((tmp_path/'work'/'verified_visual_cache').glob('*.json'))


def test_request_error_not_auto_retried(tmp_path):
    source,img=_image(tmp_path)
    p=Provider([TimeoutError('ambiguous timeout')])
    with pytest.raises(RuntimeError, match='시각 요소를 누락 없이'):
        _runner(tmp_path,p)._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==1


def test_cache_across_runs_and_changes_invalidate(tmp_path):
    source,img=_image(tmp_path)
    p=Provider([GOOD,GOOD,GOOD])
    runner=_runner(tmp_path,p)
    runner._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==1
    again=_asset(img)
    runner2=_runner(tmp_path,p)
    evidence=runner2._analyze_visual_assets(source,_norm([again]))
    assert p.calls==1 and again['vision_cache_persistent']
    assert evidence[0]['source_locator']=='Page 1 / Render'
    source.write_bytes(b'source version 2')
    runner2._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==2
    p.model='modelB'
    runner2._analyze_visual_assets(source,_norm([_asset(img)]))
    assert p.calls==3


def test_bad_cache_is_ignored(tmp_path):
    source,img=_image(tmp_path)
    p=Provider([GOOD,GOOD])
    runner=_runner(tmp_path,p)
    a=_asset(img)
    key=runner._visual_cache_path(source,a,__import__('core.visual_evidence',fromlist=['build_visual_prompt']).build_visual_prompt(a))
    key.parent.mkdir(parents=True,exist_ok=True)
    key.write_text('{invalid',encoding='utf8')
    runner._analyze_visual_assets(source,_norm([a]))
    assert p.calls==1


def test_page_fallback_recovery_uses_only_missing_page(tmp_path):
    source,img=_image(tmp_path)
    p=Provider([GOOD,'bad',GOOD])
    runner=_runner(tmp_path,p)
    before=_asset(img,'IMG-001');before['conversion_status']='source_page_fallback';before['vision_status']='pending_render_coverage';before['fallback_render_ids']=['IMG-002','IMG-003']
    first=_asset(img,'IMG-002','source_page_render')
    img2=tmp_path/'page2.png';Image.new('RGB',(10,10),'black').save(img2)
    second=_asset(img2,'IMG-003','source_page_render')
    result=runner._analyze_visual_assets(source,_norm([before,first,second]))
    assert before['vision_status']=='covered_by_document_render'
    assert p.calls==3 and len(result)==2
    p2=Provider([])
    runner2=_runner(tmp_path,p2)
    before2=dict(before,vision_status='pending_render_coverage')
    result2=runner2._analyze_visual_assets(source,_norm([before2, _asset(img,'IMG-002','source_page_render'), _asset(img2,'IMG-003','source_page_render')]))
    assert p2.calls==0 and len(result2)==2


def test_gui_has_doc_index_and_partial_failure_status():
    text=(Path(__file__).resolve().parents[1]/'main.py').read_text('utf8')
    assert 'self._current_batch_index' in text
    assert "f'%p% ({self._current_batch_index}/{self._current_batch_total} 처리 중)'" in text
    assert 'STEP {self.current_stage}' in text
    assert '성공 {success_count}건 / 실패 {fail_count}건' in text
