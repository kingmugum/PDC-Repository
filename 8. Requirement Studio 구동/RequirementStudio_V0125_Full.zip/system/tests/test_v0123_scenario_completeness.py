"""V0.123 synthetic offline checks: no artificial branch ceiling or silent TC claims."""
from pathlib import Path
from core.semantic_objective_design import identify_conditional_path_goals
from core.basic_functional_test_design import build_basic_functional_cases
from core.semantic_split_diagnostic import build_semantic_split_diagnostic


def _synth(n=12):
    atoms=[{'source_fact_fragment_id': f'SYN-F-{i:02d}',
            'behavior_text':f'센서 {i} 감지 시 장비는 표시등 {i}을 점등한다.',
            'source_location':f'fictional diagram: node {i}'} for i in range(1,n+1)]
    req={'srs_id':'SRS_SYN','function_name':'가상 표시등','requirement':'가상 기능 동작',
         'source_backed_atomic_behaviors':atoms,'fact_level_allocations':[]}
    base={'parent_srs_id':'SRS_SYN','test_object_id':'SYN-OBJ','test_object_type':'SYS5_CANDIDATE',
          'source_fact_fragment_ids':[a['source_fact_fragment_id'] for a in atoms]}
    return req,base


def test_more_than_ten_traced_conditions_not_discarded():
    req,base=_synth(12)
    records=[{'fid':a['source_fact_fragment_id'],'text':a['behavior_text']}
             for a in req['source_backed_atomic_behaviors']]
    goals=identify_conditional_path_goals(records)
    assert len(goals)==12
    # Older callers passing the historical ceiling must not drop all results.
    assert len(identify_conditional_path_goals(records, maximum_goals=10))==12
    cases,_,audit=build_basic_functional_cases({'requirements':[req]},[base])
    functional=[c for c in cases if c.get('test_design_mode')=='BASIC_FUNCTIONAL_SOURCE_BACKED']
    assert len(functional)>=12
    assert {c.get('semantic_condition_source') for c in functional if c.get('semantic_condition_source')}


def test_no_source_no_branch_or_invented_terminal_behavior():
    records=[{'fid':'','text':'센서가 켜지면 모터를 정지한다.'},
             {'fid':'SYN-A','text':'센서 감지, 이후 동작 미명시'}]
    assert identify_conditional_path_goals(records)==[]


def test_diagnostic_lists_all_thirty_three_model_scenarios_without_coverage_claim():
    req,base=_synth(1)
    cases,_,audit=build_basic_functional_cases({'requirements':[req]},[base])
    cases=cases[:1]
    scenarios=[{'scenario_candidate_id':f'SYN-SCN-{i:02d}',
                'scenario_name':f'가상 경로 {i}',
                'source_evidence':[{'document':'invented.pdf','location':f'p{i}','text':f'fictitious {i}'}]}
               for i in range(1,34)]
    report=build_semantic_split_diagnostic(source_document=Path('fictional.pdf'),
        cases=cases,human_ids=['T001'],reqs={'SRS_SYN':req},
        design_audit=audit,scenario_candidates=scenarios)
    assert 'V0.125' in report
    assert 'scenario_candidates: 33건' in report
    assert 'SYN-SCN-01' in report and 'SYN-SCN-33' in report
    assert '누락 확정 아님' in report
    assert 'fictitious 1' not in report


def test_residual_not_gated_by_number_of_legacy_cases(monkeypatch):
    from core import basic_functional_test_design as d
    req,base=_synth(3)
    def existing(r,b,i):
        old=d._fallback_case(r,b,i)
        old['basic_case_kind']='PREVIOUS_SYNTHETIC_RULE'
        old['source_fact_fragment_ids']=['SYN-F-01']
        return [old],i+1
    monkeypatch.setattr(d,'_dimension_case',existing)
    cases,_,audit=d.build_basic_functional_cases({'requirements':[req]},[base])
    events=audit['semantic_split_diagnostic_events']
    assert events and events[0]['accepted_residual_count']>=2
    assert len(cases)>=3
