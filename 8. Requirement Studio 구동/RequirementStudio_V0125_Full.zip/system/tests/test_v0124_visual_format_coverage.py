"""V0.124: image format conversion, document-render coverage, duplicate safety.

All tests are offline and never send documents/API keys to an external service.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest
from PIL import Image

from core.ai_job_runner import AIJobRunner
from core.document_normalizer import NormalizedDocument
from core.requirement_engine import RequirementEngine
from core.visual_format_adapter import try_convert_image, prepare_visual_assets


def _asset(path: Path, label: str = 'IMG-001') -> dict:
    content = path.read_bytes()
    return {
        'visual_id': label, 'kind': 'embedded_media', 'source': 'word/media/image1.emf',
        'source_locator': 'word/media/image1.emf', 'extracted_path': str(path),
        'mime_type': {'bmp':'image/bmp','tif':'image/tiff','svg':'image/svg+xml','emf':'image/x-emf'}.get(path.suffix[1:],'image/png'),
        'byte_size': len(content), 'sha256': hashlib.sha256(content).hexdigest(),
        'vision_status':'pending',
    }


def _doc(assets: list[dict]) -> NormalizedDocument:
    return NormalizedDocument('demo.docx', '', '', 'DOCX', [], assets, [], 0, '', '', '')


class _StubProvider:
    calls = 0
    def metadata(self):
        from providers.base import ProviderMetadata
        return ProviderMetadata(provider_id='fake',display_name='Test',model='mock',api_base='none',credential_status='none',supports_images=True)
    def generate_with_images(self, prompt, image_paths, **kwargs):
        self.calls += 1
        assert Image.open(image_paths[0]).format == 'PNG'
        return json.dumps({'observed':['diagram observed'],'interpreted':[], 'not_confirmed':[], 'summary':'ok'})


def _runner(tmp_path, provider):
    return AIJobRunner(tmp_path, provider, provider, None, RequirementEngine(tmp_path))


@pytest.mark.parametrize('format,extension', [('BMP','.bmp'),('TIFF','.tif')])
def test_common_unsupported_raster_is_converted_preserving_original(tmp_path, format, extension):
    p=tmp_path/('image'+extension);Image.new('RGB',(40,30),(90,120,150)).save(p,format=format)
    before=p.read_bytes();a=_asset(p)
    ok,message=try_convert_image(a,tmp_path/'converted')
    assert ok and '완료' in message
    assert a['mime_type']=='image/png' and Path(a['extracted_path']).is_file()
    assert a['original_visual']['extracted_path']==str(p)
    assert p.read_bytes()==before


def test_svg_converts_without_external_resource(tmp_path):
    p=tmp_path/'diagram.svg'
    p.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="60" height="30"><rect width="60" height="30" fill="red"/></svg>',encoding='utf-8')
    a=_asset(p)
    ok,message=try_convert_image(a,tmp_path/'converted')
    assert ok, message
    assert Image.open(a['extracted_path']).format=='PNG'


def test_untrusted_svg_fails_local_conversion(tmp_path, monkeypatch):
    # The script/external resource may not be loaded by the local converter.
    monkeypatch.setattr('core.visual_format_adapter.shutil.which',lambda *_: None)
    p=tmp_path/'remote.svg'
    p.write_text('<svg xmlns="http://www.w3.org/2000/svg"><image href="https://external.invalid/secret"/></svg>')
    ok,message=try_convert_image(_asset(p),tmp_path/'converted')
    assert not ok


def test_unconvertible_office_media_uses_page_fallback_and_reports_scope(tmp_path,monkeypatch):
    source=tmp_path/'document.docx';source.write_bytes(b'mock office doc')
    media=tmp_path/'image.emf';media.write_bytes(b'not-real-emf')
    old=_asset(media)
    rendered=tmp_path/'render.png';Image.new('RGB',(35,28),'white').save(rendered)
    monkeypatch.setattr('core.visual_format_adapter.shutil.which',lambda *_: None)
    monkeypatch.setattr('core.visual_format_adapter.render_source_pages',lambda *_args,**_kwargs: [rendered])
    assets,messages=prepare_visual_assets(source,[old],tmp_path/'media')
    assert len(assets)==2
    assert old['vision_status']=='pending_render_coverage'
    assert old['fallback_render_ids']==[assets[-1]['visual_id']]
    provider=_StubProvider(); runner=_runner(tmp_path,provider)
    evidence=runner._analyze_visual_assets(source,_doc(assets))
    assert len(evidence)==1 and provider.calls==1
    assert old['vision_status']=='covered_by_document_render'
    assert '1:1' in old['render_coverage_note']


def test_render_fallback_failure_remains_blocking(tmp_path,monkeypatch):
    source=tmp_path/'document.docx';source.write_bytes(b'mock')
    media=tmp_path/'image.emf';media.write_bytes(b'not-real-emf')
    monkeypatch.setattr('core.visual_format_adapter.shutil.which',lambda *_: None)
    def broken(*args,**kwargs): raise RuntimeError('missing renderer')
    monkeypatch.setattr('core.visual_format_adapter.render_source_pages',broken)
    assets,messages=prepare_visual_assets(source,[_asset(media)],tmp_path/'media')
    assert len(assets)==1 and 'missing renderer' in assets[0]['conversion_error']
    runner=_runner(tmp_path,_StubProvider())
    with pytest.raises(RuntimeError, match='unsupported_format'):
        runner._analyze_visual_assets(source,_doc(assets))


def test_sha_duplicate_reuses_api_observation_but_not_provenance(tmp_path):
    img=tmp_path/'same.png';Image.new('RGB',(10,10),'white').save(img)
    a=_asset(img,'IMG-001'); a['source_locator']='page1'
    b=_asset(img,'IMG-002'); b['source_locator']='page2'
    provider=_StubProvider();runner=_runner(tmp_path,provider)
    evidence=runner._analyze_visual_assets(img,_doc([a,b]))
    assert provider.calls==1
    assert len(evidence)==2
    assert evidence[0]['visual_id']=='IMG-001'
    assert evidence[1]['visual_id']=='IMG-002'
    assert evidence[1]['source_locator']=='page2'
    assert b['vision_cache_reused']


def test_failed_render_does_not_fake_covered_image(tmp_path):
    img=tmp_path/'same.png';Image.new('RGB',(10,10),'white').save(img)
    a=_asset(img,'IMG-001'); a['conversion_status']='source_page_fallback';a['vision_status']='pending_render_coverage';a['fallback_render_ids']=['IMG-002']
    b=_asset(img,'IMG-002');b['kind']='source_page_render'
    provider=_StubProvider();runner=_runner(tmp_path,provider)
    runner._call_visual=lambda *args,**kwargs: 'non-json'
    with pytest.raises(RuntimeError, match='시각 요소를 누락 없이'):
        runner._analyze_visual_assets(img,_doc([a,b]))
    assert a['vision_status']=='render_coverage_incomplete'


def test_pdf_render_only_requested_pages(tmp_path):
    import fitz
    from core.visual_format_adapter import render_source_pages
    src=tmp_path/'source.pdf';doc=fitz.open()
    for i in range(3):
        page=doc.new_page();page.insert_text((55,55),f'Page {i+1}')
    doc.save(str(src));doc.close()
    pages=render_source_pages(src,tmp_path/'images',page_numbers={2})
    assert len(pages)==1 and '0002' in pages[0].name
    assert Image.open(pages[0]).format=='PNG'
