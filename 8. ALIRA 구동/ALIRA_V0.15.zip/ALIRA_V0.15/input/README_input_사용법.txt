이 폴더에는 분석할 문서 1개만 넣어주세요.

샘플 문서는 ../sample_inputs 폴더에 있습니다.
현재 앱은 PDF / DOCX / PPTX / XLSX / XLSM 파일을 지원 대상으로 인식합니다.
