# sample_inputs 사용 방법

이 폴더에는 같은 내용을 서로 다른 문서 형식으로 작성한 요구사항 추출 시험용 샘플이 들어 있습니다.

지원 샘플:
- sample_vcu_lite_implicit_behavior.pdf
- sample_vcu_lite_implicit_behavior.docx
- sample_vcu_lite_implicit_behavior.pptx
- sample_vcu_lite_implicit_behavior.xlsx

사용 방법:
1. 이 폴더의 샘플 중 1개만 복사합니다.
2. 프로젝트 Root의 input 폴더에 붙여넣습니다.
3. 프로그램에서 [새로고침]을 누릅니다.
4. 문서명이 표시되면 [문서 분석]을 누릅니다.

주의:
- 현재 Baseline은 input 폴더의 지원 문서가 정확히 1개일 때만 분석합니다.
- 여러 샘플을 한 번에 input에 넣으면 분석 버튼이 비활성화됩니다.
- 이 샘플은 가상 차량용 제어기 설명서이며 실제 고객/회사 사양이 아닙니다.
