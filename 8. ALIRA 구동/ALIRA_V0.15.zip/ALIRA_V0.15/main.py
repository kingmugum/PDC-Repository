import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThreadPool, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QFont, QIcon
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLayout,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QPlainTextEdit,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from core.alira_client import AliraClient
from core.document_manager import DocumentManager
from core.worker import TaskWorker, ConnectionTestWorker
from core.result_exporter import AnalysisResultExporter
from core.requirement_engine import RequirementEngine


APP_TITLE = "ALIRA Requirement Studio"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.project_root = Path(__file__).resolve().parent
        self.client = AliraClient(project_root=self.project_root)
        self.documents = DocumentManager(self.project_root / "input")
        self.sample_dir = self.project_root / "sample_inputs"
        self.thread_pool = QThreadPool.globalInstance()
        self.result_exporter = AnalysisResultExporter(self.project_root / "output")
        self.requirement_engine = RequirementEngine(self.project_root)

        self.current_document = None
        self.document_error = None
        self.operation_busy = False
        self.connection_test_running = False
        self.connection_worker = None
        self._collapsed_window_height = None
        self.connection_details_expanded = False
        self.last_connection_progress = -1
        self.last_analysis_text = ""
        self.last_analysis_document = None
        self.pending_analysis_document = None
        self.pending_requirement_document = None
        self.last_requirement_data = None
        self.last_requirement_evaluation = None

        self.setWindowTitle(APP_TITLE)
        icon_path = self.project_root / "assets" / "ALIRA.ico"
        if icon_path.is_file():
            self.setWindowIcon(QIcon(str(icon_path)))

        self.resize(980, 760)
        self.setMinimumSize(820, 650)

        self._build_ui()
        self._apply_style()
        self._refresh_environment_status()
        self.refresh_input_document()

        # UI가 실제로 표시된 직후 1회 자동 연결 확인.
        QTimer.singleShot(450, self._run_initial_connection_test)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)

        layout = QVBoxLayout(root)
        layout.setContentsMargins(26, 22, 26, 22)
        layout.setSpacing(16)

        # Header
        header = QHBoxLayout()
        title_box = QVBoxLayout()

        title = QLabel(APP_TITLE)
        title.setObjectName("title")

        subtitle = QLabel("ALIRA 문서 분석 + Reference 기반 Requirement Candidate · v0.15")
        subtitle.setObjectName("subtitle")

        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        header.addLayout(title_box)
        header.addStretch()
        layout.addLayout(header)

        # Connection card
        connection_card = self._make_card()
        self.connection_card = connection_card
        connection_layout = QVBoxLayout(connection_card)
        connection_layout.setContentsMargins(20, 14, 16, 14)
        connection_layout.setSpacing(10)

        connection_header = QHBoxLayout()
        connection_header.setSpacing(9)

        connection_title = QLabel("ALIRA Connection")
        connection_title.setObjectName("sectionTitle")
        connection_header.addWidget(connection_title)
        connection_header.addStretch()

        self.connection_led = QLabel()
        self.connection_led.setFixedSize(12, 12)
        self.connection_led.setToolTip("ALIRA 연결 상태")
        connection_header.addWidget(self.connection_led)

        self.connection_status_label = QLabel("ALIRA 연결 확인 중...")
        self.connection_status_label.setObjectName("connectionStatus")
        self.connection_status_label.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )
        connection_header.addWidget(self.connection_status_label)

        self.connection_toggle_button = QPushButton("+")
        self.connection_toggle_button.setObjectName("toggleButton")
        self.connection_toggle_button.setFixedSize(34, 34)
        self.connection_toggle_button.setToolTip("연결 상세 펼치기")
        self.connection_toggle_button.clicked.connect(self.toggle_connection_details)
        connection_header.addWidget(self.connection_toggle_button)

        connection_layout.addLayout(connection_header)

        # Default hidden details.
        # Connection Result / environment / manual buttons are all hidden
        # unless the user explicitly expands the [+] section.
        self.connection_details_widget = QWidget()
        details_layout = QVBoxLayout(self.connection_details_widget)
        details_layout.setContentsMargins(0, 4, 0, 0)
        details_layout.setSpacing(8)
        details_layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)

        self.exe_label = QLabel()
        self.model_label = QLabel()
        self.api_label = QLabel()

        for widget in (self.exe_label, self.model_label, self.api_label):
            widget.setObjectName("infoText")
            widget.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            details_layout.addWidget(widget)

        conn_buttons = QHBoxLayout()
        conn_buttons.setContentsMargins(0, 4, 0, 0)

        self.test_button = QPushButton("ALIRA 연결 테스트")
        self.test_button.setObjectName("primaryButton")
        self.test_button.setMinimumWidth(170)
        self.test_button.clicked.connect(lambda: self.run_connection_test(automatic=False))

        self.clear_button = QPushButton("결과 지우기")
        self.clear_button.setObjectName("secondaryButton")
        self.clear_button.setMinimumWidth(110)
        self.clear_button.clicked.connect(self.clear_connection_result)

        conn_buttons.addWidget(self.test_button)
        conn_buttons.addWidget(self.clear_button)
        conn_buttons.addStretch()

        details_layout.addLayout(conn_buttons)

        connection_result_title = QLabel("Connection Result")
        connection_result_title.setObjectName("miniSectionTitle")
        details_layout.addWidget(connection_result_title)

        self.connection_result_box = QPlainTextEdit()
        self.connection_result_box.setReadOnly(True)
        self.connection_result_box.setMinimumHeight(92)
        self.connection_result_box.setMaximumHeight(118)
        self.connection_result_box.setPlaceholderText(
            "ALIRA 연결 확인 단계가 여기에 표시됩니다."
        )
        self.connection_result_box.setObjectName("connectionResultBox")
        details_layout.addWidget(self.connection_result_box)

        self.connection_details_widget.setVisible(False)
        connection_layout.addWidget(self.connection_details_widget)
        layout.addWidget(connection_card)

        # Document card
        document_card = self._make_card()
        document_layout = QVBoxLayout(document_card)
        document_layout.setContentsMargins(20, 16, 20, 16)
        document_layout.setSpacing(10)

        document_title = QLabel("Source Document")
        document_title.setObjectName("sectionTitle")
        document_layout.addWidget(document_title)

        self.document_name_label = QLabel("input 폴더에 문서를 넣어주세요.")
        self.document_name_label.setObjectName("documentName")
        self.document_name_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        document_layout.addWidget(self.document_name_label)

        self.document_meta_label = QLabel(
            "지원 형식: PDF / DOCX / PPTX / XLSX / XLSM"
        )
        self.document_meta_label.setObjectName("infoText")
        document_layout.addWidget(self.document_meta_label)

        doc_buttons = QHBoxLayout()

        self.open_input_button = QPushButton("input 폴더 열기")
        self.open_input_button.setObjectName("secondaryButton")
        self.open_input_button.clicked.connect(self.open_input_folder)

        self.open_sample_button = QPushButton("샘플 폴더 열기")
        self.open_sample_button.setObjectName("secondaryButton")
        self.open_sample_button.clicked.connect(self.open_sample_folder)

        self.refresh_button = QPushButton("새로고침")
        self.refresh_button.setObjectName("secondaryButton")
        self.refresh_button.clicked.connect(self.manual_refresh_input_document)

        self.policy_button = QPushButton("판단 원칙 열기")
        self.policy_button.setObjectName("secondaryButton")
        self.policy_button.clicked.connect(self.open_requirement_policy)

        self.analyze_button = QPushButton("문서 분석")
        self.analyze_button.setObjectName("secondaryButton")
        self.analyze_button.clicked.connect(self.run_document_analysis)

        self.extract_button = QPushButton("요구사항 추출")
        self.extract_button.setObjectName("primaryButton")
        self.extract_button.setMinimumWidth(125)
        self.extract_button.clicked.connect(self.run_requirement_extraction)

        doc_buttons.addWidget(self.open_input_button)
        doc_buttons.addWidget(self.open_sample_button)
        doc_buttons.addWidget(self.refresh_button)
        doc_buttons.addStretch()
        doc_buttons.addWidget(self.policy_button)
        doc_buttons.addWidget(self.analyze_button)
        doc_buttons.addWidget(self.extract_button)

        document_layout.addLayout(doc_buttons)
        layout.addWidget(document_card)

        # Result card
        result_card = self._make_card()
        result_layout = QVBoxLayout(result_card)
        result_layout.setContentsMargins(20, 16, 20, 16)
        result_layout.setSpacing(10)

        self.result_tabs = QTabWidget()
        self.result_tabs.setObjectName("resultTabs")

        # Analysis tab
        analysis_tab = QWidget()
        analysis_layout = QVBoxLayout(analysis_tab)
        analysis_layout.setContentsMargins(0, 0, 0, 0)
        analysis_layout.setSpacing(10)

        result_header = QHBoxLayout()

        result_title = QLabel("Analysis Result")
        result_title.setObjectName("sectionTitle")
        result_title.setMinimumWidth(220)
        result_header.addWidget(result_title)
        result_header.addStretch()

        self.open_output_button = QPushButton("output 폴더 열기")
        self.open_output_button.setObjectName("secondaryButton")
        self.open_output_button.clicked.connect(self.open_output_folder)

        self.export_result_button = QPushButton("분석 결과 문서 저장")
        self.export_result_button.setObjectName("primaryButton")
        self.export_result_button.setEnabled(False)
        self.export_result_button.clicked.connect(self.export_analysis_result)

        result_header.addWidget(self.open_output_button)
        result_header.addWidget(self.export_result_button)
        analysis_layout.addLayout(result_header)

        self.response_box = QPlainTextEdit()
        self.response_box.setReadOnly(True)
        self.response_box.setPlaceholderText(
            "input 폴더에 문서 1개를 넣고 ‘문서 분석’을 누르면 결과가 표시됩니다."
        )
        analysis_layout.addWidget(self.response_box, 1)

        # Requirement Candidates tab
        requirement_tab = QWidget()
        requirement_layout = QVBoxLayout(requirement_tab)
        requirement_layout.setContentsMargins(0, 0, 0, 0)
        requirement_layout.setSpacing(10)

        requirement_header = QHBoxLayout()

        requirement_title = QLabel("Requirement Candidates")
        requirement_title.setObjectName("sectionTitle")
        requirement_title.setMinimumWidth(220)
        requirement_header.addWidget(requirement_title)
        requirement_header.addStretch()

        self.open_reference_button = QPushButton("Reference 폴더 열기")
        self.open_reference_button.setObjectName("secondaryButton")
        self.open_reference_button.clicked.connect(self.open_reference_folder)

        self.open_policy_button = QPushButton("판단 원칙 열기")
        self.open_policy_button.setObjectName("secondaryButton")
        self.open_policy_button.clicked.connect(self.open_requirement_policy)

        requirement_header.addWidget(self.open_reference_button)
        requirement_header.addWidget(self.open_policy_button)
        requirement_layout.addLayout(requirement_header)

        self.requirement_result_box = QPlainTextEdit()
        self.requirement_result_box.setReadOnly(True)
        self.requirement_result_box.setPlaceholderText(
            "‘요구사항 추출’을 실행하면 Canonical Requirement 후보와 구조 평가가 표시됩니다."
        )
        requirement_layout.addWidget(self.requirement_result_box, 1)

        self.result_tabs.addTab(analysis_tab, "문서 분석")
        self.result_tabs.addTab(requirement_tab, "요구사항 후보")

        result_layout.addWidget(self.result_tabs, 1)
        layout.addWidget(result_card, 1)

        # Footer
        footer = QHBoxLayout()
        self.status_label = QLabel("준비")
        self.status_label.setObjectName("footerText")
        footer.addWidget(self.status_label)
        footer.addStretch()

        self.progress_label = QLabel("")
        self.progress_label.setObjectName("footerText")
        footer.addWidget(self.progress_label)

        layout.addLayout(footer)

    def _make_card(self):
        card = QFrame()
        card.setObjectName("card")
        return card

    def _apply_style(self):
        self.setStyleSheet(
            """
            QMainWindow, QWidget {
                background: #F5F7FB;
                color: #172033;
                font-family: "Segoe UI", "Malgun Gothic";
                font-size: 14px;
            }
            QLabel#title {
                font-size: 25px;
                font-weight: 700;
                color: #111827;
            }
            QLabel#subtitle {
                color: #667085;
                font-size: 13px;
            }
            QLabel#sectionTitle {
                font-size: 16px;
                font-weight: 700;
                color: #1D2939;
            }
            QLabel#miniSectionTitle {
                font-size: 12px;
                font-weight: 700;
                color: #667085;
                padding-top: 2px;
            }
            QLabel#connectionStatus {
                font-size: 13px;
                font-weight: 700;
                padding: 0 2px;
            }
            QLabel#infoText {
                color: #475467;
                padding: 2px 0;
            }
            QLabel#documentName {
                color: #172033;
                font-size: 15px;
                font-weight: 600;
                padding: 4px 0;
            }
            QLabel#footerText {
                color: #667085;
                font-size: 12px;
            }
            QFrame#card {
                background: white;
                border: 1px solid #E6EAF0;
                border-radius: 14px;
            }
            QPushButton {
                min-height: 40px;
                border-radius: 9px;
                padding: 0 17px;
                font-weight: 600;
            }
            QPushButton#primaryButton {
                background: #3B5CCC;
                color: white;
                border: 1px solid #3B5CCC;
            }
            QPushButton#primaryButton:hover {
                background: #324FB4;
            }
            QPushButton#primaryButton:disabled {
                background: #A9B3D9;
                border-color: #A9B3D9;
            }
            QPushButton#secondaryButton {
                background: white;
                color: #344054;
                border: 1px solid #D0D5DD;
            }
            QPushButton#secondaryButton:hover {
                background: #F9FAFB;
            }
            QPushButton#toggleButton {
                background: #FFFFFF;
                color: #344054;
                border: 1px solid #D0D5DD;
                border-radius: 8px;
                padding: 0;
                font-size: 20px;
                font-weight: 500;
            }
            QPushButton#toggleButton:hover {
                background: #F2F4F7;
                border-color: #B8C0CC;
            }
            QTabWidget#resultTabs::pane {
                border: 1px solid #E4E7EC;
                border-radius: 10px;
                background: #FFFFFF;
                top: -1px;
            }
            QTabWidget#resultTabs QTabBar::tab {
                background: #F2F4F7;
                color: #475467;
                border: 1px solid #D0D5DD;
                padding: 8px 16px;
                min-width: 110px;
            }
            QTabWidget#resultTabs QTabBar::tab:selected {
                background: #FFFFFF;
                color: #3158C8;
                font-weight: 700;
            }
            QPlainTextEdit#connectionResultBox {
                background: #F8FAFC;
                border: 1px solid #E4E7EC;
                border-radius: 8px;
                padding: 9px;
                color: #344054;
                font-family: "Consolas", "Malgun Gothic";
                font-size: 12px;
            }
            QPlainTextEdit {
                background: #FBFCFE;
                border: 1px solid #DDE3EA;
                border-radius: 10px;
                padding: 12px;
                selection-background-color: #B6C2F0;
                font-family: "Consolas", "Malgun Gothic";
                font-size: 13px;
            }
            """
        )

    # -----------------------------------------------------------------
    # Connection UI
    # -----------------------------------------------------------------
    def toggle_connection_details(self):
        self.connection_details_expanded = not self.connection_details_expanded

        if self.connection_details_expanded:
            if not self.isMaximized():
                self._collapsed_window_height = self.height()

            self.connection_details_widget.setVisible(True)
            self.connection_toggle_button.setText("−")
            self.connection_toggle_button.setToolTip("연결 상세 접기")
            QTimer.singleShot(0, self._fit_connection_details)
        else:
            self.connection_details_widget.setVisible(False)
            self.connection_toggle_button.setText("+")
            self.connection_toggle_button.setToolTip("연결 상세 펼치기")

            if (
                not self.isMaximized()
                and self._collapsed_window_height
                and self.height() > self._collapsed_window_height
            ):
                self.resize(self.width(), self._collapsed_window_height)

    def _fit_connection_details(self):
        if not self.connection_details_expanded:
            return

        self.connection_details_widget.adjustSize()
        self.connection_card.adjustSize()

        central = self.centralWidget()
        if central is not None and central.layout() is not None:
            central.layout().activate()

        if self.isMaximized():
            return

        details_h = self.connection_details_widget.sizeHint().height()
        base_h = self._collapsed_window_height or self.height()
        target_h = max(self.height(), base_h + details_h)

        screen = self.screen()
        if screen is not None:
            available_h = screen.availableGeometry().height()
            target_h = min(target_h, max(base_h, available_h - 40))

        self.resize(self.width(), target_h)

    def _set_connection_status(self, state, text, tooltip=None):
        palettes = {
            "checking": {
                "led": "#F79009",
                "border": "#FEC84B",
                "text": "#B54708",
            },
            "connected": {
                "led": "#12B76A",
                "border": "#6CE9A6",
                "text": "#3158C8",
            },
            "disconnected": {
                "led": "#F04438",
                "border": "#FDA29B",
                "text": "#D92D20",
            },
            "unknown": {
                "led": "#98A2B3",
                "border": "#D0D5DD",
                "text": "#667085",
            },
        }

        p = palettes.get(state, palettes["unknown"])
        self.connection_led.setStyleSheet(
            f"background:{p['led']};"
            f"border:1px solid {p['border']};"
            "border-radius:6px;"
        )
        self.connection_status_label.setText(text)
        self.connection_status_label.setStyleSheet(
            f"color:{p['text']}; font-weight:700;"
        )

        tip = tooltip or text
        self.connection_led.setToolTip(tip)
        self.connection_status_label.setToolTip(tip)

    def _refresh_environment_status(self):
        self.exe_label.setText(f"실행 파일   {self.client.exe_path}")
        self.model_label.setText(f"Model       {self.client.model}")
        self.api_label.setText(f"API Base    {self.client.api_base}")

        if self.client.exe_exists():
            self._set_connection_status(
                "checking",
                "ALIRA 연결 확인 중...",
                "프로그램 시작 시 ALIRA 연결을 자동 확인합니다.",
            )
        else:
            self._set_connection_status(
                "disconnected",
                "ALIRA 연결 안 됨",
                f"ALIRA 실행 파일을 찾지 못했습니다: {self.client.exe_path}",
            )

    def _run_initial_connection_test(self):
        if not self.client.exe_exists():
            self.status_label.setText("ALIRA 실행 파일 확인 필요")
            return
        self.run_connection_test(automatic=True)

    def run_connection_test(self, automatic=False):
        if self.connection_test_running:
            return

        if not self.client.exe_exists():
            message = f"ALIRA 실행 파일을 찾지 못했습니다.\n\n{self.client.exe_path}"
            self._set_connection_status(
                "disconnected",
                "ALIRA 연결 안 됨",
                message,
            )
            self.status_label.setText("ALIRA 연결 확인 실패")

            if not automatic:
                QMessageBox.critical(self, "ALIRA 실행 파일 없음", message)
            return

        self.connection_test_running = True
        self._set_connection_status(
            "checking",
            "ALIRA 연결 확인 중...",
            "사내 Qwen vLLM까지 실제 요청을 보내 연결 상태를 확인하고 있습니다.",
        )

        if not automatic:
            self.status_label.setText("ALIRA 연결 재확인 중...")

        self._sync_button_states()

        self.connection_result_box.clear()
        self.last_connection_progress = -1
        self._append_connection_result(0, "ALIRA 연결 확인 시작")

        worker = ConnectionTestWorker(self.client)
        self.connection_worker = worker
        worker.signals.progress.connect(self._on_connection_progress)
        worker.signals.success.connect(
            lambda text: self._on_connection_success(text, automatic)
        )
        worker.signals.error.connect(
            lambda error: self._on_connection_error(error, automatic)
        )
        worker.signals.finished.connect(self._on_connection_test_finished)
        self.thread_pool.start(worker)

    def _append_connection_result(self, percent, message):
        self.connection_result_box.appendPlainText(
            f"[{int(percent):3d}%] {message}"
        )

    def _on_connection_progress(self, percent, message):
        if not self.connection_test_running:
            return

        percent = max(0, min(99, int(percent)))

        self._set_connection_status(
            "checking",
            f"ALIRA 연결 확인 중... ({percent}%)",
            message,
        )
        self.status_label.setText(f"ALIRA 연결 확인 중... ({percent}%)")
        self.progress_label.setText(f"Connection {percent}%")

        if percent != self.last_connection_progress:
            self._append_connection_result(percent, message)
            self.last_connection_progress = percent

    def _on_connection_success(self, text, automatic):
        # Finalize state first so any late queued progress event is ignored.
        self.connection_test_running = False
        self.last_connection_progress = 100

        self._set_connection_status(
            "connected",
            "ALIRA 정상 연결됨 (100%)",
            f"ALIRA → 사내 Qwen 연결 확인 완료\n\n{text}",
        )
        self._append_connection_result(100, "ALIRA 정상 연결 확인 완료")
        self.status_label.setText("준비" if automatic else "ALIRA 연결 테스트 성공")
        self.progress_label.setText("")
        self._sync_button_states()

    def _on_connection_error(self, error_text, automatic):
        self.connection_test_running = False
        current = max(0, min(99, self.last_connection_progress))

        self._set_connection_status(
            "disconnected",
            f"ALIRA 연결 안 됨 ({current}%)",
            error_text,
        )
        self.connection_result_box.appendPlainText(
            f"[FAIL] {error_text}"
        )
        self.status_label.setText("ALIRA 연결 확인 실패")
        self.progress_label.setText("")
        self._sync_button_states()

        if not automatic:
            QMessageBox.warning(
                self,
                "ALIRA 연결 실패",
                error_text,
            )

    def _on_connection_test_finished(self):
        # success/error owns the final status. finished only cleans lifecycle.
        self.connection_worker = None

        # Defensive fallback: never leave the UI in permanent "checking" state.
        if self.connection_test_running:
            self.connection_test_running = False
            current = max(0, min(99, self.last_connection_progress))
            self._set_connection_status(
                "disconnected",
                f"ALIRA 연결 안 됨 ({current}%)",
                "연결 확인 Worker가 최종 결과 없이 종료되었습니다.",
            )
            self.connection_result_box.appendPlainText(
                "[FAIL] 연결 확인 Worker가 최종 결과 없이 종료되었습니다."
            )
            self.status_label.setText("ALIRA 연결 확인 비정상 종료")

        self._sync_button_states()

    # -----------------------------------------------------------------
    # Document / analysis
    # -----------------------------------------------------------------
    def open_input_folder(self):
        self.documents.ensure_input_dir()
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.documents.input_dir)))

    def open_sample_folder(self):
        self.sample_dir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.sample_dir)))

    def open_requirement_policy(self):
        policy_path = self.requirement_engine.policy_path
        if not policy_path.is_file():
            QMessageBox.warning(
                self,
                "판단 원칙 파일 없음",
                f"파일을 찾을 수 없습니다.\n\n{policy_path}",
            )
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(policy_path)))

    def open_reference_folder(self):
        ref_dir = self.project_root / "reference_library"
        ref_dir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(ref_dir)))

    def refresh_input_document(self, manual=False):
        result = self.documents.get_single_document()
        self.current_document = result.document
        self.document_error = result.error

        if result.error:
            self.document_name_label.setText(f"⚠ {result.error}")
            self.document_meta_label.setText(
                "지원 형식: PDF / DOCX / PPTX / XLSX / XLSM  ·  sample_inputs에서 1개만 input으로 복사"
            )
            self.analyze_button.setEnabled(True)
            if manual:
                self.status_label.setText(f"새로고침 완료 · {result.error}")
            return False

        doc = result.document
        self.document_name_label.setText(f"✓ {doc.name}")
        self.document_meta_label.setText(
            f"형식: {doc.suffix.upper().lstrip('.')}   ·   크기: {self.documents.format_size(doc.stat().st_size)}"
        )
        self.analyze_button.setEnabled(True)
        if manual:
            self.status_label.setText(f"새로고침 완료 · 분석 준비: {doc.name}")
        return True

    def manual_refresh_input_document(self):
        self.refresh_input_document(manual=True)

    def clear_connection_result(self):
        self.connection_result_box.clear()
        self.status_label.setText("Connection Result 지움")

    def open_output_folder(self):
        self.result_exporter.output_dir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(self.result_exporter.output_dir))
        )

    def export_analysis_result(self):
        if not self.last_analysis_text or not self.last_analysis_document:
            QMessageBox.warning(
                self,
                "저장할 분석 결과 없음",
                "먼저 문서 분석을 완료해주세요.",
            )
            return

        try:
            out_path = self.result_exporter.export_docx(
                self.last_analysis_document,
                self.last_analysis_text,
                model=self.client.model,
                api_base=self.client.api_base,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "분석 결과 문서 저장 실패",
                str(exc),
            )
            self.status_label.setText("분석 결과 문서 저장 실패")
            return

        self.status_label.setText(f"분석 결과 문서 저장 완료 · {out_path.name}")
        QMessageBox.information(
            self,
            "분석 결과 문서 저장 완료",
            f"다음 위치에 저장했습니다.\n\n{out_path}",
        )

    def run_document_analysis(self):
        self.refresh_input_document()
        if not self.current_document:
            message = self.document_error or "input 폴더에 지원 문서 1개만 넣어주세요."
            self.response_box.setPlainText(
                "문서 분석을 시작할 수 없습니다.\n\n"
                f"{message}\n\n"
                "사용 방법:\n"
                "1. [샘플 폴더 열기]에서 샘플 1개를 선택합니다.\n"
                "2. 해당 파일 1개만 input 폴더로 복사합니다.\n"
                "3. [새로고침] 후 [문서 분석]을 누릅니다."
            )
            self.status_label.setText("문서 분석 대기 · input 상태 확인 필요")
            QMessageBox.warning(self, "문서 분석 준비 필요", message)
            return

        document = self.current_document
        self.pending_analysis_document = document
        self._set_busy(True, f"{document.name} 분석 중...")
        self.response_box.setPlainText(
            f"{document.name}\n\nALIRA가 문서를 분석하고 있습니다...\n"
        )

        worker = TaskWorker(lambda: self.client.analyze_document(document))
        worker.signals.success.connect(self._on_analysis_success)
        worker.signals.error.connect(self._on_analysis_error)
        worker.signals.finished.connect(lambda: self._set_busy(False))
        self.thread_pool.start(worker)

    def run_requirement_extraction(self):
        self.refresh_input_document()
        if not self.current_document:
            message = self.document_error or "input 폴더에 지원 문서 1개만 넣어주세요."
            QMessageBox.warning(self, "요구사항 추출 준비 필요", message)
            self.status_label.setText("요구사항 추출 대기 · input 상태 확인 필요")
            return

        document = self.current_document
        self.pending_requirement_document = document
        self._set_busy(True, f"{document.name} 요구사항 추출 중...")
        self.result_tabs.setCurrentIndex(1)
        self.requirement_result_box.setPlainText(
            f"{document.name}\n\n"
            "ALIRA가 판단 원칙 + Reference Examples를 참고하여 "
            "원본 문서에서 Requirement Candidate를 추출하고 있습니다...\n\n"
            "※ Reference는 구조/패턴 참고용이며 원본 문서가 사실 기준입니다."
        )

        worker = TaskWorker(lambda: self.client.extract_requirements(document))
        worker.signals.success.connect(self._on_requirement_success)
        worker.signals.error.connect(self._on_requirement_error)
        worker.signals.finished.connect(lambda: self._set_busy(False))
        self.thread_pool.start(worker)

    def _on_requirement_success(self, text):
        try:
            data = self.requirement_engine.extract_json(text)
            evaluation = self.requirement_engine.evaluate_structure(data)
            saved_path = self.requirement_engine.save_result(
                self.pending_requirement_document,
                data,
            )
        except Exception as exc:
            self.requirement_result_box.setPlainText(
                "요구사항 추출 응답은 수신했지만 Canonical JSON 처리에 실패했습니다.\n\n"
                f"{exc}\n\n"
                "=== Raw ALIRA Response ===\n"
                f"{text}"
            )
            self.status_label.setText("요구사항 추출 결과 처리 실패")
            return

        self.last_requirement_data = data
        self.last_requirement_evaluation = evaluation
        self.requirement_result_box.setPlainText(
            self.requirement_engine.format_for_display(
                data,
                evaluation,
                saved_path,
            )
        )
        self.status_label.setText(
            f"요구사항 추출 완료 · {len(data.get('requirements', []))}개 후보 · "
            f"구조점수 {evaluation['structure_score']}/100"
        )

    def _on_requirement_error(self, error_text):
        self.requirement_result_box.setPlainText(error_text)
        self.status_label.setText("요구사항 추출 실패")

    # -----------------------------------------------------------------
    # Busy / callback
    # -----------------------------------------------------------------
    def _sync_button_states(self):
        self.test_button.setEnabled(
            not self.operation_busy and not self.connection_test_running
        )
        self.open_input_button.setEnabled(not self.operation_busy)
        self.open_sample_button.setEnabled(not self.operation_busy)
        self.refresh_button.setEnabled(not self.operation_busy)
        self.policy_button.setEnabled(not self.operation_busy)
        self.analyze_button.setEnabled(not self.operation_busy)
        self.extract_button.setEnabled(not self.operation_busy)
        self.open_reference_button.setEnabled(not self.operation_busy)
        self.open_policy_button.setEnabled(not self.operation_busy)
        self.open_output_button.setEnabled(not self.operation_busy)
        self.export_result_button.setEnabled(
            not self.operation_busy and bool(self.last_analysis_text)
        )

        if self.operation_busy:
            self.progress_label.setText("Processing...")
        elif self.connection_test_running:
            self.progress_label.setText("ALIRA 연결 확인 중...")
        else:
            self.progress_label.setText("")

    def _set_busy(self, busy, status_text=None):
        self.operation_busy = busy
        self._sync_button_states()
        if status_text:
            self.status_label.setText(status_text)

    def _on_analysis_success(self, text):
        self.response_box.setPlainText(text)
        self.last_analysis_text = text
        self.last_analysis_document = self.pending_analysis_document
        self.export_result_button.setEnabled(True)
        self.status_label.setText("문서 분석 완료 · 결과 문서 저장 가능")

    def _on_analysis_error(self, error_text):
        self.response_box.setPlainText(error_text)
        self.pending_analysis_document = None
        self.pending_requirement_document = None
        self.last_requirement_data = None
        self.last_requirement_evaluation = None
        self.status_label.setText("문서 분석 실패")


def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))

    icon_path = Path(__file__).resolve().parent / "assets" / "ALIRA.ico"
    if icon_path.is_file():
        app.setWindowIcon(QIcon(str(icon_path)))

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
