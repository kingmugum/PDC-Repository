# ALIRA Requirement Studio v0.15

v0.15는 사용자 실제 화면에서 확인된 두 가지 Connection UI 문제를 수정한 Bugfix Baseline입니다.

## 1. `ALIRA 연결 확인 중... (100%)` 고정 문제

원인은 비동기 Connection 진행률과 최종 Success 상태가 서로 다른 Callback으로 전달되면서,
마지막 Progress Event가 최종 Connected 표시를 덮어쓸 수 있고 Worker lifecycle도 명시적으로 보존되지 않았던 점입니다.

v0.15은 다음처럼 분리합니다.

```text
Progress Callback : 최대 99%
Success Callback  : 100% + 초록 LED + ALIRA 정상 연결됨
Error Callback    : 빨간 LED + ALIRA 연결 안 됨
```

Connection Worker도 MainWindow가 종료까지 강한 참조로 유지합니다.

## 2. [+] 상세 화면 잘림/겹침 문제

v0.14에서는 Connection 상세가 기본 hidden 상태에서 생성되고,
고정된 창 높이 안에 상세 정보/버튼/로그가 추가되면서 Qt가 자식 위젯을 과도하게 압축할 수 있었습니다.

v0.15:

- 상세 Layout minimum size 보장
- Connection Result 최소 높이 92px
- [+] 후 sizeHint 재계산
- 사용 가능한 화면 높이 범위에서 필요한 만큼만 창 높이 확대
- [−] 시 기존 창 높이 복원

## 사용자 확인 포인트

1. 앱 시작 후 `ALIRA 연결 확인 중... (99%)` 이후 초록색 `ALIRA 정상 연결됨 (100%)`으로 바뀌는지
2. [+] 클릭 후 실행파일 / Model / API Base / 연결 테스트 / 결과 지우기 / Connection Result가 모두 정상 표시되는지
3. [−] 클릭 후 기존 높이로 복귀하는지

실제 Windows/DPI Runtime은 사용자 환경에서 확인이 필요합니다.
