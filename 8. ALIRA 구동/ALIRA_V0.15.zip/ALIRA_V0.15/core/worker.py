from PySide6.QtCore import QObject, QRunnable, Signal, Slot


class WorkerSignals(QObject):
    success = Signal(str)
    error = Signal(str)
    finished = Signal()


class TaskWorker(QRunnable):
    def __init__(self, task):
        super().__init__()
        self.task = task
        self.signals = WorkerSignals()

    @Slot()
    def run(self):
        try:
            result = self.task()
            self.signals.success.emit(str(result))
        except Exception as exc:
            self.signals.error.emit(str(exc))
        finally:
            self.signals.finished.emit()


class ConnectionWorkerSignals(QObject):
    progress = Signal(int, str)
    success = Signal(str)
    error = Signal(str)
    finished = Signal()


class ConnectionTestWorker(QRunnable):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.signals = ConnectionWorkerSignals()

    @Slot()
    def run(self):
        try:
            result = self.client.test_connection(
                progress_callback=lambda percent, message: self.signals.progress.emit(
                    int(percent), str(message)
                )
            )
            self.signals.success.emit(str(result))
        except Exception as exc:
            self.signals.error.emit(str(exc))
        finally:
            self.signals.finished.emit()
